/*	$RCSfile: MemMap.h $				*/
/*	$Date: 2015/xx/xx 11:56:23JST $		*/
/*	$Revision: 1.1 $					*/
/*	 EXPLANATION:MemMap.h�_�~�[�t�@�C��	*/

#ifndef MEM_MAP_INC
#define MEM_MAP_INC


#endif	/* MEM_MAP_INC */
