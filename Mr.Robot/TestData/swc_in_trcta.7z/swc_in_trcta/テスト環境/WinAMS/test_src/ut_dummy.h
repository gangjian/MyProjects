/*
	dummy.h
*/

#ifndef UT_DUMMY
#define UT_DUMMY

#ifndef UT_DUMMY_DEF
#define UT_DUMMY_EXT extern
#else
#define UT_DUMMY_EXT
#endif

/*------------------------------------------------------------------------------*/
/*	�P�̃e�X�g�p�ݒ�															*/
/*------------------------------------------------------------------------------*/
#include "Platform_Types.h"
#include "Compiler_Cfg.h"
#include "Compiler.h"

#include "Rte_swc_in_trcta.h"
#include "share_lib_can_in_step.h"


#endif	/* UT_DUMMY */

/*
	* $History: $
	* $NoKeywords: $
*/
