/** \file
 *
 * \brief Generated file for Rte
 *
 * 
 *
 * \b Application:        Rte \n
 * \b Target:             see Rte.h for details \n
 * \b Compiler:           see Rte.h for details \n
 * \b Autosar-Vendor-ID:  41 \n
 *
 * \b Module:             Rte_swc_cd_sound.h \n
 * \b Generator:          Picea Rte V4.9.0-Delivery-Build275 \n
 *
 *      NOTE! This file is generated. Do not edit!
 *
 * \b Changeable-by-user: No \n
 * \b Delivery-File:      No \n
 *
 * \b Module-Owner:       Mecel Picea Team \n
 * \b Location:           Mecel \n
 * \b Phone:              +46 31 720 44 00 \n
 * \b E-Mail:             picea(at)mecel.se \n
 * \b Web:                http://bugzilla.mecel.se/ \n
 *
 * \b Traceability-Info   PICEA* \n
 * \b Classification:     Not classified \n
 * \b Deviations:         See PICEA_RTE_USG_003 \n
 *
 */

/*============================================================================*
 *
 * Copyright 2012 Mecel AB and Delphi Technologies, Inc., All Rights Reserved
 *
 *============================================================================*/
#ifndef RTE_SWC_CD_SOUND_H
#define RTE_SWC_CD_SOUND_H

#ifndef RTE_CORE
#ifdef RTE_APPLICATION_HEADER_FILE
#error Multiple application header files included.
#endif /* RTE_APPLICATION_HEADER_FILE */
#define RTE_APPLICATION_HEADER_FILE
#endif /* RTE_CORE */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/
/* PRQA S 777 ++
   Variable names are (partly) defined by user in SWC configuration.
*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte_swc_cd_sound_Type.h"
#include "Rte_DataHandleType.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_SWC_CD_SOUND_SW_MAJOR_VERSION (4u)
#define RTE_SWC_CD_SOUND_SW_MINOR_VERSION (9u)
#define RTE_SWC_CD_SOUND_SW_PATCH_VERSION (0u)

#ifndef RTE_CORE
/* Application errors --------------------------------------------------------*/

/* Init values ---------------------------------------------------------------*/

/* API Mapping ---------------------------------------------------------------*/
#define Rte_Call_rp_csIf_common_appStandbyChk_op Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op
#define Rte_Call_rp_csIf_nv_readNvData_op Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op

/* Port handle API Mapping ---------------------------------------------------*/
#endif

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

/* PDS/CDS local data types --------------------------------------------------*/

/* Port Data Structures (PDS) ------------------------------------------------*/

/* Component Data Structure (CDS) --------------------------------------------*/
struct Rte_CDS_swc_cd_sound
{
   /* Data Handles section. -----------------------*/
   /* Per-instance Memory Handles section. --------*/
   /* Inter-runnable Variable Handles section. ----*/
   /* Calibration Parameter Handles section. ------*/
   /* Exclusive-area API section. -----------------*/
   /* Port API section. ---------------------------*/
   /* Inter Runnable Variable API section. --------*/
   /* Inter Runnable Triggering API section. ------*/
   /* Vendor specific section. --------------------*/
   uint8 _dummy;
};

#ifndef RTE_CORE
/* Port handle types ---------------------------------------------------------*/

/* Pim types -----------------------------------------------------------------*/

/* Instance handle type ------------------------------------------------------*/
typedef P2CONST(struct Rte_CDS_swc_cd_sound, TYPEDEF, RTE_CONST) Rte_Instance;
#endif

/*============================================================================*
 * EXPORTED OBJECT DECLARATIONS                                               *
 *============================================================================*/

#define RTE_START_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

extern CONSTP2CONST(struct Rte_CDS_swc_cd_sound, RTE_CONST, RTE_APPL_CONST) Rte_Inst_swc_cd_sound;

#define RTE_STOP_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

/*============================================================================*
 * EXPORTED FUNCTIONS PROTOTYPES                                              *
 *============================================================================*/
/* Declaration of runnable entities ------------------------------------------*/

#define swc_cd_sound_START_SEC_CODE
#include "swc_cd_sound_MemMap.h"

extern FUNC(void, swc_cd_sound_CODE) sym_rbl_cd_sound(void);
extern FUNC(void, swc_cd_sound_CODE) sym_rbl_cd_sound_operation_InitSoundDrv(void);
extern FUNC(void, swc_cd_sound_CODE) sym_rbl_cd_sound_operation_StartSoundDrv(void);
extern FUNC(void, swc_cd_sound_CODE) sym_rbl_cd_sound_operation_StopSoundDrv(void);
extern FUNC(void, swc_cd_sound_CODE) sym_rbl_cd_sound_operation_bzOff(uint8 offdevice);
extern FUNC(void, swc_cd_sound_CODE) sym_rbl_cd_sound_operation_bzOn(uint8 ondevice, uint8 frqcy, uint8 press, uint8 attn, uint8 patten);
extern FUNC(void, swc_cd_sound_CODE) sym_rbl_cd_sound_preStandby(void);

#define swc_cd_sound_STOP_SEC_CODE
#include "swc_cd_sound_MemMap.h"


#define RTE_START_SEC_CODE
#include "MemMap.h"

/* Declaration of API functions ----------------------------------------------*/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op(uint8 id, uint8 chk);
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op(uint16 id, P2VAR(void, AUTOMATIC, RTE_APPL_DATA) data, P2VAR(uint8, AUTOMATIC, RTE_APPL_DATA) nvReadSts);

#define RTE_STOP_SEC_CODE
#include "MemMap.h"

/* PRQA S 777 -- */

#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* RTE_SWC_CD_SOUND_H */
