/** \file
 *
 * \brief Generated file for Rte
 *
 * 
 *
 * \b Application:        Rte \n
 * \b Target:             see Rte.h for details \n
 * \b Compiler:           see Rte.h for details \n
 * \b Autosar-Vendor-ID:  41 \n
 *
 * \b Module:             Rte_swc_cd_sound_Type.h \n
 * \b Generator:          Picea Rte V4.9.0-Delivery-Build275 \n
 *
 *      NOTE! This file is generated. Do not edit!
 *
 * \b Changeable-by-user: No \n
 * \b Delivery-File:      No \n
 *
 * \b Module-Owner:       Mecel Picea Team \n
 * \b Location:           Mecel \n
 * \b Phone:              +46 31 720 44 00 \n
 * \b E-Mail:             picea(at)mecel.se \n
 * \b Web:                http://bugzilla.mecel.se/ \n
 *
 * \b Traceability-Info   PICEA* \n
 * \b Classification:     Not classified \n
 * \b Deviations:         See PICEA_RTE_USG_003 \n
 *
 */

/*============================================================================*
 *
 * Copyright 2012 Mecel AB and Delphi Technologies, Inc., All Rights Reserved
 *
 *============================================================================*/
#ifndef RTE_SWC_CD_SOUND_TYPE_H
#define RTE_SWC_CD_SOUND_TYPE_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte_Type.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_SWC_CD_SOUND_TYPE_SW_MAJOR_VERSION (4u)
#define RTE_SWC_CD_SOUND_TYPE_SW_MINOR_VERSION (9u)
#define RTE_SWC_CD_SOUND_TYPE_SW_PATCH_VERSION (0u)

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

/* Mode Declaration Groups ---------------------------------------------------*/
#ifndef RTE_MODETYPE_STANDBY
#define RTE_MODETYPE_STANDBY
typedef uint8 Rte_ModeType_STANDBY;
#endif
#ifndef RTE_MODE_STANDBY_SLP_NG
#define RTE_MODE_STANDBY_SLP_NG 0U
#endif
#ifndef RTE_MODE_STANDBY_SLP_OK
#define RTE_MODE_STANDBY_SLP_OK 1U
#endif
#ifndef RTE_TRANSITION_STANDBY
#define RTE_TRANSITION_STANDBY 2U
#endif


/* Enumeration Data Types ----------------------------------------------------*/
#ifndef NV_ID_EEP_P4D_B0_DATA
#define NV_ID_EEP_P4D_B0_DATA ((uint16) 0U)
#endif /* NV_ID_EEP_P4D_B0_DATA */

#ifndef NV_ID_NUM
#define NV_ID_NUM ((uint16) 1U)
#endif /* NV_ID_NUM */

#ifndef NV_READ_SUCCESS
#define NV_READ_SUCCESS ((uint8) 0U)
#endif /* NV_READ_SUCCESS */

#ifndef NV_READ_FAIL
#define NV_READ_FAIL ((uint8) 16U)
#endif /* NV_READ_FAIL */

#ifndef NV_READ_NOTACCEPT
#define NV_READ_NOTACCEPT ((uint8) 17U)
#endif /* NV_READ_NOTACCEPT */

#ifndef NV_READ_INVALID
#define NV_READ_INVALID ((uint8) 255U)
#endif /* NV_READ_INVALID */

#ifndef STANDBY_CHK_SLEEP_OK
#define STANDBY_CHK_SLEEP_OK ((uint8) 0U)
#endif /* STANDBY_CHK_SLEEP_OK */

#ifndef STANDBY_CHK_SLEEP_NG
#define STANDBY_CHK_SLEEP_NG ((uint8) 1U)
#endif /* STANDBY_CHK_SLEEP_NG */

#ifndef SLP_ID_CD_BZ
#define SLP_ID_CD_BZ ((uint8) 0U)
#endif /* SLP_ID_CD_BZ */

#ifndef SLP_ID_NUM
#define SLP_ID_NUM ((uint8) 1U)
#endif /* SLP_ID_NUM */

#ifndef SOUND_OUT_BZ
#define SOUND_OUT_BZ ((uint8) 0U)
#endif /* SOUND_OUT_BZ */

#ifndef SOUND_OUT_NUM
#define SOUND_OUT_NUM ((uint8) 1U)
#endif /* SOUND_OUT_NUM */

#ifndef SOUNDDRV_ATTENUATION_ON
#define SOUNDDRV_ATTENUATION_ON ((uint8) 0U)
#endif /* SOUNDDRV_ATTENUATION_ON */

#ifndef SOUNDDRV_ATTENUATION_ON2
#define SOUNDDRV_ATTENUATION_ON2 ((uint8) 1U)
#endif /* SOUNDDRV_ATTENUATION_ON2 */

#ifndef SOUNDDRV_ATTENUATION_NUM
#define SOUNDDRV_ATTENUATION_NUM ((uint8) 2U)
#endif /* SOUNDDRV_ATTENUATION_NUM */

#ifndef SOUNDDRV_ATTENUATION_OFF
#define SOUNDDRV_ATTENUATION_OFF ((uint8) 3U)
#endif /* SOUNDDRV_ATTENUATION_OFF */

#ifndef FRQCY_0
#define FRQCY_0 ((uint8) 0U)
#endif /* FRQCY_0 */

#ifndef SOUNDDRV_FLSH_PTN_00
#define SOUNDDRV_FLSH_PTN_00 ((uint8) 0U)
#endif /* SOUNDDRV_FLSH_PTN_00 */

#ifndef SOUNDDRV_FLSH_PTN_01
#define SOUNDDRV_FLSH_PTN_01 ((uint8) 1U)
#endif /* SOUNDDRV_FLSH_PTN_01 */

#ifndef SOUNDDRV_FLSH_PTN_02
#define SOUNDDRV_FLSH_PTN_02 ((uint8) 2U)
#endif /* SOUNDDRV_FLSH_PTN_02 */

#ifndef SOUNDDRV_FLSH_PTN_03
#define SOUNDDRV_FLSH_PTN_03 ((uint8) 3U)
#endif /* SOUNDDRV_FLSH_PTN_03 */

#ifndef SOUNDDRV_FLSH_PTN_04
#define SOUNDDRV_FLSH_PTN_04 ((uint8) 4U)
#endif /* SOUNDDRV_FLSH_PTN_04 */

#ifndef SOUNDDRV_FLSH_PTN_05
#define SOUNDDRV_FLSH_PTN_05 ((uint8) 5U)
#endif /* SOUNDDRV_FLSH_PTN_05 */

#ifndef SOUNDDRV_FLSH_PTN_06
#define SOUNDDRV_FLSH_PTN_06 ((uint8) 6U)
#endif /* SOUNDDRV_FLSH_PTN_06 */

#ifndef SOUNDDRV_FLSH_PTN_07
#define SOUNDDRV_FLSH_PTN_07 ((uint8) 7U)
#endif /* SOUNDDRV_FLSH_PTN_07 */

#ifndef SOUNDDRV_FLSH_PTN_08
#define SOUNDDRV_FLSH_PTN_08 ((uint8) 8U)
#endif /* SOUNDDRV_FLSH_PTN_08 */

#ifndef SOUNDDRV_FLSH_PTN_09
#define SOUNDDRV_FLSH_PTN_09 ((uint8) 9U)
#endif /* SOUNDDRV_FLSH_PTN_09 */

#ifndef SOUNDDRV_FLSH_PTN_10
#define SOUNDDRV_FLSH_PTN_10 ((uint8) 10U)
#endif /* SOUNDDRV_FLSH_PTN_10 */

#ifndef SOUNDDRV_FLSH_PTN_11
#define SOUNDDRV_FLSH_PTN_11 ((uint8) 11U)
#endif /* SOUNDDRV_FLSH_PTN_11 */

#ifndef SOUNDDRV_FLSH_PTN_12
#define SOUNDDRV_FLSH_PTN_12 ((uint8) 12U)
#endif /* SOUNDDRV_FLSH_PTN_12 */

#ifndef SOUNDDRV_FLSH_PTN_13
#define SOUNDDRV_FLSH_PTN_13 ((uint8) 13U)
#endif /* SOUNDDRV_FLSH_PTN_13 */

#ifndef SOUNDDRV_FLSH_PTN_14
#define SOUNDDRV_FLSH_PTN_14 ((uint8) 14U)
#endif /* SOUNDDRV_FLSH_PTN_14 */

#ifndef SOUNDDRV_FLSH_PTN_15
#define SOUNDDRV_FLSH_PTN_15 ((uint8) 15U)
#endif /* SOUNDDRV_FLSH_PTN_15 */

#ifndef SOUNDDRV_FLSH_PTN_16
#define SOUNDDRV_FLSH_PTN_16 ((uint8) 16U)
#endif /* SOUNDDRV_FLSH_PTN_16 */

#ifndef SOUNDDRV_FLSH_PTN_17
#define SOUNDDRV_FLSH_PTN_17 ((uint8) 17U)
#endif /* SOUNDDRV_FLSH_PTN_17 */

#ifndef SOUNDDRV_FLSH_PTN_NUM
#define SOUNDDRV_FLSH_PTN_NUM ((uint8) 18U)
#endif /* SOUNDDRV_FLSH_PTN_NUM */

#ifndef SOUNDDRV_FLSH_PTN_NORMAL_BZ
#define SOUNDDRV_FLSH_PTN_NORMAL_BZ ((uint8) 19U)
#endif /* SOUNDDRV_FLSH_PTN_NORMAL_BZ */

#ifndef PRESS_0
#define PRESS_0 ((uint8) 0U)
#endif /* PRESS_0 */


/* Limits of Range Data Types  -----------------------------------------------*/
#ifndef RTE_CORE

#define common_nvId_LowerLimit ((uint16) 0U)
#define common_nvId_UpperLimit ((uint16) 65535U)

#define common_nvReadSts_LowerLimit ((uint8) 0U)
#define common_nvReadSts_UpperLimit ((uint8) 255U)

#define common_appStandbyChk_LowerLimit ((uint8) 0U)
#define common_appStandbyChk_UpperLimit ((uint8) 255U)

#define common_appStandbyId_LowerLimit ((uint8) 0U)
#define common_appStandbyId_UpperLimit ((uint8) 255U)

#define out_offdevice_LowerLimit ((uint8) 0U)
#define out_offdevice_UpperLimit ((uint8) 255U)

#define out_attn_LowerLimit ((uint8) 0U)
#define out_attn_UpperLimit ((uint8) 255U)

#define out_frqcy_LowerLimit ((uint8) 0U)
#define out_frqcy_UpperLimit ((uint8) 255U)

#define out_ondevice_LowerLimit ((uint8) 0U)
#define out_ondevice_UpperLimit ((uint8) 255U)

#define out_patten_LowerLimit ((uint8) 0U)
#define out_patten_UpperLimit ((uint8) 255U)

#define out_press_LowerLimit ((uint8) 0U)
#define out_press_UpperLimit ((uint8) 255U)

#endif /* RTE_CORE */

#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* RTE_SWC_CD_SOUND_TYPE_H */
