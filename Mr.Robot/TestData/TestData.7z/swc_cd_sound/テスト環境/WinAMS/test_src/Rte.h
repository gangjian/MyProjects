/*	$RCSfile: Rte.h $						*/
/*	$Date: 2015/xx/xx 12:00:00JST $			*/
/*	$Revision: 1.1 $						*/
/*	 EXPLANATION: Rte.h�_�~�[�w�b�_�t�@�C��	*/

#ifndef RTE_INC
#define RTE_INC

#include "Std_Types.h"
#include "Swc_custom.h"

#endif	/*	RTE_INC	*/

