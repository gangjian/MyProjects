/*
	Dummy.c
*/
/*------------------------------------------------------------------------------*/
/*	�C���N���[�h�t�@�C��														*/
/*------------------------------------------------------------------------------*/
#include "ut_dummy.h"

uint32 _udivi;
/*------------------------------------------------------------------------------*/
/*	�_�~�[�֐�																	*/
/*------------------------------------------------------------------------------*/

/* g10,s06 */
static uint8 dmy_Gpt_EnableNotification_Cnt;
static uint8 dmy_Gpt_EnableNotification_ch;
void Gpt_EnableNotification(uint8 ch)
{
	dmy_Gpt_EnableNotification_Cnt++;
	dmy_Gpt_EnableNotification_ch = ch;
}

/* g10,s06 */
static uint8 dmy_Gpt_StartTimer_Cnt;
static uint8 dmy_Gpt_StartTimer_ch;
static uint32 dmy_Gpt_StartTimer_tmr;
void Gpt_StartTimer(uint8 ch, uint32 tmr)
{
	dmy_Gpt_StartTimer_Cnt++;
	dmy_Gpt_StartTimer_ch = ch;
	dmy_Gpt_StartTimer_tmr = tmr;
}


/* g11 */
static uint8 dmy_Gpt_DisableNotification_Cnt;
static uint8 dmy_Gpt_DisableNotification_ch;
void Gpt_DisableNotification(uint8 ch)
{
	dmy_Gpt_DisableNotification_Cnt++;
	dmy_Gpt_DisableNotification_ch = ch;
}

/* g11 */
static uint8 dmy_Gpt_StopTimer_Cnt;
static uint8 dmy_Gpt_StopTimer_ch;
void Gpt_StopTimer(uint8 ch)
{
	dmy_Gpt_StopTimer_Cnt++;
	dmy_Gpt_StopTimer_ch = ch;
}


/* s01 */
static uint8 dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_Cnt;
static Std_ReturnType dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_Ret;
static uint8 dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_id;
static uint8 dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_chk;
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op(uint8 id, uint8 chk)
{
	dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_Cnt++;
	dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_id = id;
	dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_chk = chk;
	return dmy_Rte_Call_swc_cd_sound_rp_csIf_common_appStandbyChk_op_Ret;
}


/* s05 */
static uint8 dmy_Pwm_DisableNotification_Cnt;
static uint8 dmy_Pwm_DisableNotification_ch;
void Pwm_DisableNotification(uint8 ch)
{
	dmy_Pwm_DisableNotification_Cnt++;
	dmy_Pwm_DisableNotification_ch = ch;
}

/* s05 */
static uint8 dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_Cnt;
static uint8 dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_ch;
static uint32 dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_freq;
static uint16 dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_pressure;
void Dmyfunc_SOUNDDRV_SG_SET_SINGLE_SOUND(uint8 ch, uint32 freq, uint16 pressure)
{
	dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_Cnt++;
	dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_ch = ch;
	dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_freq = freq;
	dmy_SOUNDDRV_SG_SET_SINGLE_SOUND_pressure = pressure;
}

/* s05 */
static uint8 dmy_WeightAvgByte_Cnt;
static uint8 dmy_WeightAvgByte_goal;
static uint16 dmy_WeightAvgByte_pressSigma;
static uint8 dmy_WeightAvgByte_val;
static uint8 dmy_WeightAvgByte_ret;
uint8 WeightAvgByte(uint8 goal, uint16* pressSigma, uint8 val)
{
	dmy_WeightAvgByte_Cnt++;
	dmy_WeightAvgByte_goal = goal;
	*pressSigma = dmy_WeightAvgByte_pressSigma;
	dmy_WeightAvgByte_val = val;
	return dmy_WeightAvgByte_ret;
}

/* s07, s18 */
static uint8 dmy_Pwm_SetDutyCycle_Cnt;
static uint8 dmy_Pwm_SetDutyCycle_ch;
static uint16 dmy_Pwm_SetDutyCycle_val;
void Pwm_SetDutyCycle(uint8 ch, uint16 val)
{
	dmy_Pwm_SetDutyCycle_Cnt++;
	dmy_Pwm_SetDutyCycle_ch = ch;
	dmy_Pwm_SetDutyCycle_val = val;
}


/* s06 */
static uint8 dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_Cnt;
static uint8 dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_ch;
static SOUNDDRV_MULTI_SOUND_TBL_SP	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_sound;
static SOUNDDRV_PPG_CALLBACK		dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_cbk;
void Dmyfunc_SOUNDDRV_PPG_SET_MULTI_SOUND_SP(uint8 ch, SOUNDDRV_MULTI_SOUND_TBL_SP *sound, SOUNDDRV_PPG_CALLBACK	cbk)
{
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_Cnt++;
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_ch = ch;
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_sound.spFreq = sound->spFreq;
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_sound.spDuty = sound->spDuty;
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_sound.spTmr = sound->spTmr;
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_sound.spCycle = sound->spCycle;
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_sound.spNext = sound->spNext;
	dmy_SOUNDDRV_PPG_SET_MULTI_SOUND_SP_cbk = cbk;
}


/* s07 */
static uint8 dmy_SOUNDDRV_SG_STOP_Cnt;
static uint8 dmy_SOUNDDRV_SG_STOP_ch;
void Dmyfunc_SOUNDDRV_SG_STOP(uint8 ch)
{
	dmy_SOUNDDRV_SG_STOP_Cnt++;
	dmy_SOUNDDRV_SG_STOP_ch = ch;
}

/* s14, s15 */
static uint8 dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_Cnt;
static uint16 dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_id[4];
static uint8 dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_data[4];
static uint8 dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_nvReadSts[4];
static Std_ReturnType dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_Ret[4];
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op(
							uint16 id, P2VAR(void, AUTOMATIC, RTE_APPL_DATA) data,
							P2VAR(uint8, AUTOMATIC, RTE_APPL_DATA) nvReadSts)
{
	uint8 idx;
	dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_Cnt++;
	idx = dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_Cnt - 1;

	dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_id[idx] = id;
	*((uint8 *)data) = dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_data[idx];
	*nvReadSts = dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_nvReadSts[idx];

	return dmy_Rte_Call_swc_cd_sound_rp_csIf_nv_readNvData_op_Ret[idx];
}

/* s17 */
static uint8 dmy_Pwm_EnableNotification_Cnt;
static uint8 dmy_Pwm_EnableNotification_ch;
static uint16 dmy_Pwm_EnableNotification_val;
void Pwm_EnableNotification(uint8 ch, uint16 val)
{
	dmy_Pwm_EnableNotification_Cnt++;
	dmy_Pwm_EnableNotification_ch = ch;
	dmy_Pwm_EnableNotification_val = val;
}

/* s05, s17 */
static uint8 dmy_Pwm_SetPeriodAndDuty_Cnt;
static uint8 dmy_Pwm_SetPeriodAndDuty_ch;
static uint32 dmy_Pwm_SetPeriodAndDuty_freq;
static uint16 dmy_Pwm_SetPeriodAndDuty_duty;
void Pwm_SetPeriodAndDuty( uint8 ch, uint32 freq, uint16 duty )
{
	dmy_Pwm_SetPeriodAndDuty_Cnt++;
	dmy_Pwm_SetPeriodAndDuty_ch = ch;
	dmy_Pwm_SetPeriodAndDuty_freq = freq;
	dmy_Pwm_SetPeriodAndDuty_duty = duty;
}

/* s17 */
static uint8 dmy_callBackFunc_Cnt;
void dmy_callBackFunc(void)
{
	dmy_callBackFunc_Cnt++;
}

SOUNDDRV_MULTI_SOUND_TBL_BZ dmy_BzTbl[3];
SOUNDDRV_MULTI_SOUND_TBL_SP dmy_SpTbl[3];

void ISR_NATIVE(uint8 a){}
void ISR(uint8 a){}


