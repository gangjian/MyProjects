/*
 * :AMSTB_SrcFile.c
 * : BSW�P�̃e�X�g�p
 */
#define WINAMS_STUB
#ifdef WINAMS_STUB
#ifdef __cplusplus
extern "C" {
#endif
#include "Platform_Types.h"
#include "Rte_swc_cd_sound_Type.h"


/*------------------------------------------------------------------------------*/
/*   �X�^�u�֐�                                                                 */
/*------------------------------------------------------------------------------*/

/* g01 */
static uint8 stb_speakerOnCtrl_Cnt;
void AMSTB_speakerOnCtrl(void){
	stb_speakerOnCtrl_Cnt++;
}

/* g01 */
static uint8 stb_soundOutReqCtrl_Cnt;
static uint8 stb_soundOutReqCtrl_devIdx;
void AMSTB_soundOutReqCtrl(const uint8 devIdx){
	stb_soundOutReqCtrl_Cnt++;
	stb_soundOutReqCtrl_devIdx = devIdx;
}

/* g01 */
static uint8 stb_getReq_Cnt;
static uint8 stb_getReq_devIdx;
void AMSTB_getReq(const uint8 devIdx){
	stb_getReq_Cnt++;
	stb_getReq_devIdx = devIdx;
}

/* g01 */
static uint8 stb_speakerOffCtrl_Cnt;
void AMSTB_speakerOffCtrl(void){
	stb_speakerOffCtrl_Cnt++;
}

/* g01 */
static uint8 stb_chkStandbySoundDrv_Cnt;
void AMSTB_chkStandbySoundDrv(void){
	stb_chkStandbySoundDrv_Cnt++;
}

/* g02, g03, g04, g09 */
static uint8 stb_initSoundDrv_Cnt;
void AMSTB_initSoundDrv(void){
	stb_initSoundDrv_Cnt++;
}

/* g10, g11, s04 */
static uint8 stb_soundOff_Cnt;
static uint8 stb_soundOff_devIdx;
void AMSTB_soundOff(const uint8 devIdx){
	stb_soundOff_Cnt++;
	stb_soundOff_devIdx = devIdx;
}

/* g10 */
static uint8 stb_Intr_SoundDrv_TmrHook_Cnt;
static uint8 stb_Intr_SoundDrv_TmrHook_devIdx;
void AMSTB_Intr_SoundDrv_TmrHook(const uint8 devIdx){
	stb_Intr_SoundDrv_TmrHook_Cnt++;
	stb_Intr_SoundDrv_TmrHook_devIdx = devIdx;
}

/* g11,s04 */
static uint8 stb_multiSoundOn_Cnt;
static uint8 stb_multiSoundOn_devIdx;
void AMSTB_multiSoundOn(const uint8 devIdx){
	stb_multiSoundOn_Cnt++;
	stb_multiSoundOn_devIdx = devIdx;
}

/* g12 */
static uint8 stb_intrAtStateLimitedPulseOut_Cnt;
void AMSTB_intrAtStateLimitedPulseOut(void){
	stb_intrAtStateLimitedPulseOut_Cnt++;
}


/* s02 */
static uint8 stb_soundInit_Cnt;
static uint8 stb_soundInit_devIdx;
void AMSTB_soundInit(const uint8 devIdx)
{
	stb_soundInit_Cnt++;
	stb_soundInit_devIdx = devIdx;
}

/* s02, s09 */
static uint8 stb_setSpeakerVolumeData_Cnt;
void AMSTB_setSpeakerVolumeData(void)
{
	stb_setSpeakerVolumeData_Cnt++;
}

/* s02 */
static uint8 stb_initAttenuationConstant_Cnt;
void AMSTB_initAttenuationConstant(void)
{
	stb_initAttenuationConstant_Cnt++;
}

/* s04 */
static uint8 stb_singleSoundOn_Cnt;
static uint8 stb_singleSoundOn_devIdx;
void AMSTB_singleSoundOn(const uint8 devIdx){
	stb_singleSoundOn_Cnt++;
	stb_singleSoundOn_devIdx = devIdx;
}

typedef struct{
	uint8 reqFlag;																/*	�o�͗v���t���O							*/
	uint8 reqFreq;																/*	���g��(�P�ʁF100Hz)						*/
	uint8 reqPressure;															/*	����(0�`255)							*/
	uint8 reqAttnId;															/*	�����p�^�[��ID							*/
	uint8 reqFlasherId;															/*	�t���b�V���u�U�[���p�^�[��ID			*/
	uint8 reqUpdate;															/*	�o�͗v���X�V�L��						*/
}SOUNDDRV_REQ_BUFFER;


/* s09, s10 */
static uint8 stb_judgeSpeakerConnected_Cnt;
static uint8 stb_judgeSpeakerConnected_Ret;
uint8 AMSTB_judgeSpeakerConnected(void)
{
	stb_judgeSpeakerConnected_Cnt++;
	return stb_judgeSpeakerConnected_Ret;
}

/* s09 */
static uint8 stb_judgeSpeakerOn_Cnt;
static uint8 stb_judgeSpeakerOn_Ret;
uint8 AMSTB_judgeSpeakerOn(void)
{
	stb_judgeSpeakerOn_Cnt++;
	return stb_judgeSpeakerOn_Ret;
}

/* s09 */
static uint8 stb_speakerVolumeCtrl_Cnt;
void AMSTB_speakerVolumeCtrl(void)
{
	stb_speakerVolumeCtrl_Cnt++;
}


/* s06 */
static uint8 stb_setLimitedPulse_Cnt;
static uint32 stb_setLimitedPulse_pwmCh;
static uint16 stb_setLimitedPulse_pwmFreq;
static uint8 stb_setLimitedPulse_pwmDuty;
static uint8 stb_setLimitedPulse_pwmPulse;
static void(*stb_setLimitedPulse_callBackFunc)(void);
void AMSTB_setLimitedPulse(uint8 pwmCh, uint32 pwmFreq, uint16 pwmDuty, uint8 pwmPulse, void(*callBackFunc)(void))
{
	stb_setLimitedPulse_Cnt++;
	stb_setLimitedPulse_pwmCh = pwmCh;
	stb_setLimitedPulse_pwmFreq = pwmFreq;
	stb_setLimitedPulse_pwmDuty = pwmDuty;
	stb_setLimitedPulse_pwmPulse = pwmPulse;
	stb_setLimitedPulse_callBackFunc = callBackFunc;
}




#ifdef __cplusplus
}
#endif
#endif /* WINAMS_STUB */
