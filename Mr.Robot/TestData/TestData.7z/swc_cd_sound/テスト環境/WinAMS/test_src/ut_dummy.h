/*
	dummy.h
*/

#ifndef UT_DUMMY
#define UT_DUMMY

#ifndef UT_DUMMY_DEF
#define UT_DUMMY_EXT extern
#else
#define UT_DUMMY_EXT
#endif

/*------------------------------------------------------------------------------*/
/*	�P�̃e�X�g�p�ݒ�															*/
/*------------------------------------------------------------------------------*/
#include "Platform_Types.h"
#include "Compiler_Cfg.h"
#include "Compiler.h"

#include "bsw_common.h"
#include "Rte_swc_cd_sound_Type.h"
#include "Rte_swc_cd_sound_user.h"

#define RTE_CODE
typedef uint8  Std_ReturnType;
typedef void (*SOUNDDRV_PPG_CALLBACK)(void);

extern void Pwm_SetPeriodAndDuty(uint8 ch, uint32 freq, uint16 duty);
extern void Pwm_DisableNotification(uint8 ch);
extern void Dmyfunc_SOUNDDRV_SG_SET_SINGLE_SOUND(uint8 ch, uint32 freq, uint16 pressure);
extern void Pwm_SetDutyCycle(uint8, uint16);
extern void Dmyfunc_SOUNDDRV_SG_STOP(uint8 ch);

extern void Gpt_EnableNotification(uint8 ch);
extern void Gpt_StartTimer(uint8 ch, uint32 tmr);
extern void Gpt_DisableNotification(uint8 ch);

extern SOUNDDRV_MULTI_SOUND_TBL_BZ dmy_BzTbl[3];
extern SOUNDDRV_MULTI_SOUND_TBL_SP dmy_SpTbl[3];



#endif	/* UT_DUMMY */
