/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

#ifndef IMPSIM_COMMON_H_
#define IMPSIM_COMMON_H_

#include <stdarg.h>
#include <stddef.h>

#ifdef __GNUC__ 
// Nothing is needed for MinGW/gcc 
#define IMPSIM_EXPORT
#else // Assume Visual Studio
#ifdef IMPSIM_BUILD_DLL
// Building DLL on Visual Studio is not supported.
#define IMPSIM_EXPORT __declspec(dllexport)
#else
#define IMPSIM_EXPORT __declspec(dllimport)
#endif
#endif

// The following 3 typedef's are not defined in stdint.h
#ifndef NO_NEED_TYPEDEF_FOR_FLOAT32_ETC
typedef char char_t;
typedef float float32_t;
typedef double float64_t;
#endif

typedef void (*vfunc_t)(uint32_t sts);
typedef void (*vimrcb_t)(int32_t flgid, uint32_t sts);

#if defined(__GNUC_GNU_INLINE__)
#define INLINE_FUNCTION static inline
#else
#define INLINE_FUNCTION static
#endif

#ifdef HAVE_MATHF_H_
#       include <mathf.h>
#else
#       include <math.h>
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif


#ifndef MATH_PI
#define MATH_PI (3.141592653589793f)
#endif 

#define NEARLY_ZERO (1.0f/2048.0f/2048.0f)


#ifndef NO_NEED_TYPEDEF_FOR_MISC
/****************************************************************************/
/*							   type definition								*/
/****************************************************************************/
/* TBD */
typedef signed char		B;				/* signed 8 bit integer				*/
typedef signed short	H;				/* signed 16 bit integer			*/
typedef signed long		W;				/* signed 32 bit integer			*/

typedef unsigned char	UB;				/* unsigned 8 bit integer			*/
typedef unsigned short	UH;				/* unsigned 16 bit integer			*/
typedef unsigned long	UW;				/* unsigned 32 bit integer			*/

typedef B				VB;				/* variable data type (8 bit)		*/
typedef H				VH;				/* variable data type (16 bit)		*/
typedef W				VW;				/* variable data type (32 bit)		*/

typedef void			*VP;			/* pointer to variable data type	*/
typedef void			(*FP)(void);	/* program start address			*/

typedef int				INT;			/* signed integer (CPU dependent)	*/
typedef unsigned int	UINT;			/* unsigned integer (CPU dependent) */

typedef INT				BOOL;			/* Bool value						*/

typedef W				FN;				/* function code					*/
typedef W				ER;				/* error code						*/
typedef H				ID;				/* object ID (xxxid)				*/
typedef UW				ATR;			/* attribute						*/
typedef UW				STAT;			/* object status					*/
typedef UW				MODE;			/* action mode						*/
typedef H				PRI;			/* task priority					*/
// H.Shiota
// Commented out to avoid type conflict
//typedef UW				SIZE;			/* memory area size					*/

typedef W				TMO;			/* time out							*/
typedef UW				RELTIM;			/* relative time					*/
#endif

/****************************************************************************/
/*			Service call error code (Main error code)						*/
/****************************************************************************/
#define Error int

#define	E_OK			(0L)			/* normal end						*/
/*---- internal error class ----*/
#define E_SYS			(-5L)			/* system error						*/

/*---- no support error class ----*/
#define E_NOSPT			(-9L)			/* no support function				*/
#define E_RSFN			(-10L)			/* reserved function code number	*/
#define E_RSATR			(-11L)			/* reserved attribute code number	*/

/*---- parameter error class ----*/
#define E_PAR			(-17L)			/* parameter error					*/
#define E_ID			(-18L)			/* reserved id number				*/

/*---- context error class ----*/
#define E_CTX			(-25L)			/* context error					*/
#define E_MACV			(-26L)			/* memory access violation			*/
#define E_OACV			(-27L)			/* object access violation			*/
#define E_ILUSE			(-28L)			/* service call illegal use			*/

/*---- resource insufficiency error class ----*/
#define E_NOMEM			(-33L)			/* no memory						*/
#define E_NOID			(-34L)			/* no ID							*/

/*---- object status error class ----*/
#define E_OBJ			(-41L)			/* object status error				*/
#define E_NOEXS			(-42L)			/* object non existent				*/
#define E_QOVR			(-43L)			/* queuing over flow				*/

/*---- wait release error class ----*/
#define E_RLWAI			(-49L)			/* wait status forced release		*/
#define E_TMOUT			(-50L)			/* time out							*/
#define E_DLT			(-51L)			/* delete object					*/
#define E_CLS			(-52L)			/* status change of wait object		*/

/*---- warning class ----*/
#define E_WBLK			(-57L)			/* non blocking receipt				*/
#define E_BOVR			(-58L)			/* buffer over flow					*/

#define TRUE 1
#define FALSE 0

#endif /* IMPSIM_COMMON_H_ */
