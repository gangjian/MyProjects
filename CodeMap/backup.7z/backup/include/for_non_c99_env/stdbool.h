/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2015      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/*
  This header file is for an environtment does not have stdbool.h.
  One example of the case is Visual Studio 2012 or its earlier versions.

  C++ has a type "bool" as language definition. So this header is invalidated
  in the C++ case.
*/

#ifndef NON_C99_STDBOOL_H
#define NON_C99_STDBOOL_H

#ifndef __cplusplus
#define bool _Bool
#define _Bool int
#define true 1
#define false 0
#endif

#endif
