/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

#ifndef __MEMDRV_PUB_H
#define __MEMDRV_PUB_H

/*!
  @defgroup group_memdrv_pub memdrv_pub (under development)
  @brief *Limited* memory driver API (memdrv)

  The API for initialization, ie memdrv_Init() is not in public, because it is
  invoked in impsim_Open().
*/

#ifdef __cplusplus
extern "C" {
#endif

#define MEMDRV_NOFIXED 0

#define MEMDRV_8		(1)
#define MEMDRV_YUV		(2)
    
typedef int32_t membmp_id_t;

typedef struct t_memdrv_mbitmap {
	uint32_t Height;
	uint32_t Width;
	uint32_t bpp;
	uint32_t Stride;
	uint32_t Alignment;
	uint32_t Flag;
	uint32_t Mode;
	uint32_t Attr;
    uint32_t Channels;
} T_MEMDRV_MBITMAP;

/**
   @ingroup group_memdrv_pub

   TBD
   
   @param TBD
   @retval TBD
*/
int32_t memdrv_MemBitmapCreate(T_MEMDRV_MBITMAP *pMBitmap);
    
/**
   @ingroup group_memdrv_pub

   TBD
   
   @param TBD
   @retval TBD
*/
int32_t memdrv_MemBitmapDelete(int32_t id);

/**
   @ingroup group_memdrv_pub

   TBD
   
   @param TBD
   @retval TBD
*/    
int32_t memdrv_MemBitmapInfoGet(int32_t id, T_MEMDRV_MBITMAP *pMBitmap);

/**
   @ingroup group_memdrv_pub

   TBD
   
   @param TBD
   @retval TBD
*/    
int32_t memdrv_MemBitmapLock(int32_t id, uint32_t** p);

/**
   @ingroup group_memdrv_pub

   TBD
   
   @param TBD
   @retval TBD
*/    
int32_t memdrv_MemBitmapUnlock(int32_t id);

/**
   @ingroup group_memdrv_pub

   TBD
   
   @param TBD
   @retval TBD
*/    
Error memdrv_MemBitmapVirtAddrGet(membmp_id_t mid, void ** p_vptr);
/* added by hubin 20140918 -S */
Error memdrv_MemBitmapVirtAddrGetForSim(membmp_id_t mid, void ** p_vptr);
/* added by hubin 20140918 -E */
#ifdef __cplusplus
}
#endif

#endif	//__MEMDRV_H
