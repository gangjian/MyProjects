/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **

** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

#ifndef IMRLSDRV_H_
#define IMRLSDRV_H_

#ifdef __cplusplus
extern "C" {
#endif

/*!
  @defgroup group_imrlsdrv imrlsdrv (under development)
  @brief IMR-LSX2 driver API (imrlsdrv)
*/

/* 2 dimension coordinate */
typedef struct
{
	int32_t X;
	int32_t Y;
} T_IMRLSDRV_2DPOS;

/* IMRLS source setting */
typedef struct
{
	uint32_t start_line;	/* start line */
	uint32_t end_line;		/* end line */
	uint32_t mesh_size;		/* mesh size */
	uint32_t source_width;	/* source width */
	uint32_t source_height;	/* source height */
} T_IMRLSDRV_SOURCE;

/* DL format */
typedef struct _T_IMRLSDRV_DL
{
	int32_t CurLen;	/* current length. 1 length is 4 bytes. */
	int32_t Capacity;
	char pad[32 - 4 * 2];	/* DlBuffer must be 32 bytes alignment. */
	/* DlBuffer must be tail. */
	uint32_t DlBuffer[1];
} T_IMRLSDRV_DL;

/* Distortion compensation execution option */
enum IMRLSDRV_EXEC_OPT {
    IMRLSDRV_EXEC_Y = 0,
    IMRLSDRV_EXEC_UV,
};

/* callback function */
typedef void (*IMRLSDRV_CALLBACK)(int32_t ch, uint32_t param);

/**
   @ingroup group_imrlsdrv

   Initialize imrlsdrv.
   Should be called 

   @param none
   @retval none
*/
void imrlsdrv_Init(void);

/* Start */
int32_t imrlsdrv_Start(int32_t Ch);

/* Stop */
int32_t imrlsdrv_Stop(int32_t Ch);

/* Driver open */
int32_t imrlsdrv_Open(int32_t Ch);

/* Driver close */
int32_t imrlsdrv_Close(int32_t Ch);

/* Execution DL */
int32_t imrlsdrv_Execute(int32_t Ch, int32_t dl_id1, int32_t dl_id2, int32_t dst_id1, int32_t dst_id2, const T_IMRLSDRV_2DPOS *dst_pos, uint32_t mode, bool auto_rendering, IMRLSDRV_CALLBACK callbackFunc, void *callbackParam);

/* Execution DL (TXTM mode) */
int32_t imrlsdrv_ExecuteExt(int32_t Ch, int32_t dl_id1, int32_t src_id1, int32_t dst_id1, const T_IMRLSDRV_2DPOS *dst_pos, uint32_t mode, enum IMRLSDRV_EXEC_OPT opt, IMRLSDRV_CALLBACK callbackFunc, void *callbackParam);

/* Execution stop */
int32_t imrlsdrv_ExecutionStop(int32_t Ch);

/* Source setting */
int32_t imrlsdrv_SetSource(int32_t Ch, const T_IMRLSDRV_SOURCE *src_setting);

/* Software reset */
int32_t imrlsdrv_SoftwareReset(int32_t Ch);

/* Video source select */
int32_t imrlsdrv_SelVideoSorce(int32_t Ch, int32_t Sel);

/* Write User specific code */
int32_t imrlsdrv_DL_UserSpecific(int32_t dl_id, uint32_t opCode);

#ifdef __cplusplus
}
#endif

#endif /* IMRLSDRV_H_ */
