/******************************************************************************
    Copyright (C) 2000-2006 Hitachi,Ltd. All rights reserved.
    Copyright (c) 2005-2013 Renesas Electronics Corporation. All rights reserved.

        Image Recognition Library for IMP Hardware IP Core (IMPLIB)
******************************************************************************/
/******************************************************************************
 [�t�@�C��] ipxprot.h
 [ ��  �� ]
 [ ��  �� ]
  01-00-00  2005.08.30  S.SUZUKI  �t�@�C���w�b�_�V�K�쐬
  01-00-01  2005.10.14  N.MIFUNE  implib_AllocImg�Aimplib_AllocYUVImg�Aimplib_AllocCYUVImg���C��
  01-01-01  2005.12.12  N.MIFUNE  �t�@�C���w�b�_�̃o�[�W�����L�ڂ��C��
  01-02-01  2006.02.15  N.MIFUNE  implib_DriverIoControl��ǉ��A���쌠�\�L�̍ŏI�N��2006�N�ɕύX
   02-00-00  2007.11.15  S.NISHIMURA SH77650�Ή�
                                    ���쌠�\�L�̍ŏI�N��2007�N�ɕύX
                                    implib_IP_HistogramFeatures,implib_HistAnalyze ��ǉ�
                                    implib_IP_SmoothFLT5x5Ext,implib_IP_EdgeFLT5x5Ext ��ǉ�
                                    implib_SetOptFlowMode,implib_IP_OptFlow ��ǉ�
  02-01-00  2007.11.22  S.NISHIMURA implib_GetCorrMapSize,implib_IP_CorrMap ��ǉ�
  02-02-00  2008.05.29  S.NISHIMURA ���쌠�\�L�̍ŏI�N��2008�N�ɕύX
                                    implib_AllocImgExt,implib_AllocYUVImgExt,implib_AllocCYUVImgExt��ǉ�
  02-03-00  2008.07.01  K.TAKANO    implib_SetBinMatchTemplate��������const���폜[B2-D095]
  02-03-01  2008.07.23  S.SUEKI     implib_SetVideoFrame�̑������^��IMPLIB_VideoFrameSize�C��������[B2-D092]
  02-03-02  2008.07.25  S.SUEKI     implib_IP_SmoothFLT,implib_IP_EdgeFLT,implib_IP_EdgeFLTAbs,mplib_IP_LineFLT
                                    implib_IP_LineFLTAbs�֐��̈���COEFF�̌^��,implib_IP_ProjectLabelGOMinMaxValue�֐��̈������C��[B2-D098]
  02-03-03  2008.07.29  S.NISHIMURA implib_IP_TrsPipelineFLT���C��
******************************************************************************/

/*
 * 
 * 59    12/10/12 14:33 Ysuzuki
 * Addition implib_IP_FFT1DX  [P4-0218]
 * Addition implib_IMR_Exec  [P4-0218]
 * 
 * 58    12/07/19 21:05 Nishi_renesas
 * Deletion implib_IP_EdgeFLT5x5 [P4-D0007]
 * 
 * 57    12/07/14 15:34 Hoshi
 * The definition to A was added. [P5-0007]
 * 
 * 56    12/07/02 20:18 Hoshi
 * MISRA-C [P4-0197][M3_5_1]
 * 
 * 55    12/06/21 18:00 Nishi_renesas
 * Modification Copyright declaration [P4-0188]
 * 
 * 54    12/06/16 20:10 Hoshi
 * MISRA-C [P4-0182][M3_16_4]
 * 
 * 53    12/06/13 15:35 Hoshi
 * MISRA-C [P4-0169][M3_16_4]
 * 
 * 52    12/06/13 10:34 Hoshi
 * MISRA-C [P4-0167][M3_16_4]
 * 
 * 51    12/06/12 22:02 Hoshi
 * MISRA-C [P4-0166][M3_16_4]
 * 
 * 50    12/06/11 11:49 Hoshi
 * MISRA-C [P4-0155][M3_16_4]
 * 
 * 49    12/06/06 10:35 Hoshi
 * MISRA-C [P4-0133][M3_16_4]
 * 
 * 47    12/03/19 19:55 Nishi_renesas
 * Modification implib_SetEdgeCodeTbl [P4-0052]
 * Modification implib_IP_EdgeCode [P4-0052]
 * 
 * 46    12/03/19 18:05 Nishi_renesas
 * Addition implib_HistAnalyze16 [P4-0051]
 * 
 * 45    12/03/19 17:20 Nishi_renesas
 * Modification implib_OpenImgDirect [P4-0050]
 * Addition implib_ReadPixelExt [P4-0050]
 * Addition implib_WritePixelExt [P4-0050]
 * Addition implib_ReadPixelContinueExt [P4-0050]
 * Addition implib_WritePixelContinueExt [P4-0050]
 * 
 * 44    12/03/19 16:24 Nishi_renesas
 * Addition implib_IP_SmoothFLT5x5 [P4-0049]
 * Addition implib_IP_EdgeFLT5x5 [P4-0049]
 * 
 * 43    12/03/19 15:31 Nishi_renesas
 * Addition implib_IP_Div [P4-0048]
 * Addition implib_IP_Mod [P4-0048]
 * Addition implib_IP_SubSquare [P4-0048]
 * 
 * 42    12/03/19 13:22 Nishi_renesas
 * Addition implib_IP_DivConstNume [P4-0046]
 * Addition implib_IP_ModConstNume [P4-0046]
 * Addition implib_IP_DivConstDenom [P4-0046]
 * Addition implib_IP_ModConstDenom [P4-0046]
 * Addition implib_IP_ConstSub [P4-0046]
 * 
 * 41    12/03/19 10:56 Nishi_renesas
 * Addition implib_WriteConvertLUT16 [P4-0045]
 * Addition implib_AllocImg16 [P4-0018]
 * Addition implib_AllocImg32 [P4-0018]
 * Addition implib_AllocImg16Ext [P4-0018]
 * Addition implib_AllocImg32Ext [P4-0018]
 * 
 * 40    12/03/16 18:28 Nishi_renesas
 * Addition implib_IP_HarrisOperatorPrecise [P4-0043]
 * Addition implib_IP_HarrisOperatorFast [P4-0043]
 * 
 * 39    12/03/16 15:46 Nishi_renesas
 * Addition implib_IP_CovarianceMatrix [P4-0042]
 * 
 * 38    12/03/15 21:02 Nishi_renesas
 * Addition implib_SetStereoVisionMode [P4-0040]
 * Addition implib_IP_StereoVision [P4-0040]
 * Addition implib_IP_StereoVisionPrecise [P4-0040]
 * Addition implib_CreateStereoVisionModel [P4-0040]
 * Addition implib_DeleteStereoVisionModel [P4-0040]
 * Addition implib_IP_ExecuteStereoVisionModel [P4-0040]
 * 
 * 37    12/03/15 14:12 Nishi_renesas
 * Addition implib_IntegralImage
 * Addition implib_IntegralImageSquare [P4-0039]
 * Addition implib_IntegralImageUpTrpz [P4-0039]
 * Addition implib_IntegralImageLowTrpz [P4-0039]
 * Addition implib_IntegralImageSquareUpTrpz [P4-0039]
 * Addition implib_IntegralImageSquareLowTrpz [P4-0039]
 * Addition implib_IntegralImage45 [P4-0039]
 * Addition implib_IntegralImageSquare45 [P4-0039]
 * 
 * 36    12/03/14 18:29 Nishi_renesas
 * Addition implib_CreateSparseOptFlowModel [P4-0038]
 * Addition implib_IP_ExecuteSparseOptFlowModel [P4-0038]
 * Addition implib_DeleteSparseOptFlowModel [P4-0038]
 * 
 * 35    12/03/14 15:54 Nishi_renesas
 * Addition implib_IP_HoughLineVotingSpace [P4-0037]
 * Addition implib_IP_HoughLineRhoMap [P4-0037]
 * Addition implib_IP_HistogramByLine [P4-0037]
 * 
 * 34    12/03/08 16:52 Nishi_renesas
 * Addition implib_IP_NonMaximumSuppressionRT [P4-0036]
 * Addition implib_IP_NonMaximumSuppressionEC [P4-0036]
 * 
 * 33    12/03/08 15:47 Nishi_renesas
 * Addition implib_IP_LocalMax [P4-0035]
 * Addition implib_IP_LocalMin [P4-0035]
 * Addition implib_IP_PIS3x3 [P4-0035]
 * Addition implib_IP_PIS5x5 [P4-0035]
 * Addition implib_IP_PIS3x3withThreshold [P4-0035]
 * Addition implib_IP_PIS5x5withThreshold [P4-0035]
 * 
 * 32    12/03/08 15:28 Nishi_renesas
 * Addition implib_IP_TransposeMatrix [P4-0034]
 * Addition implib_IP_InnerProduct [P4-0034]
 * Addition implib_IP_ProductMatrix [P4-0034]
 * Addition implib_IP_MeanVector [P4-0034]
 * Addition implib_IP_EuclideanDistance [P4-0034]
 * 
 * 31    12/02/27 16:26 Nishi_renesas
 * Addition implib_WriteConvertLUT2Fr16 [P4-0027]
 * 
 * 29    11/01/25 10:08 Nishi_renesas
 * implib_EnableLinearTransformProject�ǉ�[P3-0055]
 * 
 * 28    11/01/20 15:41 Nishi_renesas
 * implib_DispCamera��`�폜[P3-D0028]
 * implib_DisableDisp��`�폜[P3-D0028]
 * 
 * 27    10/09/29 10:02 Nishi_renesas
 * implib_EnableRotateProjectEx�ǉ�[P3-0132]
 * 
 * 26    10/09/04 15:38 Nishi_renesas
 * implib_SetTimeOut�����f�[�^�^�C��[P3-0129]
 * 
 * 25    10/08/04 13:18 Nishi_renesas
 * implib_SetTimeOut�ǉ�[P3-0112]
 * 
 * 24    10/06/29 19:25 Nishi_renesas
 * implib_Open�ǉ�[P3-0101]
 * implib_Close�ǉ�[P3-0102]
 * 
 * 23    10/05/14 9:26 Nishi_renesas
 * implib_WriteConvertLUT2Fr�ǉ�[P3-0034]
 * 
 * 22    10/05/13 20:47 Nishi_renesas
 * implib_IP_ConvertLUT2FrMax�ǉ�[P3-0032]
 * 
 * 21    10/05/13 20:35 Nishi_renesas
 * implib_IP_ConvertLUT2FrMin�ǉ�[P3-0031]
 * 
 * 20    10/05/13 20:15 Nishi_renesas
 * implib_IP_InvertAdd�ǉ�[P3-0027]
 * 
 * 19    10/05/13 19:25 Nishi_renesas
 * implib_IP_MaxFLT5x5�ǉ�[P3-0007]
 * implib_IP_MaxFLT44�ǉ�[P3-0007]
 * implib_IP_MaxFLT88�ǉ�[P3-0007]
 * 
 * 18    10/05/13 19:18 Nishi_renesas
 * implib_IP_MinFLT5x5�ǉ�[P3-0006]
 * implib_IP_MinFLT44�ǉ�[P3-0006]
 * implib_IP_MinFLT88�ǉ�[P3-0006]
 * 
 * 17    10/05/13 17:05 Nishi_renesas
 * implib_IP_FillHole�ǉ�[P3-0020]
 * 
 * 16    10/05/12 16:46 Nishi_renesas
 * implib_IP_EdgeCodeExt�ǉ�[P3-0043]
 * 
 * 15    10/05/12 13:45 Nishi_renesas
 * implib_IP_EdgeCode�ǉ�[P3-0011]
 * 
 * 14    10/05/12 13:02 Nishi_renesas
 * implib_SetEdgeCodeTbl�ǉ�[P3-0009]
 * 
 * 13    10/05/12 9:33 Nishi_renesas
 * implib_SetEdgeCodeConfig�ǉ�[P3-0008]
 * 
 * 12    10/05/11 19:38 Nishi_renesas
 * implib_IP_ZoomOutwithFLT3x3�ǉ�[P3-0030]
 * 
 * 11    10/05/11 19:15 Nishi_renesas
 * implib_IP_EdgeFLT7x7AbsAddZoomOutExt�ǉ�[P3-0029]
 * 
 * 10    10/05/11 17:26 Nishi_renesas
 * implib_IP_EdgeFLT7x7AbsAdd�ǉ�[P3-0028]
 * 
 * 9     10/05/11 16:53 Nishi_renesas
 * implib_IP_EdgeFLT7x7�ǉ�[P3-0019]
 * 
 * 8     10/05/11 14:33 Nishi_renesas
 * implib_IP_ZoomOutExtwithFLT7x7�ǉ�[P3-0023]
 * 
 * 7     10/05/11 11:05 Nishi_renesas
 * implib_ExtractPolyline�ǉ�[P3-0021]
 * 
 * 6     10/05/11 10:00 Nishi_renesas
 * implib_IP_ZoomInLUTAnd�ǉ�[P3-0033]
 * 
 * 5     10/05/11 9:44 Nishi_renesas
 * implib_IP_ConvertLUTMax�ǉ�[P3-0026]
 * 
 * 4     10/05/10 20:38 Nishi_renesas
 * implib_IP_ConvertLUTMin�ǉ�[P3-0025]
 * 
 * 3     10/05/10 20:12 Nishi_renesas
 * implib_IP_ConvertLUTAnd��ǉ�[P3-0018]
 * 
 * 2     10/05/10 19:28 Nishi_renesas
 * implib_IP_SubLUT��ǉ�[P3-0017]
 * 
 * 1     10/05/07 11:08 Nishi_renesas
 * Initial revision

*/

#ifndef __IMPLIB_IPXPROT_H__
#define __IMPLIB_IPXPROT_H__
/* #include "ipxdef.h" */ /* M_19.15 */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/*******************************************
	�v���g�^�C�v�錾
*******************************************/

/* �摜�����`�o�h������ */
void implib_Init( void );
int32_t implib_Start( void ); /* M_6.3 */
int32_t implib_Stop( void ); /* M_6.3 */

/* �V�X�e������ */
int32_t implib_ResetIMP( void ); /* M_6.3 */
int32_t implib_InitIP( void ); /* M_6.3 */
int32_t implib_InitIPExt( void ); /* M_6.3 */
int32_t implib_ReadIPErrorTable( IMPLIB_IPErrorTbl *Tbl ); /* M_6.3 */
int32_t implib_ClearIPError( void ); /* M_6.3 */
int32_t implib_SetIPDataType( enum IMPLIB_DataType type ); /* M_6.3 */
float32_t implib_IPLibVersion( void ); /* M_6.3 */
int32_t implib_DriverIoControl(enum IMPLIB_DRVID drvid, uint32_t func, void* pinbuf, int32_t inlen, void* poutbuf, int32_t* poutlen); /* [B-C061] �ǉ� */ /* M_6.3 */
int32_t implib_Open( void ) ;  /* [P3-0101] */
int32_t implib_Close(void) ;  /* [P3-0102] */
int32_t implib_SetTimeOut( int32_t semtime ) ; /* [P3-0112] */ /* [P3-0129] */

/* �摜�������Ǘ� */
IMPLIB_IMGID implib_AllocImg( IMPLIB_ImageFrameSize size );			/* [B-D005] �C�� *//* M_10.1 */ /* [B2-D084] */
IMPLIB_IMGID implib_AllocYUVImg( IMPLIB_ImageFrameSize size );			/* [B-D006] �C�� *//* M_10.1 */ /* [B2-D085] */
IMPLIB_IMGID implib_AllocCYUVImg( IMPLIB_ImageFrameSize size );		/* [B-D007] �C�� *//* M_10.1 */ /* [B2-D086] */
#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0018] *//*[P5-0007]*/
IMPLIB_IMGID implib_AllocImg16( IMPLIB_ImageFrameSize size );
IMPLIB_IMGID implib_AllocImg32( IMPLIB_ImageFrameSize size );
IMPLIB_IMGID implib_AllocImg16Ext( int32_t mbmp_id );
IMPLIB_IMGID implib_AllocImg32Ext( int32_t mbmp_id );
#endif

IMPLIB_IMGID implib_AllocImgExt( int32_t mbmp_id );		/* [P2-429] �ǉ� */ /* M_6.3 */ /* [B2-D087] */ /* M_17.4 */
IMPLIB_IMGID implib_AllocYUVImgExt( int32_t mbmp_id );	/* [P2-429] �ǉ� */ /* M_6.3 */ /* [B2-D088] */ /* M_17.4 */
IMPLIB_IMGID implib_AllocCYUVImgExt( int32_t mbmp_id );	/* [P2-429] �ǉ� */ /* M_6.3 */ /* [B2-D089] */ /* M_17.4 */

int32_t implib_FreeImg( IMPLIB_IMGID ImgID ); /* M_6.3 */
int32_t implib_FreeAllImg( void ); /* M_6.3 */
IMPLIB_IMGID implib_GetUVImgID( IMPLIB_IMGID ImgYUV );
int32_t implib_ReadImgTable( IMPLIB_IMGID ImgID, IMPLIB_IMGTBL *Tbl );	/* M_16.4 */ /* M_6.3 */
int32_t implib_ReadYUVImgTable( IMPLIB_IMGID ImgYUV, IMPLIB_IMGTBL *YTbl, IMPLIB_IMGTBL *UVTbl );	/* M_16.4 */ /* M_6.3 */
int32_t implib_ChangeImgDataType( IMPLIB_IMGID ImgID, enum IMPLIB_DataType type ); /* M_6.3 */
int32_t implib_SetWindow( enum IMPLIB_WindowType type, int32_t sx, int32_t sy, int32_t ex, int32_t ey ); /* M_6.3 */
int32_t implib_SetAllWindow( int32_t sx, int32_t sy, int32_t ex, int32_t ey ); /* M_6.3 */
int32_t implib_ResetAllWindow( void ); /* M_6.3 */
int32_t implib_EnableIPWindow( void ); /* M_6.3 */
int32_t implib_DisableIPWindow( void ); /* M_6.3 */
int32_t implib_ReadWindow( enum IMPLIB_WindowType type, int32_t *sx, int32_t *sy, int32_t *ex, int32_t *ey ); /* M_6.3 */

/* �f�����͐��� */
int32_t implib_SetVideoFrame( enum IMPLIB_Interlace mode, IMPLIB_VideoFrameSize size ); /* M_6.3 */ /* M_10.1 */ /* [B2-D092]�Ή� */
int32_t implib_SelectCamera( enum IMPLIB_CameraID id, enum IMPLIB_CameraType type ); /* M_6.3 */
int32_t implib_CaptureContinuous( IMPLIB_CapImgTbl *capimg ); /* M_6.3 */
int32_t implib_StopCaptureContinuous( void ); /* M_6.3 */
int32_t implib_GetCamera( IMPLIB_IMGID ImgID ); /* M_6.3 */
int32_t implib_GetCameraReqScene( IMPLIB_IMGID ImgID, uint32_t ReqSceneNo, uint32_t *ResSceneNo, int32_t tmout ); /* M_6.3 */
int32_t implib_GetCameraResScene( IMPLIB_IMGID ImgID, uint32_t *ResSceneNo ); /* M_6.3 */
int32_t implib_ActiveVideoPort( enum IMPLIB_VideoPortID vpid ); /* M_6.3 */
int32_t implib_SetVFDelay( int32_t HOffset, int32_t VOffset ); /* M_6.3 */
int32_t implib_CombineYUV(IMPLIB_IMGID ImgSrc,IMPLIB_IMGID ImgDst); /* M_6.3 */

/* �f���o�͐��� */
int32_t implib_SetConfigDisp( IMPLIB_ConfigDispPara *para ); /* M_6.3 */
int32_t implib_SetDispPalette( int32_t PaletteNo, IMPLIB_DispPaletteTbl *PalTbl );	/* M_16.4 */ /* M_6.3 */
int32_t implib_SelectDisp( enum IMPLIB_DispType type ); /* M_6.3 */
#ifndef MULTI_TASK	/* [P3-D0028] */
int32_t implib_DispCamera( void ); /* M_6.3 */
int32_t implib_DisableDisp( void ); /* M_6.3 */
#endif	/* MULTI_TASK */
int32_t implib_DispImg( IMPLIB_IMGID ImgID ); /* M_6.3 */
int32_t implib_NoDisp( void ); /* M_6.3 */
int32_t implib_DispOverlap( IMPLIB_IMGID ImgID, enum IMPLIB_OverlapMode mode ); /* M_6.3 */
int32_t implib_DisableOverlap( void ); /* M_6.3 */

/* �摜�N���A */
int32_t	implib_IP_ClearAllImg( void ); /* M_6.3 */
int32_t implib_IP_ClearImg( IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Const( IMPLIB_IMGID ImgDst, int32_t constant ) ; /* M_6.3 */ /* M_16.3 */

/* �摜�]���E�A�t�B���ϊ� */
int32_t implib_IP_Copy( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Zoom( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, float32_t mag ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ZoomExt( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, float32_t xmag, float32_t ymag ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ZoomOut( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t mag ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ZoomOutExt( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t xmag, int32_t ymag ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ZoomIn( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t mag ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ZoomInExt( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t xmag, int32_t ymag ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ZoomS( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, float32_t mag, int32_t dx, int32_t dy, enum IMPLIB_SPACE_OPT opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Shift( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t dx, int32_t dy, enum IMPLIB_SPACE_OPT opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Rotate( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, float32_t mag, float32_t theta, int32_t xc, int32_t yc, int32_t dx, int32_t dy, enum IMPLIB_SPACE_OPT opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MeanShrink(IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t xmag, int32_t ymag, int32_t scale);
int32_t implib_IP_Pack( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );/* [P4-0539] */
int32_t implib_IP_Unpack( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );/* [P4-0539] */

/* �Q�l�� */
int32_t implib_IP_Binarize( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t thr ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_BinarizeExt( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t thrmin, int32_t thrmax, int32_t opt ); /* M_6.3 */ /* M_16.3 */

/* ��f�ϊ� */
int32_t implib_IP_Invert( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Minus( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Abs( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_AddConst( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_SubConst( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_SubConstAbs( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MultConst( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant, int32_t scale ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MinConst( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MaxConst( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant ); /* M_6.3 */ /* M_16.3 */
int32_t	implib_WriteConvertLUT( IMPLIB_CNVLUT lut[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ConvertLUT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ShiftDown( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ShiftUp( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale ); /* M_6.3 */ /* M_16.3 */
#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0045] *//*[P5-0007]*/
int32_t	implib_WriteConvertLUT16( IMPLIB_CNVLUT lut[], int32_t start, int32_t size );
#endif
#if defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0046] *//*[P5-0007]*/
int32_t implib_IP_DivConstNume( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant );
int32_t implib_IP_ModConstNume( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant );
int32_t implib_IP_DivConstDenom( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant );
int32_t implib_IP_ModConstDenom( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant );
int32_t implib_IP_ConstSub( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t constant );
#endif

/* ��f�ԎZ�p���Z */
int32_t implib_IP_Add( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Sub( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_SubAbs( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Comb( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t scale, int32_t a, int32_t b ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_CombAbs( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t scale, int32_t a, int32_t b ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Mult( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t scale ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Average( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Min( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Max( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_SubConstAbsAdd( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t scale, int32_t a, int32_t b ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_SubConstMultAdd( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t scale, int32_t a, int32_t b ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_SubConstMult( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t scale, int32_t a, int32_t b ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_CombDrop( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t scale, int32_t a, int32_t b ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ConvertLUTMin( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgCnv, IMPLIB_IMGID ImgDst ) ;  /* [P3-0025] */
int32_t implib_IP_ConvertLUTMax( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgCnv, IMPLIB_IMGID ImgDst ) ;  /* [P3-0026] */
int32_t implib_IP_InvertAdd(IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst) ;  /* [P3-0027] */
int32_t implib_IP_ConvertLUT2FrMin( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst) ;	/* [P3-0031] */
int32_t implib_IP_ConvertLUT2FrMax( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst) ;	/* [P3-0032] */
int32_t implib_WriteConvertLUT2Fr( IMPLIB_CNVLUT luta[], IMPLIB_CNVLUT lutb[] ) ;	/* [P3-0034] */
#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0027] *//*[P5-0007]*/
int32_t implib_WriteConvertLUT2Fr16( IMPLIB_CNVLUT luta[], IMPLIB_CNVLUT lutb[], int32_t starta, int32_t sizea, int32_t startb, int32_t sizeb ) ;
#endif
#if defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0048] *//*[P5-0007]*/
int32_t implib_IP_Div( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst );
int32_t implib_IP_Mod( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst );
int32_t implib_IP_SubSquare( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst );
#endif

/* ��f�Ԙ_�����Z */
int32_t implib_IP_And( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Or( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Xor( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_InvertAnd( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_InvertOr( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Xnor( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_SubLUT( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* [P3-0017] */
int32_t implib_IP_ConvertLUTAnd( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst ); /* [P3-0018] */
int32_t implib_IP_ZoomInLUTAnd( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t mag) ; /* [P3-0033] */
int32_t implib_IP_BitCount( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );/*[P4-0500]*/
int32_t implib_IP_AndBitCount( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst );/* [P4-0539] */
int32_t implib_IP_OrBitCount( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst );/* [P4-0539] */
int32_t implib_IP_XorBitCount( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst );/* [P4-0539] */
int32_t implib_IP_XnorBitCount( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst );/* [P4-0539] */
int32_t implib_IP_ConstAndOrBitCount( IMPLIB_IMGID ImgSrc0, IMPLIB_IMGID ImgSrc1, IMPLIB_IMGID ImgDst, int32_t a, int32_t b );/* [P4-0539] */

/* �Q�l�摜�`��ϊ� */
int32_t implib_IP_PickNoise4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_PickNoise8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Outline4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Outline8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Dilation4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Dilation8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Erosion4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Erosion8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Thin4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Thin8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Shrink4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Shrink8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */

/* �R���{�����[�V���� */
int32_t	implib_IP_SmoothFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] ); /* M_6.3 */ /* [B2-D098] */
int32_t	implib_IP_EdgeFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] ); /* M_6.3 */ /* [B2-D098] */
int32_t	implib_IP_EdgeFLTAbs( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] ); /* M_6.3 */ /* [B2-D098] */
int32_t implib_IP_Lapl4FLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Lapl8FLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Lapl4FLTAbs( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Lapl8FLTAbs( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t	implib_IP_LineFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] ); /* M_6.3 */ /* [B2-D098] */
int32_t	implib_IP_LineFLTAbs( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] ); /* M_6.3 */ /* [B2-D098] */
int32_t implib_IP_SmoothFLT5x5Ext( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, enum IMPLIB_IPConvExtOpt opt, int32_t COEFF[] ); /* M_6.3 */	/* [P2-417] �ǉ� */ /* M_17.4 */
int32_t implib_IP_EdgeFLT5x5Ext( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, enum IMPLIB_IPConvExtOpt opt, int32_t COEFF[] ); /* M_6.3 */ /* [P2-417] �ǉ� */ /* M_17.4 */
int32_t implib_IP_EdgeFLT7x7( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] ); /* [P3-0019] */
int32_t implib_IP_ZoomOutExtwithFLT7x7( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t xmag, int32_t ymag, int32_t scale, int32_t COEFF[] ); /* [P3-0023] */
int32_t implib_IP_EdgeFLT7x7AbsAdd( IMPLIB_IMGID ImgEdge, IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[]) ; /* [P3-0028] */
int32_t implib_IP_EdgeFLT7x7AbsAddZoomOutExt( IMPLIB_IMGID ImgEdge, IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[], int32_t xmag, int32_t ymag) ; /* [P3-0029] */
int32_t implib_IP_ZoomOutwithFLT3x3( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale , int32_t COEFF[], int32_t mag ) ;/* [P3-0030] */
#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0049] *//*[P5-0007]*/
int32_t implib_IP_SmoothFLT5x5( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] );
int32_t implib_IP_EdgeFLT5x5( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] );/* [P4-0338] */
#endif
#if defined(IPCORE_IMPX2) || defined(CPU_RCARV2H)/* [P4-0351] */
int32_t implib_IP_EdgeFLT7x7AbsAdd2( IMPLIB_IMGID ImgEdge, IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[]);/* [P4-0351] */
int32_t implib_IP_EdgeFLT7x7AbsAddZoomOutExt2( IMPLIB_IMGID ImgEdge, IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[], int32_t xmag, int32_t ymag) ;/* PRQA S:QAC_M4_5_1 777 *//* [P4-0351] */
int32_t	implib_IP_LineFLT1x25( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] );/* [P4-554](#54941) */
int32_t	implib_IP_LineFLT1x25Abs( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF[] );/* [P4-554](#54941) */
#endif

/* �~�j�E�}�b�N�X�t�B���^ */
int32_t implib_IP_MinFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MinFLT4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MinFLT8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MaxFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MaxFLT4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MaxFLT8( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_LineMinFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_LineMaxFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MinFLT5x5( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn); /* [P3-0006] */
int32_t implib_IP_MaxFLT5x5( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn); /* [P3-0007] */
#define	implib_IP_MinFLT44(ImgSrc,ImgDst)	implib_IP_MinFLT5x5(ImgSrc,ImgDst,0x0000005fU) /* [P3-0006] */
#define	implib_IP_MaxFLT44(ImgSrc,ImgDst)	implib_IP_MaxFLT5x5(ImgSrc,ImgDst,0x0000005fU) /* [P3-0007] */
#define	implib_IP_MinFLT88(ImgSrc,ImgDst)	implib_IP_MinFLT5x5(ImgSrc,ImgDst,0x000001ffU) /* [P3-0006] */
#define	implib_IP_MaxFLT88(ImgSrc,ImgDst)	implib_IP_MaxFLT5x5(ImgSrc,ImgDst,0x000001ffU) /* [P3-0007] */

/* �����N�t�B���^ */
int32_t implib_IP_RankFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn, int32_t rank ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Rank4FLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t rank ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Rank8FLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t rank ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_MedFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t calptn ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Med4FLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Med8FLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* M_16.3 */

/* ���x�����O */
int32_t implib_IP_Label4( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, enum IMPLIB_IP_Label_opt opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Label8( IMPLIB_IMGID  ImgSrc, IMPLIB_IMGID  ImgDst, enum IMPLIB_IP_Label_opt opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Label4withAreaFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t thrmin, int32_t thrmax, enum IMPLIB_IP_Label_opt opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Label8withAreaFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t thrmin, int32_t thrmax, enum IMPLIB_IP_Label_opt opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Label4withAreaFLTSort( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t thrmin, int32_t thrmax, enum IMPLIB_IP_Label_opt opt, enum IMPLIB_IP_Label_Sort_opt opt2 ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_Label8withAreaFLTSort( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t thrmin, int32_t thrmax, enum IMPLIB_IP_Label_opt opt, enum IMPLIB_IP_Label_Sort_opt opt2 ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ExtractLORegionX( IMPLIB_IMGID ImgSrc, int32_t TblMinX[], int32_t TblMaxX[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ExtractLORegionY( IMPLIB_IMGID ImgSrc, int32_t TblMinY[], int32_t TblMaxY[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ExtractLOArea( IMPLIB_IMGID ImgSrc, int32_t Tbl[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ExtractLOAreaExt( IMPLIB_IMGID ImgSrc,int32_t Tbl[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ExtractLOGravity( IMPLIB_IMGID ImgSrc, IMPLIB_IPLOGravityTbl Tbl[] ); /* M_6.3 */ /* M_17.4 */

/* �Z�W�摜�����ʒ��o */
int32_t implib_IP_ExtractGOFeatures( IMPLIB_IMGID ImgSrc, IMPLIB_IPGOFeatureTbl *FtrTbl, enum IMPLIB_IPGOFeatureOpt opt ); /* M_6.3 */ /* M_16.3 */
int32_t	implib_IP_Histogram( IMPLIB_IMGID ImgSrc, int32_t Tbl[], IMPLIB_IPGOFeatureTbl *FtrTbl, int32_t opt ); /* M_6.3 */ /* M_17.4 */
int32_t	implib_IP_HistogramShort( IMPLIB_IMGID ImgSrc, int32_t Tbl[], IMPLIB_IPGOFeatureTbl *FtrTbl, int32_t opt ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectGO( IMPLIB_IMGID ImgSrc, int32_t TblX[], int32_t TblY[], IMPLIB_IPGOFeatureTbl *FtrTbl ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectGOonX( IMPLIB_IMGID ImgSrc, int32_t TblX[], IMPLIB_IPGOFeatureTbl *FtrTbl ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectGOonY( IMPLIB_IMGID ImgSrc, int32_t TblY[], IMPLIB_IPGOFeatureTbl *FtrTbl ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectGOMaxValue( IMPLIB_IMGID ImgSrc, int32_t TblX[], int32_t TblY[], IMPLIB_IPGOFeatureTbl *FtrTbl ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectGOMinValue( IMPLIB_IMGID ImgSrc, int32_t TblX[], int32_t TblY[], IMPLIB_IPGOFeatureTbl *FtrTbl ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectBlockGO( IMPLIB_IMGID ImgSrc, int32_t Tbl[], IMPLIB_IPGOFeatureTbl *FtrTbl, IMPLIB_IPDivideTbl *DivideTbl ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectBlockGOMinMaxValue( IMPLIB_IMGID ImgSrc, IMPLIB_IPGOMinMaxTbl Tbl[], IMPLIB_IPDivideTbl *DivideTbl ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectLabelGO( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgLabel, int32_t Tbl[] ); /* M_6.3 */ /* M_17.4 */
int32_t	implib_IP_ProjectLabelGOMinMaxValue( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgLabel, IMPLIB_IPGOMinMaxTbl Tbl[] ); /* M_6.3 */ /* [B2-D098] */
int32_t implib_EnableRotateProject( float32_t theta ); /* M_6.3 */ /* M_16.3 */
int32_t	implib_DisableRotateProject( void ); /* M_6.3 */
int32_t implib_IP_HistogramFeatures( IMPLIB_IMGID ImgSrc, int32_t Tbl[], IMPLIB_HISTOGRAM_FEATURE *HistTbl, int32_t opt );	/* [P2-421] �ǉ� */ /* M_6.3 */ /* M_17.4 */
int32_t implib_EnableRotateProjectEx( float32_t thetaX, float32_t thetaY) ; /* P3-0132 */
int32_t implib_EnableLinearTransformProject( float32_t coeff_a, float32_t coeff_b, float32_t coeff_c, float32_t coeff_d) ;	/* [P3-0055] */

/* �Q�l�摜�����ʒ��o */
int32_t implib_IP_ExtractBOFeatures( IMPLIB_IMGID ImgSrc, IMPLIB_IPBOFeatureTbl *FtrTbl, enum IMPLIB_IPBOFeatureOpt opt ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_ProjectBO( IMPLIB_IMGID ImgSrc, int32_t TblX[], int32_t TblY[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectBORegionX( IMPLIB_IMGID ImgSrc, int32_t TblMinX[], int32_t TblMaxX[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectBORegionY( IMPLIB_IMGID ImgSrc, int32_t TblMinY[], int32_t TblMaxY[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_ProjectBlockBO( IMPLIB_IMGID ImgSrc, int32_t Tbl[], IMPLIB_IPDivideTbl *DivideTbl ); /* M_6.3 */ /* M_17.4 */

/* �摜�������A�N�Z�X */
int32_t implib_OpenImg( enum IMPLIB_WaitMode mode ); /* M_6.3 */
int32_t implib_OpenImgExt( IMPLIB_IMGID ImgID , enum IMPLIB_WaitMode mode ); /* M_6.3 */
int32_t implib_CloseImg( void ); /* M_6.3 */
int32_t implib_ReadImg( IMPLIB_IMGID ImgID, uint8_t ImgTbl[], int32_t count ); /* M_6.3 */ /* M_17.4 */
int32_t implib_WriteImg( IMPLIB_IMGID ImgID, uint8_t ImgTbl[], int32_t count ); /* M_6.3 */ /* M_17.4 */
int32_t implib_SetPixelPointer( IMPLIB_IMGID ImgID ); /* M_6.3 */
int32_t implib_ReadPixel( int32_t x, int32_t y, int8_t *data ); /* M_6.3 */
int32_t implib_WritePixel( int32_t x, int32_t y, int8_t data ); /* M_6.3 */
int32_t implib_ReadPixelContinue( int8_t *data ); /* M_6.3 */
int32_t implib_WritePixelContinue( int8_t data ); /* M_6.3 */
int32_t implib_RefreshImg( IMPLIB_IMGID ImgID ); /* M_6.3 */
#if defined(CPU_SHNAVI2V) || defined(CPU_SH77650)
int32_t implib_OpenImgDirect( IMPLIB_IMGID ImgID, int32_t *xsize, int32_t *ysize, int8_t **address ); /* M_6.3 */
#else
int32_t implib_OpenImgDirect( IMPLIB_IMGID ImgID, int32_t *xsize, int32_t *ysize, void **address );	/* [P4-0050] */
#endif
int32_t implib_CloseImgDirect( IMPLIB_IMGID ImgID ); /* M_6.3 */
#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0050] *//*[P5-0007]*/
int32_t implib_ReadPixelExt( int32_t x, int32_t y, void *data );
int32_t implib_WritePixelExt( int32_t x, int32_t y, void *data );
int32_t implib_ReadPixelContinueExt( void *data );
int32_t implib_WritePixelContinueExt( void *data );
#endif

/* �Q�l�p�C�v���C���t�B���^ */
int32_t implib_SetTrsPipelineFLTMode( enum IMPLIB_PipelineMode pmode, IMPLIB_PipelineStageMode *fmode ); /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_TrsPipelineFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst ); /* M_6.3 */ /* [B2-D094]�C�� */ /* M_16.3 */

/* �p�C�v���C������ */
int32_t implib_EnablePipeline( void ); /* M_6.3 */
int32_t implib_DisablePipeline( void ); /* M_6.3 */

/* �x�t�u�J���[ */
int32_t implib_IP_Mask( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgMask, IMPLIB_IMGID ImgDst ); /* M_6.3 */
int32_t implib_IP_ClearColor( IMPLIB_IMGID ImgYUV ); /* M_6.3 */
int32_t implib_IP_ExtractColor( IMPLIB_IMGID ImgYUV, IMPLIB_IMGID ImgDst, int32_t Ythrmin, int32_t Ythrmax, int32_t Uthrmin, int32_t Uthrmax, int32_t Vthrmin, int32_t Vthrmax, enum IMPLIB_ColorOpt opt ); /* M_6.3 */
int32_t implib_IP_ExtractColorRhoTheta( IMPLIB_IMGID ImgYUV, IMPLIB_IMGID ImgDst, int32_t Ythrmin, int32_t Ythrmax, int32_t Rthrmin, int32_t Rthrmax, int32_t Tthrmin, int32_t Tthrmax, enum IMPLIB_ColorOpt opt ); /* M_6.3 */
int32_t implib_IP_ConvertRho( IMPLIB_IMGID ImgYUV, IMPLIB_IMGID ImgDstRho,int32_t RhoScale, enum IMPLIB_ColorOpt opt );	/* M_16.4 */ /* M_6.3 */
int32_t implib_IP_ConvertTheta( IMPLIB_IMGID ImgYUV, IMPLIB_IMGID ImgDstTheta, enum IMPLIB_ColorOpt opt );			/* M_16.4 */ /* M_6.3 */
int32_t implib_IP_ConvertRhoTheta( IMPLIB_IMGID ImgYUV, IMPLIB_IMGID ImgDstRho,IMPLIB_IMGID ImgDstTheta, int32_t RhoScale, enum IMPLIB_ColorOpt opt );	/* M_16.4 */ /* M_6.3 */

/* �Q�l�}�b�`���O�t�B���^ */
int32_t implib_SetBinMatchTemplate( int32_t Temp[], int32_t TmpID ); /* M_6.3 */ /* M_17.4 *//* [B2-D095] �C�� */
int32_t implib_IP_BinMatchFLT( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t TmpID, enum IMPLIB_IPBinMatchMode mode ); /* M_6.3 */ /* M_16.3 */

/* ���K������ */
int32_t implib_SetCorrMode(int32_t SearchMode, int32_t count, float32_t CorrThr); /* M_6.3 */
int32_t implib_DisableCorrMask( void ); /* M_6.3 */
int32_t implib_EnableCorrMask( void ); /* M_6.3 */
int32_t implib_SetCorrBreakThr(int32_t thr); /* M_6.3 */
int32_t implib_DisableCorrBreak( void ); /* M_6.3 */
int32_t implib_EnableCorrBreak( void ); /* M_6.3 */
int32_t implib_SetCorrControl(IMPLIB_IPCorrControl *cnt); /* M_6.3 */
int32_t implib_SetCorrTemplate(IMPLIB_IMGID ImgTmp, int32_t TmpID); /* M_6.3 */
int32_t implib_SetCorrTemplateExt(IMPLIB_IMGID ImgTmp, int32_t TmpID, int32_t xmag, int32_t ymag); /* M_6.3 */
int32_t implib_IP_Corr( IMPLIB_IMGID ImgSrc, int32_t TmpID, IMPLIB_IPCorrTbl Tbl[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_IP_CorrPrecise(IMPLIB_IMGID ImgSrc, int32_t TmpID, int32_t xc, int32_t yc, IMPLIB_IPCorrPreciseTbl *Tbl, enum IMPLIB_IPCorrPreciseOpt opt); /* M_6.3 */
int32_t implib_SetOptFlowMode( enum IMPLIB_Opt_SearchMode SearchMode, IMPLIB_IPFlowSize tempsize, int32_t variance, int32_t thr_c_value );	/* [P2-413] �ǉ� */ /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_OptFlow( IMPLIB_IMGID ImgOld, IMPLIB_IMGID ImgCurrent, int32_t num, IMPLIB_IPFlowPoint Tbl[] );/* [P2-413] �ǉ� */ /* M_6.3 */ /* M_17.4 */
int32_t implib_GetCorrMapSize( IMPLIB_IMGID ImgSrc, int32_t TmpID, int32_t *xlng, int32_t *ylng, int32_t *size );/* [P2-424] �ǉ� */ /* M_6.3 */ /* M_16.3 */
int32_t implib_IP_CorrMap( IMPLIB_IMGID ImgSrc, int32_t TmpID, float32_t pCorrVal[], int32_t cNum );	/* [P2-424] �ǉ� */ /* M_6.3 */ /* M_17.4 */


/* �O���t�B�b�N�X */
int32_t implib_SetDrawMode( IMPLIB_IMGID ImgSrc, enum IMPLIB_DRAW_MODE mode, int32_t color ); /* M_6.3 */ /* M_16.3 */
int32_t implib_SetStringAttributes( enum IMPLIB_STRING_SIZE size, int32_t C_Interval, int32_t L_Interval ); /* M_6.3 */ /* M_16.3 */
int32_t implib_RefreshGraphics( void ); /* M_6.3 */
int32_t implib_DrawString( int32_t x, int32_t y, char_t str[] ); /* M_6.3 */ /* M_17.4 */
int32_t implib_DrawLine( int32_t sx, int32_t sy, int32_t ex, int32_t ey ); /* M_6.3 */ /* M_16.3 */
int32_t implib_DrawSegments( IMPLIB_SEGMENT segments[], int32_t ns ); /* M_6.3 */ /* M_17.4 */
int32_t implib_DrawLines( IMPLIB_POINT points[], int32_t np ); /* M_6.3 */ /* M_17.4 */
int32_t implib_DrawRectangle( int32_t x, int32_t y, int32_t width, int32_t height ); /* M_6.3 */ /* M_16.3 */
int32_t implib_DrawPolygon( IMPLIB_POINT points[], int32_t np ); /* M_6.3 */ /* M_17.4 */
int32_t implib_DrawArc( int32_t x, int32_t y, int32_t width, int32_t height, int32_t angle1, int32_t angle2 ); /* M_6.3 */ /* M_16.3 */

/* �Q�l��臒l�Z�o�x�� */
int32_t implib_HistAnalyze( IMPLIB_HISTANATBL *HistAnaTbl, int32_t lower, int32_t upper);	/* [P2-401] �ǉ� */ /* M_6.3 */ /* M_16.3 */
#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0051] *//*[P5-0007]*/
int32_t implib_HistAnalyze16( IMPLIB_HISTANATBL16 *HistAnaTbl16, int32_t lower, int32_t upper);
#endif

/* �Q�l�摜�̌����� */
int32_t implib_IP_FillHole(IMPLIB_IMGID ImgSrc,IMPLIB_IMGID ImgDst,int32_t opt,int32_t col,IMPLIB_OBJ_AREA_OPT *hole_opt); /* [P3-0020] */

/* ������ */
int32_t implib_ExtractPolyline(IMPLIB_IMGID ImgID,int32_t sx,int32_t sy,int32_t col,int32_t opt,IMPLIB_POLY_TBL* poly,int32_t maxnum); /* [P3-0021] */

/* �G�b�W�R�[�h */
int32_t implib_SetEdgeCodeConfig( enum IMPLIB_ECBinarizeMode ec_opt, enum IMPLIB_ECEdgeMode ec_mode, enum IMPLIB_ECEdgeVolume ec_vol ) ; /* [P3-0008] */
#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)	/* [P4-0052] *//*[P5-0007]*/
int32_t implib_SetEdgeCodeTbl( uint8_t trans_a[], uint16_t trans_b[] ) ;
int32_t implib_IP_EdgeCode( IMPLIB_IMGID ImgSrc, void* EdgeCode, int32_t scale, int32_t COEFF_H[], int32_t COEFF_V[], int32_t thrmin, int32_t thrmax, int32_t EdgeCodeNum, enum IMPLIB_ECBufferMode mode ) ;
#else
int32_t implib_SetEdgeCodeTbl( uint8_t trans_a[], uint8_t trans_b[] ) ; /* [P3-0009] */
int32_t implib_IP_EdgeCode( IMPLIB_IMGID ImgSrc, IMPLIB_IPEdgePoint EdgeCode[], int32_t scale, int32_t COEFF_H[], int32_t COEFF_V[], int32_t thrmin, int32_t thrmax, int32_t EdgeCodeNum, enum IMPLIB_ECBufferMode mode ) ; /* [P3-0011] */
#endif
int32_t implib_IP_EdgeCodeExt( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, int32_t COEFF_H[], int32_t COEFF_V[], int32_t thrmin, int32_t thrmax ) ; /* [P3-0043] */

#if defined(CPU_SHNAVI3) || defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)/*[P5-0007]*/
int32_t implib_IP_TransposeMatrix(IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst);	/* [P4-0034] */
int32_t implib_IP_InnerProduct(IMPLIB_IMGID imgSrc0, IMPLIB_IMGID imgSrc1, IMPLIB_IMGID imgDst, int32_t scale);	/* [P4-0034] */
int32_t implib_IP_ProductMatrix(IMPLIB_IMGID imgSrc0, IMPLIB_IMGID imgSrc1, IMPLIB_IMGID imgDst, int32_t scale);	/* [P4-0034] */
int32_t implib_IP_MeanVector(IMPLIB_IMGID imgSrc, IMPLIB_IMGID imgDst, enum IMPLIB_MEANDIRECT direct );	/* [P4-0034] */
int32_t implib_SetStereoVisionMode(IMPLIB_Stereo_SearchArea SearchArea, IMPLIB_IPFlowSize tempsize, int32_t variance, int32_t thr_c_value, enum IMPLIB_Stereo_SearchMode s_mode);	/* [P4-0040] *//*[P4-0169][M3_16_4]*//* [P4-0517] */
int32_t implib_IP_StereoVision( IMPLIB_IMGID ImgLeft, IMPLIB_IMGID ImgRight, int32_t num, IMPLIB_IPFlowPoint Tbl[]);	/* [P4-0040] */
int32_t implib_IP_StereoVisionPrecise( IMPLIB_IMGID ImgLeft, IMPLIB_IMGID ImgRight, int32_t num, IMPLIB_IPFlowPoint Tbl[], IMPLIB_IPFlowPointPrecise preciseTbl[]);	/* [P4-0040] */
IMPLIB_MODELID implib_CreateStereoVisionModel(IMPLIB_Stereo_SearchArea  SearchArea, IMPLIB_IPFlowSize tempsize, int32_t max_point, enum IMPLIB_Stereo_MatchingMode m_mode, int32_t variance, int32_t thr_c_value, enum IMPLIB_Stereo_SearchMode s_mode);	/* [P4-0040] *//*[P4-0167][M3_16_4]*//* [P4-0517] */
int32_t implib_DeleteStereoVisionModel( IMPLIB_MODELID ModelID );	/* [P4-0040] */
int32_t implib_IP_ExecuteStereoVisionModel( IMPLIB_MODELID ModelID, IMPLIB_IMGID ImgLeft, IMPLIB_IMGID ImgRight, int32_t num, IMPLIB_IPFlowPoint Tbl[]);	/* [P4-0040] */
int32_t implib_IP_CovarianceMatrix( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t scale, enum IMPLIB_COVMTX_INPUTTYPE type );	/* [P4-0042] */
IMPLIB_MODELID implib_CreateSparseOptFlowModel(IMPLIB_SparseOptFlowConfig *config, IMPLIB_SparseOptFlowParam *param, enum IMPLIB_OPTFLOW_METHOD method);	/* [P4-0038] */
int32_t implib_IP_ExecuteSparseOptFlowModel(IMPLIB_MODELID ModelID, IMPLIB_IMGID ImgOld, IMPLIB_IMGID ImgCurrent, int32_t num, IMPLIB_SparseOptFlowPoint Tbl[]);	/* [P4-0038] */
int32_t implib_DeleteSparseOptFlowModel(IMPLIB_MODELID ModelID);	/* [P4-0038] */

int32_t implib_IP_HoughLineVotingSpace( IMPLIB_IMGID CrdX, IMPLIB_IMGID CrdY, IMPLIB_IMGID ImgHist, IMPLIB_HoughLineConfig *config );	/* [P4-0037] *//*[P4-0133][M3_16_4]*/
int32_t implib_IP_HoughLineRhoMap( IMPLIB_IMGID CrdX, IMPLIB_IMGID CrdY, IMPLIB_IMGID RhoMap, IMPLIB_HoughLineConfig *config, int32_t scale );	/* [P4-0037] */
int32_t implib_IP_HistogramByLine( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgHist, IMPLIB_HoughFeatureTbl *FtrTbl, int32_t  startBin, int32_t  endBin, int32_t scale );	/* [P4-0037] */
int32_t implib_IP_FFT1DX(IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgRDst, IMPLIB_IMGID ImgIDst);	/* [P4-0218][M3_8_8]*/
int32_t implib_IP_FFT1DCX(IMPLIB_IMGID ImgRSrc, IMPLIB_IMGID ImgISrc, IMPLIB_IMGID ImgRDst, IMPLIB_IMGID ImgIDst, enum IMPLIB_FFT1D_Scale scale);
int32_t implib_IP_InverseFFT1DX(IMPLIB_IMGID ImgRSrc, IMPLIB_IMGID ImgISrc, IMPLIB_IMGID ImgRDst, enum IMPLIB_FFT1D_Scale scale);
int32_t implib_IP_InverseFFT1DCX(IMPLIB_IMGID ImgRSrc, IMPLIB_IMGID ImgISrc, IMPLIB_IMGID ImgRDst, IMPLIB_IMGID ImgIDst, enum IMPLIB_FFT1D_Scale scale);
#if defined(CPU_RCARV2H)
int32_t implib_IMR_Exec( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, IMPLIB_IMGID DLID );	/* [P4-0218][M3_8_8]*/
#else
int32_t implib_IMR_Exec( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, uint32_t *DLAddr, int32_t DLSize );	/* [P4-0218][M3_8_8]*/
#endif
#endif
#if defined(CPU_SH7766) || defined(CPU_SH7779) || defined(CPU_RCARV2H)/*[P5-0007]*/

int32_t implib_IP_LocalMax( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t mode );	/* [P4-0035] */
int32_t implib_IP_LocalMin( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t mode );	/* [P4-0035] */

int32_t implib_IP_PIS3x3( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0035] */
int32_t implib_IP_PIS5x5( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0035] */
int32_t implib_IP_PIS3x3withThreshold( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t pisthr );	/* [P4-0035] *//*[P4-0155][M3_16_4]*/
int32_t implib_IP_PIS5x5withThreshold( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, int32_t pisthr );	/* [P4-0035] *//*[P4-0155][M3_16_4]*/

int32_t implib_IP_EuclideanDistance( IMPLIB_IMGID imgSrc0, IMPLIB_IMGID imgSrc1, IMPLIB_IMGID imgDst, int32_t scale );	/* [P4-0034] *//*[P4-0166][M3_16_4]*//*[P4-0182][M3_16_4]*/

int32_t implib_IP_IntegralImage( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */
int32_t implib_IP_IntegralImageSquare( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */
int32_t implib_IP_IntegralImageUpTrpz( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */
int32_t implib_IP_IntegralImageLowTrpz( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */
int32_t implib_IP_IntegralImageSquareUpTrpz( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */
int32_t implib_IP_IntegralImageSquareLowTrpz( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */
int32_t implib_IP_IntegralImage45( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */
int32_t implib_IP_IntegralImageSquare45( IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst );	/* [P4-0039] */ /* [P4-0321] */

int32_t implib_IP_HarrisOperatorPrecise(IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, enum IMPLIB_Harris_DiffFlt fltSize, float32_t k);	/* [P4-0043] */
int32_t implib_IP_HarrisOperatorFast(IMPLIB_IMGID ImgSrc, IMPLIB_IMGID ImgDst, enum IMPLIB_Harris_DiffFlt fltSize, float32_t k);	/* [P4-0043] */

int32_t implib_IP_NMS_RT( IMPLIB_IMGID ImgRho, IMPLIB_IMGID ImgTheta, IMPLIB_IMGID ImgDst, IMPLIB_CNVLUT lut[], int32_t thr, int32_t rho_dt );	/* [P4-0036] *//*[P4-0197][M3_5_1]*/
int32_t implib_IP_NMS_EC( IMPLIB_IMGID ImgEC, IMPLIB_IMGID ImgDst, IMPLIB_CNVLUT lut[], int32_t thr, enum IMPLIB_ECEdgeVolume ec_vol, int32_t rho_dt );	/* [P4-0036] *//*[P4-0197][M3_5_1]*/


#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* !__IPXPROT_H__ */
