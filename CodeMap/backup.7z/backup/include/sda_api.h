/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

#ifndef SDA_API_H
#define SDA_API_H

#include "rcvlib_bsd.h"
#include "rcvlib_usr.h"
#ifdef __INTEGRITY
#include "rcv_impdrv.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*!
  @defgroup group_sda_api sda_api (under development)
  @brief Shader Direct Access API "SDA API" (sda_api)
*/
    
struct SHADER_STATUS {
    int a;  
};

#define VUNR_NUM 32
#define PUNR_NUM 128
#define IMG_NUM 16

typedef struct {
    uint32_t val;
    int written; // 0:The register is not set, 1:The register is set.
} RegVal;

/**
  @ingroup group_sda_api
  
  Open SDA API.

  @param[in] rcvdrvctl IMP driver context.
  @return Result of execution.  
  @retval E_OK No error. Normal return.
  @retval Others Other error took place.
  
 */
int sdaOpen(RCvIMPDRVCTL *rcvdrvctl);

    
/**
  @ingroup group_sda_api
  
  Invoke Shader cores with the specified display lists. Return from the function
  after the Shader processing is completed.

  @param[in] rcvdrvctl IMP driver context.
  @param[in] dl_addr Physical address of display lists.
  @return Result of execution.  
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.

  Must call this API after sdaOpen() and before sdaClose().
  This API will be revised to retrieve error status from Shader hardware.
 */
int sdaInvokeShader(RCvIMPDRVCTL *rcvdrvctl, const uint32_t *dl_addr[RCVDRV_SHADER_MODULE_NUM]);

    
/**
  @ingroup group_sda_api
  
  Close SDA API.

  @param[in] rcvdrvctl IMP driver context.
  @return Result of execution.  
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.

  This API will be revised to retrieve error status from Shader hardware.
 */
int sdaClose(RCvIMPDRVCTL *rcvdrvctl);

    
/**
  @ingroup group_sda_api
  
  Check the debugger is attached to the specified Shader core.

  @param[in] Shader core number.
  @return Return whether the Shader core is attached or not.
  @retval true Shader attached.
  @retval false Shader not attached.

 */
bool sdaIsDebuggerAttached(int core);

/**
  @ingroup group_sda_api

  Ingredient to create the display list. The struct is given to sdaCreateDL().

  \attention This sturct is under development.
 */    
typedef struct {
    bool enable_debugger; //! Specify if the debugger is used or not.

    int vtx_so_size; //! Size of Vertex Shader object in quad byte.
    int vtx_stack_size; //! Size of Vertex Shader stack in quad byte.    
    int px_so_size; //! Size of Pixel Shader object in quad byte.
    int px_stack_size; //! Size of Pixel Shader stack in quad byte.    
    
    int width, height; //! Widht and height of the source and destination image.
    
    RegVal VUNR[VUNR_NUM]; //! Uniform region for Vertex Shader.
    RegVal PUNR[PUNR_NUM]; //! Uniform region for Pixel Shader.

    // Address indicated by "_laddr" means the logical address. L to P is done in sdaCreateDL()
    RegVal IMGBAR_laddr[IMG_NUM]; //! IMGBAR register for image IMG_NUM. Logical address is specified.
    RegVal IMGSTR[IMG_NUM]; //! IMGSTR register for image IMG_NUM.
    RegVal IMGCOR[IMG_NUM]; //! IMGCOR register for image IMG_NUM.

    RegVal VPCSAR; //! VPCSAR register.
    RegVal VSINISAR; //! VSINISAR register. 
    RegVal VIBAR_laddr; //! VIBAR register. Logical address is specified.
    RegVal VSBAR_laddr; //! VSBAR register. Logical address is specified.
    RegVal VSAOFSR; //! VSAOFSR register. Logical address is specified.
    RegVal VSMMSR; //! VSMMSR register. Logical address is specified.        

    RegVal PPCSAR; //! PPCSAR register.
    RegVal PSINISAR; //! PSINISAR register.
    RegVal PIBAR_laddr; //! PIBAR register. Logical address is specified.
    RegVal PSBAR_laddr; //! PSBAR register. Logical address is specified.
    RegVal PSAOFSR; //! PSAOFSR register. Logical address is specified.
    RegVal PSMMSR; //! PSMMSR register. Logical address is specified.        
    
} INGREDIENT;


/**
  @ingroup group_sda_api
  
  Create display list made from some informations, eg. image addresses, register configuration,
  addresses for the Shader object, etc. Memory region for the display list is allocated in this
  API. 

  @param[in] ing Ingredient to make the display list. 
  @param[in,out] dl_addr Pointer to an array having addresses of display list. The actual memory
  for this array is allocated in this API.
  @return Result of execution.
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.

  The memory region for display list must be released by sdaFreeDL().
  
  \attention This API is provided as non-guaranteed. User must confirm created display list has
  no problem.
 */
int sdaCreateDL(const INGREDIENT ing, uint32_t **dl_addr);

    
/**
  @ingroup group_sda_api

  Release allocated memory for the display list.

  @param[in] dl_addr Pointer to an array having address of display lists.
  @return Result of execution.
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.
  
  \attention This API is provided as non-guaranteed. User must confirm created display list has
  no problem.
 */
void sdaFreeDL(uint32_t *dl_addr);

    
/**
  @ingroup group_sda_api

  Method to specify value of register as a member of INGREDIENT struct.
  
  @param[in] reg Register name of Shader core.
  @param[in] val Register value.
  @return none 
  
  Some examples;
  
  @code
  sdaSetValToReg(&ing.IMGBAR_laddr[0], (uint32_t)src); // Set source address to IMGBAR register as a logical address.
  sdaSetValToReg(&ing.IMGSTR[0], width*depth*channels); // Set stride of the image 0 to IMGSTR0 register.
  @endcode
  
  \attention This API is provided as non-guaranteed. User must confirm created display list has
  no problem.
 */
void sdaSetValToReg(RegVal *reg, uint32_t val);

#ifdef __cplusplus
}
#endif

#endif /* SDA_API_H */
