/******************************************************************************
IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 

 By downloading, copying, installing or using the software you agree to this license.
 If you do not agree to this license, do not download, install,
 copy or use the software.


                          License Agreement
               For Open Source Computer Vision Library

Copyright (C) 2000-2008, Intel Corporation, all rights reserved.
Copyright (C) 2008-2011, Willow Garage Inc., all rights reserved.
Copyright (C) 2012-2014, Renesas Electronics Corporation, all rights reserved.
Third party copyrights are property of their respective owners.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

  * The name of the copyright holders may not be used to endorse or promote products
    derived from this software without specific prior written permission.

This software is provided by the copyright holders and contributors "as is" and
any express or implied warranties, including, but not limited to, the implied
warranties of merchantability and fitness for a particular purpose are disclaimed.
In no event shall the Intel Corporation or contributors be liable for any direct,
indirect, incidental, special, exemplary, or consequential damages
(including, but not limited to, procurement of substitute goods or services;
loss of use, data, or profits; or business interruption) however caused
and on any theory of liability, whether in contract, strict liability,
or tort (including negligence or otherwise) arising in any way out of
the use of this software, even if advised of the possibility of such damage.
     $Revision: 438 $*//* PRQA S 0292 *//*
******************************************************************************/
#ifndef RCVLIB_DEFINE_H
#define RCVLIB_DEFINE_H

#ifdef __cplusplus
extern "C" {
#endif


#include <stddef.h>

#include "rcvlib_types.h"
#include "rcvlib_usr.h"
#include "rcv_define_conf.h"

typedef void RCvArr;

/* IPL depth */
#define RIPL_DEPTH_SIGN		(0x80000000U)
#define RIPL_DEPTH_8U	(8L)
#define RIPL_DEPTH_8S	(-2147483640L)	/* (RIPL_DEPTH_SIGN | 8L)  */
#define RIPL_DEPTH_16S	(-2147483632L)	/* (RIPL_DEPTH_SIGN | 16L) */
#define RIPL_DEPTH_32S	(-2147483616L)	/* (RIPL_DEPTH_SIGN | 32L) */
#define RIPL_DEPTH_32F	(32L)
#define RIPL_DEPTH_64F	(64L)

/* depth */
#define RCV_CN_SHIFT	(3)
#define RCV_8U		(0)
#define RCV_8S		(1)
#define RCV_16U		(2)
#define RCV_16S		(3)
#define RCV_32S		(4)
#define RCV_32F		(5)
#define RCV_64F		(6)

/* element type */
#define RCV_8UC1	(RCV_8U | ( 0 << RCV_CN_SHIFT ))
#define RCV_8UC2	(RCV_8U | ( 1 << RCV_CN_SHIFT ))
#define RCV_8UC3	(RCV_8U | ( 2 << RCV_CN_SHIFT ))
#define RCV_8UC4	(RCV_8U | ( 3 << RCV_CN_SHIFT ))
#define RCV_8SC1	(RCV_8S | ( 0 << RCV_CN_SHIFT ))
#define RCV_8SC2	(RCV_8S | ( 1 << RCV_CN_SHIFT ))
#define RCV_8SC3	(RCV_8S | ( 2 << RCV_CN_SHIFT ))
#define RCV_8SC4	(RCV_8S | ( 3 << RCV_CN_SHIFT ))
#define RCV_16SC1	(RCV_16S | ( 0 << RCV_CN_SHIFT ))
#define RCV_16SC2	(RCV_16S | ( 1 << RCV_CN_SHIFT ))
#define RCV_16SC3	(RCV_16S | ( 2 << RCV_CN_SHIFT ))
#define RCV_16SC4	(RCV_16S | ( 3 << RCV_CN_SHIFT ))
#define RCV_32SC1	(RCV_32S | ( 0 << RCV_CN_SHIFT ))
#define RCV_32SC2	(RCV_32S | ( 1 << RCV_CN_SHIFT ))
#define RCV_32SC3	(RCV_32S | ( 2 << RCV_CN_SHIFT ))
#define RCV_32SC4	(RCV_32S | ( 3 << RCV_CN_SHIFT ))
#define RCV_32FC1	(RCV_32F | ( 0 << RCV_CN_SHIFT ))
#define RCV_32FC2	(RCV_32F | ( 1 << RCV_CN_SHIFT ))
#define RCV_32FC3	(RCV_32F | ( 2 << RCV_CN_SHIFT ))
#define RCV_32FC4	(RCV_32F | ( 3 << RCV_CN_SHIFT ))
#define RCV_64FC1	(RCV_64F | ( 0 << RCV_CN_SHIFT ))
#define RCV_64FC2	(RCV_64F | ( 1 << RCV_CN_SHIFT ))
#define RCV_64FC3	(RCV_64F | ( 2 << RCV_CN_SHIFT ))
#define RCV_64FC4	(RCV_64F | ( 3 << RCV_CN_SHIFT ))
#define RCV_8UC2_YUV422	( 4 << RCV_CN_SHIFT )

/* image data order */
#define RIPL_DATA_ORDER_PIXEL  (0)
#define RIPL_DATA_ORDER_PLANE  (1)

/* image origin */
#define RIPL_ORIGIN_TL  (0)

/* step in RCvMat */
#define RCV_AUTOSTEP  (0x7fffffff)

/* special 'channels' value in rcvInitImageHeader() to create YUV4:2:2 images */
#define RCV_CHANNELS_YUV422		(422)

/* color conversion */
#define RCV_BGR2GRAY    (6)
#define RCV_GRAY2BGR    (8)
#define RCV_BGR2YCrCb   (36)
#define RCV_YCrCb2BGR   (38)
#define RCV_BGR2HSV     (40)
#define RCV_HSV2BGR     (54)
#define RCV_BGR2YUV422  (98)
#define RCV_YUV4222BGR  (99)

/* smooth type */
#define RCV_GAUSSIAN	(2)
#define RCV_MEDIAN		(3)

/* Interpolation method */
#define RCV_INTER_NN		(0)
#define RCV_INTER_LINEAR	(1)
#define RCV_INTER_CUBIC		(2)

/* image warping flags */
#define RCV_WARP_FILL_OUTLIERS	(8)
#define RCV_WARP_INVERSE_MAP	(16)

/* shape of the structuring element */
#define RCV_SHAPE_RECT	(0)
#define RCV_SHAPE_CROSS	(1)

/* slice parameter */
#define RCV_WHOLE_SEQ_END_INDEX	(0x3fffffff)
#define RCV_WHOLE_SEQ	(rcvSlice(0, RCV_WHOLE_SEQ_END_INDEX))

/* fields of sequence structure */
#define RCV_SEQUENCE_FIELDS()	\
	RCvS32 magicCode;	\
	RCvS32 flags;		\
	RCvS32 header_size;	\
	struct ST_RCvSeq* h_prev;	\
	struct ST_RCvSeq* h_next;	\
	struct ST_RCvSeq* v_prev;	\
	struct ST_RCvSeq* v_next;	\
	RCvS32 total;	\
	RCvS32 elem_size;	\
	RCvS8* block_max;	\
	RCvS8* ptr;	\
	RCvS32 delta_elems;	\
	RCvMemStorage* storage;	\
	RCvSeqBlock* free_blocks;	\
	RCvSeqBlock* first;		/* PRQA S 3412 */

/* fields of sequence writer */
#define RCV_SEQ_WRITER_FIELDS() \
	RCvS32       header_size; \
	RCvSeq*      seq;         \
	RCvSeqBlock* block;       \
	RCvS8*       ptr;         \
	RCvS8*       block_min;   \
	RCvS8*       block_max;   \
	RCvS32       error;		/* PRQA S 3412 */

/* fields of sequence reader */
#define RCV_SEQ_READER_FIELDS()	\
	RCvS32       header_size;	\
	RCvSeq*      seq;        \
	RCvSeqBlock* block; \
	RCvS8*       ptr;         \
	RCvS8*       block_min;   \
	RCvS8*       block_max;   \
	RCvS32       delta_index; \
	RCvS8*       prev_elem;		/* PRQA S 3412 */

/* write sequence element */
#define RCV_WRITE_SEQ_ELEM( elem, writer ) \
do{ \
	if( (writer).ptr >= (writer).block_max ) \
	{ \
		rcvCreateSeqBlock( &(writer) ); \
		if( (writer).error == 1 )	\
		{	\
			break;	\
		}	\
	} \
	RCV_CFG_MEMCPY( (writer).ptr, &(elem), sizeof(elem) ); \
	(writer).ptr += sizeof(elem); \
}while(0)

#define RCV_WRITE_SEQ_ELEM_PNT( elem, writer ) \
do{ \
	if( (writer).ptr >= (writer).block_max ) \
	{ \
		rcvCreateSeqBlock( &(writer) ); \
		if( (writer).error == 1 )	\
		{	\
			break;	\
		}	\
	} \
	((RCvPoint*)((writer).ptr))->x = (elem).x;	\
	((RCvPoint*)((writer).ptr))->y = (elem).y;	\
	(writer).ptr += sizeof(elem); \
}while(0)

/* move reader position forward/backward */
#define RCV_NEXT_SEQ_ELEM( elem_size, reader ) \
do{ \
	(reader).ptr += (elem_size); \
	if( (reader).ptr >= (reader).block_max ) \
	{ \
		rcvChangeSeqBlock( &(reader), 1 ); \
	}\
}while(0)

#define RCV_PREV_SEQ_ELEM( elem_size, reader ) \
do{ \
	(reader).ptr -= (elem_size); \
	if( (reader).ptr < (reader).block_min ) \
	{ \
		rcvChangeSeqBlock( &(reader), -1 ); \
	} \
}while(0)

/* read sequence element */
#define RCV_READ_SEQ_ELEM( elem, reader ) \
do{ \
	RCV_CFG_MEMCPY( &(elem), (reader).ptr, sizeof((elem)) ); \
	RCV_NEXT_SEQ_ELEM( sizeof(elem), reader ); \
}while(0)

#define RCV_REV_READ_SEQ_ELEM( elem, reader ) \
do{ \
	RCV_CFG_MEMCPY( &(elem), (reader).ptr, sizeof((elem)) ); \
	RCV_PREV_SEQ_ELEM( sizeof(elem), reader ); \
}while(0)

#define RCV_READ_SEQ_ELEM_PNT( elem, reader ) \
do{ \
	(elem).x = ((RCvPoint*)((reader).ptr))->x;	\
	(elem).y = ((RCvPoint*)((reader).ptr))->y;	\
	RCV_NEXT_SEQ_ELEM( sizeof(elem), reader ); \
}while(0)

#define RCV_REV_READ_SEQ_ELEM_PNT( elem, reader ) \
do{ \
	(elem).x = ((RCvPoint*)((reader).ptr))->x;	\
	(elem).y = ((RCvPoint*)((reader).ptr))->y;	\
	RCV_PREV_SEQ_ELEM( sizeof(elem), reader ); \
}while(0)

/* sequence flags */
#define RCV_SEQ_ELTYPE_BITS		(12)
#define RCV_SEQ_KIND_BITS		(2)
/* types of sequences */
#define RCV_SEQ_ELTYPE_POINT	(RCV_32SC2)
#define RCV_SEQ_ELTYPE_GENERIC	(0)
/* kinds of sequences */
#define RCV_SEQ_KIND_GENERIC	(0 << RCV_SEQ_ELTYPE_BITS)
#define RCV_SEQ_KIND_CURVE		(1 << RCV_SEQ_ELTYPE_BITS)
/* flags for curves */
#define RCV_SEQ_FLAG_CLOSED		(1 << (RCV_SEQ_KIND_BITS + RCV_SEQ_ELTYPE_BITS))
#define RCV_SEQ_FLAG_HOLE		(2 << (RCV_SEQ_KIND_BITS + RCV_SEQ_ELTYPE_BITS))
/* sets of sequence flags */
#define RCV_SEQ_POLYLINE		(RCV_SEQ_KIND_CURVE  |  RCV_SEQ_ELTYPE_POINT)
#define RCV_SEQ_POLYGON			(RCV_SEQ_FLAG_CLOSED  |  RCV_SEQ_POLYLINE)		/* e.g. FindContours */
#define RCV_SEQ_32SC4_SET		(RCV_SEQ_KIND_GENERIC| RCV_32SC4)	/* e.g. HoughLine2 (x,y,x,y)*/
#define RCV_SEQ_32FC2_SET		(RCV_SEQ_KIND_GENERIC| RCV_32FC2)	/* e.g. HoughLine2 (p,theta)*/
#define RCV_SEQ_32FC3_SET		(RCV_SEQ_KIND_GENERIC| RCV_32FC3)	/* e.g. HoughCircle */
#define RCV_SEQ_GENERIC			(RCV_SEQ_KIND_GENERIC| RCV_SEQ_ELTYPE_GENERIC)	/* e.g. sequence of RCvKeyPoint */

/* retrieval mode */
#define RCV_RETR_EXTERNAL	(0)
#define RCV_RETR_LIST		(1)
#define RCV_RETR_TREE		(3)

/* approximation method */
#define RCV_CHAIN_APPROX_NONE	(1)
#define RCV_CHAIN_APPROX_SIMPLE	(2)

/* contour approximation method */
#define RCV_POLY_APPROX_DP	(0)

/* line type */
#define RCV_AA		(16)

/* DFT flag */
#define RCV_DXT_FORWARD		(0)
#define RCV_DXT_INVERSE		(1)
#define RCV_DXT_SCALE		(2)

/* MulSpectrums flag */
#define RCV_DXT_MUL_CONJ	(8)

/* threshold type */
typedef enum {
	RCV_THRESH_BINARY			= 0,
	RCV_THRESH_BINARY_INV		= 1,
	RCV_THRESH_TRUNC			= 2,
	RCV_THRESH_TOZERO			= 3,
	RCV_THRESH_TOZERO_INV		= 4,
	RCV_THRESH_MASK				= 7,
	RCV_THRESH_OTSU				= 8
} RCvThresholdType;

/* Adaptive threshold methods */
typedef enum {
	RCV_ADAPTIVE_THRESH_MEAN_C		= 0,
	RCV_ADAPTIVE_THRESH_GAUSSIAN_C	= 1
} RCvAdaptiveThresholdMethod;

/* template match method */
typedef enum {
	RCV_TM_SQDIFF			= 0,
	RCV_TM_SQDIFF_NORMED,
	RCV_TM_CCORR,
	RCV_TM_CCORR_NORMED,
	RCV_TM_CCOEFF,
	RCV_TM_CCOEFF_NORMED
} RCvTemplateMatchMethod;

/* Maximum value of dimensions */
#define RCV_HIST_MAX_DIM	(2)

/* Histogram array type */
#define RCV_HIST_ARRAY	(0)

/* Operation flags */
#define RCV_GEMM_A_T	(1)
#define RCV_GEMM_B_T	(2)
#define RCV_GEMM_C_T	(4)

/* Inversion method */
typedef enum {
	RCV_LU		 = 0,
	RCV_SVD		 = 1,
	RCV_EIG		 = 2,
	RCV_CHOLESKY = 3,
	RCV_QR		 = 4,
	RCV_NORMAL	 = 16
} RCvInversionMethod;

#define RCV_INVERT_LU		RCV_LU
#define RCV_INVERT_SVD		RCV_SVD
#define RCV_INVERT_CHOLESKY	RCV_CHOLESKY

/* SVD flags */
#define RCV_SVD_MODIFY_A	(1)
#define RCV_SVD_U_T			(2)
#define RCV_SVD_V_T			(4)

/* type of RCvTermCriteria */
#define RCV_TERMCRIT_ITER		(1)
#define RCV_TERMCRIT_NUMBER		RCV_TERMCRIT_ITER
#define RCV_TERMCRIT_EPS		(2)

/* method of Hough Transform */
#define RCV_HOUGH_STANDARD		(0)
#define RCV_HOUGH_PROBABILISTIC	(1)
#define RCV_HOUGH_MULTI_SCALE	(2)
#define RCV_HOUGH_GRADIENT		(3)

/* aperture type Sobel */
#define RCV_SCHARR			(-1)

/* filter type PyrUp,PyrDown  */
#define RCV_GAUSSIAN_5x5	(7)

/* filter border type  */
#define RCV_BORDER_CONSTANT   (0)
#define RCV_BORDER_REPLICATE  (1)
#define RCV_BORDER_REFLECT    (2)
#define RCV_BORDER_WRAP       (3)

/* compare hist method type  */
#define RCV_COMP_CORREL			(0)
#define RCV_COMP_CHISQR			(1)
#define RCV_COMP_INTERSECT		(2)
#define RCV_COMP_BHATTACHARYYA	(3)

/* norm type */
#define RCV_C			(1)
#define RCV_L1			(2)
#define RCV_L2			(4)
#define RCV_RELATIVE_C	(9)
#define RCV_RELATIVE_L1	(10)
#define RCV_RELATIVE_L2	(12)
#define RCV_MINMAX		(32)

/* flags of calculate covarient matrix */
#define RCV_COVAR_SCRAMBLED	(0)
#define RCV_COVAR_NORMAL	(1)
#define RCV_COVAR_USE_AVG	(2)
#define RCV_COVAR_SCALE		(4)
#define RCV_COVAR_ROWS		(8)
#define RCV_COVAR_COLS		(16)

/* reduction operation */
#define RCV_REDUCE_SUM	(0)
#define RCV_REDUCE_AVG	(1)
#define RCV_REDUCE_MAX	(2)
#define RCV_REDUCE_MIN	(3)

/* flags of CalcOpticalFlowPyrLK */
#define RCV_LKFLOW_PYR_A_READY		(1)
#define RCV_LKFLOW_PYR_B_READY		(2)
#define RCV_LKFLOW_INITIAL_GUESSES	(4)

/* Method for computing the fundamental matrix */
#define RCV_FM_7POINT	(1)
#define RCV_FM_8POINT	(2)
#define RCV_FM_LMEDS	(4)
#define RCV_FM_RANSAC	(8)

/* preset of FindStereoCorrespondenceBM */
#define RCV_STEREO_BM_BASIC		(0)
#define RCV_STEREO_BM_FISH_EYE	(1)
#define RCV_STEREO_BM_NARROW	(2)

#define RCV_STEREO_BM_NORMALIZED_RESPONSE	(0)
#define RCV_STEREO_BM_XSOBEL				(1)


/*************************************************************
 *   Structure definition
 *************************************************************/

typedef struct ST_RCvRect {
	RCvS32 x;
	RCvS32 y;
	RCvS32 width;
	RCvS32 height;
} RCvRect ;

typedef struct ST_RCvPoint {
	RCvS32 x;
	RCvS32 y;
} RCvPoint ;

typedef struct ST_RCvPoint2D32f {
	RCvF32 x;
	RCvF32 y;
} RCvPoint2D32f ;

typedef struct ST_RCvPoint2D64f {
	RCvF64 x;
	RCvF64 y;
} RCvPoint2D64f ;

typedef struct ST_RCvSize {
	RCvS32 width;
	RCvS32 height;
} RCvSize ;

typedef struct ST_RCvScalar {
	RCvF64 val[4];
} RCvScalar ;

typedef struct ST_RIplROI {
	RCvS32 xOffset;
	RCvS32 yOffset;
	RCvS32 width;
	RCvS32 height;
} RIplROI ;

typedef struct ST_RIplImage {
	RCvS32 magicCode;
	RCvS32 nChannels;
	RCvS32 depth;
	RCvS32 dataOrder;
	RCvS32 origin;
	RCvS32 width;
	RCvS32 height;
	RIplROI roi;
	RCvS32 imageSize;
	RCvS8* imageData;
	RCvS8* imageData2;
	RCvS32 widthStep;
	RCvS8* imageDataOrigin;
	RCvS8* imageDataOrigin2;
} RIplImage ;

typedef struct ST_RCvMat {
	RCvS32 magicCode;
	RCvS32 type;
	RCvS32 step;
	RCvS32 refcount;

	/* not use union */
	struct st_data {
		RCvU8*  ptr;
		RCvS16* s;
		RCvS32* i;
		RCvF32* fl;
		RCvF64* db;
	} data;

	RCvS32 rows;
	RCvS32 cols;
} RCvMat ;

typedef struct ST_RCvMemBlock {
	struct ST_RCvMemBlock* prev;
	struct ST_RCvMemBlock* next;
} RCvMemBlock ;

typedef struct ST_RCvMemStorage {
	RCvS32 magicCode;
	RCvMemBlock* bottom;
	RCvMemBlock* top;
	struct ST_RCvMemStorage* parent;
	RCvS32 block_size;
	RCvS32 free_space;
} RCvMemStorage ;

typedef struct ST_RIplConvKernel {
	RCvS32 nCols;
	RCvS32 nRows;
	RCvS32 anchorX;
	RCvS32 anchorY;
	RCvS32 *values;
	RCvS32 nShiftR;
} RIplConvKernel ;

typedef struct ST_RCvSeqBlock {
	struct ST_RCvSeqBlock* prev;
	struct ST_RCvSeqBlock* next;
	RCvS32 start_index;
	RCvS32 count;
	RCvS8* data;
} RCvSeqBlock ;

typedef struct ST_RCvSeq {
	RCV_SEQUENCE_FIELDS()
} RCvSeq ;

typedef struct ST_RCvContour {
	RCV_SEQUENCE_FIELDS()
	RCvRect rect;
	RCvS32 color;
	RCvS32 reserved[3];
} RCvContour ;

typedef struct ST_RCvSeqWriter {
	RCV_SEQ_WRITER_FIELDS()
} RCvSeqWriter ;

typedef struct ST_RCvSeqReader {
	RCV_SEQ_READER_FIELDS()
} RCvSeqReader ;

typedef struct ST_RCvSlice {
	RCvS32 start_index;
	RCvS32 end_index;
} RCvSlice ;

typedef struct ST_RCvMoments {
	RCvF64 m00, m10, m01, m20, m11, m02, m30, m21, m12, m03;
	RCvF64 mu20, mu11, mu02, mu30, mu21, mu12, mu03;
	RCvF64 inv_sqrt_m00;
} RCvMoments ;

/* pointer to inner structure */
typedef void* RCvContourScanner;

typedef struct ST_RCvHistogram
{
	RCvS32   type;
	RCvArr*  bins;
	RCvF32   thresh[RCV_HIST_MAX_DIM][2];
	RCvF32** thresh2;
	RCvMat   mat;
} RCvHistogram ;

/* Termination criteria for iterative algorithms */
typedef struct ST_RCvTermCriteria
{
	RCvS32 type;
	RCvS32 max_iter;
	RCvF64 epsilon;
}RCvTermCriteria ;

/* StereoBM status */
typedef struct ST_RCvStereoBMState
{
	RCvS32 preFilterType;
	RCvS32 preFilterSize;
	RCvS32 preFilterCap;
	RCvS32 SADWindowSize;
	RCvS32 minDisparity;
	RCvS32 numberOfDisparities;
	RCvS32 textureThreshold; 
	RCvS32 uniquenessRatio; 
	RCvS32 speckleWindowSize; 
	RCvS32 speckleRange; 
	RCvS32 trySmallerWindows;
	RCvRect roi1;
	RCvRect roi2;
	RCvS32 disp12MaxDiff;
	RCvMat* preFilteredImg0;
	RCvMat* preFilteredImg1;
	RCvMat* slidingSumBuf;
	RCvMat* cost;
	RCvMat* disp;
} RCvStereoBMState;

/* Params for Feature detection and description */
typedef struct ST_RCvDetectorParams {
	RCvS32 flags; 
	RCvF64 respThreshold;
	RCvF64 diffThreshold;
	RCvS32 nOctaves;
	RCvS32 nOctaveLayers;
} RCvDetectorParams;

/* Keypoint for Feature detection and description */
typedef struct ST_RCvKeyPoint{
	RCvPoint2D32f pt;
	RCvS32 class_id;
	RCvF32 size; 
	RCvF32 angle; 
	RCvF32 response;
	RCvS32 octave; 
	RCvS32 reserved;
} RCvKeyPoint;


#ifdef __cplusplus
}
#endif


#endif	/* RCVLIB_DEFINE_H */
