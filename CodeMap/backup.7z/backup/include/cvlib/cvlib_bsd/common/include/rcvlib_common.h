#ifndef RCVLIB_COMMON_H
#define RCVLIB_COMMON_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvlib_common.h
*/
/* PRQA S 0292 1 */
/* $Revision: 173 $
******************************************************************************/

#include "rcvlib_bsd.h"
#include "rcvcm.h"

/*************************************************************
 *   Constant Value Definitions
 *************************************************************/
#define RCV_VERSION			(0x10000104)
	/***********************************
	 * version number format 0xABBBCCDD
	 *   A  : Major version
	 *   BBB: Minor version
	 *   CC : Build version
	 *   DD : Classification code (constant 04)
	 ***********************************/
	 
/* magic code */
#define RCV_MAGIC_CODE_IMG		(0x474d4952)	/* RIMG */
#define RCV_MAGIC_CODE_MAT		(0x54414d52)	/* RMAT */
#define RCV_MAGIC_CODE_SEQ		(0x51455352)	/* RSEQ */
#define RCV_MAGIC_CODE_MES		(0x53454d52)	/* RMES */


#define RCV_MAT_TYPE_MASK		(CV_DEPTH_MAX*CV_CN_MAX - 1)

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCvS32
rcv_getMatChannels(
	RCvS32 mat_type);

RCvS32
rcv_getMatElemSize(
	RCvS32 mat_type);

RCvExErrorCode 
rcv_convertReturnCode(
	RCVCM_Ret cmRet);

RCvExErrorCode
rcv_convertImgToCM(
	const RIplImage* img,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertImgToCM_C2(
	const RIplImage* img,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertImgToCM_64F(
	const RIplImage* img,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertImgToCM_64FC2(
	const RIplImage* img,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertMatToCM(
	const RCvMat* mat,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertMatToCM_C2(
	const RCvMat* mat,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertMatToCM_64F(
	const RCvMat* mat,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode 
rcv_convertMatToCM_64FC2(
	const RCvMat* mat,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertArrToCM(
	const RCvArr* arr,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertArrToCM_C2(
	const RCvArr* arr,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_convertArrToCM_64F(
	const RCvArr* arr,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode 
rcv_convertArrToCM_64FC2(
	const RCvArr* arr,
	RCVCM_Image* cm_img,
	RCvExErrorCode allocCheck);

RCvExErrorCode
rcv_arrToImage(
	const RCvArr* arr,
	RCVCM_Image* cm_img);

RCvU32
rcv_calcAlign(
	RCvU32	val,
	RCvU32	align);

RCvExErrorCode
rcv_convKernelToCM(
	const RIplConvKernel* element,
	RCVCM_ConvKernel* cm_kernel );

void
rcv_initialize_memstorage_cb_funcs( RCVCM_MEMSTORAGE_CB_FUNCS* memst_cb );
void
rcv_initialize_seq_cb_funcs( RCVCM_SEQ_CB_FUNCS* seq_cb );

#ifdef __cplusplus
}
#endif

#endif /* #ifndef RCVLIB_COMMON_H */
