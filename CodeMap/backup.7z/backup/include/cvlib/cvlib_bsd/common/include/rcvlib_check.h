#ifndef RCVLIB_CHECK_H
#define RCVLIB_CHECK_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvlib_check.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/

#include "rcvlib_types.h"
#include "rcv_define.h"


/*************************************************************
 *   Constant Value Definitions
 *************************************************************/
/* check mode of RCV_EC_NG_ARG_ARRUNMATCH */
#define	RCV_CHECKMODE_ROI		(0x01)
#define	RCV_CHECKMODE_CHANNELS	(0x02)
#define	RCV_CHECKMODE_DEPTH		(0x04)
#define	RCV_CHECKMODE_TYPE		RCV_CHECKMODE_DEPTH
#define	RCV_CHECKMODE_SIZE		(0x08)
#define	RCV_CHECKMODE_SIZE2		(0x10)


/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCvExErrorCode 
rcv_checkArr(
	const RCvArr* arr);

RCvExErrorCode 
rcv_checkArrImg(
	const RCvArr* arr);

RCvExErrorCode 
rcv_checkArrMat(
	const RCvArr* arr);

RCvExErrorCode 
rcv_checkArrSeq(
	const RCvArr* arr);

RCvExErrorCode 
rcv_checkArrMemStorage(
	const RCvArr* arr);

RCvExErrorCode
rcv_checkImgYUV422(
	const RIplImage* img);

RCvExErrorCode 
rcv_checkImg(
	const RIplImage* img);

RCvExErrorCode 
rcv_checkImgC2(
	const RIplImage* img);

RCvExErrorCode 
rcv_checkImg64F(
	const RIplImage* img);

RCvExErrorCode 
rcv_checkImg64FC2(
	const RIplImage* img);

RCvExErrorCode
rcv_checkImgMask(
	const RIplImage* mask,
	const RIplROI* roi);

RCvExErrorCode
rcv_checkImgAlloc(
	const RIplImage* img);

RCvExErrorCode
rcv_checkImgNotAlloc(
	const RIplImage* img);

RCvExErrorCode
rcv_checkImgUnmatch(
	const RIplImage* img1,
	const RIplImage* img2,
	RCvU32 checkMode);

RCvExErrorCode 
rcv_checkCmYUV422(
	const RCVCM_Image* img);

RCvExErrorCode
rcv_checkCmUnmatch(
	const RCVCM_Image* img1,
	const RCVCM_Image* img2,
	RCvU32 checkMode);

RCvExErrorCode 
rcv_checkCmMask(
	const RCVCM_Image* mask,
	const RCVCM_Image* image);

RCvExErrorCode 
rcv_checkMat(
	const RCvMat* mat);

RCvExErrorCode 
rcv_checkMatAlloc(
	const RCvMat* mat);

RCvExErrorCode 
rcv_checkMatNotAlloc(
	const RCvMat* mat);

RCvExErrorCode
rcv_checkEven(
	RCvU32	val);

RCvExErrorCode
rcv_checkPowerOf2(
	RCvU32	val);

RCvExErrorCode 
rcv_checkSeq(
	const RCvSeq* seq,
	const RCvS32 bCheckDeltaElems);

#ifdef __cplusplus
}
#endif

#endif /* #ifndef RCVLIB_CHECK_H */
