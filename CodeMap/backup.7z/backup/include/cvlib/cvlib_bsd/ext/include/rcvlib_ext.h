#ifndef RCVLIB_EXT_H
#define RCVLIB_EXT_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvlib_ext.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvlib_bsd.h"

/**************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/* labeling */
#define RCV_LABEL_OBJ		(0)
#define RCV_LABEL_BKG		(1)

#define RCV_LABEL_SORT_DESCENDING	(0)
#define RCV_LABEL_SORT_ASCENDING	(1)
#define RCV_LABEL_SORT_NONE			(2)


/***************************************
 * Extension
 ***************************************/

RCvS32	rcvExGetVersion(
    void
    );

RIplImage*	rcvExCreateImage(
	RCvSize size,
	RCvS32 depth,
	RCvS32 channels,
	void* data,
	void* data2
	);

RCvS32 rcvExLabeling(
	const RCvArr* src,
	RCvArr* dst,
	RCvS32 connect,
	RCvS32 opt);

RCvS32 rcvExLabelingAreaFilter(
	const RCvArr* src,
	RCvArr* dst,
	RCvS32 connect,
	RCvS32 thmin,
	RCvS32 thmax,
	RCvS32 opt1,
	RCvS32 opt2);

void rcvExGetLabelRegionX(
	const RCvArr* src,
	RCvS32* minX,
	RCvS32* maxX);

void rcvExGetLabelRegionY(
	const RCvArr* src,
	RCvS32* minY,
	RCvS32* maxY);

void rcvExGetLabelArea(
	const RCvArr* src,
	RCvS32* area);

void rcvExGetLabelGravity(
	const RCvArr* src,
	RCvPoint2D32f* gravity);

void rcvExPointUndistort(
	const RCvPoint2D32f* src,
	RCvPoint2D32f* dst,
	const RCvMat* distortion,
	RCvF64 err
	);


#ifdef __cplusplus
}
#endif


#endif  /* RCVLIB_EXT_H */
