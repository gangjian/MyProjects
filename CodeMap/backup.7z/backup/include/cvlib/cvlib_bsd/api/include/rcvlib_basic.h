/******************************************************************************
IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 

 By downloading, copying, installing or using the software you agree to this license.
 If you do not agree to this license, do not download, install,
 copy or use the software.


                          License Agreement
               For Open Source Computer Vision Library

Copyright (C) 2000-2008, Intel Corporation, all rights reserved.
Copyright (C) 2008-2011, Willow Garage Inc., all rights reserved.
Copyright (C) 2012-2014, Renesas Electronics Corporation, all rights reserved.
Third party copyrights are property of their respective owners.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

  * The name of the copyright holders may not be used to endorse or promote products
    derived from this software without specific prior written permission.

This software is provided by the copyright holders and contributors "as is" and
any express or implied warranties, including, but not limited to, the implied
warranties of merchantability and fitness for a particular purpose are disclaimed.
In no event shall the Intel Corporation or contributors be liable for any direct,
indirect, incidental, special, exemplary, or consequential damages
(including, but not limited to, procurement of substitute goods or services;
loss of use, data, or profits; or business interruption) however caused
and on any theory of liability, whether in contract, strict liability,
or tort (including negligence or otherwise) arising in any way out of
the use of this software, even if advised of the possibility of such damage.
     $Revision: 286 $*//* PRQA S 0292 *//*
******************************************************************************/
#ifndef RCVLIB_BASIC_H
#define RCVLIB_BASIC_H


#ifdef __cplusplus
extern "C" {
#endif


/***************************************
 * Basic functions
 ***************************************/

RCvRect	rcvRect(
	RCvS32 x,
	RCvS32 y,
	RCvS32 width,
	RCvS32 height
	);

RCvPoint	rcvPoint(
	RCvS32 x,
	RCvS32 y
	);

RCvPoint2D32f	rcvPoint2D32f(
	RCvF32 x,
	RCvF32 y
	);

RCvSize	rcvSize(
	RCvS32 width,
	RCvS32 height
	);

RCvScalar	rcvScalar(
	RCvF64 val0,
	RCvF64 val1,
	RCvF64 val2,
	RCvF64 val3
	);

RCvSlice	rcvSlice(
	RCvS32 start,
	RCvS32 end
	);

RIplImage*	rcvCreateImageHeader(
	RCvSize size,
	RCvS32 depth,
	RCvS32 channels
	);

RIplImage*	rcvInitImageHeader(
	RIplImage* image,
	RCvSize size,
	RCvS32 depth,
	RCvS32 channels,
	RCvS32 origin,
	RCvS32 align
	);

RIplImage*	rcvCreateImage(
	RCvSize size,
	RCvS32 depth,
	RCvS32 channels
	);

void	rcvReleaseImageHeader(
	RIplImage** image
	);

void	rcvReleaseImage(
	RIplImage** image
	);

void	rcvSetImageROI(
	RIplImage* image,
	RCvRect rect
	);

void	rcvResetImageROI(
	RIplImage* image
	);

RCvRect	rcvGetImageROI(
	const RIplImage* image
	);

RIplImage*	rcvCloneImage(
	const RIplImage* image
	);

RCvMat*	rcvCreateMatHeader(
	RCvS32 rows,
	RCvS32 cols,
	RCvS32 type
	);

RCvMat*	rcvInitMatHeader(
	RCvMat* mat,
	RCvS32 rows,
	RCvS32 cols,
	RCvS32 type,
	void* data,
	RCvS32 step
	);

RCvMat*	rcvCreateMat(
	RCvS32 rows,
	RCvS32 cols,
	RCvS32 type
	);

void	rcvReleaseMat(
	RCvMat** mat
	);

RCvMat*	rcvGetSubRect(
	const RCvArr* arr,
	RCvMat* submat,
	RCvRect rect
	);

RCvMat*	rcvCloneMat(
	const RCvMat* mat
	);

RCvS32	rcvGetElemType(
	const RCvArr* arr
	);

RCvScalar	rcvGet1D(
	const RCvArr* arr,
	RCvS32 idx0
	);

RCvScalar	rcvGet2D(
	const RCvArr* arr,
	RCvS32 idx0,
	RCvS32 idx1
	);

RCvF64	rcvGetReal2D(
	const RCvArr* arr,
	RCvS32 idx0,
	RCvS32 idx1
	);

void	rcvSet1D(
	RCvArr* arr,
	RCvS32 idx0,
	RCvScalar value
	);

void	rcvSet2D(
	RCvArr* arr,
	RCvS32 idx0,
	RCvS32 idx1,
	RCvScalar value
	);

void	rcvSetReal2D(
	RCvArr* arr,
	RCvS32 idx0,
	RCvS32 idx1,
	RCvF64 value
	);

void	rcvCreateData(
	RCvArr* arr
	);

void	rcvReleaseData(
	RCvArr* arr
	);

void	rcvSetData(
	RCvArr* arr,
	void* data,
	RCvS32 step
	);

RCvSize rcvGetSize(
	const RCvArr* arr
	);

void	rcvSplit(
	const RCvArr* src,
	RCvArr* dst0,
	RCvArr* dst1,
	RCvArr* dst2,
	RCvArr* dst3
	);

void	rcvMerge(
	const RCvArr* src0,
	const RCvArr* src1,
	const RCvArr* src2,
	const RCvArr* src3,
	RCvArr* dst
	);

void	rcvCopy(
	const RCvArr* src,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvSet(
	RCvArr* arr,
	RCvScalar value,
	const RCvArr* mask
	);

void	rcvSetZero(
	RCvArr* arr
	);

void 	rcvFlip(
	const RCvArr* src,
	RCvArr* dst,
	RCvS32 flipMode
	);

/* Initializes a scaled identity matrix */
void	rcvSetIdentity(
	RCvArr* arr,
	RCvScalar value);

RCvSeq* rcvCreateSeq(
	RCvS32 seq_flags,
	RCvS32 header_size,
	RCvS32 elem_size,
	RCvMemStorage* storage
	);

void rcvClearSeq(
	RCvSeq* seq
	);

RCvSeq* rcvMakeSeqHeaderForArray(
	RCvS32 seq_type,
	RCvS32 header_size,
	RCvS32 elem_size,
	void* elements,
	RCvS32 total,
	RCvSeq* seq,
	RCvSeqBlock* block
	);

RCvS8*	rcvGetSeqElem(
	const RCvSeq* seq,
	RCvS32 index
	);

void 	rcvSetSeqBlockSize(
	RCvSeq* seq,
	RCvS32 delta_elems
	);

void	rcvCreateSeqBlock(
	RCvSeqWriter* writer
	);

void	rcvChangeSeqBlock(
	void* reader,
	RCvS32 direction
	);

RCvS8*	rcvSeqPush(
	RCvSeq* seq,
	const void* element
	);

void	rcvSeqPop(
	RCvSeq* seq,
	void* element
	);

void	rcvStartAppendToSeq(
	RCvSeq* seq,
	RCvSeqWriter* writer
	);

void	rcvFlushSeqWriter(
	RCvSeqWriter * writer
	);

RCvSeq*	rcvEndWriteSeq(
	RCvSeqWriter* writer
	);

void	rcvStartReadSeq(
	const RCvSeq *seq,
	RCvSeqReader * reader,
	RCvS32 reverse1
	);

void	rcvSetSeqReaderPos(
	RCvSeqReader* reader,
	RCvS32 index,
	RCvS32 is_relative
	);

RCvS32	rcvSliceLength(
	RCvSlice slice,
	const RCvSeq* seq
	);

RCvMemStorage*	rcvCreateMemStorage(
	RCvS32 block_size
	);

void	rcvReleaseMemStorage(
	RCvMemStorage** storage
	);

void	rcvClearMemStorage(
	RCvMemStorage* storage
	);

void*	rcvMemStorageAlloc(
	RCvMemStorage* storage,
	RCvS32 size
	);

void*	rcvAlloc(
	size_t size
	);

void	rcvFree(
	void** ptr
	);

RCvS32	rcvRound(
	RCvF64 value
	);

/**************************************************/

/* dummy function to set link order */
void	rcvDummyFuncForLinkOrder( void );



#ifdef __cplusplus
}
#endif


#endif	/* RCVLIB_BASIC_H */
