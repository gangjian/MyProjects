/******************************************************************************
IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 

 By downloading, copying, installing or using the software you agree to this license.
 If you do not agree to this license, do not download, install,
 copy or use the software.


                          License Agreement
               For Open Source Computer Vision Library

Copyright (C) 2000-2008, Intel Corporation, all rights reserved.
Copyright (C) 2008-2011, Willow Garage Inc., all rights reserved.
Copyright (C) 2012-2014, Renesas Electronics Corporation, all rights reserved.
Third party copyrights are property of their respective owners.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

  * The name of the copyright holders may not be used to endorse or promote products
    derived from this software without specific prior written permission.

This software is provided by the copyright holders and contributors "as is" and
any express or implied warranties, including, but not limited to, the implied
warranties of merchantability and fitness for a particular purpose are disclaimed.
In no event shall the Intel Corporation or contributors be liable for any direct,
indirect, incidental, special, exemplary, or consequential damages
(including, but not limited to, procurement of substitute goods or services;
loss of use, data, or profits; or business interruption) however caused
and on any theory of liability, whether in contract, strict liability,
or tort (including negligence or otherwise) arising in any way out of
the use of this software, even if advised of the possibility of such damage.
     $Revision: 149 $*//* PRQA S 0292 *//*
******************************************************************************/
#ifndef RCVLIB_ARITHMETIC_H
#define RCVLIB_ARITHMETIC_H


#ifdef __cplusplus
extern "C" {
#endif

#define rcvAbs(src, dst) rcvAbsDiffS(src, dst, rcvScalar(0,0,0,0))

/***************************************
 * Arithmetic functions
 ***************************************/

void	rcvAdd(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvAddS(
	const RCvArr* src,
	RCvScalar value,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvSub(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvSubRS(
	const RCvArr* src,
	RCvScalar value,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvSubS(
	const RCvArr* src,
	RCvScalar value,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvMul(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	RCvF64 scale
	);

void	rcvDiv(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	RCvF64 scale
	);

void	rcvAbsDiff(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst
	);

void	rcvAbsDiffS(
	const RCvArr* src,
	RCvArr* dst,
	RCvScalar value
	);

void	rcvConvertScale(
	const RCvArr* src,
	RCvArr* dst,
	RCvF64 scale,
	RCvF64 shift
	);

void	rcvSqrt(
	const RCvArr* src,
	RCvArr* dst
	);

void	rcvMax(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst
	);

void	rcvMin(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst
	);

void	rcvMaxS(
	const RCvArr* src,
	RCvF64 value,
	RCvArr* dst
	);

void	rcvMinS(
	const RCvArr* src,
	RCvF64 value,
	RCvArr* dst
	);

RCvScalar	rcvSum(
	const RCvArr* src
	);

/***************************************
 * Logical functions
 ***************************************/

void	rcvAnd(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvAndS(
	const RCvArr* src,
	RCvScalar value,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvOr(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvOrS(
	const RCvArr* src,
	RCvScalar value,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvXor(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvXorS(
	const RCvArr* src,
	RCvScalar value,
	RCvArr* dst,
	const RCvArr* mask
	);

void	rcvNot(
	const RCvArr* src,
	RCvArr* dst
	);


#ifdef __cplusplus
}
#endif


#endif	/* RCVLIB_ARITHMETIC_H */
