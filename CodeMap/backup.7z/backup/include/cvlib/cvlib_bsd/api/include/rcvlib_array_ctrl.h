/******************************************************************************
IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING. 

 By downloading, copying, installing or using the software you agree to this license.
 If you do not agree to this license, do not download, install,
 copy or use the software.


                          License Agreement
               For Open Source Computer Vision Library

Copyright (C) 2000-2008, Intel Corporation, all rights reserved.
Copyright (C) 2008-2011, Willow Garage Inc., all rights reserved.
Copyright (C) 2012-2014, Renesas Electronics Corporation, all rights reserved.
Third party copyrights are property of their respective owners.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

  * The name of the copyright holders may not be used to endorse or promote products
    derived from this software without specific prior written permission.

This software is provided by the copyright holders and contributors "as is" and
any express or implied warranties, including, but not limited to, the implied
warranties of merchantability and fitness for a particular purpose are disclaimed.
In no event shall the Intel Corporation or contributors be liable for any direct,
indirect, incidental, special, exemplary, or consequential damages
(including, but not limited to, procurement of substitute goods or services;
loss of use, data, or profits; or business interruption) however caused
and on any theory of liability, whether in contract, strict liability,
or tort (including negligence or otherwise) arising in any way out of
the use of this software, even if advised of the possibility of such damage.
     $Revision: 414 $*//* PRQA S 0292 *//*
******************************************************************************/
#ifndef RCVLIB_ARRAY_CTRL_H
#define RCVLIB_ARRAY_CTRL_H


#ifdef __cplusplus
extern "C" {
#endif

#define rcvMatMulAdd( src1, src2, src3, dst )	rcvGEMM( src1, src2, 1, src3, 1, dst, 0 )
#define rcvMatMul( src1, src2, dst )			rcvMatMulAdd( src1, src2, 0, dst )

/***************************************
 * array ctrl
 ***************************************/
void	rcvLUT(
	const RCvArr* src,
	RCvArr* dst,
	const RCvArr* lut
	);

void	rcvMinMaxLoc(
	const RCvArr* arr,
	RCvF64* min_val,
	RCvF64* max_val,
	RCvPoint* min_loc,
	RCvPoint* max_loc,
	const RCvArr* mask
	);

void	rcvInRange(
	const RCvArr* src,
	const RCvArr* lower,
	const RCvArr* upper,
	RCvArr* dst
	);

void	rcvInRangeS(
	const RCvArr* src,
	RCvScalar lower,
	RCvScalar upper,
	RCvArr* dst
	);

void	rcvCartToPolar(
	const RCvArr* x,
	const RCvArr* y,
	RCvArr* magnitude,
	RCvArr* angle,
	RCvS32 angleInDegrees);

void	rcvPolarToCart(
	const RCvArr* magnitude,
	const RCvArr* angle,
	RCvArr* x,
	RCvArr* y,
	RCvS32 angleInDegrees);

void	rcvGEMM(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvF64 alpha,
	const RCvArr* src3,
	RCvF64 beta,
	RCvArr* dst,
	RCvS32 tABC
	);

void	rcvTranspose(
	const RCvArr* src,
	RCvArr* dst);

RCvF64	rcvInvert(
	const RCvArr* src,
	RCvArr* dst,
	RCvS32 method
	);

RCvS32	rcvSolve(
	const RCvArr* src1,
	const RCvArr* src2,
	RCvArr* dst,
	RCvS32 method
	);

void	rcvDFT(
	const RCvArr* srcarr,
	RCvArr* dstarr,
	RCvS32 flags,
	RCvS32 nonzero_rows
	);

RCvS32	rcvGetOptimalDFTSize(
	RCvS32 size0
	);

void	rcvMulSpectrums(
	const RCvArr* srcAarr,
	const RCvArr* srcBarr,
	RCvArr* dstarr,
	RCvS32 flags
	);

void	rcvSVD(
	RCvArr* A,
	RCvArr* W,
	RCvArr* U,
	RCvArr* V,
	RCvS32 flags
	);

void	rcvSVBkSb(
	const RCvArr* W,
	const RCvArr* U,
	const RCvArr* V,
	const RCvArr* B,
	RCvArr* X,
	RCvS32 flags);

RCvF64	rcvNorm(
	const RCvArr* arr1,
	const RCvArr* arr2,
	RCvS32 normType,
	const RCvArr* mask);

void	rcvNormalize(
	const RCvArr* src,
	RCvArr* dst,
	RCvF64 alpha,
	RCvF64 beta,
	RCvS32 normType,
	const RCvArr* mask);

RCvMat*	rcvReshape(
	const RCvArr* arr,
	RCvMat* header,
	RCvS32 newCn,
	RCvS32 newRows);

void	rcvCalcCovarMatrix(
	const RCvArr** vects,
	RCvS32 count,
	RCvArr* covMat,
	RCvArr* avg,
	RCvS32 flags);

void	rcvTransform(
	const RCvArr* src,
	RCvArr* dst,
	const RCvMat* transmat,
	const RCvMat* shiftvec);

void rcvReduce(
	const RCvArr* src,
	RCvArr* dst,
	RCvS32 dim,
	RCvS32 op);

RCvS32 rcvSolveCubic(
	const RCvArr* coeffs,
	RCvArr* roots);


#ifdef __cplusplus
}
#endif


#endif	/* RCVLIB_ARRAY_CTRL_H */
