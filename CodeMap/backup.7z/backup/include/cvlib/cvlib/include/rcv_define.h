#ifndef RCVCM_DEFINE_H
#define RCVCM_DEFINE_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcv_define.h
*/
/* PRQA S 0292 1 */
/* $Revision: 634 $
******************************************************************************/
#include "rcv_define_conf.h"

typedef signed char		RCVCM_Schar ;
typedef signed char		RCVCM_S8 ;
typedef unsigned char	RCVCM_U8 ;
typedef signed short	RCVCM_S16 ;
typedef unsigned short	RCVCM_U16 ;
typedef signed long		RCVCM_S32 ;
typedef unsigned long	RCVCM_U32 ;
typedef float			RCVCM_F32 ;
typedef double			RCVCM_F64 ;
typedef signed int		RCVCM_Sint ;
typedef unsigned int	RCVCM_Uint ;

/* virtual type of RCvMemStorage, RCvSeq, RCvSeqWriter in CoreModule */
typedef void RCVCM_MEMSTORAGE ;
typedef void RCVCM_SEQ ;
typedef void RCVCM_SEQWRITER ;
typedef void RCVCM_SEQREADER ;

/*************************************************************
 *   Constant Value Definitions
 *************************************************************/

#define RCVCM_UNUSED_VARIABLE(x) (void)(x)

#define RCVCM_ST_NULL		{0}

/* Data Format */
typedef enum emRCVCM_IMAGE_DATA_FORMAT
{
	RCVCM_ORDER_UNKNOWN			= 0,	/* cannot Check */
	RCVCM_ORDER_PIXEL_IMG		= 1,	/* interleaved image */
	RCVCM_ORDER_PIXEL_UNKNOWN	= 2,	/* interleaved image - channel value is out of range */
	RCVCM_ORDER_PLANE_YUV422	= 3,	/* separated image - YUV image */
	RCVCM_ORDER_PLANE_UNKNOWN	= 4		/* separated image - type is not U8 and channel is not 2. */
} RCVCM_Format;

typedef enum emRCVCM_INTERPORATION
{
	RCVCM_INTER_NN		= 0,	/* cannot Check */
	RCVCM_INTER_LINEAR	= 1,	/* interleaved image */
	RCVCM_INTER_CUBIC	= 2,	/* interleaved image - channel value is out of range */
	RCVCM_WARP_FILL_OUTLIERS= 8,	/*  */
	RCVCM_WARP_INVERSE_MAP	=16		/*  */
} RCVCM_Format2;

/*************************************************************
 *   Structure Definitions
 *************************************************************/
typedef struct ST_RCVCM_Rect {
	RCVCM_S32 x;
	RCVCM_S32 y;
	RCVCM_S32 width;
	RCVCM_S32 height;
} RCVCM_Rect ;

typedef struct ST_RCVCM_Point {
	RCVCM_S32 x;
	RCVCM_S32 y;
} RCVCM_Point ;

typedef struct ST_RCVCM_Point2D32f {
	RCVCM_F32 x;
	RCVCM_F32 y;
} RCVCM_Point2D32f ;

typedef struct ST_RCVCM_Point2D64f {
	RCVCM_F64 x;
	RCVCM_F64 y;
} RCVCM_Point2D64f ;

typedef struct ST_RCVCM_Size {
	RCVCM_S32 width;
	RCVCM_S32 height;
} RCVCM_Size ;

typedef struct ST_RCVCM_Slice {
	RCVCM_S32 start_index;
	RCVCM_S32 end_index;
} RCVCM_Slice ;

typedef struct ST_RCVCM_Scalar {
	RCVCM_F64 val[4];
} RCVCM_Scalar ;

typedef struct ST_RCVCM_ROI {
	RCVCM_S32 xOffset;
	RCVCM_S32 yOffset;
	RCVCM_S32 width;
	RCVCM_S32 height;
} RCVCM_ROI ;

typedef struct ST_RCVCM_Image {
	RCVCM_S8* buffer;
	RCVCM_S8* buffer2;
	RCVCM_S32 stride;
	RCVCM_S32 width;
	RCVCM_S32 height;
	RCVCM_S32 roi_sx;
	RCVCM_S32 roi_sy;
	RCVCM_S32 roi_w;
	RCVCM_S32 roi_h;
	RCVCM_S32 channels;
	RCVCM_S32 type;		/* depth type */
} RCVCM_Image ;

typedef struct ST_RCVCM_ConvKernel {
	RCVCM_S32 width;  /* cols */
	RCVCM_S32 height; /* rows */
	RCVCM_S32 ax; /* anchor */
	RCVCM_S32 ay;
	RCVCM_S32* v; /* values */
	RCVCM_S32 shape;
} RCVCM_ConvKernel ;

typedef struct ST_RCVCM_MOMENTS {
	RCVCM_F64 m00, m10, m01, m20, m11, m02, m30, m21, m12, m03;
	RCVCM_F64 mu20, mu11, mu02, mu30, mu21, mu12, mu03;
	RCVCM_F64 inv_sqrt_m00;
} RCVCM_MOMENTS ;

/* return code of functions in sequence callback function table */
typedef enum emRCVCM_SEQ_Ret
{
	RCVCM_RET_SEQ_OK				= 0,
	RCVCM_RET_SEQ_NG				= -1,
	RCVCM_RET_SEQ_NG_INTERNAL		= -99
} RCVCM_SEQ_Ret;


/* memory storage callback function table
 This table provides memory storage interfaces to access memstorage-APIs
   in API layer from CoreModule layer.
 */
typedef struct ST_RCVCM_MEMSTORAGE_CB_FUNCS {
	/* function pointers */
	RCVCM_MEMSTORAGE*	(*memstorage_create)( RCVCM_S32 );
	void				(*memstorage_release)( RCVCM_MEMSTORAGE** );
	void* 				(*memstorage_alloc)( RCVCM_MEMSTORAGE*, RCVCM_S32 );
} RCVCM_MEMSTORAGE_CB_FUNCS ;

/* sequence callback function table
 This table provides sequence interfaces to access seq-APIs
   in API layer from CoreModule layer.
 */
typedef struct ST_RCVCM_SEQ_CB_FUNCS {
	/* function pointers */
	RCVCM_SEQ*		(*seq_create)( RCVCM_S32, RCVCM_S32, RCVCM_S32, RCVCM_MEMSTORAGE* );
	RCVCM_SEQ_Ret	(*seq_clear)( RCVCM_SEQ* );
	RCVCM_S8*		(*seq_push)( RCVCM_SEQ*, const void* element );
	RCVCM_S8*		(*seq_get)( const RCVCM_SEQ*, RCVCM_S32 index );
	RCVCM_S32		(*seq_get_num_of_elem)( const RCVCM_SEQ* );
	RCVCM_SEQ_Ret	(*seq_start_append)( RCVCM_SEQ*, RCVCM_SEQWRITER* );
	RCVCM_SEQ_Ret	(*seq_write_elem_pnt)( RCVCM_Point, RCVCM_SEQWRITER* );
	RCVCM_SEQ*		(*seq_end_write)( RCVCM_SEQWRITER* );
	RCVCM_SEQ_Ret	(*seq_start_read)(  const RCVCM_SEQ*, RCVCM_SEQREADER*, RCVCM_S32 );
	RCVCM_SEQ_Ret	(*seq_set_seq_reader_pos)( RCVCM_SEQREADER*, RCVCM_S32, RCVCM_S32 );
	RCVCM_SEQ_Ret	(*seq_read_elem_pnt)( RCVCM_Point*, RCVCM_SEQREADER* );
	RCVCM_SEQ_Ret	(*seq_add_flags_hole)( RCVCM_SEQ* );
	RCVCM_SEQ_Ret	(*seq_connect_next)( RCVCM_SEQ*, RCVCM_SEQ* );
	RCVCM_SEQ_Ret	(*seq_connect_parent_child)( RCVCM_SEQ*, RCVCM_SEQ* );
	RCVCM_SEQ_Ret	(*seq_get_bounding_rect)( RCVCM_Rect*, RCVCM_SEQ*, RCVCM_S32 );
} RCVCM_SEQ_CB_FUNCS ;

/* type of RCVCM_TERMINATOR */
#define RCVCM_TERMINATOR_MAX	(1)	/* use max */
#define RCVCM_TERMINATOR_EPS	(2)	/* use epsilon */
#define RCVCM_TERMINATOR_MAXCOUNT	(100)	/* max count of iteration */

/* Terminator for iteration */
typedef struct ST_RCVCM_Terminator
{
	RCVCM_S32 type;
	RCVCM_S32 max;
	RCVCM_F64 epsilon;
} RCVCM_Terminator ;

/* stereo block matching */
typedef struct ST_RCVCM_StereoBMState
{
	RCVCM_S32 preFilterType;
	RCVCM_S32 preFilterSize;
	RCVCM_S32 preFilterCap;
	RCVCM_S32 SADWindowSize;
	RCVCM_S32 minDisparity;
	RCVCM_S32 numberOfDisparities;
	RCVCM_S32 textureThreshold; 
	RCVCM_S32 uniquenessRatio; 
	RCVCM_S32 speckleWindowSize; 
	RCVCM_S32 speckleRange; 
	RCVCM_S32 trySmallerWindows;
	RCVCM_Rect roi1;
	RCVCM_Rect roi2;
	RCVCM_S32 disp12MaxDiff;
	RCVCM_Image* preFilteredImg0;
	RCVCM_Image* preFilteredImg1;
	RCVCM_Image* slidingSumBuf;
	RCVCM_Image* cost;
	RCVCM_Image* disp;
} RCVCM_StereoBMState;

/* Params for Feature detection and description */
typedef struct ST_RCVCM_DetectorParams {
	RCVCM_S32 flags; 
	RCVCM_F64 respThreshold;
	RCVCM_F64 diffThreshold;
	RCVCM_S32 nOctaves;
	RCVCM_S32 nOctaveLayers;
} RCVCM_DetectorParams;

/* Keypoint for Feature detection and description */
typedef struct ST_RCVCM_KeyPoint{
	RCVCM_Point2D32f pt;
	RCVCM_S32 class_id;	/* surf:sign of laplacian for the matching step */
	RCVCM_F32 size; 	/* Diameter of the useful keypoint adjacent area */
	RCVCM_F32 angle; 
	RCVCM_F32 response;
	RCVCM_S32 octave; 
	RCVCM_S32 reserved;
} RCVCM_KeyPoint;

/* HOG BlockWeight */
typedef struct ST_RCVCM_HOG_BlockWeight {
	RCVCM_S32 neighbors;
	RCVCM_S32 hist_offset[4];
	RCVCM_F32 position_weight[4];
	RCVCM_F32 gaussian_weight;
} RCVCM_HOG_BlockWeight;

/* HOG BlockDataInfo */
typedef struct ST_RCVCM_HOG_BlockDataInfo {
	RCVCM_Size win_size;
	RCVCM_Size block_size;
	RCVCM_Size block_stride;
	RCVCM_Size cell_size;
	RCVCM_S32 nbins;
	RCVCM_F64 threshold_L2hys;
	RCVCM_S32 svmDetector_count;
	RCVCM_F32 *svmDetector;
	
	RCVCM_S32 iw;
	RCVCM_S32 ih;
	RCVCM_S32 ww;
	RCVCM_S32 wh;
	RCVCM_S32 bw;
	RCVCM_S32 bh;
	RCVCM_S32 blocksize;
	RCVCM_S32 size;
} RCVCM_HOG_BlockDataInfo;

#endif /* #ifndef RCVCM_DEFINE_H */
