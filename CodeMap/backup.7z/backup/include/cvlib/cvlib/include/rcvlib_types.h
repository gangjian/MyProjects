#ifndef RCVLIB_TYPES_H
#define RCVLIB_TYPES_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2014 Renesas Electronics Corporation, all rights reserved.

    [File] rcvlib_types.h
*/
/* PRQA S 0292 1 */
/* $Revision: 414 $
******************************************************************************/
#include <limits.h>  /* LONG_MAX, etc */
#include <float.h>   /* FLT_MAX, etc */

/*************************************************************
 *   typedef
 *************************************************************/

typedef signed char		RCvSchar ;
typedef signed char		RCvS8 ;
typedef unsigned char	RCvU8 ;
typedef signed short	RCvS16 ;
typedef unsigned short	RCvU16 ;
typedef signed long		RCvS32 ;
typedef unsigned long	RCvU32 ;
typedef float			RCvF32 ;
typedef double			RCvF64 ;
typedef signed int		RCvSint ;
typedef unsigned int	RCvUint ;

/* max/min value */
#define RCV_MAX_S8	(SCHAR_MAX)
#define RCV_MIN_S8	(SCHAR_MIN)
#define RCV_MAX_U8	(UCHAR_MAX)
#define RCV_MIN_U8	(0)
#define RCV_MAX_S16	(SHRT_MAX)
#define RCV_MIN_S16	(SHRT_MIN)
#define RCV_MAX_U16	(USHRT_MAX)
#define RCV_MIN_U16	(0)
#define RCV_MAX_S32	(LONG_MAX)
#define RCV_MIN_S32	(LONG_MIN)
#define RCV_MAX_U32	(ULONG_MAX)
#define RCV_MIN_U32	(0)
#define RCV_MAX_F32	(FLT_MAX)
#define RCV_PMIN_F32	(FLT_MIN)
#define RCV_MIN_F32	(-FLT_MAX)	/* caution : that is a min negative value, not FLT_MIN (min positive value) */
#define RCV_MAX_F64	(DBL_MAX)
#define RCV_PMIN_F64	(DBL_MIN)
#define RCV_MIN_F64	(-DBL_MAX)	/* caution : that is a min negative value, not DBL_MIN (min positive value) */
/* Epsilon */
#define RCV_EPSILON_F32	(FLT_EPSILON)
#define RCV_EPSILON_F64	(DBL_EPSILON)

typedef enum {
	RCV_EC_OK							= 0,
	RCV_EC_NG_MEM						= -1,
	RCV_EC_NG_ARG_NULL					= -2,
	RCV_EC_NG_ARG_ARRTYPE				= -3,
	RCV_EC_NG_ARG_ARRSTATE				= -4,
	RCV_EC_NG_ARG_ARRUNMATCH			= -5,
	RCV_EC_NG_ARG_ARRINPLACE			= -6,
	RCV_EC_NG_ARG_ALLOCATED				= -7,
	RCV_EC_NG_ARG_NOTALLOCATED			= -8,
	RCV_EC_NG_ARG_SEQSTATE				= -9,
	RCV_EC_NG_ARG_SEQOUTOFRANGE			= -10,
	RCV_EC_NG_ARG_MEMBLOCKSIZE			= -11,
	RCV_EC_NG_LO_OVERFLOW				= -12,
	RCV_EC_NG_ARG_INTERNAL				= -99,
	RCV_EC_NG_ARG_1						= -101,
	RCV_EC_NG_ARG_2						= -102,
	RCV_EC_NG_ARG_3						= -103,
	RCV_EC_NG_ARG_4						= -104,
	RCV_EC_NG_ARG_5						= -105,
	RCV_EC_NG_ARG_6						= -106,
	RCV_EC_NG_ARG_7						= -107,
	RCV_EC_NG_ARG_8						= -108,
	RCV_EC_NG_ARG_9						= -109,
	RCV_EC_NG_ARG_10					= -110,
	RCV_EC_NG_ARG_11					= -111,
	RCV_EC_NG_ARG_12					= -112,
	RCV_EC_NG_ARG_13					= -113
} RCvExErrorCode ;

#endif  /* RCVLIB_TYPES_H */
