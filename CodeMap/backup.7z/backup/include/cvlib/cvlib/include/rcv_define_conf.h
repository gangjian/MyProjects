#ifndef RCVCM_DEFINE_CONF_H
#define RCVCM_DEFINE_CONF_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcv_define_conf.h
*/
/* PRQA S 0292 1 */
/* $Revision: 669 $
******************************************************************************/
/* include for standard library definition */
#include <string.h>
#include <stdlib.h> 
#include <math.h>


/*************************************************************
 *   CONFIG - COMMON
 *************************************************************/

/* standard library definition */
#define RCV_CFG_MEMCPY	memcpy
#define RCV_CFG_MEMSET	memset
#define RCV_CFG_ABS		abs
#define RCV_CFG_FABS	fabs
#define RCV_CFG_FLOOR	floor
#define RCV_CFG_CEIL	ceil
#define RCV_CFG_SIN		sin
#define RCV_CFG_COS		cos
#define RCV_CFG_TAN		tan
#define RCV_CFG_ATAN	atan
#define RCV_CFG_ACOS	acos
#define RCV_CFG_EXP		exp
#define RCV_CFG_SQRT	sqrt
#define RCV_CFG_POW		pow
#define RCV_CFG_LOG		log
#define RCV_CFG_QSORT	qsort


/* max/min width/height in RIplImage and RCvMat */
#define RCV_CFG_MAX_IMG_WIDTH			(4096)
#define RCV_CFG_MIN_IMG_WIDTH			(1)
#define RCV_CFG_MAX_IMG_HEIGHT			(4096)
#define RCV_CFG_MIN_IMG_HEIGHT			(1)
#define RCV_CFG_MAX_MAT_ROW				(4096)
#define RCV_CFG_MIN_MAT_ROW				(1)
#define RCV_CFG_MAX_MAT_COL				(4096)
#define RCV_CFG_MIN_MAT_COL				(1)


/*************************************************************
 *   CONFIG - API
 *************************************************************/
/* config */
/* #define RCV_CFG_DEBUG */

/* alignment in RIplImage and RCvMat */
#define RCV_CFG_IMG_ADDR_ALIGN			(128)
#define RCV_CFG_DEFAULT_IMG_STEP_ALIGN	(128)
#define RCV_CFG_MAT_ADDR_ALIGN			(128)
#define RCV_CFG_DEFAULT_MAT_STEP_ALIGN	(1)
/* structure default alignment value */
#define RCV_CFG_STRUCT_ALIGN			(8)
/* default block size of memory storage */
#define RCV_CFG_STORAGE_BLOCK_SIZE		( (1<<16) - 128 )
/* limit kernel size in rcvFilter2D */
#define	RCV_CFG_MAX_KERNEL 				(50)


#if defined(WIN32) || defined(__ghs__)
#define RCV_FUNCNAME	__FUNCTION__ 
#else
#define RCV_FUNCNAME	__func__ 
#endif

#ifdef RCV_CFG_DEBUG
#include <stdio.h>

#define RCV_DEBUG_PRINT(fmt,p1,p2,p3)	\
	do {	\
		fprintf(stderr,"%15s, %5d, %20s,"fmt,__FILE__, __LINE__, RCV_FUNCNAME, (p1), (p2), (p3) );	\
	} while(0)
#else
#define RCV_DEBUG_PRINT(fmt,p1,p2,p3)	\
	do{	\
		/* DO NOTHING */	\
	}while(0)
#endif /* RCV_CFG_DEBUG */


/*************************************************************
 *   CONFIG - CORE MODULE
 *************************************************************/
/* config */

/* PI */
#define RCVCM_PI	(3.1415926535897932384626433832795)

/* min, max */
#define RCVCM_MIN(a,b)	(((a) < (b)) ? (a) : (b))
#define RCVCM_MAX(a,b)	(((a) > (b)) ? (a) : (b))

/* OpenCV defects */
/* if defined, rcvErode/rcvDilate runs the defect as same as OpenCV2.3.1. */
/* #define RCVCM_CFG_DEFECT_ERODEDILATE */

/* Debug Macro Definitions */
#define RCVCM_CFG_DEBUG_LEVEL	(4)
#define RCVCM_LEV_ERROR			(1)
#define RCVCM_LEV_WARN			(2)
#define RCVCM_LEV_DEBUG			(3)
#define RCVCM_LEV_INFO			(4)

#if defined(WIN32) || defined(__ghs__)
#define RCVCM_FUNCNAME	__FUNCTION__ 
#else
#define RCVCM_FUNCNAME	__func__ 
#endif

#ifdef RCVCM_CFG_DEBUG

#include <stdio.h>

#define RCVCM_DEBUG_PRINT(level,fmt,p1,p2,p3)	\
	do{	\
		if((level) <= RCVCM_CFG_DEBUG_LEVEL)	\
		{	\
			fprintf(stderr,"%15s, %5d, %20s,"fmt,__FILE__, __LINE__, RCVCM_FUNCNAME, (p1), (p2), (p3) );	\
		}	\
	}while(0)
#else
#define RCVCM_DEBUG_PRINT(level,fmt,p1,p2,p3)	/* PRQA S 1030 */ \
	do{	\
		/* DO NOTHING */	\
	}while(0)
#endif

#endif /* #ifndef RCVCM_DEFINE_CONF_H */
