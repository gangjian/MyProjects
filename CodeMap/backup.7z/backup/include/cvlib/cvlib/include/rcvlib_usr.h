#ifndef RCVLIB_USR_H
#define RCVLIB_USR_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2015 Renesas Electronics Corporation, all rights reserved.

    [File] rcvlib_usr.h

******************************************************************************/

#include "rcvlib_types.h"

/* bit field definition in flags of rcvUsrAlloc */
#define RCV_ALLOC_BIT_ACCESS	(0)
#define RCV_ALLOC_LEN_ACCESS	(2)
#define RCV_ALLOC_BIT_KIND		(2)
#define RCV_ALLOC_LEN_KIND		(2)
#define RCV_ALLOC_BIT_ROW		(8)
#define RCV_ALLOC_LEN_ROW		(24)
/* mask */
#define RCV_ALLOC_MASK_ACCESS	( ((1 << RCV_ALLOC_LEN_ACCESS)	- 1) << RCV_ALLOC_BIT_ACCESS )
#define RCV_ALLOC_MASK_KIND		( ((1 << RCV_ALLOC_LEN_KIND)	- 1) << RCV_ALLOC_BIT_KIND )
#define RCV_ALLOC_MASK_ROW		( ((1 << RCV_ALLOC_LEN_ROW)		- 1) << RCV_ALLOC_BIT_ROW )
/* bit definition in flags of rcvUsrAlloc */
#define RCV_ALLOC_ACCESS_NORMAL	(0 << RCV_ALLOC_BIT_ACCESS)
#define RCV_ALLOC_ACCESS_FAST	(1 << RCV_ALLOC_BIT_ACCESS)
#define RCV_ALLOC_KIND_STRUCT	(0 << RCV_ALLOC_BIT_KIND)
#define RCV_ALLOC_KIND_DATA		(1 << RCV_ALLOC_BIT_KIND)
#define RCV_ALLOC_KIND_HW		(2 << RCV_ALLOC_BIT_KIND)

#define RCV_MEMORY_FROM_HW_TO_CPU		(0x01)
#define RCV_MEMORY_FROM_CPU_TO_HW		(0x02)

/* System Mode (Soft or Hard) */
#define	RCV_SYSTEM_MODE_SOFT		(1)
#define	RCV_SYSTEM_MODE_HARD		(2)

/* Type of DL */
#define RCV_DL_TYPE_IMP		0
#define RCV_DL_TYPE_SHADER	1

/* random */
#define RCV_RAND_MAX	(32767)

#ifdef __cplusplus
extern "C" {
#endif

/***************************************
 * user defined
 ***************************************/
RCvU32 rcvUsrGetSystemMode( void );
#ifdef RCV_SYS_HARD
typedef struct rcv_impdrv_ctl_struct RCvIMPDRVCTL;
RCvIMPDRVCTL* rcvUsrGetIMPDrvInfo( void );
RCvU32 rcvUsrStartHardwareAccess( void* addr, RCvS32 size, RCvU32 flags );
void rcvUsrEndHardwareAccess( void* addr );
RCvS32 rcvUsrCheckDL( RCvS32 type, RCvS32 num, RCvU32** addr, RCvS32* size );
#endif /* RCV_SYS_HARD */
void* rcvUsrAlloc( const RCvS32 size, const RCvS32 align, const RCvU32 flags );
void rcvUsrFree( void** addr );
void rcvUsrNotifyErr( const RCvExErrorCode ec );
RCvExErrorCode rcvUsrGetErrorCode(void);

RCvS32 rcvUsrRand_r(RCvU32* seedp);

#ifdef __cplusplus
}
#endif

#endif  /* RCVLIB_USR_H */
