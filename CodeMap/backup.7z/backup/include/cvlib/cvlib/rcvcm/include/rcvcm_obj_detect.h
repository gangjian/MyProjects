#ifndef RCVCM_OBJ_DETECT_H
#define RCVCM_OBJ_DETECT_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_obj_detect.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/* square difference */
RCVCM_Ret 
rcvcm_sqdiff(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* templ,
	RCVCM_S32 normalize);

/* cross correlation */
RCVCM_Ret 
rcvcm_ccorr(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* templ,
	RCVCM_S32 normalize);

/* correlation coefficient */
RCVCM_Ret 
rcvcm_ccoeff(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* templ,
	RCVCM_S32 normalize);

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_OBJ_DETECT_H */
