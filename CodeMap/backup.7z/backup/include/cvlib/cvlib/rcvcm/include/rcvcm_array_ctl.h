#ifndef RCVCM_ARRAY_CTL_H
#define RCVCM_ARRAY_CTL_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2014 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_array_ctl.h
*/
/* PRQA S 0292 1 */
/* $Revision: 414 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Constant Value Definitions
 *************************************************************/
#define RCVCM_MAX_GETDFTSIZE		(1073741824)	/* 2^30 */

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

#define rcvcm_matMulAdd( src1, src2, src3, dst )	rcvcm_gemm( src1, src2, 1, src3, 1, dst, 0 )
#define rcvcm_matMul( src1, src2, dst )			rcvcm_matMulAdd( src1, src2, 0, dst )

RCVCM_Ret 
rcvcm_conv(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_F64 scale,
	RCVCM_F64 shift);

RCVCM_Ret 
rcvcm_LUT(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* lut);

RCVCM_Ret 
rcvcm_minmaxloc(
	const RCVCM_Image* src,
	RCVCM_F64* min_val,
	RCVCM_F64* max_val,
	RCVCM_Point* min_loc,
	RCVCM_Point* max_loc,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_DFT(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 flags,
	RCVCM_S32 rows);

RCVCM_S32 
rcvcm_getDFTSize(
	RCVCM_S32 size0);

RCVCM_Ret 
rcvcm_mulSpectrums(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	const RCVCM_Image* dst,
	RCVCM_S32 flags);

RCVCM_Ret
rcvcm_DFT_split(
	const RCVCM_Image* src,
	const RCVCM_Image* dft,
	RCVCM_S32 src_ch);

RCVCM_Ret 
rcvcm_DFT_add(
	const RCVCM_Image* dft,
	const RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_inrange(
	const RCVCM_Image* src,
	const RCVCM_Image* lower,
	const RCVCM_Image* upper,
	const RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_inrangeScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar lower,
	RCVCM_Scalar upper,
	const RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_cart2polar(
	const RCVCM_Image* x,
	const RCVCM_Image* y,
	RCVCM_Image* mag,
	RCVCM_Image* angle,
	RCVCM_S32 flag);

RCVCM_Ret 
rcvcm_polar2cart(
	const RCVCM_Image* mag,
	const RCVCM_Image* angle,
	RCVCM_Image* x,
	RCVCM_Image* y,
	RCVCM_S32 flag);

RCVCM_Ret 
rcvcm_gemm(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_F64 alpha,
	const RCVCM_Image* src3,
	RCVCM_F64 beta,
	RCVCM_Image* dst,
	RCVCM_S32 tABC);

RCVCM_Ret 
rcvcm_transpose(
	const RCVCM_Image* src,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_invert(
	const RCVCM_Image* src,
	RCVCM_Image* dst,
	RCVCM_S32 method,
	RCVCM_F64* value);

RCVCM_Ret 
rcvcm_solve(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	RCVCM_S32 method,
	RCVCM_S32 normal,
	RCVCM_S32* value);

RCVCM_Ret 
rcvcm_svd(
	const RCVCM_Image* A,
	RCVCM_Image* W,
	RCVCM_Image* U,
	RCVCM_Image* V,
	RCVCM_S32 flags);

RCVCM_Ret 
rcvcm_SVBkSb(
	const RCVCM_Image* W,
	const RCVCM_Image* U,
	const RCVCM_Image* V,
	const RCVCM_Image* B,
	RCVCM_Image* X,
	RCVCM_S32 flags);

RCVCM_Ret 
rcvcm_norm(
	const RCVCM_Image* arr1,
	const RCVCM_Image* arr2,
	RCVCM_S32 normType,
	const RCVCM_Image* mask,
	RCVCM_F64* norm_val);

RCVCM_Ret 
rcvcm_normalize(
	const RCVCM_Image* src,
	RCVCM_Image* dst,
	RCVCM_F64 alpha,
	RCVCM_F64 beta,
	RCVCM_S32 normType,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_reshape(
	RCVCM_Image* arr,
	RCVCM_S32 newCn,
	RCVCM_S32 newRows);

RCVCM_Ret 
rcvcm_calcCovarMatrix(
	RCVCM_Image** vects,
	RCVCM_S32 count,
	RCVCM_Image* covMat,
	RCVCM_Image* avg,
	RCVCM_S32 flags);

RCVCM_Ret 
rcvcm_transform(
	const RCVCM_Image* src,
	RCVCM_Image* dst,
	const RCVCM_Image* transmat,
	const RCVCM_Image* shiftvec);

RCVCM_Ret 
rcvcm_reduce(
	const RCVCM_Image* src,
	RCVCM_Image* dst,
	RCVCM_S32 dim,
	RCVCM_S32 op);

RCVCM_Ret 
rcvcm_getRow(
	const RCVCM_Image* src,
	RCVCM_Image* dst,
	RCVCM_S32 row);

RCVCM_Ret
rcvcm_solveCubic(
	RCVCM_Image *coeffs,
	RCVCM_Image *roots,
	RCVCM_S32* rnum);


#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_ARRAY_CTL_H */
