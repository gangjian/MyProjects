#ifndef RCVCM_INTEGRALT_H
#define RCVCM_INTEGRALT_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_integral.h
*/
/* PRQA S 0292 1 */
/* $Revision: 372 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/* integral image */
RCVCM_Ret rcvcm_integral(
	const RCVCM_Image* src,
	const RCVCM_Image* integral,
	const RCVCM_Image* integral2,
	const RCVCM_Image* tiltedSum);

RCVCM_Ret 
rcvcm_boxfilter(
	const RCVCM_Image* integral,
	RCVCM_S32 posx,
	RCVCM_S32 posy,
	RCVCM_Rect* box,
	RCVCM_F64* value);

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_OBJ_DETECT_H */
