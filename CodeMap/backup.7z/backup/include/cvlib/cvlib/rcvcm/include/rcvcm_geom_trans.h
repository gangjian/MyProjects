#ifndef RCVCM_GEOM_TRANS_H
#define RCVCM_GEOM_TRANS_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_geom_trans.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret rcvcm_Resize(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 method );

RCVCM_Ret rcvcm_GetRectSubPix(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_F32 center_x,
	RCVCM_F32 center_y  );

RCVCM_Ret 
rcvcm_getAffine(
	const RCVCM_Point2D32f* src_p,
	const RCVCM_Point2D32f* dst_p,
	RCVCM_Image* mat);

RCVCM_Ret 
rcvcm_getPerspective(
	const RCVCM_Point2D32f* src_p,
	const RCVCM_Point2D32f* dst_p,
	const RCVCM_Image* mat);

RCVCM_Ret 
rcvcm_warpAffine(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* mat,
	RCVCM_S32 flags,
	RCVCM_Scalar fillval);

RCVCM_Ret 
rcvcm_warpPerspective(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* mat,
	RCVCM_S32 flags,
	RCVCM_Scalar fillval);

RCVCM_Ret rcvcm_remap(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* mapx,
	const RCVCM_Image* mapy,
	RCVCM_S32 flags,
	RCVCM_Scalar fillval );

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_GEOM_TRANS_H */
