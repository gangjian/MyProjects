#ifndef RCVCM_CHECK_H
#define RCVCM_CHECK_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_check.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret 
rcvcm_CheckPoint(
	const RCVCM_Point point);

RCVCM_Ret 
rcvcm_CheckRowsCols(
	const RCVCM_S32 rows,
	const RCVCM_S32 cols);

RCVCM_Ret 
rcvcm_CheckWidthHeight(
	const RCVCM_S32 width,
	const RCVCM_S32 height);

RCVCM_Ret 
rcvcm_CheckRect(
	const RCVCM_Rect rect);

RCVCM_Ret 
rcvcm_CheckChannels(
	const RCVCM_S32 channels);

RCVCM_Ret 
rcvcm_CheckType(
	const RCVCM_S32 type);

RCVCM_Ret 
rcvcm_CheckOrigin(
	const RCVCM_U32 origin);

RCVCM_Ret 
rcvcm_CheckAlign(
	const RCVCM_S32 align);
	
RCVCM_Ret 
rcvcm_CheckSrcDst(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_SRCDST_PTN uiCheckPtn);

RCVCM_Ret 
rcvcm_CheckRoi(
	const RCVCM_Image* src);

RCVCM_Ret 
rcvcm_CheckPointInImage(
	const RCVCM_Image* src,
	const RCVCM_S32 y,
	const RCVCM_S32 x);


#ifdef __cplusplus
}
#endif

#endif /* #ifndef RCVCM_COMMON_H */
