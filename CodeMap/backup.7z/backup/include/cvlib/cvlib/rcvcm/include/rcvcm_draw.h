#ifndef RCVCM_DRAW_H
#define RCVCM_DRAW_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_draw.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret 
rcvcm_fillconvexpoly(
	const RCVCM_Image* src,
	const RCVCM_Point* pts,
	RCVCM_S32 npts,
	const RCVCM_Scalar *color,
	RCVCM_S32 line_type,
	RCVCM_S32 shift);

RCVCM_Ret 
rcvcm_circle(
	const RCVCM_Image* src,
	const RCVCM_Point* center,
	RCVCM_S32 radius,
	const RCVCM_Scalar* color,
	RCVCM_S32 thickness,
	RCVCM_S32 line_type,
	RCVCM_S32 shift);

RCVCM_Ret 
rcvcm_line(
	const RCVCM_Image* src,
	const RCVCM_Point* pt1,
	const RCVCM_Point* pt2,
	const RCVCM_Scalar* color,
	RCVCM_S32 thickness,
	RCVCM_S32 line_type,
	RCVCM_S32 shift);

RCVCM_Ret 
rcvcm_rectangle(
	const RCVCM_Image* src,
	const RCVCM_Point* pt1,
	const RCVCM_Point* pt2,
	const RCVCM_Scalar* color,
	RCVCM_S32 thickness,
	RCVCM_S32 line_type,
	RCVCM_S32 shift);

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_DRAW_H */
