#ifndef RCVCM_MOMENTS_H
#define RCVCM_MOMENTS_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_moments.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret	rcvcm_get_image_moments(
	const RCVCM_Image* img,
	RCVCM_MOMENTS* moments );

RCVCM_Ret	rcvcm_get_contour_moments(
	const RCVCM_SEQ* seq,
	RCVCM_MOMENTS* moments,
	RCVCM_SEQ_CB_FUNCS* seq_cb,
	RCVCM_SEQREADER*  reader,
	RCVCM_SEQ_Ret*    sqret );

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_MOMENTS_H */
