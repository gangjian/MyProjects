#ifndef RCVCM_HISTOGRAM_H
#define RCVCM_HISTOGRAM_H
/******************************************************************************
    CV Library
     Copyright (C) 2013-2015 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_histogram.h
*/
/* PRQA S 0292 1 */
/* $Revision: 229 $
******************************************************************************/
#include "rcvcm.h"

#define RCVCM_COMP_CORREL			(0)
#define RCVCM_COMP_CHISQR			(1)
#define RCVCM_COMP_INTERSECT		(2)
#define RCVCM_COMP_BHATTACHARYYA	(3)

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret 
rcvcm_calchist(
	const RCVCM_Image** src,
	const RCVCM_Image* hist,
	const RCVCM_Image* mask,
	RCVCM_S32 dims,
	const RCVCM_F32 thresh[][2],
	const RCVCM_F32 **thresh2,
	RCVCM_S32 uniform
	);

RCVCM_Ret 
rcvcm_gethistvalue_2d(
	const RCVCM_Image* hist,
	RCVCM_S32 y,
	RCVCM_S32 x,
	const RCVCM_F32** value);

RCVCM_Ret 
rcvcm_comparehist(
	const RCVCM_Image* hist1,
	const RCVCM_Image* hist2,
	RCVCM_S32 method,
	RCVCM_F64* val);

RCVCM_Ret 
rcvcm_equalizehist(
	const RCVCM_Image* src,
	RCVCM_Image* dst);


#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_HISTOGRAM_H */
