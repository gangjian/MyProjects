#ifndef RCVCM_BASIC_CTL_H
#define RCVCM_BASIC_CTL_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_basic_ctl.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret 
rcvcm_Copy(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret
rcvcm_cloneImage(
	const RCVCM_Image* src,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_Set(
	const RCVCM_Image* arr,
	RCVCM_Scalar value,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_SetZero(
	const RCVCM_Image* arr);

RCVCM_Ret 
rcvcm_flip(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 flipMode);

RCVCM_Ret 
rcvcm_identity(
	const RCVCM_Image* arr,
	RCVCM_Scalar value);

RCVCM_Ret 
rcvcm_Split(
	const RCVCM_Image* src,
	RCVCM_Image* dst0,
	RCVCM_Image* dst1,
	RCVCM_Image* dst2,
	RCVCM_Image* dst3);

RCVCM_Ret 
rcvcm_Merge(
	const RCVCM_Image* src0,
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	const RCVCM_Image* src3,
	RCVCM_Image* dst);


#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_BASIC_CTL_H */
