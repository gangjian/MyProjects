#ifndef RCVCM_ARITHMETIC_H
#define RCVCM_ARITHMETIC_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2014 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_arithmetic.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret 
rcvcm_add(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);
	
RCVCM_Ret 
rcvcm_addScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_sub(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);
	
RCVCM_Ret 
rcvcm_subRScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_subNScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_and(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);
	
RCVCM_Ret 
rcvcm_andScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_or(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);
	
RCVCM_Ret 
rcvcm_orScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_xor(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);
	
RCVCM_Ret 
rcvcm_xorScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_not(
	const RCVCM_Image* src,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_mul(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	RCVCM_F64 scale);

RCVCM_Ret 
rcvcm_div(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst,
	RCVCM_F64 scale);

RCVCM_Ret 
rcvcm_absdiff(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_absdiffs(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_sqrt(
	const RCVCM_Image* src,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_max(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_min(
	const RCVCM_Image* src1,
	const RCVCM_Image* src2,
	RCVCM_Image* dst);

RCVCM_Ret 
rcvcm_maxScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_minScalar(
	const RCVCM_Image* src,
	RCVCM_Scalar value,
	RCVCM_Image* dst,
	const RCVCM_Image* mask);

RCVCM_Ret 
rcvcm_sum(
	const RCVCM_Image* src,
	RCVCM_Scalar *result );

RCVCM_Ret 
rcvcm_sqsum(
	const RCVCM_Image* src,
	RCVCM_Scalar *result );

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_ARITHMETIC_H */
