#ifndef RCVCM_H
#define RCVCM_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2014 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm.h
*/
/* PRQA S 0292 1 */
/* $Revision: 414 $
******************************************************************************/
#include "rcv_define.h"

/* CoreModule parameter check setting */
#define RCVCM_SKIP_ARGCHK

/*************************************************************
 *   Constant Value Definitions
 *************************************************************/
/* CoreModule - Return Code */
typedef enum emRCVCM_Ret
{
	RCVCM_RET_OK					= 0,
	RCVCM_RET_NG_MEM				= -10,
	RCVCM_RET_NG_ARG_NULL			= -20,
	RCVCM_RET_NG_ST_CONDITION		= -40,
	RCVCM_RET_NG_ST_UNMATCH			= -50,
	RCVCM_RET_NG_ST_DATA_NOTNULL	= -70,
	RCVCM_RET_NG_ST_DATA_NULL		= -80,
	RCVCM_RET_NG_LABEL_OVERFLOW		= -90,
	RCVCM_RET_NG_INTERNAL			= -99
} RCVCM_Ret;

typedef enum emRCVCM_TYPE_IDX
{
	RCVCM_8U					= 0,
	RCVCM_8S					,
	RCVCM_16S					,
	RCVCM_32S					,
	RCVCM_32F					,
	RCVCM_64F					,
	RCVCM_TYPE_IDX_MAX
} RCVCM_TYPE_IDX;

/* image data order */
#define RCVCM_ORDER_PIXEL	(0)
#define RCVCM_ORDER_PLANE	(1)

/* image origin */
#define RCVCM_ORIGIN_TL		(0)	/* Top Left */
#define RCVCM_ORIGIN_BL		(1)	/* Bottom Left */

/* step in RCvMat */
#define RCVCM_AUTOSTEP		(0x7FFFFFFF)

/* color conversion */
#define RCVCM_BGR2GRAY		(6)
#define RCVCM_GRAY2BGR		(8)
#define RCVCM_BGR2YCrCb		(36)
#define RCVCM_YCrCb2BGR		(38)
#define RCVCM_BGR2HSV		(40)
#define RCVCM_HSV2BGR		(54)
#define RCVCM_BGR2YUV422	(98)
#define RCVCM_YUV4222BGR	(99)

/* threshold type */
#define RCVCM_THRESH_BINARY		(0)
#define RCVCM_THRESH_BINARY_INV	(1)
#define RCVCM_THRESH_TRUNC		(2)
#define RCVCM_THRESH_TOZERO		(3)
#define RCVCM_THRESH_TOZERO_INV	(4)

/* adaptive threshold methods */
#define RCVCM_ADAPTIVE_THRESH_MEAN_C		(0)
#define RCVCM_ADAPTIVE_THRESH_GAUSSIAN_C	(1)

/* border type */
#define RCVCM_BORDER_CONSTANT	(0)
#define RCVCM_BORDER_REPLICATE	(1)
#define RCVCM_BORDER_REFLECT	(2)
#define RCVCM_BORDER_WRAP		(3)

/* check type for src/dst */
typedef enum emRCVCM_SRCDST_PTN
{
	RCVCM_SRCDST_PTN1 = 0,		/* Check ROI Size/depth/Channels */
	RCVCM_SRCDST_PTN2 = 1,		/* Check width/height/depth      */
	RCVCM_SRCDST_PTN3 = 2		/* Check ROI Size/Channels       */
} RCVCM_SRCDST_PTN;


/* channels */
#define RCVCM_CHANNELS_NUM1    (1)
#define RCVCM_CHANNELS_NUM2    (2)
#define RCVCM_CHANNELS_NUM3    (3)


/* DFT flag */
#define RCVCM_DFT_FORWARD	(0)
#define RCVCM_DFT_INVERSE	(1)
#define RCVCM_DFT_SCALE		(2)

#define RCVCM_DFT_SIZE		(50)

/* MulSpectrums flag */
#define RCVCM_DFT_MUL_CONJ	(8)

/* GEMM Operation flags */
#define RCVCM_GEMM_A_T	(1)
#define RCVCM_GEMM_B_T	(2)
#define RCVCM_GEMM_C_T	(4)

/* Inversion method */
#define RCVCM_INVERT_LU			(0)
#define RCVCM_INVERT_SVD		(1)
#define RCVCM_INVERT_CHOLESKY	(3)

/* SVD flags */
#define RCVCM_SVD_MODIFY_A		(1)
#define RCVCM_SVD_U_T			(2)
#define RCVCM_SVD_V_T			(4)

/* norm type */
#define RCVCM_C				(1)
#define RCVCM_L1			(2)
#define RCVCM_L2			(4)
#define RCVCM_RELATIVE		(8)
#define RCVCM_RELATIVE_C	(9)
#define RCVCM_RELATIVE_L1	(10)
#define RCVCM_RELATIVE_L2	(12)
#define RCVCM_MINMAX		(32)

/* calculate covarient matrix */
#define RCVCM_COVAR_SCRAMBLED	(0)
#define RCVCM_COVAR_NORMAL		(1)
#define RCVCM_COVAR_USE_AVG		(2)
#define RCVCM_COVAR_SCALE		(4)
#define RCVCM_COVAR_ROWS		(8)
#define RCVCM_COVAR_COLS		(16)

/* reduction operation */
#define RCVCM_REDUCE_SUM	(0)
#define RCVCM_REDUCE_AVG	(1)
#define RCVCM_REDUCE_MAX	(2)
#define RCVCM_REDUCE_MIN	(3)

/* flags of CalcOpticalFlowPyrLK */
#define RCVCM_LKFLOW_PYR_A_READY		(1)
#define RCVCM_LKFLOW_PYR_B_READY		(2)
#define RCVCM_LKFLOW_INITIAL_GUESSES	(4)

/* line type */
#define RCVCM_AA	(16)

/* contour approximation method */
#define RCVCM_POLY_APPROX_DP	(0)

/* labeling */
#define RCVCM_LABEL_OBJ		(0)
#define RCVCM_LABEL_BKG		(1)

#define RCVCM_LABEL_SORT_DESCENDING	(0)
#define RCVCM_LABEL_SORT_ASCENDING	(1)
#define RCVCM_LABEL_SORT_NONE		(2)

#define RCVCM_LABEL_CM_MAX		(4096)
#define RCVCM_LABEL_HM_MAX		(2048)
#define RCVCM_LABEL_MAX			(256)

/* Method for computing the fundamental matrix */
#define RCVCM_FM_7POINT	(1)
#define RCVCM_FM_8POINT	(2)
#define RCVCM_FM_LMEDS	(4)
#define RCVCM_FM_RANSAC	(8)

/* Method for StereoBM */
#define RCVCM_STEREO_BM_NORMALIZED_RESPONSE	(0)
#define RCVCM_STEREO_BM_XSOBEL				(1)


#ifdef __cplusplus
extern "C" {
#endif
	

#ifdef __cplusplus
}
#endif


#endif /* #ifndef RCVCM_H */
