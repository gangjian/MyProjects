#ifndef RCVCM_FEAT_DETECT_H
#define RCVCM_FEAT_DETECT_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2015 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_feat_detect.h
*/
/* PRQA S 0292 1 */
/* $Revision: 279 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret 
rcvcm_canny(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_F64 min,
	RCVCM_F64 max,
	RCVCM_S32 gradient,
	RCVCM_S32 aperture_size);

RCVCM_Ret
rcvcm_harris(
	const RCVCM_Image* src,
	const RCVCM_Image* harris,
	RCVCM_S32 blockSize,
	RCVCM_S32 aperture_size,
	RCVCM_F64 k);

RCVCM_Ret 
rcvcm_findCorner(
	const RCVCM_Image* image,
	RCVCM_Point2D32f* corners,
	RCVCM_S32 count,
	RCVCM_Size wsize,
	RCVCM_Size zsize,
	RCVCM_Terminator term);

RCVCM_Ret 
rcvcm_cornerMinEigenVal(
	const RCVCM_Image* image,
	RCVCM_Image* eigenval,
	RCVCM_S32 blockSize,
	RCVCM_S32 aperture_size);

RCVCM_Ret 
rcvcm_HoughLines(
	const RCVCM_Image* src,
	RCVCM_F64 rho,
	RCVCM_F64 theta,
	RCVCM_S32 threshold,
	RCVCM_SEQ* seq,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	RCVCM_S32 max_count);

RCVCM_Ret 
rcvcm_HoughLinesP(
	const RCVCM_Image* src,
	RCVCM_F64 rho,
	RCVCM_F64 theta,
	RCVCM_S32 threshold,
	RCVCM_F64 param1,
	RCVCM_F64 param2,
	RCVCM_SEQ* seq,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	const RCVCM_MEMSTORAGE_CB_FUNCS* memst_cb,
	RCVCM_S32 max_count);

RCVCM_Ret 
rcvcm_HoughLinesMS(
	const RCVCM_Image* src,
	RCVCM_F64 rho,
	RCVCM_F64 theta,
	RCVCM_S32 threshold,
	RCVCM_F64 param1,
	RCVCM_F64 param2,
	RCVCM_SEQ* seq,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	RCVCM_S32 max_count);

RCVCM_Ret 
rcvcm_HoughCircles(
	const RCVCM_Image* src,
	RCVCM_F64 dp,
	RCVCM_F64 minDist,
	RCVCM_F64 param1,
	RCVCM_F64 param2,
	RCVCM_S32 minRadius,
	RCVCM_S32 maxRadius,
	RCVCM_SEQ* seq,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	const RCVCM_MEMSTORAGE_CB_FUNCS* memst_cb,
	RCVCM_S32 max_count);


#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_FEAT_DETECT_H */
