#ifndef RCVCM_BASIC_H
#define RCVCM_BASIC_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2014 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_basic.h
*/
/* PRQA S 0292 1 */
/* $Revision: 577 $
******************************************************************************/

#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Format 
rcvcm_GetImageDataFormat(
	const RCVCM_Image* arr);

RCVCM_S32 
rcvcm_getTypeSize(
	RCVCM_S32 type);

RCVCM_S32 
rcvcm_getElemSize(
	const RCVCM_Image* image);

RCVCM_Ret
rcvcm_initImage(
	RCVCM_Image* image,
	RCVCM_S32 width,
	RCVCM_S32 height,
	RCVCM_S32 type,
	RCVCM_S32 channels);

RCVCM_Ret
rcvcm_initImageCont(
	RCVCM_Image* image,
	RCVCM_S32 width,
	RCVCM_S32 height,
	RCVCM_S32 type,
	RCVCM_S32 channels);

RCVCM_Ret
rcvcm_createImage(
	RCVCM_Image* image,
	RCVCM_S32 width,
	RCVCM_S32 height,
	RCVCM_S32 type,
	RCVCM_S32 channels);

RCVCM_Ret
rcvcm_createImageCont(
	RCVCM_Image* image,
	RCVCM_S32 width,
	RCVCM_S32 height,
	RCVCM_S32 type,
	RCVCM_S32 channels);

RCVCM_Ret
rcvcm_createData(
	RCVCM_Image* image);

void
rcvcm_releaseData(
	RCVCM_Image* image);

RCVCM_Scalar rcvcm_scalar(
	RCVCM_F64 val0,
	RCVCM_F64 val1,
	RCVCM_F64 val2,
	RCVCM_F64 val3);

RCVCM_Rect rcvcm_rect(
	RCVCM_S32 x,
	RCVCM_S32 y,
	RCVCM_S32 width,
	RCVCM_S32 height);

RCVCM_Size rcvcm_size(
	RCVCM_S32 width,
	RCVCM_S32 height);

RCVCM_Ret	rcvcm_setRoi(
	RCVCM_Image* src,
	RCVCM_Rect rect);

RCVCM_Ret	rcvcm_resetRoi(
	RCVCM_Image* src);

RCVCM_Rect	rcvcm_getRoi(
	RCVCM_Image* src);

RCVCM_Ret rcvcm_get1d(
	const RCVCM_Image* src,
	RCVCM_S32 index,
	RCVCM_Scalar* value);

RCVCM_Ret rcvcm_get2d(
	const RCVCM_Image* src,
	RCVCM_S32 y,
	RCVCM_S32 x,
	RCVCM_Scalar* value);

RCVCM_Ret rcvcm_get1dC1(
	const RCVCM_Image* src,
	RCVCM_S32 index,
	RCVCM_F64* value);

RCVCM_Ret rcvcm_get2dC1(
	const RCVCM_Image* src,
	RCVCM_S32 y,
	RCVCM_S32 x,
	RCVCM_F64* value);

RCVCM_Ret rcvcm_set1d(
	RCVCM_Image* src,
	RCVCM_S32 index,
	RCVCM_Scalar* value);

RCVCM_Ret rcvcm_set2d(
	const RCVCM_Image* src,
	RCVCM_S32 y,
	RCVCM_S32 x,
	RCVCM_Scalar* value);

RCVCM_Ret rcvcm_set1dC1(
	const RCVCM_Image* src,
	RCVCM_S32 index,
	RCVCM_F64 value);

RCVCM_Ret rcvcm_set2dC1(
	const RCVCM_Image* src,
	RCVCM_S32 y,
	RCVCM_S32 x,
	RCVCM_F64 value);

RCVCM_S32 rcvcm_round(
	RCVCM_F64 value);


#ifdef __cplusplus
}
#endif

#endif  /* RCVCM_BASIC_H */
