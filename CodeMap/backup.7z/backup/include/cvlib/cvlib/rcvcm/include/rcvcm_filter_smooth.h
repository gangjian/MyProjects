#ifndef RCVCM_FILTER_SMOOTH_H
#define RCVCM_FILTER_SMOOTH_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_filter_smooth.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret
rcvcm_smooth_gaussian(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* kernelH,
	const RCVCM_Image* kernelV);

RCVCM_Ret
rcvcm_smooth_median(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 median_size);


#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_FILTER_SMOOTH_H */
