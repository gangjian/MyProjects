#ifndef RCVCM_OPTFLOW_H
#define RCVCM_OPTFLOW_H
/******************************************************************************
    CV Library
     Copyright (C) 2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_optflow.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret 
rcvcm_optflowBM(
	const RCVCM_Image* prev,
	const RCVCM_Image* curr,
	RCVCM_Size b_size,
	RCVCM_Size s_size,
	RCVCM_Size range,
	RCVCM_S32 use_previous,
	RCVCM_S32 lower,
	RCVCM_S32 upper,
	RCVCM_Image* velx,
	RCVCM_Image* vely);

RCVCM_Ret 
rcvcm_optflowLK(
	const RCVCM_Image* prev,
	const RCVCM_Image* curr,
	RCVCM_Size w_size,
	RCVCM_Image* velx,
	RCVCM_Image* vely);

RCVCM_Ret 
rcvcm_optflowPyrLK(
	const RCVCM_Image* prev,
	const RCVCM_Image* curr,
	RCVCM_Image* prevPyr,
	RCVCM_Image* currPyr,
	const RCVCM_Point2D32f* prevFeatures,
	RCVCM_Point2D32f* currFeatures,
	RCVCM_S32 count,
	RCVCM_Size winSize,
	RCVCM_S32 level,
	RCVCM_S8* status,
	RCVCM_F32* track_error,
	RCVCM_Terminator term,
	RCVCM_S32 flags);


#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_OPTFLOW_H */
