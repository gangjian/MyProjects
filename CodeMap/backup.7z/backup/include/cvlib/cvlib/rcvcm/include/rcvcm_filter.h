#ifndef RCVCM_FILTER_H
#define RCVCM_FILTER_H
/******************************************************************************
    CV Library
     Copyright (C) 2014-2015 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_filter.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret 
rcvcm_interpolate(
	RCVCM_S32 p,
	RCVCM_S32 len,
	RCVCM_S32 borderType,
	RCVCM_S32* out_pos);

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_FILTER_H */
