#ifndef RCVCM_LABELING_H
#define RCVCM_LABELING_H
/******************************************************************************
    CV Library
     Copyright (C) 2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_labeling.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret rcvcm_labeling(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 connect,
	RCVCM_S32 opt,
	RCVCM_S32* count);

RCVCM_Ret rcvcm_labelingAreaFilter(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 connect,
	RCVCM_S32 thmin,
	RCVCM_S32 thmax,
	RCVCM_S32 opt1,
	RCVCM_S32 opt2,
	RCVCM_S32* count);

RCVCM_Ret rcvcm_getLabelRegionX(
	RCVCM_Image* src,
	RCVCM_S32* minX,
	RCVCM_S32* maxX);

RCVCM_Ret rcvcm_getLabelRegionY(
	RCVCM_Image* src,
	RCVCM_S32* minY,
	RCVCM_S32* maxY);

RCVCM_Ret rcvcm_getLabelArea(
	RCVCM_Image* src,
	RCVCM_S32* area);

RCVCM_Ret rcvcm_getLabelGravity(
	RCVCM_Image* src,
	RCVCM_Point2D32f* gravity);


#ifdef __cplusplus
}
#endif

#endif  /* RCVCM_LABELING_H */
