#ifndef RCVCM_DILATE_H
#define RCVCM_DILATE_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_dilate.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/* shape of the structuring element */
#define RCVCM_SHAPE_NONE	(-1)
#define RCVCM_SHAPE_RECT	(0)
#define RCVCM_SHAPE_CROSS	(1)

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret	rcvcm_ErodeDilate(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_ConvKernel* kernel,
	const RCVCM_S32 iterations,
	RCVCM_S32 erodedilate );

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_DILATE_H */
