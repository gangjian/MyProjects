#ifndef RCVCM_MISC_TRANS_H
#define RCVCM_MISC_TRANS_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2015 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_misc_trans.h
*/
/* PRQA S 0292 1 */
/* $Revision: 218 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret
rcvcm_threshold(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_F64 threshold,
	RCVCM_F64 max_value,
	RCVCM_S32 threshold_type);

RCVCM_Ret
rcvcm_otsu_method(
	const RCVCM_Image* src,
	RCVCM_F64* threshold);

RCVCM_Ret
rcvcm_adaptiveThreshold(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_F64 max_value,
	RCVCM_S32 adaptive_method,
	RCVCM_S32 threshold_type,
	RCVCM_S32 block_size,
	RCVCM_F64 param1);

RCVCM_Ret 
rcvcm_cvtcolor(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 code);


#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_MISC_TRANS_H */
