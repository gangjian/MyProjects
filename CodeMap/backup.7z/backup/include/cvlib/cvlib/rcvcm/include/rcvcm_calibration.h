#ifndef RCVCM_CALIBRATION_H
#define RCVCM_CALIBRATION_H
/******************************************************************************
    CV Library
     Copyright (C) 2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_calibration.h
*/
/* PRQA S 0292 1 */
/* $Revision: 634 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret	rcvcm_extrinsicCameraParams(
	RCVCM_Image* points3d,
	RCVCM_Image* points2d,
	RCVCM_Image* camMatrix,
	RCVCM_Image* distortion,
	RCVCM_Image* rvec,
	RCVCM_Image* tvec,
	RCVCM_S32 use_previous);

RCVCM_Ret	rcvcm_projectPoints(
	RCVCM_Image* points3d,
	RCVCM_Image* rvec,
	RCVCM_Image* tvec,
	RCVCM_Image* camMatrix,
	RCVCM_Image* distCoeffs,
	RCVCM_Image* points2d,
	RCVCM_Image* dpdr,
	RCVCM_Image* dpdt,
	RCVCM_Image* dpdf,
	RCVCM_Image* dpdc,
	RCVCM_Image* dpdd,
	RCVCM_F64 aspect_ratio);

RCVCM_Ret	rcvcm_Rodrigues(
	RCVCM_Image* src,
	RCVCM_Image* dst,
	RCVCM_Image* jacobian);

RCVCM_Ret	rcvcm_undistort(
	RCVCM_Image* src,
	RCVCM_Image* dst,
	RCVCM_Image* camMatrix,
	RCVCM_Image* distortion,
	RCVCM_Image* newCamMatrix);

RCVCM_Ret	rcvcm_undistortPoints(
	RCVCM_Image* src,
	RCVCM_Image* dst,
	RCVCM_Image* camMatrix,
	RCVCM_Image* distCoeffs,
	RCVCM_Image* R,
	RCVCM_Image* P);

RCVCM_Ret	rcvcm_findFundamentalMat(
	const RCVCM_Image* points1,
	const RCVCM_Image* points2,
	RCVCM_Image* fundamentalMatrix,
	RCVCM_S32 method,
	RCVCM_F64 param1,
	RCVCM_F64 param2,
	RCVCM_Image* status,
	RCVCM_S32* nroots);

RCVCM_Ret	rcvcm_InitUndistortRectifyMap(
	RCVCM_Image*  cameraMatrix,
	RCVCM_Image*  distCoeffs,
	RCVCM_Image*  R,
	RCVCM_Image*  newCameraMatrix,
	RCVCM_Image*  map1,
	RCVCM_Image*  map2);

RCVCM_Ret	rcvcm_PointUndistort(
	RCVCM_Point2D32f* src,
	RCVCM_Point2D32f* dst,
	RCVCM_Image* distortion,
	RCVCM_F64 err);

RCVCM_Ret	rcvcm_stereoBM(
	const RCVCM_Image* left,
	const RCVCM_Image* right,
	RCVCM_Image* disparity,
	RCVCM_StereoBMState* state);


#ifdef __cplusplus
}
#endif

#endif  /* RCVCM_CALIBRATION_H */
