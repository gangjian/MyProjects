#ifndef RCVCM_FILTER_CONVOLUTION_H
#define RCVCM_FILTER_CONVOLUTION_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_filter_convolution.h
*/
/* PRQA S 0292 1 */
/* $Revision: 268 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

#ifdef IMPSIM_INTEGRATED // sim_patch
RCVCM_Ret
rcvcm_convolution(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* kernel,
	RCVCM_Point anchor,
	RCVCM_S32 border,
    int *floating_point);
#else
RCVCM_Ret
rcvcm_convolution(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* kernel,
	RCVCM_Point anchor,
	RCVCM_S32 border);
#endif

RCVCM_Ret
rcvcm_convolution_separate(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* kernel_x,
	const RCVCM_Image* kernel_y,
	RCVCM_Point anchor,
	RCVCM_S32 border);

RCVCM_Ret
rcvcm_blur(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 size1,
	RCVCM_S32 size2,
	RCVCM_S32 normalize);

RCVCM_Ret
rcvcm_gaussian(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 size1,
	RCVCM_S32 size2,
	RCVCM_S32 normalize,
	RCVCM_S32 border);

RCVCM_Ret
rcvcm_sobel(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_S32 xorder,
	RCVCM_S32 yorder,
	RCVCM_S32 aperture_size,
	RCVCM_S32 normalize);

RCVCM_Ret
rcvcm_pyrDown5(
	const RCVCM_Image* src,
	const RCVCM_Image* dst);

RCVCM_Ret
rcvcm_pyrUp5(
	const RCVCM_Image* src,
	const RCVCM_Image* dst);

RCVCM_Ret
rcvcm_convolution_fixed(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	const RCVCM_Image* kernel,
	RCVCM_Point anchor,
	RCVCM_S32 scale,
	RCVCM_S32 border);

RCVCM_Ret
rcvcm_copyWithBorder(
	const RCVCM_Image* src,
	const RCVCM_Image* dst,
	RCVCM_Point offset,
	RCVCM_S32 border);

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_FILTER_CONVOLUTION_H */
