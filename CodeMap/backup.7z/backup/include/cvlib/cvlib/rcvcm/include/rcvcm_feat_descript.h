#ifndef RCVCM_FEAT_DESCRIPT_H
#define RCVCM_FEAT_DESCRIPT_H
/******************************************************************************
    CV Library
     Copyright (C) 2014-2015 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_feat_detect.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


RCVCM_Ret 
rcvcm_fast(
	const RCVCM_Image* src,
	RCVCM_SEQ* keypoints,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	RCVCM_DetectorParams* params);


RCVCM_Ret 
rcvcm_nms_response(
	RCVCM_SEQ* inkeys,
	RCVCM_SEQ* keypoints,
	RCVCM_Size roi_size,
	const RCVCM_SEQ_CB_FUNCS* seq_cb);

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_FEAT_DESCRIPT_H */
