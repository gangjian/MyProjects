#ifndef RCVCM_COMMON_H
#define RCVCM_COMMON_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_common.h
*/
/* PRQA S 0292 1 */
/* $Revision: 149 $
******************************************************************************/
#include "rcvcm.h"
#include "rcvsip.h"

#ifdef IMPSIM_INTEGRATED // sim_patch    
#include <stdint.h> // sim_patch
#include <stdbool.h> // sim_patch
#include "impsim_int.h" // sim_patch
#endif // sim_patch  
/*************************************************************
 *   Function Definitions
 *************************************************************/

#ifdef __cplusplus
extern "C" {
#endif


void 
rcvcm_setPict(
	RCVCM_Pict* pict,
	const RCVCM_Image* image);

void 
rcvcm_setPictYUV(
	RCVCM_Pict* pict1,
	RCVCM_Pict* pict2,
	const RCVCM_Image* image);

void
rcvcm_calcAddr(
	RCVCM_Pict* pict,
	const RCVCM_Image* image,
	RCVCM_S32 y,
	RCVCM_S32 x);

void
rcvcm_calcAddrYUV(
	RCVCM_Pict* pict,
	RCVCM_Pict* pict2,
	const RCVCM_Image* image,
	RCVCM_S32 y,
	RCVCM_S32 x);


#ifdef __cplusplus
}
#endif

#endif /* #ifndef RCVCM_COMMON_H */
