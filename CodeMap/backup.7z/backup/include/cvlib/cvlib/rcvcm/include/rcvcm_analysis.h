#ifndef RCVCM_ANALYSIS_H
#define RCVCM_ANALYSIS_H
/******************************************************************************
    CV Library
     Copyright (C) 2012-2013 Renesas Electronics Corporation, all rights reserved.

    [File] rcvcm_analysis.h
*/
/* PRQA S 0292 1 */
/* $Revision: 373 $
******************************************************************************/
#include "rcvcm.h"

/* Core Module Seq Tree Scanner */
typedef struct ST_RCVCM_TREE_SCANNER {
	RCVCM_S32		order;
	RCVCM_SEQ*		node;
	RCVCM_SEQ*		node_from;
	RCVCM_S32		is_vertical;	/* 0: horizontal 1:vertical */
} RCVCM_TREE_SCANNER ;

/*************************************************************
 *   Function Definitions
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

RCVCM_Ret	rcvcm_Binarize(
	const RCVCM_Image* img );

RCVCM_Ret	rcvcm_contours_find_start(
	void** dst_scanner,
	const RCVCM_Image* img,
	RCVCM_MEMSTORAGE* storage,
	RCVCM_S32 seq_flags,
	RCVCM_S32 header_size,
	RCVCM_S32 elem_size,
	RCVCM_S32 mode,
	RCVCM_S32 method,
	RCVCM_Point offset,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	const RCVCM_MEMSTORAGE_CB_FUNCS* memst_cb
	);

RCVCM_Ret	rcvcm_contours_find_next(
	RCVCM_SEQ** dst_seq,
	void* scanner,
	RCVCM_SEQWRITER* writer_mem );

RCVCM_Ret	rcvcm_contours_find_end(
	RCVCM_SEQ** dst_seq,
	void* scanner );

RCVCM_Ret	rcvcm_get_contour_area(
	RCVCM_F64* area,
	const RCVCM_SEQ* seq,
	const RCVCM_S32 start,
	const RCVCM_S32 end,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	RCVCM_SEQREADER* reader,
	RCVCM_SEQ_Ret* sqret
	);

RCVCM_Ret rcvcm_bounding_rect(
	RCVCM_Rect* rect,
	const RCVCM_SEQ* seq,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	RCVCM_SEQREADER* reader,
	RCVCM_SEQ_Ret* sqret
	);

RCVCM_Ret rcvcm_arc_length(
	RCVCM_F64* len,
	const RCVCM_SEQ* seq,
	const RCVCM_S32 start, 
	const RCVCM_S32 slice_length,
	const RCVCM_SEQ_CB_FUNCS* seq_cb,
	RCVCM_SEQREADER* reader,
	RCVCM_SEQ_Ret* sqret
	);

RCVCM_Ret rcvcm_approx_poly(
	const RCVCM_SEQ* src_seq,
	RCVCM_S32 method,
	RCVCM_F64 parameter,
	RCVCM_S32 parameter2,
	const RCVCM_SEQ_CB_FUNCS* seq_cb, 
	RCVCM_SEQ* dst_seq,
	RCVCM_F64 *distance
	);

#ifdef __cplusplus
}
#endif

#endif  /* #RCVCM_ANALYSIS_H */
