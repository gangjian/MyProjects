/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

#ifndef DUMPIMP_H
#define DUMPIMP_H

#ifdef __cplusplus
extern "C" {
#endif

/*!
  @defgroup group_dumpimp dumpimp (under development)
  @brief Utility library to handle Shader object created by Shader
  compiler/assembler. This API is provided "as is".
*/


enum DumpimpObjType {OBJVTX, OBJPX};

    
/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */
void *dumpimpOpen(char *file_name);

    
/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */
int dumpimpClose(void *obj);

    
/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */
void dumpimpDump(void *obj);

    
/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */
void dumpimpGetSize(void *obj, enum DumpimpObjType obj_type, int *uniform_size, int *code_size);

    
/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */
void dumpimpGetEntry(void *obj, enum DumpimpObjType obj_type, uint32_t *main_addr, uint32_t *sini_addr);

    
/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */
void dumpimpCopyCode(void *obj, enum DumpimpObjType obj_type, uint32_t *code_array);

    
/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */
void dumpimpCopyUniform(void *obj, uint32_t *uniform_array);


/**
  @ingroup group_dumpimp

  TBD
  
  @param TBD
  @return TBD
 */    
void dumpimpDisassembleOneLine(uint32_t data, char *code);
    
#ifdef __cplusplus
}
#endif

#endif /* DUMPIMP_H */
