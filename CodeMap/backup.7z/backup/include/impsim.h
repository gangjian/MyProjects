/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

#ifndef IMPSIM_H_
#define IMPSIM_H_

#include "impsim_common.h"

// Header for performance simulator.
#ifdef IMPSIM_PROFILE
#include "impp.h"
#endif

// Headers for IMPLIB.
#include "ipxdef.h"
#include "ipxsys.h"
#include "ipxprot.h"

// Headers for CVLib.
#define RCV_SYS_HARD 1 // To utilize some methods and macros for the IMP driver.
#include "rcvlib_bsd.h"

// Header for dumpimp
#include "dumpimp.h"

// Header for SDA API.
#define RCVDRV_SHADER_MODULE_NUM 2 // H.Shiota, Defined here to avoid including IMP driver header.
#include "sda_api.h"

#ifdef __cplusplus
extern "C" {
#endif
    
/*!
  @defgroup group_impsim impsim
  @brief IMP-X simulator API (impsim)
*/

// Bit assignment for simlog.
// Upper 8bits are to specify log level.
// Lower 24bits are to specify log category.

// The following macros are for simlog()/SIMLOG()
// Log categoris.
#define SL_USER 0x00000001 // Log from user application
#define SL_COMMON 0x00000002 // Log from sim common
#define SL_LS_ADPT 0x00000004 // Log from legacy_sim_adpt
#define SL_CV_ADPT 0x00000008 // Log from cvlib_adpt
#define SL_IL_ADPT 0x00000010 // Log from implib_adpt
#define SL_IM_ADPT 0x00000020 // Log from imrsx_sim_adpt
#define SL_IX_ADPT 0x00000040 // Log from imrlsx_sim_adpt
#define SL_LS 0x00000100 // Log from legacy sim
#define SL_IM 0x00000200 // Log from imrsx sim
#define SL_IX 0x00000400 // Log from imrlsx sim
#define SL_SS 0x00001000 // Log from shader sim
#define SL_PS 0x00002000 // Log from performance sim
#define SL_SA 0x00004000 // Log from sda api and dumpimp
#define SL_ANYCAT 0x00ffffff // Any category of log

// Log levels.
#define SL_ALWAYS_ON 0x80000000 // Always on
#define SL_ERR 0x40000000 // Error case
#define SL_L1 0x20000000 // Log level 1
#define SL_L2 0x10000000 // Log level 2
#define SL_L3 0x08000000 // Log level 3
#define SL_L4 0x04000000 // Log level 4
#define SL_L5 0x02000000 // Log level 5
#define SL_L6 0x01000000 // Log level 6

// Log categoris.
#define SL_EN_NO_LOG 0x00000000 // No log is printed out
#define SL_EN_USER SL_USER // Log from user application
#define SL_EN_COMMON SL_COMMON // Log from sim common
#define SL_EN_LS_ADPT SL_LS_ADPT // Log from legacy_sim_adpt
#define SL_EN_CV_ADPT SL_CV_ADPT // Log from cvlib_adpt
#define SL_EN_IL_ADPT SL_IL_ADPT // Log from implib_adpt
#define SL_EN_IM_ADPT SL_IM_ADPT // Log from imrx_sim_adpt
#define SL_EN_IX_ADPT SL_IX_ADPT // Log from imrlsx_sim_adpt
#define SL_EN_LS SL_LS // Log from legacy sim
#define SL_EN_IM SL_IM // Log from imrsx sim
#define SL_EN_IX SL_IX // Log from imrlsx sim
#define SL_EN_SS SL_SS // Log from shader sim
#define SL_EN_PS SL_PS // Log from performance sim
#define SL_EN_SA SL_SA // Log from sda api and dumpimp 
#define SL_EN_ANYCAT 0x00ffffff // Any category of log

// Log level
#define SL_EN_NO_LOG 0x00000000 // No log is printed out
#define SL_EN_REL SL_ALWAYS_ON | SL_ERR // Default for release version
#define SL_EN_L1 SL_EN_REL | SL_L1 // Log level 1
#define SL_EN_L2 SL_EN_L1 | SL_L2 // Log level 2
#define SL_EN_L3 SL_EN_L2 | SL_L3 // Log level 3
#define SL_EN_L4 SL_EN_L3 | SL_L4 // Log level 4
#define SL_EN_L5 SL_EN_L4 | SL_L5 // Log level 5
#define SL_EN_L6 SL_EN_L5 | SL_L6 // Log level 6

// Log format
#define SL_EN_NONE 0x00000000 // Disable all
#define SL_EN_FUNC_NAME 0x80000000 // Enable to output function name
#define SL_EN_LINE 0x40000000 // Enable to output line number of function
#define SL_EN_TIME 0x20000000 // Enable to output logger time 

/**
  @ingroup group_impsim
  @struct IMPSIM_CONFIG
  @brief Struct to configure impsim which is passed to impsim_Open().
 */
typedef struct {
    /** Heap size the memory manager uses. Unit is "byte". Required heap size
        depends on sum of source and destination images mainly. This heap is
        commonly used by IMPLIB, CVLib and memdrv_pub.
    */
    uint32_t heap_size;
    /** Not used. No need to set this variable at the moment.
        If need to disable initial log like copyright display, turn it
        off by impsim_EnableDebugLog().*/
    bool disable_initial_log;
    /** Specify mode of CVLib. */
    //int cvlib_mode;
} IMPSIM_CONFIG;


/**
  @ingroup group_impsim
  @struct IMPSIM_VERSION
  @brief Struct to store version information of impsim. Actual contents
  of the struct is provided by impsim_GetVersion().
 */
typedef struct {
    /** Major version of impsim. */     
    const int major;
    /** Minor version of impsim. */
    const int minor;
    /** Build number. */    
    const int build;
    /** Release name. */    
    const char *release;
} IMPSIM_VERSION;


/**
  @ingroup group_impsim
  
  Open impsim and initialize simulator resources.
  The following procedures are done in this function.
  -# Allocate heap with the heap size specified in IMPSIM_CONFIG and initialize memory driver.
  -# Initialize and start IMP core simulator and its device driver.
  -# Initialize and start IMRX/IMRLSX driver.
  -# Initialize and start Shader core simulator and its device driver.

  @param[in] impsim_config Configuration parameters for IMP simulator.
  See the description of IMPSIM_CONFIG for detail.
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.
  
 */
int impsim_Open(IMPSIM_CONFIG impsim_config);


/**
  @ingroup group_impsim
  
  Close impsim. All resouces are released.

  @param none
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.
  
 */
int impsim_Close(void);


/**
  @ingroup group_impsim

  Get version information of IMPSIM.

  @param none
  @return The struct IMPSIM_VERSION is returned.

 */
IMPSIM_VERSION impsim_GetVersion(void);


/**
  @ingroup group_impsim

  Emulated video-in to put image data to IMR LSX simulator.

  @param [in] ch IMR LSX channel number. Channel 0, 1, 2 and 3 are acceptable. 
  @param [in] src_id Memory block ID for source image. Memory block is reserved
  via memory driver. See memory driver API for detail.
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.
  
  \note This API is not implemented in the Demo release.
 */
int impsim_Vin(const int32_t ch, const int32_t src_id);


/**
   @ingroup group_impsim

   Enable log output. Log is output to standard output.
   Log category and log level are able to be specified via parameters.

   @param new_category Category of the log message. The "or" of following parameters is able
   to be specified.<br>
   - SL_EN_NO_LOG: No log is printed out
   - SL_EN_USER: Log from user application
   - SL_EN_COMMON: Log from sim common. Only this category is specified after impsim_Open().
   - SL_EN_LS_ADPT: Log from legacy_sim_adpt
   - SL_EN_CV_ADPT: Log from cvlib_adpt
   - SL_EN_IL_ADPT: Log from implib_adpt
   - SL_EN_IM_ADPT: Log from imrx_sim_adpt
   - SL_EN_IX_ADPT: Log from imrlsx_sim_adpt       
   - SL_EN_LS: Log from legacy sim
   - SL_EN_IM: Log from imrsx sim
   - SL_EN_IX: Log from imrlsx sim       
   - SL_EN_SS: Log from shader sim
   - SL_EN_PS: Log from performance sim
   - SL_EN_SA: Log from sda api and dumpimp   
   - SL_EN_ANYCAT: Any category of log
   @param new_level Log level of this log message. The one of following parameters should be
   specified.<br>
   - SL_EN_NO_LOG: No log is printed out
   - SL_EN_REL: Enable the minimum logs like copyiright. This is the default after impsim_Open().
   - SL_EN_L1: Enable log level 1 and lower level log.
   - SL_EN_L2: Enable log level 2 and lower level log.
   - SL_EN_L3: Enable log level 3 and lower level log.
   - SL_EN_L4: Enable log level 4 and lower level log.
   - SL_EN_L5: Enable log level 5 and lower level log.
   - SL_EN_L6: Enable log level 6 and lower level log.  
   @param new_format Specify format of log message in printf style with the following variable
   arguments. SL_EN_FUNC_NAME, SL_EN_LINE and SL_EN_TIME are able to be specified at the same
   time by "or".
   - SL_EN_NONE: Disable all. This is the default after impsim_Open().
   - SL_EN_FUNC_NAME: Enable to output function name
   - SL_EN_LINE: Enable to output line number of function
   - SL_EN_TIME: Enable to output logger time
   @return none
*/
int impsim_EnableDebugLog(uint32_t new_category, uint32_t new_level, uint32_t new_format);


typedef void * ImpsimProfileContext; // Opaque pointer.
    
/**
  @ingroup group_impsim

  Open performance simulator. Dedicated context created by this API should be held
  user software.

  @param none
  @return Opaque pointer storing internal the internal data for IMPSIM profile.
  @retval non-NULL Pointer to ImpsimProfileContext variable. Nomal end.
  @retval NULL Error takes place.
 */
ImpsimProfileContext impsim_ProfileOpen(void);


/**
  @ingroup group_impsim

  Close performance simulator.

  @param [in] ctx Opaque pointer storing internal data for IMPSIM profile.
  @return none
 */
void impsim_ProfileClose(ImpsimProfileContext *ctx);

    
/**
  @ingroup group_impsim

  Start performance simulation. After this API called, processing time
  of each API are recorded.
  Past simulated times before this API called are cleared automatically.

  @param [in] ctx Opaque pointer storing internal data for IMPSIM profile.
  @return none

  This function must be invoked after impsim_ProfileOpen().
 */
void impsim_ProfileStart(ImpsimProfileContext *ctx);


/**
  @ingroup group_impsim

  Stop performance simulation. 

  @param [in] ctx Opaque pointer storing internal data for IMPSIM profile.
  @return none

  This function must be invoked before impsim_Close().
 */
void impsim_ProfileStop(ImpsimProfileContext *ctx);


/**
  @ingroup group_impsim

  @enum Library
  @brief Specify the library, "IMPLIB" or "CVLib" for impsim_ProfileTimeOfLastApi().
 */
enum Library {
    IMPLIB,
    CVLIB
};


/**
  @ingroup group_impsim

  Return processing time of the last API in 100nsec unit for specified library.\n
  If one of the following cases takes place, the return value from
  impsim_ProfileTimeOfLastAPI() is *undefined*.
  - Case the last API does not support profiling.
  - Case the last API is failed. 
  - Case any API is not executed before impsim_ProfileTimeOfLastAPI() is invoked.

  @param [in] ctx Opaque pointer storing internal data for IMPSIM profile.
  @param [in] library Specify "IMPLIB" or "CVLib" the API processing time is simulated.
  @return Processing time of the last API invoked.
 */
int impsim_ProfileTimeOfLastApi(ImpsimProfileContext *ctx, enum Library library);

    
/**
  @ingroup group_impsim

  Dump processing times recorded to the file.
  Output file has the CSV format.
  
  @param [in] ctx Opaque pointer storing internal data for IMPSIM profile.
  @param [in] file_name File name without suffix to be dumped. The suffix is
  added by this API automatically.
  @return Result of API execution.
  @retval E_OK No error. Normal return.
  @retval Others Other error takes place.

 */
int impsim_ProfileOutput(ImpsimProfileContext *ctx, char* file_name);

    
/**
  @ingroup group_impsim

  Convert an image data for IMPLIB to the one for CVlib.
  Create new RIplImage from given IMPLIB_IMGID.

  @param [in] id Image ID created by IMPLIB.
  @retval RIplImage* Image data type for CVlib.
 */
RIplImage *impsim_convert_ImgIDToRIplImage(IMPLIB_IMGID id);


/**
  @ingroup group_impsim

  Alias of impsim_convert_ImgIDToRIplImage() for code compatibility.
 */
#define convert_ImgIDToRIplImage(ID) impsim_convert_ImgIDToRIplImage(ID)

// H.Shiota, temporary hacked until CVLib spec is finally fixed.
RCvU32 rcvUsrDataPhysAddrGet(void *virt_addr);
    
#ifdef __cplusplus
}
#endif

#endif /* IMPSIM_H_ */
