#ifndef IMPSIM_INT_H_
#define IMPSIM_INT_H_

#include "impsim_common.h"

// Header for performance simulator.
#ifdef IMPSIM_PROFILE
#include "impp.h"
#endif

#include "version.h"
#include "error.h"
#include "simlog.h"

#define RELIP_IMPX4_LC0_BASE 0xff900000 // Legacy Core 0
#define RELIP_IMPX4_LC1_BASE 0xff920000 // Legacy Core 1
#define RELIP_IMPX4_LC2_BASE 0xff940000 // Legacy Core 2
#define RELIP_IMPX4_LC3_BASE 0xff960000 // Legacy Core 3
#define RELIP_IMPX4_SC0_BASE 0xff980000 // Shader Core 0
#define RELIP_IMPX4_SC1_BASE 0xff990000 // Shader Core 1            
#define RELIP_IMPX4_DIST_BASE 0xffa00000 // Distributer

#include "impdrv.h"
#include "memdrv.h"
#include "distributer_sim_prot.h"
#include "legacy_sim_prot.h"
#include "imrdrv.h"
#include "imrlsdrv_int.h"
#include "imrlsxemu_prot.h"
#include "imrlsdrv_impl.h"

#include "vin_emu.h"

#include "relip_if.h"

#include "rcvlib_usr_impsim.h"
#include "rcv_impdrv.h"
#include "rcvlib_usr.h"

// To use Integrity specific methods.
#include "ipxdvc_inner.h"

#include "dumpimp.h"

#include "sda_api.h"

#include "implib_profile.h"
#include "cvlib_profile.h"

// Common functions for Renesas internal, but not for public.
int start_thread(void (*func)(void));
int wait_thread(void);
void sync_thread_start(void);
void sync_thread_end(void);

#endif /* IMPSIM_INT_H_ */
