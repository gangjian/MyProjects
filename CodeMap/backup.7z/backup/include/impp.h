/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */
#ifndef __IMPP_H__
#define __IMPP_H__

// 1
#define implib_Init                    impplib_Init
#define implib_Start                   impplib_Start
#define implib_Stop                    impplib_Stop

// 2
#define implib_InitIP                  impplib_InitIP
#define implib_InitIPExt               impplib_InitIPExt
#define implib_ReadIPErrorTable        impplib_ReadIPErrorTable
#define implib_ClearIPError            impplib_ClearIPError
#define implib_SetIPDataType           impplib_SetIPDataType
#define implib_IPLibVersion            impplib_IPLibVersion
#define implib_DriverIoControl         impplib_DriverIoControl
// H.Shiota, enable implib_Open
#define implib_Open                    impplib_Open
// H.Shiota, enable implib_Close
#define implib_Close                   impplib_Close
#define implib_SetTimeOut              impplib_SetTimeOut

// 3
#define implib_AllocImg                impplib_AllocImg
#define implib_AllocYUVImg             impplib_AllocYUVImg
#define implib_AllocCYUVImg            impplib_AllocCYUVImg
#define implib_FreeImg                 impplib_FreeImg
#define implib_FreeAllImg              impplib_FreeAllImg
#define implib_GetUVImgID              impplib_GetUVImgID
#define implib_ReadImgTable            impplib_ReadImgTable
#define implib_ReadYUVImgTable         impplib_ReadYUVImgTable
#define implib_ChangeImgDataType       impplib_ChangeImgDataType
#define implib_SetWindow               impplib_SetWindow
#define implib_SetAllWindow            impplib_SetAllWindow
#define implib_ResetAllWindow          impplib_ResetAllWindow
#define implib_EnableIPWindow          impplib_EnableIPWindow
#define implib_DisableIPWindow         impplib_DisableIPWindow
#define implib_ReadWindow              impplib_ReadWindow
#define implib_AllocImgExt             impplib_AllocImgExt              // enabel by fuku
#define implib_AllocYUVImgExt          impplib_AllocYUVImgExt           // enabel by fuku
#define implib_AllocCYUVImgExt         impplib_AllocCYUVImgExt          // enabel by fuku
#define implib_AllocImg16              impplib_AllocImg16
#define implib_AllocImg32              impplib_AllocImg32
#define implib_AllocImg16Ext           impplib_AllocImg16Ext            // enabel by fuku
#define implib_AllocImg32Ext           impplib_AllocImg32Ext            // enabel by fuku

// 4
#define implib_ActiveVideoPort         impplib_ActiveVideoPort
#define implib_SetVideoFrame           impplib_SetVideoFrame
#define implib_SelectCamera            impplib_SelectCamera
#define implib_GetCamera               impplib_GetCamera
#define implib_SetVFDelay              impplib_SetVFDelay
#define implib_CaptureContinuous       impplib_CaptureContinuous
#define implib_StopCaptureContinuous   impplib_StopCaptureContinuous
#define implib_GetCameraReqScene       impplib_GetCameraReqScene
#define implib_GetCameraResScene       impplib_GetCameraResScene

// 5
#define implib_SetConfigDisp           impplib_SetConfigDisp
#define implib_SetDispPalette          impplib_SetDispPalette
#define implib_SelectDisp              impplib_SelectDisp
#define implib_DispImg                 impplib_DispImg
#define implib_NoDisp                  impplib_NoDisp
#define implib_DispOverlap             impplib_DispOverlap
#define implib_DisableOverlap          impplib_DisableOverlap
#define implib_CombineYUV              impplib_CombineYUV

// 6
#define implib_IP_ClearAllImg          impplib_IP_ClearAllImg
#define implib_IP_ClearImg             impplib_IP_ClearImg
#define implib_IP_Const                impplib_IP_Const

// 7
#define implib_IP_Copy                 impplib_IP_Copy
#define implib_IP_Zoom                 impplib_IP_Zoom
#define implib_IP_ZoomExt              impplib_IP_ZoomExt
#define implib_IP_ZoomOut              impplib_IP_ZoomOut
#define implib_IP_ZoomOutExt           impplib_IP_ZoomOutExt
#define implib_IP_ZoomIn               impplib_IP_ZoomIn
#define implib_IP_ZoomInExt            impplib_IP_ZoomInExt
#define implib_IP_ZoomS                impplib_IP_ZoomS
#define implib_IP_Shift                impplib_IP_Shift
#define implib_IP_Rotate               impplib_IP_Rotate
#define implib_IP_MeanShrink           impplib_IP_MeanShrink    // add by fuku -F
#define implib_IP_Pack                 impplib_IP_Pack          // add by fuku -F
#define implib_IP_Unpack               impplib_IP_Unpack        // add by fuku -F

// 8
#define implib_IP_Binarize             impplib_IP_Binarize
#define implib_IP_BinarizeExt          impplib_IP_BinarizeExt

// 9
#define implib_IP_Invert               impplib_IP_Invert
#define implib_IP_Minus                impplib_IP_Minus
#define implib_IP_Abs                  impplib_IP_Abs
#define implib_IP_AddConst             impplib_IP_AddConst
#define implib_IP_SubConst             impplib_IP_SubConst
#define implib_IP_SubConstAbs          impplib_IP_SubConstAbs
#define implib_IP_MultConst            impplib_IP_MultConst
#define implib_IP_MinConst             impplib_IP_MinConst
#define implib_IP_MaxConst             impplib_IP_MaxConst
#define implib_WriteConvertLUT         impplib_WriteConvertLUT
#define implib_IP_ConvertLUT           impplib_IP_ConvertLUT
#define implib_IP_ShiftDown            impplib_IP_ShiftDown
#define implib_IP_ShiftUp              impplib_IP_ShiftUp
#define implib_WriteConvertLUT16       impplib_WriteConvertLUT16
#define implib_IP_DivConstNume         impplib_IP_DivConstNume
#define implib_IP_ModConstNume         impplib_IP_ModConstNume
#define implib_IP_DivConstDenom        impplib_IP_DivConstDenom
#define implib_IP_ModConstDenom        impplib_IP_ModConstDenom
#define implib_IP_ConstSub             impplib_IP_ConstSub

// 10
#define implib_IP_Add                  impplib_IP_Add
#define implib_IP_Sub                  impplib_IP_Sub
#define implib_IP_SubAbs               impplib_IP_SubAbs
#define implib_IP_Comb                 impplib_IP_Comb
#define implib_IP_CombAbs              impplib_IP_CombAbs
#define implib_IP_Mult                 impplib_IP_Mult
#define implib_IP_Average              impplib_IP_Average
#define implib_IP_Min                  impplib_IP_Min
#define implib_IP_Max                  impplib_IP_Max
#define implib_IP_SubConstAbsAdd       impplib_IP_SubConstAbsAdd
#define implib_IP_SubConstMultAdd      impplib_IP_SubConstMultAdd
#define implib_IP_SubConstMult         impplib_IP_SubConstMult
#define implib_IP_CombDrop             impplib_IP_CombDrop
#define implib_IP_ConvertLUTMin        impplib_IP_ConvertLUTMin
#define implib_IP_ConvertLUTMax        impplib_IP_ConvertLUTMax
#define implib_IP_InvertAdd            impplib_IP_InvertAdd
#define implib_IP_SubLUT               impplib_IP_SubLUT
#define implib_WriteConvertLUT2Fr      impplib_WriteConvertLUT2Fr
#define implib_IP_ConvertLUT2FrMin     impplib_IP_ConvertLUT2FrMin
#define implib_IP_ConvertLUT2FrMax     impplib_IP_ConvertLUT2FrMax
#define implib_WriteConvertLUT2Fr16    impplib_WriteConvertLUT2Fr16
#define implib_IP_Div                  impplib_IP_Div                   // enabel by fuku
#define implib_IP_Mod                  impplib_IP_Mod                   // enabel by fuku
#define implib_IP_SubSquare            impplib_IP_SubSquare             // enabel by fuku

// 11
#define implib_IP_And                  impplib_IP_And
#define implib_IP_Or                   impplib_IP_Or
#define implib_IP_Xor                  impplib_IP_Xor
#define implib_IP_InvertAnd            impplib_IP_InvertAnd
#define implib_IP_InvertOr             impplib_IP_InvertOr
#define implib_IP_Xnor                 impplib_IP_Xnor
#define implib_IP_ConvertLUTAnd        impplib_IP_ConvertLUTAnd
#define implib_IP_ZoomInLUTAnd         impplib_IP_ZoomInLUTAnd
#define implib_IP_BitCount             impplib_IP_BitCount             // H.Shiota
#define implib_IP_AndBitCount          impplib_IP_AndBitCount             // H.Shiota
#define implib_IP_OrBitCount           impplib_IP_OrBitCount             // add by fuku -F
#define implib_IP_XorBitCount          impplib_IP_XorBitCount            // add by fuku -F
#define implib_IP_XnorBitCount         impplib_IP_XnorBitCount           // add by fuku -F

// 12
#define implib_IP_PickNoise4           impplib_IP_PickNoise4
#define implib_IP_PickNoise8           impplib_IP_PickNoise8
#define implib_IP_Outline4             impplib_IP_Outline4
#define implib_IP_Outline8             impplib_IP_Outline8
#define implib_IP_Dilation4            impplib_IP_Dilation4
#define implib_IP_Dilation8            impplib_IP_Dilation8
#define implib_IP_Erosion4             impplib_IP_Erosion4
#define implib_IP_Erosion8             impplib_IP_Erosion8
#define implib_IP_Thin4                impplib_IP_Thin4
#define implib_IP_Thin8                impplib_IP_Thin8
#define implib_IP_Shrink4              impplib_IP_Shrink4
#define implib_IP_Shrink8              impplib_IP_Shrink8

// 13
#define implib_IP_SmoothFLT            impplib_IP_SmoothFLT
#define implib_IP_EdgeFLT              impplib_IP_EdgeFLT
#define implib_IP_EdgeFLTAbs           impplib_IP_EdgeFLTAbs
#define implib_IP_Lapl4FLT             impplib_IP_Lapl4FLT
#define implib_IP_Lapl8FLT             impplib_IP_Lapl8FLT
#define implib_IP_Lapl4FLTAbs          impplib_IP_Lapl4FLTAbs
#define implib_IP_Lapl8FLTAbs          impplib_IP_Lapl8FLTAbs
#define implib_IP_LineFLT              impplib_IP_LineFLT
#define implib_IP_LineFLTAbs           impplib_IP_LineFLTAbs
#define implib_IP_SmoothFLT5x5Ext      impplib_IP_SmoothFLT5x5Ext
#define implib_IP_EdgeFLT5x5Ext        impplib_IP_EdgeFLT5x5Ext
#define implib_IP_EdgeFLT7x7           impplib_IP_EdgeFLT7x7
#define implib_IP_EdgeFLT7x7AbsAdd     impplib_IP_EdgeFLT7x7AbsAdd
#define implib_IP_EdgeFLT7x7AbsAddZoomOutExt \
                                       impplib_IP_EdgeFLT7x7AbsAddZoomOutExt
#define implib_IP_EdgeFLT7x7AbsAddZoomOutExt2 \
                                       impplib_IP_EdgeFLT7x7AbsAddZoomOutExt2
#define implib_IP_ZoomOutwithFLT3x3    impplib_IP_ZoomOutwithFLT3x3
#define implib_IP_ZoomOutExtwithFLT7x7 impplib_IP_ZoomOutExtwithFLT7x7
#define implib_IP_SmoothFLT5x5         impplib_IP_SmoothFLT5x5
#define implib_IP_EdgeFLT5x5           impplib_IP_EdgeFLT5x5            // add by fuku -F
#define implib_IP_EdgeFLT7x7AbsAdd2    impplib_IP_EdgeFLT7x7AbsAdd2     // add by fuku -F
#define implib_IP_LineFLT1x25          impplib_IP_LineFLT1x25           // add by fuku -F
#define implib_IP_LineFLT1x25Abs       impplib_IP_LineFLT1x25Abs        // add by fuku -F

// 14
#define implib_IP_MinFLT               impplib_IP_MinFLT
#define implib_IP_MinFLT4              impplib_IP_MinFLT4
#define implib_IP_MinFLT8              impplib_IP_MinFLT8
#define implib_IP_MaxFLT               impplib_IP_MaxFLT
#define implib_IP_MaxFLT4              impplib_IP_MaxFLT4
#define implib_IP_MaxFLT8              impplib_IP_MaxFLT8
#define implib_IP_LineMinFLT           impplib_IP_LineMinFLT
#define implib_IP_LineMaxFLT           impplib_IP_LineMaxFLT
#define implib_IP_MinFLT5x5            impplib_IP_MinFLT5x5
#define implib_IP_MaxFLT5x5            impplib_IP_MaxFLT5x5

// 15
#define implib_IP_RankFLT              impplib_IP_RankFLT
#define implib_IP_Rank4FLT             impplib_IP_Rank4FLT
#define implib_IP_Rank8FLT             impplib_IP_Rank8FLT
#define implib_IP_MedFLT               impplib_IP_MedFLT
#define implib_IP_Med4FLT              impplib_IP_Med4FLT
#define implib_IP_Med8FLT              impplib_IP_Med8FLT

// 16
#define implib_IP_Label4               impplib_IP_Label4
#define implib_IP_Label8               impplib_IP_Label8
#define implib_IP_Label4withAreaFLT    impplib_IP_Label4withAreaFLT
#define implib_IP_Label8withAreaFLT    impplib_IP_Label8withAreaFLT
#define implib_IP_Label4withAreaFLTSort \
        impplib_IP_Label4withAreaFLTSort
#define implib_IP_Label8withAreaFLTSort \
        impplib_IP_Label8withAreaFLTSort
#define implib_IP_ExtractLORegionX     impplib_IP_ExtractLORegionX
#define implib_IP_ExtractLORegionY     impplib_IP_ExtractLORegionY
#define implib_IP_ExtractLOArea        impplib_IP_ExtractLOArea
#define implib_IP_ExtractLOAreaExt     impplib_IP_ExtractLOAreaExt
#define implib_IP_ExtractLOGravity     impplib_IP_ExtractLOGravity

// 17
#define implib_IP_ExtractGOFeatures    impplib_IP_ExtractGOFeatures
#define implib_IP_Histogram            impplib_IP_Histogram
#define implib_IP_HistogramShort       impplib_IP_HistogramShort
#define implib_IP_ProjectGO            impplib_IP_ProjectGO
#define implib_IP_ProjectGOonX         impplib_IP_ProjectGOonX
#define implib_IP_ProjectGOonY         impplib_IP_ProjectGOonY
#define implib_IP_ProjectGOMaxValue    impplib_IP_ProjectGOMaxValue
#define implib_IP_ProjectGOMinValue    impplib_IP_ProjectGOMinValue
#define implib_IP_ProjectBlockGO       impplib_IP_ProjectBlockGO
#define implib_IP_ProjectBlockGOMinMaxValue \
        impplib_IP_ProjectBlockGOMinMaxValue
#define implib_IP_ProjectLabelGO       impplib_IP_ProjectLabelGO
#define implib_IP_ProjectLabelGOMinMaxValue \
        impplib_IP_ProjectLabelGOMinMaxValue
#define implib_EnableRotateProject     impplib_EnableRotateProject
#define implib_DisableRotateProject    impplib_DisableRotateProject
#define implib_IP_HistogramFeatures    impplib_IP_HistogramFeatures
#define implib_EnableRotateProjectEx   impplib_EnableRotateProjectEx
#define implib_EnableLinearTransformProject \
        impplib_EnableLinearTransformProject

// 18
#define implib_IP_ExtractBOFeatures    impplib_IP_ExtractBOFeatures
#define implib_IP_ProjectBO            impplib_IP_ProjectBO
#define implib_IP_ProjectBORegionX     impplib_IP_ProjectBORegionX
#define implib_IP_ProjectBORegionY     impplib_IP_ProjectBORegionY
#define implib_IP_ProjectBlockBO       impplib_IP_ProjectBlockBO

// 19
#define implib_OpenImg                 impplib_OpenImg
#define implib_OpenImgExt              impplib_OpenImgExt
#define implib_CloseImg                impplib_CloseImg
#define implib_ReadImg                 impplib_ReadImg
#define implib_WriteImg                impplib_WriteImg
#define implib_SetPixelPointer         impplib_SetPixelPointer
#define implib_ReadPixel               impplib_ReadPixel
#define implib_WritePixel              impplib_WritePixel
#define implib_ReadPixelContinue       impplib_ReadPixelContinue
#define implib_WritePixelContinue      impplib_WritePixelContinue
#define implib_RefreshImg              impplib_RefreshImg
#define implib_OpenImgDirect           impplib_OpenImgDirect
#define implib_CloseImgDirect          impplib_CloseImgDirect
#define implib_ReadPixelExt            impplib_ReadPixelExt
#define implib_WritePixelExt           impplib_WritePixelExt
#define implib_ReadPixelContinueExt    impplib_ReadPixelContinueExt
#define implib_WritePixelContinueExt   impplib_WritePixelContinueExt
#define implib_ReadImg                 impplib_ReadImg          // add by fuku -F
#define implib_WriteImg                impplib_WriteImg         // add by fuku -F

// 20
#define implib_SetTrsPipelineFLTMode   impplib_SetTrsPipelineFLTMode
#define implib_IP_TrsPipelineFLT       impplib_IP_TrsPipelineFLT

// 21
#define implib_EnablePipeline          impplib_EnablePipeline
#define implib_DisablePipeline         impplib_DisablePipeline

// 22
#define implib_IP_Mask                 impplib_IP_Mask
#define implib_IP_ClearColor           impplib_IP_ClearColor
#define implib_IP_ExtractColor         impplib_IP_ExtractColor
#define implib_IP_ExtractColorRhoTheta impplib_IP_ExtractColorRhoTheta
#define implib_IP_ConvertRho           impplib_IP_ConvertRho
#define implib_IP_ConvertTheta         impplib_IP_ConvertTheta
#define implib_IP_ConvertRhoTheta      impplib_IP_ConvertRhoTheta

// 23
#define implib_SetBinMatchTemplate     impplib_SetBinMatchTemplate
#define implib_IP_BinMatchFLT          impplib_IP_BinMatchFLT

// 24
#define implib_SetCorrMode             impplib_SetCorrMode
#define implib_DisableCorrMask         impplib_DisableCorrMask
#define implib_EnableCorrMask          impplib_EnableCorrMask
#define implib_SetCorrBreakThr         impplib_SetCorrBreakThr
#define implib_DisableCorrBreak        impplib_DisableCorrBreak
#define implib_EnableCorrBreak         impplib_EnableCorrBreak
#define implib_SetCorrControl          impplib_SetCorrControl
#define implib_SetCorrTemplate         impplib_SetCorrTemplate
#define implib_SetCorrTemplateExt      impplib_SetCorrTemplateExt
#define implib_IP_Corr                 impplib_IP_Corr
#define implib_IP_CorrPrecise          impplib_IP_CorrPrecise
#define implib_SetOptFlowMode          impplib_SetOptFlowMode
#define implib_IP_OptFlow              impplib_IP_OptFlow
#define implib_GetCorrMapSize          impplib_GetCorrMapSize
#define implib_IP_CorrMap              impplib_IP_CorrMap
#define implib_CreateSparseOptFlowModel     impplib_CreateSparseOptFlowModel            // enabel by fuku
#define implib_IP_ExecuteSparseOptFlowModel impplib_IP_ExecuteSparseOptFlowModel        // enabel by fuku
#define implib_DeleteSparseOptFlowModel     impplib_DeleteSparseOptFlowModel            // enabel by fuku


// 25
#define implib_SetDrawMode             impplib_SetDrawMode
#define implib_SetStringAttributes     impplib_SetStringAttributes
#define implib_RefreshGraphics         impplib_RefreshGraphics
#define implib_DrawString              impplib_DrawString
#define implib_DrawLine                impplib_DrawLine
#define implib_DrawSegments            impplib_DrawSegments
#define implib_DrawLines               impplib_DrawLines
#define implib_DrawRectangle           impplib_DrawRectangle
#define implib_DrawPolygon             impplib_DrawPolygon
#define implib_DrawArc                 impplib_DrawArc

// 26
#define implib_HistAnalyze             impplib_HistAnalyze
#define implib_HistAnalyze16           impplib_HistAnalyze16

// 27
#define implib_ExtractPolyline         impplib_ExtractPolyline

// 28
#define implib_IP_FillHole             impplib_IP_FillHole

// 29
#define implib_SetEdgeCodeTbl          impplib_SetEdgeCodeTbl
#define implib_SetEdgeCodeConfig       impplib_SetEdgeCodeConfig
#define implib_IP_EdgeCode             impplib_IP_EdgeCode
#define implib_IP_EdgeCodeExt          impplib_IP_EdgeCodeExt

// 30
#define implib_IMR_Exec                impplib_IMR_Exec

// 31
#define implib_IP_HarrisOperatorPrecise impplib_IP_HarrisOperatorPrecise
#define implib_IP_HarrisOperatorFast impplib_HarrisOperatorFast

// 32
#define implib_IP_HoughLineVotingSpace          impplib_IP_HoughLineVotingSpace         // enabel by fuku -F
#define implib_IP_HoughLineRhoMap               impplib_IP_HoughLineRhoMap              // enabel by fuku -F
#define implib_IP_HistogramByLine               impplib_IP_HistogramByLine              // enabel by fuku -F

// 33
#define implib_IP_FFT1DX                        impplib_IP_FFT1DX                       // add by fuku
#define implib_IP_InverseFFT1DX                 impplib_IP_InverseFFT1DX                // add by fuku -F

// 34
#define implib_IP_IntegralImage                 impplib_IP_IntegralImage
#define implib_IP_IntegralImageSquare           impplib_IP_IntegralImageSquare
#define implib_IP_IntegralImage45               impplib_IP_IntegralImage45              // add by fuku -F
#define implib_IP_IntegralImageSquare45         impplib_IP_IntegralImageSquare45        // add by fuku -F
#define implib_IP_IntegralImageUpTrpz           impplib_IP_IntegralImageUpTrpz          // add by fuku -F
#define implib_IP_IntegralImageLowTrpz          impplib_IP_IntegralImageLowTrpz         // add by fuku -F
#define implib_IP_IntegralImageSquareUpTrpz     impplib_IP_IntegralImageSquareUpTrpz    // add by fuku -F
#define implib_IP_IntegralImageSquareLowTrpz    impplib_IP_IntegralImageSquareLowTrpz   // add by fuku -F

// 35
#define implib_IP_ProductMatrix                 impplib_IP_ProductMatrix                // add by fuku -F
#define implib_IP_InnerProduct                  impplib_IP_InnerProduct                 // add by fuku -F
#define implib_IP_TransposeMatrix               impplib_IP_TransposeMatrix              // add by fuku -F
#define implib_IP_MeanVector                    impplib_IP_MeanVector                   // add by fuku -F
#define implib_IP_CovarianceMatrix              impplib_IP_CovarianceMatrix             // add by fuku -F

// 36
#define implib_IP_EuclideanDistance             impplib_IP_EuclideanDistance            // add by fuku -F

// 37
#define implib_SetStereoVisionMode              impplib_SetStereoVisionMode             // add by fuku
#define implib_DeleteStereoVisionModel          impplib_DeleteStereoVisionModel         // add by fuku
#define implib_IP_StereoVision                  impplib_IP_StereoVision                 // add by fuku -F
#define implib_IP_StereoVisionPrecise           impplib_IP_StereoVisionPrecise          // add by fuku -F
#define implib_CreateStereoVisionModel          impplib_CreateStereoVisionModel         // add by fuku -F
#define implib_IP_ExecuteStereoVisionModel      impplib_IP_ExecuteStereoVisionModel     // add by fuku -F

// 38
#define implib_IP_LocalMax                      impplib_IP_LocalMax                     // add by fuku -F
#define implib_IP_LocalMin                      impplib_IP_LocalMin                     // add by fuku -F

// 39
#define implib_IP_PIS3x3                        impplib_IP_PIS3x3                       // add by fuku -F
#define implib_IP_PIS5x5                        impplib_IP_PIS5x5                       // add by fuku -F
#define implib_IP_PIS3x3withThreshold           impplib_IP_PIS3x3withThreshold          // add by fuku -F
#define implib_IP_PIS5x5withThreshold           impplib_IP_PIS5x5withThreshold          // add by fuku -F

// 40
#define implib_IP_NMS_EC                        impplib_IP_NMS_EC                       // add by fuku -F
#define implib_IP_NMS_RT                        impplib_IP_NMS_RT                       // add by fuku -F

#include <ipxdef.h>
#include <ipxsys.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef int32_t IMPLIB_MODELID;

#if 0 // H.Shiota    
enum IMPLIB_OPTFLOW_METHOD {
    IMPLIB_OPTFLOW_METHOD_SAD,
    IMPLIB_OPTFLOW_METHOD_ZNCC
};

typedef struct _IMPLIB_Point2D {
    int32_t  X; /* X-coordinate */
    int32_t  Y; /* Y-coordinate */
} IMPLIB_Point2D;
    
typedef struct _IMPLIB_IPMatching {
    IMPLIB_Point2D  point;      /* the matching point */
    float32_t       value;      /* the matching value */
} IMPLIB_IPMatching;

typedef struct _IMPLIB_SparseOptFlowParam {
    int32_t   max_templates;    /* the max number of templates while using the model */
    int32_t   max_searchpoints; /* the max number of search points among templates which appear while using the model */
    float32_t thr_variance;     /* threshold parameter for variance of a template's gray values, */
                                /* it becomes invalid, if config.flgTmplEvl = 0                  */
    int32_t   stepX;            /* step = 0, 1 or 2  */
    int32_t   stepY;            /* step = 0, 1 or 2  */
} IMPLIB_SparseOptFlowParam;
    
typedef struct _IMPLIB_SparseOptFlowConfig {
    int32_t  flg_tempevl;         /* flag : API does template evaluation or not,    {1,0}         */
    int32_t  vflg_searchpoints;   /* flag : the number of search points is variable or not, {1,0} */
} IMPLIB_SparseOptFlowConfig;

typedef struct _IMPLIB_SparseOptFlowPoint {
    IMPLIB_Point2D    temppoint;   /* the point for template                                            */
    IMPLIB_IPFlowSize tempsize;    /* template size : it becomes invalid, if config.vflg_tempsize = 0   */
    int32_t           numsearchs;  /* the number of search points                                       */
    IMPLIB_IPMatching *searchinfo; /* address for the search points and mathing value information   */
    int32_t           eva;         /* the variance information of the template                          */
    int32_t           sumT;        /* using only in system */
} IMPLIB_SparseOptFlowPoint;

enum IMPLIB_RhoTransMode {
    IMPLIB_RHOTRANSMODE_NORMAL,     /* rho conversion system  */
    IMPLIB_RHOTRANSMODE_TAN,        /* rho conversion system which uses tangent  */
    IMPLIB_RHOTRANSMODE_INVTAN,     /* rho conversion system which uses invert-tangent */
    IMPLIB_RHOTRANSMODE_MAX
};

typedef struct {
    IMPLIB_Point2D center;
    int32_t    startTheta;          /* Vote start angle (degree measure:0-360) */
    int32_t    endTheta;            /* Vote end angle (degree measure:0-360) */
    float32_t  rslTheta;            /* Resolution of theta */
    float32_t  maxRho;              /* Max-value of rho */
    float32_t  rslRho;              /* Resolution of rho */
    enum IMPLIB_RhoTransMode mode;  /* rho conversion mode */
} IMPLIB_HoughLineConfig;

typedef struct {
    int16_t  MIN_LEVEL_X; /* HPX0  */
    int16_t  MIN_LEVEL_Y; /* HPY0  */
    int16_t  MAX_LEVEL_X; /* HPX1  */
    int16_t  MAX_LEVEL_Y; /* HPY1  */
    int32_t  ACC_LEVEL;   /* HPACC */
    int16_t  MIN_LEVEL;   /* HPMIN */
    int16_t  MAX_LEVEL;   /* HPMAX */
} IMPLIB_HoughFeatureTbl;
#endif // H.Shiota

// H.Shiota, declaration moved to ipxprot.h
// int32_t  implib_Open(void);
int32_t  implib_Close(void);
int32_t  implib_SetTimeOut(int32_t semtime);

// H.Shiota, API spec was changed.
IMPLIB_IMGID  implib_AllocImgExt(int32_t mbmp_id);

// H.Shiota, API spec was changed.
IMPLIB_IMGID  implib_AllocYUVImgExt(int32_t mbmp_id);

// H.Shiota, API spec was changed.
IMPLIB_IMGID  implib_AllocCYUVImgExt(int32_t mbmp_id);

// H.Shiota, API spec was changed.
IMPLIB_IMGID  implib_AllocImg16Ext(int32_t mbmp_id);

// H.Shiota, API spec was changed.
IMPLIB_IMGID  implib_AllocImg32Ext(int32_t mbmp_id);

int32_t  implib_WriteConvertLUT2Fr16(IMPLIB_CNVLUT luta[],
                                           IMPLIB_CNVLUT lutb[],
                                           int32_t starta,
                                           int32_t sizea,
                                           int32_t startb,
                                           int32_t sizeb);

int32_t  implib_IP_Div(IMPLIB_IMGID ImgSrc0,
                             IMPLIB_IMGID ImgSrc1,
                             IMPLIB_IMGID ImgDst);

int32_t  implib_IP_Mod(IMPLIB_IMGID ImgSrc0,
                             IMPLIB_IMGID ImgSrc1,
                             IMPLIB_IMGID ImgDst);

int32_t  implib_IP_SubSquare(IMPLIB_IMGID ImgSrc0,
                                   IMPLIB_IMGID ImgSrc1,
                                   IMPLIB_IMGID ImgDst);

IMPLIB_MODELID  implib_CreateSparseOptFlowModel(IMPLIB_SparseOptFlowConfig *config,
                                                      IMPLIB_SparseOptFlowParam *param,
                                                      enum IMPLIB_OPTFLOW_METHOD method);


int32_t  implib_IP_ExecuteSparseOptFlowModel(IMPLIB_MODELID MOdelID,
                                                   IMPLIB_IMGID ImgOld,
                                                   IMPLIB_IMGID ImgCurrent,
                                                   int32_t num,
                                                   IMPLIB_SparseOptFlowPoint tbl[]);

int32_t  implib_DeleteSparseOptFlowModel(IMPLIB_MODELID ModelID);

#if defined(CPU_RCARV2H)
int32_t  implib_IMR_Exec(IMPLIB_IMGID ImgSrc,
                         IMPLIB_IMGID ImgDst,
                         IMPLIB_IMGID DLID );
#else
int32_t  implib_IMR_Exec(IMPLIB_IMGID ImgSrc,
                         IMPLIB_IMGID ImgDst,
                         uint32_t *DLID,
                         int32_t DLSize);
#endif

/* H.Shiota
int32_t  implib_IP_HarrisOperatorPrecise(IMPLIB_IMGID ImgSrc,
                                               IMPLIB_IMGID ImgDst,
                                               enum IMPLIB_Harris_DiffFlg fltSize,
                                               float32_t k);
    
int32_t  implib_IP_HarrisOperatorFast(IMPLIB_IMGID ImgSrc,
                                            IMPLIB_IMGID ImgDst,
                                            enum IMPLIB_Harris_DiffFlg fltSize,
                                            float32_t k);
*/

int32_t  implib_IP_HoughLineVotingSpace(IMPLIB_IMGID CrdX,
                                              IMPLIB_IMGID CrdY,
                                              IMPLIB_IMGID HoughSpace,
                                              IMPLIB_HoughLineConfig *config);

int32_t  implib_IP_HoughLineRhoMap(IMPLIB_IMGID CrdX,
                                         IMPLIB_IMGID CrdY,
                                         IMPLIB_IMGID RhoMap,
                                         IMPLIB_HoughLineConfig *config,
                                         int32_t scale);

int32_t  implib_IP_HistogramByLine(IMPLIB_IMGID ImgSrc,
                                         IMPLIB_IMGID ImgHist,
                                         IMPLIB_HoughFeatureTbl FtrTbl[],
                                         int32_t startBin,
                                         int32_t endBin,
                                         int32_t scale);

int32_t  implib_IP_FFT1DX(IMPLIB_IMGID ImgSrc,
                          IMPLIB_IMGID ImgRDst,
                          IMPLIB_IMGID ImgIDst);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __IMPP_H__ */
