/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_kick.c                                      */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/

#include <stdio.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif

#include "legacy_sim.h"

#define HAVE_STDINT_H_ // To avoid typedef conflict.
#include "impsim_int.h"
#include "legacy_sim_prot.h"


/******************************************************************************/
/* kick_software_reset                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void kick_software_reset(void) {  
	int i, j;

	SIMLOG(SL_LS_ADPT, SL_L3, "kick_software_reset(): Reset IMP.\n");
	
	/* Software reset is done synchronously. */
	//	 sync_thread_start();
	SIMLOG(SL_LS_ADPT, SL_L5, "kick_software_reset(): Reset is ongoing..\n");

	for(i = 0; i < REGSETS_MAX; i++) {
		for(j = 0; j < REGMAX; j++) {
			// 0:no reset 1:Software reset, 2:Hardware reset
			if ((regtable[j].reset & IMP_SW_RESET) == IMP_SW_RESET) {
				IMPREG[IMP_WORK_CH][i][regtable[j].No] = regtable[j].initnum;
			}
		}
	}
	
	//sync_thread_end();
	return;
}

/******************************************************************************/
/* kick_ap                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void kick_ap(void) {
	int ret;
	
	SIMLOG(SL_LS_ADPT, SL_L3, "kick_ap(): Activate AP.\n");
	sync_thread_start();
	SIMLOG(SL_LS_ADPT, SL_L5, "kick_ap(): IMP is working..\n");

	if (IMPREG_MCINIT_READ() & _MCINIT_MC_EN) {
		ret = PIPEExec();
	} else {
		ret = APExec();
	}
	if (ret) {
		SIMLOG(SL_LS_ADPT, SL_ERR, "kick_ap(): ERROR, but nothing has been implemented here: %d\n", ret);
	}

	sync_thread_end();
	return;    
}

/******************************************************************************/
/* kick_ifid_with_dl                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void kick_ifid_with_dl(void) {
	uint32_t *dl_adr = 0;

	uint16_t reg_num;
	uint16_t reg_adr;

	int sleep, ret;
	int i;
	bool ap_must_be_started; // Set to TRUE, if EX bit of APCMD is asserted. HP is automatically activated.
	bool hp_must_be_started; // Set to TRUE, if write access to HMDATA occurs, which causes zero-clear of HM.
	bool pipe_must_be_started; // Set to TRUE, if EX bit of APCMD is asserted. PIPE is automatically activated.
		
	// uint32_t *work1;
	
	SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): Activate IF/ID interface with display list.\n");
	
	sync_thread_start();
	SIMLOG(SL_LS_ADPT, SL_L5, "kick_ifid_with_dl(): IMP is working.\n");

	read_reg(IMP_WORK_CH, (uint32_t)regtable[_PSA].adr, (uint32_t *)&dl_adr);
	SIMLOG(SL_LS_ADPT, SL_L5, "kick_ifid_with_dl(): PSA: %08lx.\n", (unsigned long)dl_adr);
	
	/* Following code is copied & pasted from Exec.c, and bit-midified. */
	sleep = 0;
	ret = 0;
	ap_must_be_started = FALSE;
	hp_must_be_started = FALSE;
	pipe_must_be_started = FALSE;
	
	while(sleep == 0){
		switch(((unsigned int)*dl_adr>>24) & 0xff){
		case 0x41: /* MOV */
			reg_num = ((unsigned int)*dl_adr>>16) & 0xff;
			reg_adr = (unsigned int)*dl_adr & 0xffff;
			// #59683, modified by hubin 20140829 -S
			//if(!reg_num) reg_num = (((IMPREG_IFCFG_READ() )>>16) & 0xffff); // In case of no specification of reg num in DL. See SYSP spec for more detail.
			if(!reg_num) reg_num = (((IMPREG_IFCFG_READ() )>>16) & 0x1fff); // In case of no specification of reg num in DL. See SYSP spec for more detail.
			// #59683, modified by hubin 20140829 -E
			SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): MOV %04x, %04x\n", reg_num, reg_adr);

			#if 0
			// HM
			if ( adr*4 >= DL_IPREG_HM_S && adr*4 <= DL_IPREG_HM_E ) {
				for(i=0;i<num;i++){
					cnt++;
					if(adr*4+4*i <= DL_IPREG_HM_E){
						WriteHM( (adr*4 - DL_IPREG_HM_S)/4+i, (unsigned long)mem[cnt]);
						SIMLOG(TBD, "kick_ifid_with_dl(): HM adr=%x data=%x\n", ((adr*4)+4*i), mem[cnt]);
					}else{
						ret = -1;
						sleep = 1;
						SIMLOG(TBD, "kick_ifid_with_dl(): HM adr Error\n");
					}
				}
			// CM0 & CM1  // H.Shiota Not debugged yet.
			}else if (( adr*4 >= DL_IPREG_CMA_S && adr*4 <= DL_IPREG_CMA_E )||( adr*4 >= DL_IPREG_CMB_S && adr*4 <= DL_IPREG_CMB_E )){
				for(i=0;i<num;i++){
					cnt++;
					if(adr*4+4*i >= DL_IPREG_CMA_S && adr*4+4*i <= DL_IPREG_CMA_E){
						*(pCM0[IMP_WORK_CH] + ( (adr*4 - DL_IPREG_CMA_S)/4 + i )) = (unsigned char)((mem[IMP_WORK_CH][cnt])&0xff);
						SIMLOG(SL_LS, SL_L4, "kick_ifid_with_dl(): CM0 adr=%x data=%x\n", ((adr*4)+4*i), (mem[IMP_WORK_CH][cnt])&0xff);
					}else if(adr*4+4*i >= DL_IPREG_CMB_S && adr*4+4*i <= DL_IPREG_CMB_E){
						*(pCM1[IMP_WORK_CH] + ( (adr*4 - DL_IPREG_CMB_S)/4 + i )) = (unsigned char)((mem[IMP_WORK_CH][cnt])&0xff);
						SIMLOG(TBD, "kick_ifid_with_dl(): CM1 adr=%x data=%x\n", ((adr*4)+4*i), (mem[IMP_WORK_CH][cnt])&0xff);
					}else{
						ret = -1;
						sleep = 1;
						SIMLOG(TBD, "kick_ifid_with_dl(): CM adr Error\n");
					}
				}
				// Img Register 
			} else {
			#endif

			if (ap_must_be_started || hp_must_be_started) {
				SIMLOG(SL_LS_ADPT, SL_L1,
					   "kick_ifid_with_dl(): WARNING. Register write just after activating AP or HP is not expected.\n");
				SIMLOG(SL_LS_ADPT, SL_L1, "kick_ifid_with_dl(): WARNING. AP:%d, HP:%d\n",
					   ap_must_be_started, hp_must_be_started);
				SIMLOG(SL_LS_ADPT, SL_L1, "kick_ifid_with_dl(): WARNING. Register write is ignored.\n");
			}

			for(i=0; i<reg_num; i++) {
				uint32_t reg_adr_shifted;
				dl_adr++;
				// ret = McomGetRegAdr((((reg_adr*4)+4*i) | 0x00001000), &work1);
				// if(ret==1){
				//	  SIMLOG(SL_LS, SL_L4, "kick_ifid_with_dl(): adr=%x data=%08lx\n", ((reg_adr*4)+4*i), (unsigned long)*dl_adr);
				//	  *work1 = *dl_adr;
				//} else {
				//	  ret = -1;
				//	 sleep = 1;
				//	  SIMLOG(SL_LS, SL_L4, "kick_ifid_with_dl(): Register adr Error\n");
				reg_adr_shifted = (reg_adr<<2) + 4*i;

#define DL_IPREG_THTDATA0_S 0x00010000
#define DL_IPREG_THTDATA0_E 0x00013FFF
#define DL_IPREG_THTDATA1_S 0x00014000
#define DL_IPREG_THTDATA1_E 0x000147FF
				/* Check if PIPE code */
				if (reg_adr_shifted >= DL_IPREG_PIPEM_S && reg_adr_shifted <= DL_IPREG_PIPEM_E) {
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): PIPE memory write: adr=%08lx data=%08lx\n",
						   (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					mem[IMP_WORK_CH][(reg_adr_shifted - DL_IPREG_PIPEM_S)/2	  ] = (*dl_adr & 0xffff0000) >> 16; // Copy upper 16 bits as 1 PIPE code to PIPE memory.
					mem[IMP_WORK_CH][(reg_adr_shifted - DL_IPREG_PIPEM_S)/2 + 1] = (*dl_adr & 0x0000ffff);		// Copy lower 16 bits as 1 PIPE code to PIPE memory. 				   
					
				/* Check if immediate action is required or just write the value to the register. */
				} else if ((regtable[_IFCTL].adr == reg_adr_shifted) && (*dl_adr & _IFCTL_IF_EXEC)) {
					SIMLOG(SL_LS_ADPT, SL_L1, "kick_ifid_with_dl(): WARNING. IF/DL is kicked in DL. Write is ignored.\n");
				//#59683, modified by hubin 20140829 -S
				} else if (reg_adr_shifted >= DL_IPREG_CMA_S && reg_adr_shifted <= DL_IPREG_CMA_E) {
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): CMA memory write: adr=%08lx data=%08lx\n",
											   (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					WriteCM0(IMP_WORK_CH, (int)((reg_adr_shifted - DL_IPREG_CMA_S)/4), (unsigned long)*dl_adr);
				} else if (reg_adr_shifted >= DL_IPREG_CMB_S && reg_adr_shifted <= DL_IPREG_CMB_E) {
									SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): CMB memory write: adr=%08lx data=%08lx\n",
															   (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					WriteCM1(IMP_WORK_CH, (int)((reg_adr_shifted - DL_IPREG_CMB_S)/4), (unsigned long)*dl_adr);
				//#59683, modified by hubin 20140829 -E
				} else if (reg_adr_shifted >= DL_IPREG_THTDATA0_S && reg_adr_shifted <= DL_IPREG_THTDATA0_E) {
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): TH0 memory write: adr=%08lx data=%08lx\n",
											   (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					WriteTHTDATA0(IMP_WORK_CH, (int)((reg_adr_shifted - DL_IPREG_THTDATA0_S)/4), (unsigned long)*dl_adr);
				} else if (reg_adr_shifted >= DL_IPREG_THTDATA1_S && reg_adr_shifted <= DL_IPREG_THTDATA1_E) {
									SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): TH1 memory write: adr=%08lx data=%08lx\n",
															   (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					WriteTHTDATA1(IMP_WORK_CH, (int)((reg_adr_shifted - DL_IPREG_THTDATA1_S)/4), (unsigned long)*dl_adr);
				} else if ((regtable[_APCMD].adr == reg_adr_shifted) && (*dl_adr & _APCMD_EX)) {
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): register write: [%s] adr=%08lx data=%08lx\n",
						   reg_offset_to_name(reg_adr_shifted), (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					
					if (IMPREG_MCINIT_READ() & _MCINIT_MC_EN) {
						SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): PIPE will be started by activating exec bit. MCINIT:%08lx\n",
							   (unsigned long)IMPREG_MCINIT_READ());
						write_reg(IMP_WORK_CH, reg_adr_shifted, *dl_adr);
						pipe_must_be_started = TRUE;
					} else {
						SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): AP will be started by activating exec bit.\n");
						write_reg(IMP_WORK_CH, reg_adr_shifted, *dl_adr);
						ap_must_be_started = TRUE;
					}

				} else if (regtable[_HMDATA].adr == reg_adr_shifted) {
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): register write: [%s] adr=%08lx data=%08lx\n",
						   reg_offset_to_name(reg_adr_shifted), (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): Histogram memory will be cleared.\n");
					write_reg(IMP_WORK_CH, reg_adr_shifted, *dl_adr);
					hp_must_be_started = TRUE;

				} else if (regtable[_HPCTL].adr == reg_adr_shifted) {
					/* H.Shiota, need to implement hpen operation. */
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): register write: [%s] adr=%08lx data=%08lx\n",
						   reg_offset_to_name(reg_adr_shifted), (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					write_reg(IMP_WORK_CH, reg_adr_shifted, *dl_adr);
					if (*dl_adr & _HPCTL_HPEN) {
						SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): hpen of HPCTL is asserted.\n");
						HPExec(HPEXEC_HPEN);
					}
				} else if (regtable[_APSIZE_SA].adr == reg_adr_shifted) {
					SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): register write: [%s] adr=%08lx data=%08lx\n",
						   reg_offset_to_name(reg_adr_shifted), (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					SIMLOG(SL_LS_ADPT, SL_L3,
						   "kick_ifid_with_dl(): APSIZE_SA is written. The same value is written to APSIZE_SB and APSIZE_DST because of HW spec.\n");
					write_reg(IMP_WORK_CH, reg_adr_shifted, *dl_adr); // Should be APSIZE_SA
					write_reg(IMP_WORK_CH, regtable[_APSIZE_SB].adr, *dl_adr);
					write_reg(IMP_WORK_CH, regtable[_APSIZE_DST].adr, *dl_adr);

				} else { // Just write the value to the register.
					if (write_reg(IMP_WORK_CH, reg_adr_shifted, *dl_adr) == E_OK) {
						SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): register write: [%s] adr=%08lx data=%08lx\n",
							   reg_offset_to_name(reg_adr_shifted), (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);
					} else {
						SIMLOG(SL_LS_ADPT, SL_L1,
							   "kick_ifid_with_dl(): register write: [WARNING:unknown] adr=%08lx data=%08lx\n",
							   (unsigned long)reg_adr_shifted, (unsigned long)*dl_adr);  
					}
				}
			}
			break;
		case 0x42: /* INT */
			SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): INT\n");
			break;
		case 0x43: /* SYNCM */
			SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): SYNCM\n");
			if (ap_must_be_started) {
				ret = APExec();
				ap_must_be_started = FALSE;
			} else if (hp_must_be_started) {
				ret = HPExec(HPEXEC_HM_RESET);
				hp_must_be_started = FALSE;
			} else if (pipe_must_be_started) {
				ret = PIPEExec();
				pipe_must_be_started = FALSE;
			} else {
				/* If no IMP HW runing. Just return. */
			}

			if(ret) {
				SIMLOG(SL_LS_ADPT, SL_L1, "Error is detected by xxExec(), %d\n", ret);
				sleep = 1; // IMP does not stop unless error is detected. Next instruction will be fetched.
			}
			break;
		case 0x40: /* NOP */
			SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): NOP\n");
			break;
		case 0x4f: /* TRAP */
			SIMLOG(SL_LS_ADPT, SL_L3, "kick_ifid_with_dl(): TRAP\n");
			if (ap_must_be_started) {
				ret = APExec();
				ap_must_be_started = FALSE;
			} else if (hp_must_be_started) {
				ret = HPExec(HPEXEC_HM_RESET);
				hp_must_be_started = FALSE;
			} else if (pipe_must_be_started) {
				ret = PIPEExec();
				pipe_must_be_started = FALSE;
			} else {
				/* If no IMP HW runing. Just return. */
			}

			sleep = 1; // IMP stops.
			break;
		case 0x00:
			SIMLOG(SL_LS_ADPT, SL_ERR, "ERROR, 0x00 is detected in display list.\n");
			assert_error();
			break;
		default:
			SIMLOG(SL_LS_ADPT, SL_ERR, "ERROR, unknown code=%x\n",
				   (uint8_t)((unsigned long)*dl_adr>>24) & 0xff);
			ret = -1;
			sleep = 1;
			break;
		}
		dl_adr++;
	}
		
	SIMLOG(SL_LS_ADPT, SL_L3, "End of processing DL.\n");
	sync_thread_end();
	return;
}


