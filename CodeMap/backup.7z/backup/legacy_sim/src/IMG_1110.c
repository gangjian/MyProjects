/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_1110.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/30                                                      */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"

static int64 IMG_1110_Rank(long m[]);

/******************************************************************************/
/* IMG_1110                                                                   */
/*       Kyokusyo Sabun                                                       */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/30                                                      */
/* 01-01-00 : 2007/04/18 S.Ishikawa                                           */
/*                       Src1 data kernel e -> a                              */
/* 01-01-01 : 2007/05/15   S.Ishikawa                                         */
/*                         Add MCom                                           */
/* 01-02-00 : 2007/06/22   S.Ishikawa                                         */
/*                         Add 'Widthcnt initialize' (MCom)                   */
/* 01-02-01 : 2007/07/20   S.Ishikawa                                         */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
int IMG_1110(){
    long xlng, ylng, Widthcnt, Heightcnt;
    int i, edge, rank;
    long m[9];
    short sour_id[LINE_SIZE];
    int64 result[LINE_SIZE];

	SIMLOG(SL_LS, SL_ERR, "ERROR, IMG_1110 is not supported.\n");
		Legacy_assert_error();
	
#if SKIP_FOR_COVERAGE
		/* skip */
#else

	rank = (((IMPREG_KNLMSK_READ())>>12) & 0x000f); /* rank 0:max�`8:min */
    if(rank>8){
        SIMLOG(SL_LS, SL_L4, "Error rank=%d\n",rank);
        return(-1);
    }

    edge   = (((IMPREG_IPFUN_READ())>>24) & 0x0003); /* 3:"0" */
    if(edge!=3){
        SIMLOG(SL_LS, SL_L4, "Error edgecnt=%d\n",edge);
        return(-1);
    }

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

/********** 3x3 **********/
        Heightcnt = 0;

        if(McomFlg){
            Widthcnt = 0;

            for(i=0;i<xlng;i++){
                if((Widthcnt==0)||(Widthcnt==xlng-1)){
                    result[i] = 0;
                }else{
                    m[0] = (long)(abs(ReadLM256A(2, Widthcnt-1)-ReadLM256B(Widthcnt+1))); m[1] = (long)(abs(ReadLM256A(2, Widthcnt)-ReadLM256B(Widthcnt+1))); m[2] = (long)(abs(ReadLM256A(2, Widthcnt+1)-ReadLM256B(Widthcnt+1)));
                    m[3] = (long)(abs(ReadLM256A(1, Widthcnt-1)-ReadLM256B(Widthcnt+1))); m[4] = (long)(abs(ReadLM256A(1, Widthcnt)-ReadLM256B(Widthcnt+1))); m[5] = (long)(abs(ReadLM256A(1, Widthcnt+1)-ReadLM256B(Widthcnt+1)));
                    m[6] = (long)(abs(ReadLM256A(0, Widthcnt-1)-ReadLM256B(Widthcnt+1))); m[7] = (long)(abs(ReadLM256A(0, Widthcnt)-ReadLM256B(Widthcnt+1))); m[8] = (long)(abs(ReadLM256A(0, Widthcnt+1)-ReadLM256B(Widthcnt+1)));

                    result[i] = IMG_1110_Rank(m);
                }
                Widthcnt++;

            }

            Write1LineDst(Heightcnt, result);
        }else{
        /* First Line */
            for(i=0;i<xlng;i++){
                result[i] = 0;
            }
            Write1LineDst(Heightcnt, result);

        /* Middle Line */
            Heightcnt++;

        /* All Line loop */
            while(Heightcnt < ylng - 1){
        /* 1Line */
                Read1LineSrc0(Heightcnt - 1, sour_id);
                WriteLM0(0, sour_id, xlng);

                Read1LineSrc0(Heightcnt    , sour_id);
                WriteLM1(0, sour_id, xlng);

                Read1LineSrc0(Heightcnt + 1, sour_id);
                WriteLM2(0, sour_id, xlng);

                Read1LineSrc1(Heightcnt+1 , sour_id);

                Widthcnt = 0;

                for(i=0;i<xlng;i++){
                    if((Widthcnt==0)||(Widthcnt==xlng-1)){
                        result[i] = 0;
                    }else{
                        m[0] = (long)(abs(ReadLM0(Widthcnt-1)-sour_id[Widthcnt+1])); m[1] = (long)(abs(ReadLM0(Widthcnt)-sour_id[Widthcnt+1])); m[2] = (long)(abs(ReadLM0(Widthcnt+1)-sour_id[Widthcnt+1]));
                        m[3] = (long)(abs(ReadLM1(Widthcnt-1)-sour_id[Widthcnt+1])); m[4] = (long)(abs(ReadLM1(Widthcnt)-sour_id[Widthcnt+1])); m[5] = (long)(abs(ReadLM1(Widthcnt+1)-sour_id[Widthcnt+1]));
                        m[6] = (long)(abs(ReadLM2(Widthcnt-1)-sour_id[Widthcnt+1])); m[7] = (long)(abs(ReadLM2(Widthcnt)-sour_id[Widthcnt+1])); m[8] = (long)(abs(ReadLM2(Widthcnt+1)-sour_id[Widthcnt+1]));
    /*
                        m[0] = abs(ReadLM0(Widthcnt-1)-sour_id[Widthcnt]); m[1] = abs(ReadLM0(Widthcnt)-sour_id[Widthcnt]); m[2] = abs(ReadLM0(Widthcnt+1)-sour_id[Widthcnt]);
                        m[3] = abs(ReadLM1(Widthcnt-1)-sour_id[Widthcnt]); m[4] = abs(ReadLM1(Widthcnt)-sour_id[Widthcnt]); m[5] = abs(ReadLM1(Widthcnt+1)-sour_id[Widthcnt]);
                        m[6] = abs(ReadLM2(Widthcnt-1)-sour_id[Widthcnt]); m[7] = abs(ReadLM2(Widthcnt)-sour_id[Widthcnt]); m[8] = abs(ReadLM2(Widthcnt+1)-sour_id[Widthcnt]);
    */
                        result[i] = IMG_1110_Rank(m);
                    }
                    Widthcnt++;

                }

                Write1LineDst(Heightcnt, result);
        /* Next Line */
                Heightcnt++;

            }

        /* Last Line */
            if(Heightcnt < ylng){
                for(i=0;i<xlng;i++){
                    result[i] = 0;
                }

                Write1LineDst(Heightcnt, result);
            }
        }
#endif 

    return(0);
}
/******************************************************************************/
/* IMG_RankFLT                                                                */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/12/26                                                      */
/* 01-00-01 : 2007/01/17                                                      */
/* 01-02-00 : 2007/07/20                                                      */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
#if SKIP_FOR_COVERAGE
		/* skip */
#else

static int64 IMG_1110_Rank(long m[])
{
    int i, j, rank, k[9], msk ; 
    int64 work[9], temp;

    rank = (((IMPREG_KNLMSK_READ())>>12) & 0x000f); /* rank 0:max�`8:min */

    for(i=0;i<9;i++)
        k[i] = (((IMPREG_KNLMSK_READ())>>i) & 0x0001); /* kernelmask 0:use 1:unuse */

    msk = (((IMPREG_IPFUN_READ())>>26) & 0x0001); /* 0:mask disable 1:mask enable */


    for(i=0;i<9;i++){
//        if(msk & k[i]) work[i] = -256;
        if(msk & k[i]) work[i] = -65536;
        else work[i] = (int64)m[i];
    }

/* Sort */
    for(i=0;i<9;i++){
        for(j=i+1;j<9;j++){
            if(work[i] < work[j]){
                temp = work[i];
                work[i] = work[j];
                work[j] = temp;
            }
        }
    }

    return(work[rank]);
}

#endif

