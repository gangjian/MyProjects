/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0010.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New                                                */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "impsim_int.h"
#include "legacy_sim.h"

static int64 IMG_AND(short f, short g);	//AND
static int64 IMG_OR(short f, short g);	//OR
static int64 IMG_XOR(short f, short g);	//Exclusive OR
static int64 IMG_XNOR(short f, short g); //Exclusive NOR
static int64 IMG_CANDOR(short f, short g, short consta, short constb);//constant AND OR

static int64 IMG_ANDC(short f, short g); //AND count
static int64 IMG_ORC(short f, short g);	//OR count
static int64 IMG_XORC(short f, short g); //Exclusive OR count
static int64 IMG_XNORC(short f, short g);//Exclusive NOR count
static int64 IMG_CANDORC(short f, short g, short consta, short constb);//constant AND OR count


#define check_srca_ind_om ( (((IMPREG_IPFORM_READ()>>16) & 0x0000007)==2) ? 1 : 0)

/******************************************************************************/
/* IMG_0010  (two images logical operation)                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                       New                                                  */
/******************************************************************************/
int IMG_0010()
{
    unsigned long xlng, ylng;
    unsigned int Widthcnt, Heightcnt, subfun;
	short *soura_id = psLM0;
	short *sourb_id = psLM1;
	int64 result[LINE_SIZE];
	short consta, constb;//constant a,b
	unsigned int srca_ind_om, srcb_ind_om;
	unsigned int dest_dt, ex_dest_dt;

	
	if ( !USE_PIPE_FUNC && McomFlg ) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (PIPE). turn on USE_PIPE_FUNC when use PIPE for IMG_0010.\n");
		Legacy_assert_error();
	}

    dest_dt = ((IMPREG_IPFUN_READ() >> 16) & 0x0003);

	srca_ind_om = ((IMPREG_IPFORM_READ() >> 16) & 0x0007);
	srcb_ind_om = ((IMPREG_IPFORM_READ() >> 20) & 0x0007);
	ex_dest_dt = ((IMPREG_IPFUN2_READ() >> 4) & 0x000C) | dest_dt;

    if (srca_ind_om == 2) { // PXL16BPP
    	GET_CNSTA16(consta) //get constant a bit
    } else{
    	GET_CNSTA(consta)//get constant a bit
    }
    if (srcb_ind_om == 2) { // PXL16BPP
    	GET_CNSTB16(constb) //get constant b bit
    } else {
    	GET_CNSTB(constb)//get constant b bit
    }

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
#if USE_PIPE_FUNC
	ylng = (McomFlg) ? 1 : (((IMPREG_APLNG_READ())>>16) & 0x3fff);
#else
	ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
#endif 

	subfun = (((IMPREG_IPFUN_READ())>>24) & 0x0000000f);//get subfun bit 

#ifdef DEBUG_OUTPUT
	ResetDebugGamen();
#endif

    Heightcnt = 0;
// All Line loop
    while(Heightcnt < ylng)
	{
// 1Line
// Read Img Data 1Line
#if USE_PIPE_FUNC
        if(McomFlg){
            Read1LineLM256A(Heightcnt, soura_id);
            Read1LineLM256B(sourb_id);
        }else{
#endif 
        	Read1LineSrc0(Heightcnt, soura_id);
            Read1LineSrc1(Heightcnt, sourb_id);
#if USE_PIPE_FUNC
        }
#endif 

        Widthcnt = 0;

        while(Widthcnt < xlng)
		{
            switch(subfun)//branch subfun bit
			{
				case 0:	//AND
					result[Widthcnt] = IMG_AND(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 1:	//OR
					result[Widthcnt] = IMG_OR(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 2:	//Exclusive OR
					result[Widthcnt] = IMG_XOR(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 3:	//Exclusive NOR
					result[Widthcnt] = IMG_XNOR(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 4:	//constant AND OR
					result[Widthcnt] = IMG_CANDOR(soura_id[Widthcnt], sourb_id[Widthcnt], consta, constb);
					break;
				case 8:	//AND count
					result[Widthcnt] = IMG_ANDC(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 9:	//OR count
					result[Widthcnt] = IMG_ORC(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 10://Exclusive OR count
					result[Widthcnt] = IMG_XORC(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 11://Exclusive NOR
					result[Widthcnt] = IMG_XNORC(soura_id[Widthcnt], sourb_id[Widthcnt]);
					break;
				case 12://constant AND OR count
					result[Widthcnt] = IMG_CANDORC(soura_id[Widthcnt], sourb_id[Widthcnt], consta, constb);
					break;

				case 5:	//reserved bit 0101
					return (-1);
					break;
				case 6:	//reserved bit 0110
					return (-1);
					break;
				case 7:	//reserved bit 0111
					return (-1);
					break;
				default:
					SIMLOG(SL_LS, SL_ERR, "subfun=%x, besides reserved bit!\n", subfun);
					Legacy_assert_error();
					break;
			}
			if (ex_dest_dt == 1) {  /* U8bpp */
    	        result[Widthcnt] = (result[Widthcnt] & 0x00000000000000ffLL);
            }
            Widthcnt++;
        }
/* Next Line */
#ifdef DEBUG_OUTPUT
		DebugOutputGamen(result,3,xlng);
#endif
        Write1LineDst(Heightcnt, result);
        Heightcnt++;
    }

    return(0);
}
/******************************************************************************/
/* IMG_AND  (AND / subfun:0000)                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/12/26                                                      */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_AND(short f, short g)
{
//    return(unsigned char)((f & g) & 0xff);
    return(f & g);
}

/******************************************************************************/
/* IMG_OR (OR / subfun:0001)                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22  T.Kumabe                                            */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_OR(short f, short g)
{
//    return((unsigned char)((f | g) & 0xff));
    return(f | g);
}


/******************************************************************************/
/* IMG_XOR (Exclusive OR / subfun:0010)                                       */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22  T.Kumabe                                            */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_XOR(short f, short g)
{
//    return((unsigned char)((f ^ g) & 0xff));
    return(f ^ g);
}


/******************************************************************************/
/* IMG_XNOR (Exclusive NOR / subfun:0011)                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22   T.Kumabe                                           */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_XNOR(short f, short g)
{
//    return((unsigned char)((~(f ^ g)) & 0xff));
    return(~(f ^ g));
}


/******************************************************************************/
/* IMG_CANDOR (constant AND OR / subfun:0100)                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22   T.Kumabe                                           */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_CANDOR(short f, short g, short consta, short constb)
{
//    return((unsigned char)(((consta & f)|(constb & g)) & 0xff));
    return((consta & f)|(constb & g));
}


/******************************************************************************/
/* IMG_ANDC (AND count / subfun:1000)	                                      */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22   T.Kumabe                                           */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-02-01 : 2007/06/22   S.Ishikawa                                         */
/*                         Add check_srca_ind_om,temp char -> short           */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_ANDC(short f, short g)
{
	int64 temp;
	int64 result;

//    temp = (unsigned char)((f & g) & 0xff);
    temp = ((int64)f & (int64)g);

	//count of bit"1"
	result = (temp & 0x01) + ((temp & 0x02)>>1) + ((temp & 0x04)>>2) + ((temp & 0x08)>>3)+
		((temp & 0x10)>>4) + ((temp & 0x20)>>5) + ((temp & 0x40)>>6) + ((temp & 0x80)>>7);

	if(check_srca_ind_om){
        result += ((temp & 0x0100)>>8) + ((temp & 0x0200)>>9) + ((temp & 0x0400)>>10) + ((temp & 0x0800)>>11)+
		((temp & 0x1000)>>12) + ((temp & 0x2000)>>13) + ((temp & 0x4000)>>14) + ((temp & 0x8000)>>15);
    }
	return result;
}

/******************************************************************************/
/* IMG_ORC (OR count / subfun:1001)	                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22  T.Kumabe                                            */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-02-01 : 2007/06/22   S.Ishikawa                                         */
/*                         Add check_srca_ind_om,temp char -> short           */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_ORC(short f, short g)
{
	int64 temp;
	int64 result;

//    temp = (unsigned char)((f | g) & 0xff);
    temp = ((int64)f | (int64)g);

	//count of bit"1"
	result = (temp & 0x01) + ((temp & 0x02)>>1) + ((temp & 0x04)>>2) + ((temp & 0x08)>>3)+
		((temp & 0x10)>>4) + ((temp & 0x20)>>5) + ((temp & 0x40)>>6) + ((temp & 0x80)>>7);

	if(check_srca_ind_om){
        result += ((temp & 0x0100)>>8) + ((temp & 0x0200)>>9) + ((temp & 0x0400)>>10) + ((temp & 0x0800)>>11)+
		((temp & 0x1000)>>12) + ((temp & 0x2000)>>13) + ((temp & 0x4000)>>14) + ((temp & 0x8000)>>15);
    }
	return result;
}

/******************************************************************************/
/* IMG_XORC (Exclusive OR count / subfun:1010)	                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22   T.Kumabe                                           */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-02-01 : 2007/06/22   S.Ishikawa                                         */
/*                         Add check_srca_ind_om,temp char -> short           */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_XORC(short f, short g)
{
	int64 temp;
	int64 result;

//    temp = (unsigned char)((f ^ g) & 0xff);
    temp = ((int64)f ^ (int64)g);

	//count of bit"1"
	result = (temp & 0x01) + ((temp & 0x02)>>1) + ((temp & 0x04)>>2) + ((temp & 0x08)>>3)+
		((temp & 0x10)>>4) + ((temp & 0x20)>>5) + ((temp & 0x40)>>6) + ((temp & 0x80)>>7);

	if(check_srca_ind_om){
        result += ((temp & 0x0100)>>8) + ((temp & 0x0200)>>9) + ((temp & 0x0400)>>10) + ((temp & 0x0800)>>11)+
		((temp & 0x1000)>>12) + ((temp & 0x2000)>>13) + ((temp & 0x4000)>>14) + ((temp & 0x8000)>>15);
    }
	return result;
}


/******************************************************************************/
/* IMG_XNORC (Exclusive NOR count / subfun:1011)	                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22    T.Kumabe                                          */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-02-01 : 2007/06/22   S.Ishikawa                                         */
/*                         Add check_srca_ind_om,temp char -> short           */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_XNORC(short f, short g)
{
	int64 temp;
	int64 result;

//    temp = (unsigned char)((~(f ^ g)) & 0xff);
    temp = (~((int64)f ^ (int64)g));

	//count of bit"1"
	result = (temp & 0x01) + ((temp & 0x02)>>1) + ((temp & 0x04)>>2) + ((temp & 0x08)>>3)+
		((temp & 0x10)>>4) + ((temp & 0x20)>>5) + ((temp & 0x40)>>6) + ((temp & 0x80)>>7);

	if(check_srca_ind_om){
        result += ((temp & 0x0100)>>8) + ((temp & 0x0200)>>9) + ((temp & 0x0400)>>10) + ((temp & 0x0800)>>11)+
		((temp & 0x1000)>>12) + ((temp & 0x2000)>>13) + ((temp & 0x4000)>>14) + ((temp & 0x8000)>>15);
    }
	return result;
}

/******************************************************************************/
/* IMG_CANDORC (constant AND OR count / subfun:1100)	                      */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/22   T.Kumabe                                           */
/* 01-02-00 : 2007/06/18   S.Ishikawa                                         */
/*                         Add 16bpp                                          */
/* 01-02-01 : 2007/06/22   S.Ishikawa                                         */
/*                         Add check_srca_ind_om,temp char -> short           */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
int64 IMG_CANDORC(short f, short g, short consta, short constb)
{
	int64 temp;
	int64 result;

//    temp = (unsigned char)(((consta & f)|(constb & g)) & 0xff);
    temp = (((int64)consta & (int64)f)|((int64)constb & (int64)g));

	//count of bit"1"
	result = (temp & 0x01) + ((temp & 0x02)>>1) + ((temp & 0x04)>>2) + ((temp & 0x08)>>3)+
		((temp & 0x10)>>4) + ((temp & 0x20)>>5) + ((temp & 0x40)>>6) + ((temp & 0x80)>>7);

	if(check_srca_ind_om){
        result += ((temp & 0x0100)>>8) + ((temp & 0x0200)>>9) + ((temp & 0x0400)>>10) + ((temp & 0x0800)>>11)+
		((temp & 0x1000)>>12) + ((temp & 0x2000)>>13) + ((temp & 0x4000)>>14) + ((temp & 0x8000)>>15);
    }
	return result;
}
