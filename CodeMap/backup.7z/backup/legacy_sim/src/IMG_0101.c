/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0101.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "legacy_sim.h"
#include "impsim_int.h"


#define GET_CNSTA(consta) {\
	consta = (short)((IMPREG_CNST_READ()>>16)&0xff);\
	if(IMPREG_CNST_READ()&0x01000000)	consta |= 0xff00;\
	}
#define GET_CNSTB(constb) {\
	constb = (short)(IMPREG_CNST_READ()&0xff);\
	if(IMPREG_CNST_READ()&0x100)	constb |= 0xff00;\
	}
#define GET_CNSTA16(consta) {\
	consta = (short)((IMPREG_CNST_READ()>>16)&0xffff);\
	}
#define GET_CNSTB16(constb) {\
	constb = (short)(IMPREG_CNST_READ()&0xffff);\
	}

#if 0 // not support subfun
static int64 IMG_ADD(short f, short g);
#endif
static int64 IMG_SUB(short f, short g);
#if 0 // not support subfun
static int64 IMG_COMB(short f, short g, short consta, short constb);
static int64 IMG_MULT(short f, short g);
static int64 IMG_MIN(short f,short g);
static int64 IMG_MAX(short f, short g);
static int64 IMG_SUADD(short f, short g, short consta, short constb);
#endif
static int64 IMG_SQUADD(short f, short g, short consta, short constb);
#if 0 // not support subfun
static int64 IMG_SMULT(short f, short g, short consta, short constb);
static int64 IMG_SUBSQ(short f, short g);
static int64 IMG_ADDSQ(short f, short g);
#endif

/******************************************************************************/
/* IMG_0101                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
int IMG_0101(){
	unsigned long xlng, ylng;
	unsigned int widthcnt, heightcnt;
	short *soura_id = psLM0;
	short *sourb_id = psLM1;
	int64 result[LINE_SIZE];
	short consta, constb;
	unsigned char subfun;
	int datatype, datatypesb;
	short data0 = 0, data1  = 0;
    datatype = ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
    datatypesb = ((IMPREG_IPFUN_READ() >> 20) & 0x0003);
	
	if ( !USE_PIPE_FUNC && McomFlg ) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (PIPE). turn on USE_PIPE_FUNC when use PIPE for IMG_0101.\n");
		Legacy_assert_error();
	}
	
    if((IMPREG_IPFORM_READ() >> 16) & 0x0007){
        datatype = ((IMPREG_IPFORM_READ() >> 16) & 0x0007) + 4;
    }
    if((IMPREG_IPFORM_READ() >> 20) & 0x0007){
        datatypesb = ((IMPREG_IPFORM_READ() >> 20) & 0x0007) + 4;
    }

	xlng = IMPREG_APLNG_READ() & 0x3fff;
//	ylng = (IMPREG_APLNG_READ() >>16) & 0x3fff;
#if USE_PIPE_FUNC
    ylng = (McomFlg) ? 1 : (((IMPREG_APLNG_READ())>>16) & 0x3fff);
#else
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
#endif	
	heightcnt = 0;
	subfun = (char)((IMPREG_IPFUN_READ()>>24)&0x000f);
    if(datatype!=6){
	    GET_CNSTA(consta);
    }else{
	    GET_CNSTA16(consta);
    }
    if(datatypesb!=6){
	    GET_CNSTB(constb);
    }else{
	    GET_CNSTB16(constb);
    }
	
#ifdef DEBUG_OUTPUT
	ResetDebugGamen();
#endif
        	
	while(heightcnt<ylng)
	{
		widthcnt = 0;
#if USE_PIPE_FUNC
        if(McomFlg){
            Read1LineLM256A(heightcnt, soura_id);
        }else{
#endif	
		    Read1LineSrc0(heightcnt, soura_id);
            if (subfun == 15) {
                Read1LineSrc1(heightcnt, sourb_id);
            }
#if USE_PIPE_FUNC
        }
#endif	
		while(widthcnt<xlng)
		{
			if(widthcnt % 2 == 0) {
				switch(subfun) {
#if 0 // not support subfun
				case 0:	/* srcA + srcB */
					result[widthcnt] = IMG_ADD(soura_id[widthcnt], soura_id[widthcnt+1]);
					break;
#endif
				case 1:	/* srcA - srcB */
					data0 = *(pCM0[IMP_WORK_CH] + (4 * soura_id[widthcnt]));
					data1 = *(pCM0[IMP_WORK_CH] + (4 * soura_id[widthcnt+1]));
					result[widthcnt] = IMG_SUB(data0, data1);
					break;
#if 0 // not support subfun
				case 2:	/* a*srcA + b*srcB */
					result[widthcnt] = IMG_COMB(soura_id[widthcnt], soura_id[widthcnt+1], consta, constb);
					break;
				case 3:	/* srcA * srcB */
					result[widthcnt] = IMG_MULT(soura_id[widthcnt], soura_id[widthcnt+1]);
					break;
				case 4:	/* min(srcA,srcB) */
					result[widthcnt] = IMG_MIN(soura_id[widthcnt], soura_id[widthcnt+1]);
					break;
				case 5:	/* max(srcA,srcB) */
					result[widthcnt] = IMG_MAX(soura_id[widthcnt], soura_id[widthcnt+1]);
					break;
				case 6:	/* |srcA-a| + |srcB-b| */
					result[widthcnt] = IMG_SUADD(soura_id[widthcnt], soura_id[widthcnt+1], consta, constb);
					break;
#endif
				case 7:	/* (srcA-a)^2 + (srcB-b)^2 */
					result[widthcnt] = IMG_SQUADD(soura_id[widthcnt], soura_id[widthcnt+1], consta, constb);
					break;
#if 0 // not support subfun
				case 8:	/* (srcA-a) * (srcB-b) */
					result[widthcnt] = IMG_SMULT(soura_id[widthcnt], soura_id[widthcnt+1], consta, constb);
					break;
				case 9:	/* (srcA-srcB) * (srcA-srcB) */
					result[widthcnt] = IMG_SUBSQ(soura_id[widthcnt], soura_id[widthcnt+1]);
					break;
				case 10:	/* (srcA+srcB) * (srcA+srcB) */
					result[widthcnt] = IMG_ADDSQ(soura_id[widthcnt], soura_id[widthcnt+1]);
					break;
#endif
				case 15:	/*  */
					data0 = ((soura_id[widthcnt] & 0x80) << 1) | (soura_id[widthcnt+1] & 0x80) | (sourb_id[widthcnt] & 0x7f);
					data0 = *(pCM0[IMP_WORK_CH] + (4 * data0)); /* CM memory is accessed by 4 bytes */
					result[widthcnt] = data0;
					break;
				default:	/*error*/
					SIMLOG(SL_LS, SL_ERR, "ERROR, Not support subfun[%d]\n", subfun);
					Legacy_assert_error();
				}
			}
			widthcnt++;

			/* Write Dst data*/
		}
#ifdef DEBUG_OUTPUT
		DebugOutputGamen(result,3,xlng);
#endif
        Write1LineDst(heightcnt, result);
		heightcnt++;
	}
	return 0;
}

#if 0 // not support subfun
/******************************************************************************/
/* IMG_ADD                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_ADD(short f, short g)
{
	return (int64)f+(int64)g;
}
#endif 

/******************************************************************************/
/* IMG_SUB                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_SUB(short f, short g)
{
	return (int64)f-(int64)g;
}

#if 0 // not support subfun
/******************************************************************************/
/* IMG_COMB                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_COMB(short f, short g, short consta, short constb)
{
	return (int64)f * (int64)consta + (int64)g * (int64)constb;
}

/******************************************************************************/
/* IMG_MULT                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_MULT(short f, short g)
{
	return (int64)f * (int64)g;
}

/******************************************************************************/
/* IMG_MIN                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_MIN(short f,short g)
{
	return (int64)MIN(f,g);
}

/******************************************************************************/
/* IMG_MAX                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_MAX(short f, short g)
{
	return (int64)MAX(f,g);
}

/******************************************************************************/
/* IMG_SUADD                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_SUADD(short f, short g, short consta, short constb)
{
	return (int64)(abs((int)f-(int)consta) + abs((int)g-(int)constb));
}
#endif

/******************************************************************************/
/* IMG_SQUADD                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_SQUADD(short f, short g, short consta, short constb)
{
	return ((int64)f-(int64)consta) * ((int64)f-(int64)consta) + ((int64)g-(int64)constb) * ((int64)g-(int64)constb);
}

#if 0 // not support subfun
/******************************************************************************/
/* IMG_SMULT                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  j.ishii                                             */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_SMULT(short f, short g, short consta, short constb)
{
	return ((int64)f-(int64)consta) * ((int64)g-(int64)constb);
}

static int64 IMG_SUBSQ(short f, short g)
{
	return ((int64)f - (int64)g) * ((int64)f - (int64)g);
}

static int64 IMG_ADDSQ(short f, short g)
{
	return ((int64)f + (int64)g) * ((int64)f + (int64)g);
}
#endif
