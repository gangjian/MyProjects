/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_1000.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "legacy_sim.h"

/******************************************************************************/
/* IMG_1000                                                                   */
/*       Corr                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
int IMG_1000(){
    long xlng, ylng, Widthcnt, Heightcnt;
    int msk, thrsubt, mismten;
	short *soura_id = psLM0;
	short *sourb_id = psLM1;
    unsigned long Count_SUM, Count_SQSUM, Count_MSKCNT, Count_CRSUM, Count_TMSUM;
    unsigned long work;

    msk     = (((IMPREG_IPFUN_READ())>>26) & 0x0001);
    thrsubt = (((IMPREG_IPFUN_READ())>>25) & 0x0001);
    mismten = (((IMPREG_IPFUN_READ())>>24) & 0x0001);

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

	IMPREG_SUM0_WRITE( 0); IMPREG_SQSUM0_WRITE( 0); IMPREG_CRSUM0_WRITE( 0);
    IMPREG_SUM1_WRITE( 0); IMPREG_SQSUM1_WRITE( 0); IMPREG_CRSUM1_WRITE( 0);
    IMPREG_SUM2_WRITE( 0); IMPREG_SQSUM2_WRITE( 0); IMPREG_CRSUM2_WRITE( 0);
    IMPREG_SUM3_WRITE( 0); IMPREG_SQSUM3_WRITE( 0); IMPREG_CRSUM3_WRITE( 0);
    IMPREG_SUM4_WRITE( 0); IMPREG_SQSUM4_WRITE( 0); IMPREG_CRSUM4_WRITE( 0);
    IMPREG_SUM5_WRITE( 0); IMPREG_SQSUM5_WRITE( 0); IMPREG_CRSUM5_WRITE( 0);
    IMPREG_SUM6_WRITE( 0); IMPREG_SQSUM6_WRITE( 0); IMPREG_CRSUM6_WRITE( 0);
    IMPREG_SUM7_WRITE( 0); IMPREG_SQSUM7_WRITE( 0); IMPREG_CRSUM7_WRITE( 0);
    IMPREG_SUM8_WRITE( 0); IMPREG_SQSUM8_WRITE( 0); IMPREG_CRSUM8_WRITE( 0);
    IMPREG_SUM9_WRITE( 0); IMPREG_SQSUM0_WRITE( 0); IMPREG_CRSUM9_WRITE( 0);
    IMPREG_SUM10_WRITE( 0); IMPREG_SQSUM10_WRITE( 0); IMPREG_CRSUM10_WRITE( 0);
    IMPREG_SUM11_WRITE( 0); IMPREG_SQSUM11_WRITE( 0); IMPREG_CRSUM11_WRITE( 0);
    IMPREG_SUM12_WRITE( 0); IMPREG_SQSUM12_WRITE( 0); IMPREG_CRSUM12_WRITE( 0);
    IMPREG_SUM13_WRITE( 0); IMPREG_SQSUM13_WRITE( 0); IMPREG_CRSUM13_WRITE( 0);
    IMPREG_SUM14_WRITE( 0); IMPREG_SQSUM14_WRITE( 0); IMPREG_CRSUM14_WRITE( 0);
    IMPREG_SUM15_WRITE( 0); IMPREG_SQSUM15_WRITE( 0); IMPREG_CRSUM15_WRITE( 0);

    work = (IMPREG_TMSUMT_READ()&0x7fff) | ((IMPREG_TMSUMT_READ()&0x00800000)>>8);
    work = (work<<16) | work;

	IMPREG_TMSUM01_WRITE( work);
    IMPREG_TMSUM23_WRITE( work);
    IMPREG_TMSUM45_WRITE( work);
    IMPREG_TMSUM67_WRITE( work);
    IMPREG_TMSUM1011_WRITE( work);
    IMPREG_TMSUM1213_WRITE( work);
    IMPREG_TMSUM1415_WRITE( work);
    IMPREG_TMSUM8_WRITE( IMPREG_TMSUMT_READ());
    IMPREG_TMSUM9_WRITE( work&0xffff);

    Heightcnt = 0;
    Count_SUM = Count_SQSUM = Count_MSKCNT = Count_CRSUM = Count_TMSUM = 0;

	while(Heightcnt<ylng){
		Widthcnt = 0;
		/* read by 1 line data */
		Read1LineSrc0(Heightcnt, soura_id);
		Read1LineSrc1(Heightcnt, sourb_id);

        while(Widthcnt < xlng)
		{
            if(soura_id[Widthcnt]==0) Count_MSKCNT++;
            if(!( (msk)&&(sourb_id[Widthcnt] == 0) )){
                Count_SUM += (unsigned long)soura_id[Widthcnt];
                Count_SQSUM += (unsigned long)soura_id[Widthcnt] * (unsigned long)soura_id[Widthcnt];
                Count_CRSUM += (unsigned long)soura_id[Widthcnt] * (unsigned long)sourb_id[Widthcnt];
                Count_TMSUM += abs((unsigned long)soura_id[Widthcnt] - (unsigned long)sourb_id[Widthcnt]);
            }
            if((mismten)&&(IMPREG_TMSUMT_READ()<Count_TMSUM )) goto EXIT01;

            Widthcnt++;
        }
        Heightcnt++;
    }


EXIT01:
	IMPREG_SUM8_WRITE( Count_SUM & 0x00ffffff);
    IMPREG_SQSUM8_WRITE( Count_SQSUM);
    IMPREG_MSKCNT_WRITE( Count_MSKCNT);
    IMPREG_CRSUM8_WRITE( Count_CRSUM);
    IMPREG_TMSUM8_WRITE( (IMPREG_TMSUM8_READ() - Count_TMSUM));

    if(thrsubt==1){
        if(IMPREG_TMSUMT_READ() > Count_TMSUM ){
        	IMPREG_TMSUMT_WRITE( Count_TMSUM);
        }
    }

    return(0);
}
