/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_1001.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif
#include "impsim_int.h"
#include "legacy_sim.h"

short g_sad_updata[25] = {0};
short g_sad_lowdata[25] = {0};



/******************************************************************************/
/* IMG_1001                                                                   */
/*       Corr (Pala)                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New                                                */
/******************************************************************************/
int IMG_1001(){
	unsigned long pre_TMSUM8;
    long xlng, ylng, Widthcnt, Heightcnt;
    int i, kernel, msk, thrsubt, mismten, scale0, scale1, scale2, scale3, xstep, ystep, mismatch, lm_mode, lmw, xsize, ysize;
	short *soura_id0 = psLM0;
	short *soura_id1 = psLM1;
	short *soura_id2 = psLM2;
	short *soura_id3 = psLM3;
	short *soura_id4 = psLM4;
	short *sourb_id = psLM5;
    unsigned long Count_SUM[25], Count_SQSUM[25], Count_CRSUM[25], Count_TMSUM[25], Count_MSKCNT;
    unsigned long Temp_SUM[25], Temp_SQSUM[25], Temp_CRSUM[25], Temp_TMSUM[25];
	unsigned long work;
	int64 result[LINE_SIZE];
	int64 result2[LINE_SIZE];
	int k3x3[9] = { 0,1,2,3,4,5,6,7,8};
	int k4x4[16] = {5,6,7,9,10,11,13,14,15,0,1,2,3,4,8,12};
	int k5x5[25] = {12,13,14,17,18,19,22,23,24,6,7,8,9,11,16,21,0,1,2,3,4,5,10,15,20};
	int loop;
    int mode = 0;/*  3:3x3 or 1x9
	                 4:4x4 or 1x16
	                 5:5x5 or 1x25
	              */
    int exsubfun;
    unsigned long Aplng_BK;

    mismatch = 1;/* IP stopped during process: 1. IP finished normally: 0 */
	kernel  = (((IMPREG_IPFUN_READ())>>27) & 0x0001);
    msk     = (((IMPREG_IPFUN_READ())>>26) & 0x0001);
    thrsubt = (((IMPREG_IPFUN_READ())>>25) & 0x0001);
    mismten = (((IMPREG_IPFUN_READ())>>24) & 0x0001);
    scale3 = (((IMPREG_IPFUN_READ())>>3) & 0x0001);
    scale2 = (((IMPREG_IPFUN_READ())>>2) & 0x0001);
    scale1 = (((IMPREG_IPFUN_READ())>>1) & 0x0001);
    scale0 = (IMPREG_IPFUN_READ() & 0x0001);
    exsubfun = (((IMPREG_IPFUN2_READ())>>24) & 0x000f);
	lm_mode = (IMPREG_KNLMSK_READ()>>29) & 0x0001;
	lmw = IMPREG_LMCTL_READ() & 0x0007;
	
	if((lm_mode == 0) && (lmw == 1)
	 ||(lm_mode == 0) && (lmw == 2)
	 ||(lm_mode == 0) && (lmw == 4))
	{ /* 5x5 or 1x25 */
        mode = 5;
    }
	else if((lm_mode == 1) && (lmw == 0))
	{ /* 4x4 or 1x16 */
        mode = 4;
    }
	else if((lm_mode == 0) && (lmw == 0))
	{ /* 3x3 or 1x9 */
        mode = 3;
    }
	else
	{
        SIMLOG(SL_LS, SL_L4, "Register set error LMCTL lmw= %x KNLMSK lm_mode=%x\n", (IMPREG_LMCTL_READ() & 0x0007), ((IMPREG_KNLMSK_READ()>>29) & 0x0001));
        return(-1);
    }

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

    pre_TMSUM8 = IMPREG_TMSUM8_READ();/* used to update TMSUMT */
	/* update TMSUMT before updating other TMSUM register */
	if(1 == mismten)
	{
		if(1 == thrsubt)
		{
	        if(pre_TMSUM8 > 0 )
			{
	            IMPREG_TMSUMT_WRITE( (IMPREG_TMSUMT_READ() - pre_TMSUM8));
	        }
		}
	}
	
	
    IMPREG_SUM0_WRITE( 0); IMPREG_SQSUM0_WRITE( 0); IMPREG_CRSUM0_WRITE( 0);
    IMPREG_SUM1_WRITE( 0); IMPREG_SQSUM1_WRITE( 0); IMPREG_CRSUM1_WRITE( 0);
    IMPREG_SUM2_WRITE( 0); IMPREG_SQSUM2_WRITE( 0); IMPREG_CRSUM2_WRITE( 0);
    IMPREG_SUM3_WRITE( 0); IMPREG_SQSUM3_WRITE( 0); IMPREG_CRSUM3_WRITE( 0);
    IMPREG_SUM4_WRITE( 0); IMPREG_SQSUM4_WRITE( 0); IMPREG_CRSUM4_WRITE( 0);
    IMPREG_SUM5_WRITE( 0); IMPREG_SQSUM5_WRITE( 0); IMPREG_CRSUM5_WRITE( 0);
    IMPREG_SUM6_WRITE( 0); IMPREG_SQSUM6_WRITE( 0); IMPREG_CRSUM6_WRITE( 0);
    IMPREG_SUM7_WRITE( 0); IMPREG_SQSUM7_WRITE( 0); IMPREG_CRSUM7_WRITE( 0);
    IMPREG_SUM8_WRITE( 0); IMPREG_SQSUM8_WRITE( 0); IMPREG_CRSUM8_WRITE( 0);
    IMPREG_SUM9_WRITE( 0); IMPREG_SQSUM9_WRITE( 0); IMPREG_CRSUM9_WRITE( 0);
    IMPREG_SUM10_WRITE( 0); IMPREG_SQSUM10_WRITE( 0); IMPREG_CRSUM10_WRITE( 0);
    IMPREG_SUM11_WRITE( 0); IMPREG_SQSUM11_WRITE( 0); IMPREG_CRSUM11_WRITE( 0);
    IMPREG_SUM12_WRITE( 0); IMPREG_SQSUM12_WRITE( 0); IMPREG_CRSUM12_WRITE( 0);
    IMPREG_SUM13_WRITE( 0); IMPREG_SQSUM13_WRITE( 0); IMPREG_CRSUM13_WRITE( 0);
    IMPREG_SUM14_WRITE( 0); IMPREG_SQSUM14_WRITE( 0); IMPREG_CRSUM14_WRITE( 0);
    IMPREG_SUM15_WRITE( 0); IMPREG_SQSUM15_WRITE( 0); IMPREG_CRSUM15_WRITE( 0);
    IMPREG_SUM16_WRITE( 0); IMPREG_SQSUM16_WRITE( 0); IMPREG_CRSUM16_WRITE( 0);
    IMPREG_SUM17_WRITE( 0); IMPREG_SQSUM17_WRITE( 0); IMPREG_CRSUM17_WRITE( 0);
    IMPREG_SUM18_WRITE( 0); IMPREG_SQSUM18_WRITE( 0); IMPREG_CRSUM18_WRITE( 0);
    IMPREG_SUM19_WRITE( 0); IMPREG_SQSUM19_WRITE( 0); IMPREG_CRSUM19_WRITE( 0);
    IMPREG_SUM20_WRITE( 0); IMPREG_SQSUM20_WRITE( 0); IMPREG_CRSUM20_WRITE( 0);
    IMPREG_SUM21_WRITE( 0); IMPREG_SQSUM21_WRITE( 0); IMPREG_CRSUM21_WRITE( 0);
    IMPREG_SUM22_WRITE( 0); IMPREG_SQSUM22_WRITE( 0); IMPREG_CRSUM22_WRITE( 0);
    IMPREG_SUM23_WRITE( 0); IMPREG_SQSUM23_WRITE( 0); IMPREG_CRSUM23_WRITE( 0);
    IMPREG_SUM24_WRITE( 0); IMPREG_SQSUM24_WRITE( 0); IMPREG_CRSUM24_WRITE( 0);

    work = (IMPREG_TMSUMT_READ()&0x7fff) | ((IMPREG_TMSUMT_READ()&0x00800000)>>8);
    work = (work<<16) | work;

    IMPREG_TMSUM01_WRITE( work);
    IMPREG_TMSUM23_WRITE( work);
    IMPREG_TMSUM45_WRITE( work);
    IMPREG_TMSUM67_WRITE( work);
    IMPREG_TMSUM1011_WRITE( work);
    IMPREG_TMSUM1213_WRITE( work);
    IMPREG_TMSUM1415_WRITE( work);
    IMPREG_TMSUM8_WRITE( IMPREG_TMSUMT_READ());
    IMPREG_TMSUM9_WRITE( work&0xffff);
    IMPREG_TMSUM1617_WRITE( work);
    IMPREG_TMSUM1819_WRITE( work);
    IMPREG_TMSUM2021_WRITE( work);
    IMPREG_TMSUM2223_WRITE( work);
    IMPREG_TMSUM24_WRITE( work&0xffff);

    Heightcnt = 0;
    Count_MSKCNT = 0;
    for(i=0;i<25;i++){
        Count_SUM[i] = Count_SQSUM[i] = Count_CRSUM[i] = Count_TMSUM[i] = 0;
        Temp_SUM[i] = Temp_SQSUM[i] = Temp_CRSUM[i] = Temp_TMSUM[i] = 0;

    }
/* ystep */
    if(scale3){
        if(scale1) ystep = 3;
        else ystep = 2;
    }else{
        ystep = 1;
    }
/* xstep */
    if(scale2){
        if(scale1) xstep = 3;
        else xstep = 2;
    }else{
        xstep = 1;
    }
    
	if((mode == 3) && (kernel == 0))
	{/* 3x3 */
		xsize = xlng - (mode - 1) * xstep;
		ysize = ylng - (mode - 1) * ystep;
		for(Heightcnt = 0; Heightcnt < ysize; Heightcnt++)
		{
		    /* read by 1 line data */
		    Read1LineSrc0(Heightcnt,             soura_id0);
		    Read1LineSrc0(Heightcnt + ystep,     soura_id1);
		    Read1LineSrc0(Heightcnt + 2 * ystep, soura_id2);
		    Read1LineSrc1(Heightcnt + 2 * ystep, sourb_id);

            for(Widthcnt = 0; Widthcnt < xsize; Widthcnt++)
		    {
                if(soura_id0[Widthcnt * xstep] == 0)
		    	{
		    		Count_MSKCNT++;
		    	}
                if(!( (msk)&&(sourb_id[Widthcnt + 2 * xstep] == 0) ))
		    	{
                    for(i = 0;i < 3; i++)
                    {
                        Temp_SUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_SQSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_CRSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 2 * xstep];
                        Temp_TMSUM[i] += abs((unsigned long)soura_id0[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 2 * xstep]);

                        Temp_SUM[i + 3] += (unsigned long)soura_id1[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 3] += (unsigned long)soura_id1[Widthcnt + i * xstep] * (unsigned long)soura_id1[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 3] += (unsigned long)soura_id1[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 2 * xstep];
                        Temp_TMSUM[i + 3] += abs((unsigned long)soura_id1[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 2 * xstep]);
                        
                        Temp_SUM[i + 6] += (unsigned long)soura_id2[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 6] += (unsigned long)soura_id2[Widthcnt + i * xstep] * (unsigned long)soura_id2[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 6] += (unsigned long)soura_id2[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 2 * xstep];
                        Temp_TMSUM[i + 6] += abs((unsigned long)soura_id2[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 2 * xstep]);
                    }
                }
                if(1 == mismten)
		    	{
                    mismatch = 1;
                    for(i = 0; i < 9; i++)
		    		{
                        if( IMPREG_TMSUMT_READ() >= Temp_TMSUM[i] )
		    			{
		    				mismatch = 0;
		    			}
                    }
                    if(1 == mismatch)
		    		{
		    			SIMLOG(SL_LS, SL_L5, " -- IP Stop!! -- (x,y)=(%d, %d)\n", (int)Widthcnt, (int)Heightcnt);
                        goto EXIT01;
                    }
                }
            }
       }
    }
	else if((mode == 3) && (kernel == 1))
    { /* 1x9 */
		xsize = xlng - 8 * xstep;
		ysize = ylng;
		for(Heightcnt = 0; Heightcnt < ysize; Heightcnt++)
		{
		    /* read by 1 line data */
		    Read1LineSrc0(Heightcnt * ystep, soura_id0);
		    Read1LineSrc1(Heightcnt,         sourb_id);

            for(Widthcnt = 0; Widthcnt < xsize; Widthcnt++)
		    {
                if(soura_id0[Widthcnt * xstep] == 0)
		    	{
		    		Count_MSKCNT++;
		    	}
                if(!( (msk)&&(sourb_id[Widthcnt + 8 * xstep] == 0) ))
		    	{
                    for(i = 0;i < 9; i++)
                    {
                        Temp_SUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_SQSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_CRSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 8 * xstep];
                        Temp_TMSUM[i] += abs((unsigned long)soura_id0[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 8 * xstep]);
                    }
                }
                if(1 == mismten)
		    	{
                    mismatch = 1;
                    for(i = 0; i < 9; i++)
		    		{
                        if( IMPREG_TMSUMT_READ() >= Temp_TMSUM[i] )
		    			{
		    				mismatch = 0;
		    			}
                    }
                    if(1 == mismatch)
		    		{
		    			SIMLOG(SL_LS, SL_L5, " -- IP Stop!! -- (x,y)=(%d, %d)\n", (int)Widthcnt, (int)Heightcnt);
                        goto EXIT01;
                    }
                }
            }
       }
    }
	else if((mode == 4) && (kernel == 0))
	{/* 4x4 */
		xsize = xlng - (mode - 1) * xstep;
		ysize = ylng - (mode - 1) * ystep;
		for(Heightcnt = 0; Heightcnt < ysize; Heightcnt++)
		{
		    /* read by 1 line data */
		    Read1LineSrc0(Heightcnt,             soura_id0);
		    Read1LineSrc0(Heightcnt + ystep,     soura_id1);
		    Read1LineSrc0(Heightcnt + 2 * ystep, soura_id2);
		    Read1LineSrc0(Heightcnt + 3 * ystep, soura_id3);
			Read1LineSrc1(Heightcnt + 3 * ystep, sourb_id);

            for(Widthcnt = 0; Widthcnt < xsize; Widthcnt++)
		    {
                if(soura_id0[Widthcnt * xstep] == 0)
		    	{
		    		Count_MSKCNT++;
		    	}
                if(!( (msk)&&(sourb_id[Widthcnt + 3 * xstep] == 0) ))
		    	{
                    for(i = 0;i < 4; i++)
                    {
                        Temp_SUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_SQSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_CRSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 3 * xstep];
                        Temp_TMSUM[i] += abs((unsigned long)soura_id0[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 3 * xstep]);

                        Temp_SUM[i + 4] += (unsigned long)soura_id1[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 4] += (unsigned long)soura_id1[Widthcnt + i * xstep] * (unsigned long)soura_id1[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 4] += (unsigned long)soura_id1[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 3 * xstep];
                        Temp_TMSUM[i + 4] += abs((unsigned long)soura_id1[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 3 * xstep]);
                        
                        Temp_SUM[i + 8] += (unsigned long)soura_id2[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 8] += (unsigned long)soura_id2[Widthcnt + i * xstep] * (unsigned long)soura_id2[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 8] += (unsigned long)soura_id2[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 3 * xstep];
                        Temp_TMSUM[i + 8] += abs((unsigned long)soura_id2[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 3 * xstep]);

                    	Temp_SUM[i + 12] += (unsigned long)soura_id3[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 12] += (unsigned long)soura_id3[Widthcnt + i * xstep] * (unsigned long)soura_id3[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 12] += (unsigned long)soura_id3[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 3 * xstep];
                        Temp_TMSUM[i + 12] += abs((unsigned long)soura_id3[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 3 * xstep]);
                    }
                }
                if(1 == mismten)
		    	{
                    mismatch = 1;
                    for(i = 0; i < 16; i++)
		    		{
                        if( IMPREG_TMSUMT_READ() >= Temp_TMSUM[i] )
		    			{
		    				mismatch = 0;
		    			}
                    }
                    if(1 == mismatch)
		    		{
		    			SIMLOG(SL_LS, SL_L5, " -- IP Stop!! -- (x,y)=(%d, %d)\n", (int)Widthcnt, (int)Heightcnt);
                        goto EXIT01;
                    }
                }
            }
       }
    }
	else if((mode == 4) && (kernel == 1))
    { /* 1x16 */
		xsize = xlng - 15 * xstep;
		ysize = ylng;
		for(Heightcnt = 0; Heightcnt < ysize; Heightcnt++)
		{
		    /* read by 1 line data */
		    Read1LineSrc0(Heightcnt * ystep, soura_id0);
		    Read1LineSrc1(Heightcnt,         sourb_id);

            for(Widthcnt = 0; Widthcnt < xsize; Widthcnt++)
		    {
                if(soura_id0[Widthcnt * xstep] == 0)
		    	{
		    		Count_MSKCNT++;
		    	}
                if(!( (msk)&&(sourb_id[Widthcnt + 15 * xstep] == 0) ))
		    	{
                    for(i = 0;i < 16; i++)
                    {
                    	Temp_SUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_SQSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_CRSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 15 * xstep];
                        Temp_TMSUM[i] += abs((unsigned long)soura_id0[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 15 * xstep]);
                    }
                }
                if(1 == mismten)
		    	{
                    mismatch = 1;
                    for(i = 0; i < 16; i++)
		    		{
                        if( IMPREG_TMSUMT_READ() >= Temp_TMSUM[i] )
		    			{
		    				mismatch = 0;
		    			}
                    }
                    if(1 == mismatch)
		    		{
		    			SIMLOG(SL_LS, SL_L5, " -- IP Stop!! -- (x,y)=(%d, %d)\n", (int)Widthcnt, (int)Heightcnt);
                        goto EXIT01;
                    }
                }
		    }
       }
    }
	else if((mode == 5) && (kernel == 0))
	{/* 5x5 */
		xsize = xlng - (mode - 1) * xstep;
		ysize = ylng - (mode - 1) * ystep;
		for(Heightcnt = 0; Heightcnt < ysize; Heightcnt++)
		{
		    /* read by 1 line data */
		    Read1LineSrc0(Heightcnt,             soura_id0);
		    Read1LineSrc0(Heightcnt + ystep,     soura_id1);
		    Read1LineSrc0(Heightcnt + 2 * ystep, soura_id2);
		    Read1LineSrc0(Heightcnt + 3 * ystep, soura_id3);
		    Read1LineSrc0(Heightcnt + 4 * ystep, soura_id4);
			Read1LineSrc1(Heightcnt + 4 * ystep, sourb_id);

            for(Widthcnt = 0; Widthcnt < xsize; Widthcnt++)
		    {
                if(soura_id0[Widthcnt * xstep] == 0)
		    	{
		    		Count_MSKCNT++;
		    	}
                if(!( (msk)&&(sourb_id[Widthcnt + 4 * xstep] == 0) ))
		    	{
                    for(i = 0;i < 5; i++)
                    {
                        Temp_SUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_SQSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_CRSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 4 * xstep];
                        Temp_TMSUM[i] += abs((unsigned long)soura_id0[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 4 * xstep]);

                        Temp_SUM[i + 5] += (unsigned long)soura_id1[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 5] += (unsigned long)soura_id1[Widthcnt + i * xstep] * (unsigned long)soura_id1[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 5] += (unsigned long)soura_id1[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 4 * xstep];
                        Temp_TMSUM[i + 5] += abs((unsigned long)soura_id1[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 4 * xstep]);
                        
                        Temp_SUM[i + 10] += (unsigned long)soura_id2[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 10] += (unsigned long)soura_id2[Widthcnt + i * xstep] * (unsigned long)soura_id2[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 10] += (unsigned long)soura_id2[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 4 * xstep];
                        Temp_TMSUM[i + 10] += abs((unsigned long)soura_id2[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 4 * xstep]);

                    	Temp_SUM[i + 15] += (unsigned long)soura_id3[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 15] += (unsigned long)soura_id3[Widthcnt + i * xstep] * (unsigned long)soura_id3[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 15] += (unsigned long)soura_id3[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 4 * xstep];
                        Temp_TMSUM[i + 15] += abs((unsigned long)soura_id3[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 4 * xstep]);

                    	Temp_SUM[i + 20] += (unsigned long)soura_id4[Widthcnt + i * xstep];
                        Temp_SQSUM[i + 20] += (unsigned long)soura_id4[Widthcnt + i * xstep] * (unsigned long)soura_id4[Widthcnt + i * xstep];
                        Temp_CRSUM[i + 20] += (unsigned long)soura_id4[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 4 * xstep];
                        Temp_TMSUM[i + 20] += abs((unsigned long)soura_id4[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 4 * xstep]);
                    }
                }
                if(1 == mismten)
		    	{
                    mismatch = 1;
                    for(i = 0; i < 25; i++)
		    		{
                        if( IMPREG_TMSUMT_READ() >= Temp_TMSUM[i] )
		    			{
		    				mismatch = 0;
		    			}
                    }
                    if(1 == mismatch)
		    		{
		    			SIMLOG(SL_LS, SL_L5, " -- IP Stop!! -- (x,y)=(%d, %d)\n", (int)Widthcnt, (int)Heightcnt);
                        goto EXIT01;
                    }
                }
            }
       }
    }
	else if((mode == 5) && (kernel == 1))
    { /* 1x25 */
		xsize = xlng - 24 * xstep;
		ysize = ylng;
		for(Heightcnt = 0; Heightcnt < ysize; Heightcnt++)
		{
		    /* read by 1 line data */
		    Read1LineSrc0(Heightcnt * ystep, soura_id0);
		    Read1LineSrc1(Heightcnt,         sourb_id);

            for(Widthcnt = 0; Widthcnt < xsize; Widthcnt++)
		    {
                if(soura_id0[Widthcnt * xstep] == 0)
		    	{
		    		Count_MSKCNT++;
		    	}
                if(!( (msk)&&(sourb_id[Widthcnt + 24 * xstep] == 0) ))
		    	{
                    for(i = 0;i < 25; i++)
                    {
                        Temp_SUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_SQSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)soura_id0[Widthcnt + i * xstep];
                        Temp_CRSUM[i] += (unsigned long)soura_id0[Widthcnt + i * xstep] * (unsigned long)sourb_id[Widthcnt + 24 * xstep];
                        Temp_TMSUM[i] += abs((unsigned long)soura_id0[Widthcnt + i * xstep] - (unsigned long)sourb_id[Widthcnt + 24 * xstep]);
                    }
                }
                if(1 == mismten)
		    	{
                    mismatch = 1;
                    for(i = 0; i < 8; i++)
		    		{
                        if( IMPREG_TMSUMT_READ() >= Temp_TMSUM[i] )
		    			{
		    				mismatch = 0;
		    			}
                    }
                    if(1 == mismatch)
		    		{
		    			SIMLOG(SL_LS, SL_L5, " -- IP Stop!! -- (x,y)=(%d, %d)\n", (int)Widthcnt, (int)Heightcnt);
                        goto EXIT01;
                    }
                }
            }
       }
    }
	

EXIT01:
	/* -> HP (START) */
	if(exsubfun==1)
	{
		for(i=0;i<25;i++)
		{
		    if(((IMPREG_MTRXEN_READ()) >> i ) & 0x1)
			{
		    	result[i] = Temp_TMSUM[i];
			}
			else
			{
				result[i] = 0x7fffff;
			}
		    g_sad_updata[i] = (result[i]>>16) & 0xffff;/* this data is to be used in SAD HP */
		    g_sad_lowdata[i] = result[i] & 0xffff;/* this data is to be used in SAD HP */
		}
	}
	/* -> HP (END) */

	if(mode == 3)
	{
		for(i = 0;i < 9;i++)
		{
			Count_SUM[i] = Temp_SUM[k3x3[i]];
			Count_SQSUM[i] = Temp_SQSUM[k3x3[i]];
			Count_CRSUM[i] = Temp_CRSUM[k3x3[i]];
			Count_TMSUM[i] = Temp_TMSUM[k3x3[i]];
		}
	}
	else if(mode == 4)
	{
		for(i = 0;i < 16;i++)
		{
			Count_SUM[i] = Temp_SUM[k4x4[i]];
			Count_SQSUM[i] = Temp_SQSUM[k4x4[i]];
			Count_CRSUM[i] = Temp_CRSUM[k4x4[i]];
			Count_TMSUM[i] = Temp_TMSUM[k4x4[i]];
		}
	}
	else if(mode == 5)
	{
		for(i = 0;i < 25;i++)
		{
			Count_SUM[i] = Temp_SUM[k5x5[i]];
			Count_SQSUM[i] = Temp_SQSUM[k5x5[i]];
			Count_CRSUM[i] = Temp_CRSUM[k5x5[i]];
			Count_TMSUM[i] = Temp_TMSUM[k5x5[i]];
		}
	}	

	/* update TMSUMT before updating other TMSUM register */
	if(1 == mismten)
	{
		if(1 == mismatch)
		{
			IMPREG_STS_WRITE( IMPREG_STS_READ() | _STS_MIS_MAT);
		}
	}
	
	
    IMPREG_MSKCNT_WRITE( Count_MSKCNT);

	
    IMPREG_SUM0_WRITE( Count_SUM[0] & 0x00ffffff);
    IMPREG_SQSUM0_WRITE( Count_SQSUM[0]);
    IMPREG_CRSUM0_WRITE( Count_CRSUM[0]);

    IMPREG_SUM1_WRITE( Count_SUM[1] & 0x00ffffff);
    IMPREG_SQSUM1_WRITE( Count_SQSUM[1]);
    IMPREG_CRSUM1_WRITE( Count_CRSUM[1]);

    Count_TMSUM[0] = (IMPREG_TMSUMT_READ() - Count_TMSUM[0]);
    Count_TMSUM[1] = (IMPREG_TMSUMT_READ() - Count_TMSUM[1]);

    IMPREG_SAD0_WRITE( abs(Count_TMSUM[0]));
    IMPREG_SAD1_WRITE( abs(Count_TMSUM[1]));

    work = (Count_TMSUM[1]&0x7fff) | ((Count_TMSUM[1]&0x00800000)>>8);
    work = (work<<16) | ((Count_TMSUM[0]&0x7fff) | ((Count_TMSUM[0]&0x00800000)>>8));
    IMPREG_TMSUM01_WRITE( work);

    IMPREG_SUM2_WRITE( Count_SUM[2] & 0x00ffffff);
    IMPREG_SQSUM2_WRITE( Count_SQSUM[2]);
    IMPREG_CRSUM2_WRITE( Count_CRSUM[2]);

    IMPREG_SUM3_WRITE( Count_SUM[3] & 0x00ffffff);
    IMPREG_SQSUM3_WRITE( Count_SQSUM[3]);
    IMPREG_CRSUM3_WRITE( Count_CRSUM[3]);

    Count_TMSUM[2] = (IMPREG_TMSUMT_READ() - Count_TMSUM[2]);
    Count_TMSUM[3] = (IMPREG_TMSUMT_READ() - Count_TMSUM[3]);

    IMPREG_SAD2_WRITE( abs(Count_TMSUM[2]));
    IMPREG_SAD3_WRITE( abs(Count_TMSUM[3]));

    work = (Count_TMSUM[3]&0x7fff) | ((Count_TMSUM[3]&0x00800000)>>8);
    work = (work<<16) | ((Count_TMSUM[2]&0x7fff) | ((Count_TMSUM[2]&0x00800000)>>8));
    IMPREG_TMSUM23_WRITE( work);

    IMPREG_SUM4_WRITE( Count_SUM[4] & 0x00ffffff);
    IMPREG_SQSUM4_WRITE( Count_SQSUM[4]);
    IMPREG_CRSUM4_WRITE( Count_CRSUM[4]);

    IMPREG_SUM5_WRITE( Count_SUM[5] & 0x00ffffff);
    IMPREG_SQSUM5_WRITE( Count_SQSUM[5]);
    IMPREG_CRSUM5_WRITE( Count_CRSUM[5]);

    Count_TMSUM[4] = (IMPREG_TMSUMT_READ() - Count_TMSUM[4]);
    Count_TMSUM[5] = (IMPREG_TMSUMT_READ() - Count_TMSUM[5]);

    IMPREG_SAD4_WRITE( abs(Count_TMSUM[4]));
    IMPREG_SAD5_WRITE( abs(Count_TMSUM[5]));

    work = (Count_TMSUM[5]&0x7fff) | ((Count_TMSUM[5]&0x00800000)>>8);
    work = (work<<16) | ((Count_TMSUM[4]&0x7fff) | ((Count_TMSUM[4]&0x00800000)>>8));
    IMPREG_TMSUM45_WRITE( work);

    IMPREG_SUM6_WRITE( Count_SUM[6] & 0x00ffffff);
    IMPREG_SQSUM6_WRITE( Count_SQSUM[6]);
    IMPREG_CRSUM6_WRITE( Count_CRSUM[6]);

    IMPREG_SUM7_WRITE( Count_SUM[7] & 0x00ffffff);
    IMPREG_SQSUM7_WRITE( Count_SQSUM[7]);
    IMPREG_CRSUM7_WRITE( Count_CRSUM[7]);

    Count_TMSUM[6] = (IMPREG_TMSUMT_READ() - Count_TMSUM[6]);
    Count_TMSUM[7] = (IMPREG_TMSUMT_READ() - Count_TMSUM[7]);

    IMPREG_SAD6_WRITE( abs(Count_TMSUM[6]));
    IMPREG_SAD7_WRITE( abs(Count_TMSUM[7]));

    work = (Count_TMSUM[7]&0x7fff) | ((Count_TMSUM[7]&0x00800000)>>8);
    work = (work<<16) | ((Count_TMSUM[6]&0x7fff) | ((Count_TMSUM[6]&0x00800000)>>8));
    IMPREG_TMSUM67_WRITE( work);

    IMPREG_SUM8_WRITE( Count_SUM[8] & 0x00ffffff);
    IMPREG_SQSUM8_WRITE( Count_SQSUM[8]);
    IMPREG_CRSUM8_WRITE( Count_CRSUM[8]);
    IMPREG_TMSUM8_WRITE( IMPREG_TMSUMT_READ() - Count_TMSUM[8]);

    IMPREG_SAD8_WRITE( abs(IMPREG_TMSUMT_READ() - Count_TMSUM[8]));

	if((mode == 4) || (mode == 5))
	{
	    IMPREG_SUM9_WRITE( Count_SUM[9] & 0x00ffffff);
	    IMPREG_SQSUM9_WRITE( Count_SQSUM[9]);
	    IMPREG_CRSUM9_WRITE( Count_CRSUM[9]);

	    Count_TMSUM[9] = (IMPREG_TMSUMT_READ() - Count_TMSUM[9]);

	    IMPREG_SAD9_WRITE( abs(Count_TMSUM[9]));

	    work = (Count_TMSUM[9]&0x7fff) | ((Count_TMSUM[9]&0x00800000)>>8);
	    IMPREG_TMSUM9_WRITE( work);

	    IMPREG_SUM10_WRITE( Count_SUM[10] & 0x00ffffff);
	    IMPREG_SQSUM10_WRITE( Count_SQSUM[10]);
	    IMPREG_CRSUM10_WRITE( Count_CRSUM[10]);

	    IMPREG_SUM11_WRITE( Count_SUM[11] & 0x00ffffff);
	    IMPREG_SQSUM11_WRITE( Count_SQSUM[11]);
	    IMPREG_CRSUM11_WRITE( Count_CRSUM[11]);

	    Count_TMSUM[10] = (IMPREG_TMSUMT_READ() - Count_TMSUM[10]);
	    Count_TMSUM[11] = (IMPREG_TMSUMT_READ() - Count_TMSUM[11]);

	    IMPREG_SAD10_WRITE( abs(Count_TMSUM[10]));
	    IMPREG_SAD11_WRITE( abs(Count_TMSUM[11]));

	    work = (Count_TMSUM[11]&0x7fff) | ((Count_TMSUM[11]&0x00800000)>>8);
	    work = (work<<16) | ((Count_TMSUM[10]&0x7fff) | ((Count_TMSUM[10]&0x00800000)>>8));
	    IMPREG_TMSUM1011_WRITE( work);

	    IMPREG_SUM12_WRITE( Count_SUM[12] & 0x00ffffff);
	    IMPREG_SQSUM12_WRITE( Count_SQSUM[12]);
	    IMPREG_CRSUM12_WRITE( Count_CRSUM[12]);

	    IMPREG_SUM13_WRITE( Count_SUM[13] & 0x00ffffff);
	    IMPREG_SQSUM13_WRITE( Count_SQSUM[13]);
	    IMPREG_CRSUM13_WRITE( Count_CRSUM[13]);

	    Count_TMSUM[12] = (IMPREG_TMSUMT_READ() - Count_TMSUM[12]);
	    Count_TMSUM[13] = (IMPREG_TMSUMT_READ() - Count_TMSUM[13]);

	    IMPREG_SAD12_WRITE( abs(Count_TMSUM[12]));
	    IMPREG_SAD13_WRITE( abs(Count_TMSUM[13]));

	    work = (Count_TMSUM[13]&0x7fff) | ((Count_TMSUM[13]&0x00800000)>>8);
	    work = (work<<16) | ((Count_TMSUM[12]&0x7fff) | ((Count_TMSUM[12]&0x00800000)>>8));
	    IMPREG_TMSUM1213_WRITE( work);

	    IMPREG_SUM14_WRITE( Count_SUM[14] & 0x00ffffff);
	    IMPREG_SQSUM14_WRITE( Count_SQSUM[14]);
	    IMPREG_CRSUM14_WRITE( Count_CRSUM[14]);

	    IMPREG_SUM15_WRITE( Count_SUM[15] & 0x00ffffff);
	    IMPREG_SQSUM15_WRITE( Count_SQSUM[15]);
	    IMPREG_CRSUM15_WRITE( Count_CRSUM[15]);

	    Count_TMSUM[14] = (IMPREG_TMSUMT_READ() - Count_TMSUM[14]);
	    Count_TMSUM[15] = (IMPREG_TMSUMT_READ() - Count_TMSUM[15]);

	    IMPREG_SAD14_WRITE( abs(Count_TMSUM[14]));
	    IMPREG_SAD15_WRITE( abs(Count_TMSUM[15]));

	    work = (Count_TMSUM[15]&0x7fff) | ((Count_TMSUM[15]&0x00800000)>>8);
	    work = (work<<16) | ((Count_TMSUM[14]&0x7fff) | ((Count_TMSUM[14]&0x00800000)>>8));
	    IMPREG_TMSUM1415_WRITE( work);
	}
	
	if(mode == 5)
	{
		IMPREG_SUM16_WRITE( Count_SUM[16] & 0x00ffffff);
	    IMPREG_SQSUM16_WRITE( Count_SQSUM[16]);
	    IMPREG_CRSUM16_WRITE( Count_CRSUM[16]);

	    IMPREG_SUM17_WRITE( Count_SUM[17] & 0x00ffffff);
	    IMPREG_SQSUM17_WRITE( Count_SQSUM[17]);
	    IMPREG_CRSUM17_WRITE( Count_CRSUM[17]);

	    Count_TMSUM[16] = (IMPREG_TMSUMT_READ() - Count_TMSUM[16]);
	    Count_TMSUM[17] = (IMPREG_TMSUMT_READ() - Count_TMSUM[17]);
	 
	    IMPREG_SAD16_WRITE( abs(Count_TMSUM[16]));
	    IMPREG_SAD17_WRITE( abs(Count_TMSUM[17]));
	 
	    work = (Count_TMSUM[17]&0x7fff) | ((Count_TMSUM[17]&0x00800000)>>8);
	    work = (work<<16) | ((Count_TMSUM[16]&0x7fff) | ((Count_TMSUM[16]&0x00800000)>>8));
	    IMPREG_TMSUM1617_WRITE( work);

	    IMPREG_SUM18_WRITE( Count_SUM[18] & 0x00ffffff);
	    IMPREG_SQSUM18_WRITE( Count_SQSUM[18]);
	    IMPREG_CRSUM18_WRITE( Count_CRSUM[18]);

	    IMPREG_SUM19_WRITE( Count_SUM[19] & 0x00ffffff);
	    IMPREG_SQSUM19_WRITE( Count_SQSUM[19]);
	    IMPREG_CRSUM19_WRITE( Count_CRSUM[19]);

	    Count_TMSUM[18] = (IMPREG_TMSUMT_READ() - Count_TMSUM[18]);
	    Count_TMSUM[19] = (IMPREG_TMSUMT_READ() - Count_TMSUM[19]);

	    IMPREG_SAD18_WRITE( abs(Count_TMSUM[18]));
	    IMPREG_SAD19_WRITE( abs(Count_TMSUM[19]));

	    work = (Count_TMSUM[19]&0x7fff) | ((Count_TMSUM[19]&0x00800000)>>8);
	    work = (work<<16) | ((Count_TMSUM[18]&0x7fff) | ((Count_TMSUM[18]&0x00800000)>>8));
	    IMPREG_TMSUM1819_WRITE( work);

	    IMPREG_SUM20_WRITE( Count_SUM[20] & 0x00ffffff);
	    IMPREG_SQSUM20_WRITE( Count_SQSUM[20]);
	    IMPREG_CRSUM20_WRITE( Count_CRSUM[20]);

	    IMPREG_SUM21_WRITE( Count_SUM[21] & 0x00ffffff);
	    IMPREG_SQSUM21_WRITE( Count_SQSUM[21]);
	    IMPREG_CRSUM21_WRITE( Count_CRSUM[21]);

	    Count_TMSUM[20] = (IMPREG_TMSUMT_READ() - Count_TMSUM[20]);
	    Count_TMSUM[21] = (IMPREG_TMSUMT_READ() - Count_TMSUM[21]);

	    IMPREG_SAD20_WRITE( abs(Count_TMSUM[20]));
	    IMPREG_SAD21_WRITE( abs(Count_TMSUM[21]));

	    work = (Count_TMSUM[21]&0x7fff) | ((Count_TMSUM[21]&0x00800000)>>8);
	    work = (work<<16) | ((Count_TMSUM[20]&0x7fff) | ((Count_TMSUM[20]&0x00800000)>>8));
	    IMPREG_TMSUM2021_WRITE( work);

	    IMPREG_SUM22_WRITE( Count_SUM[22] & 0x00ffffff);
	    IMPREG_SQSUM22_WRITE( Count_SQSUM[22]);
	    IMPREG_CRSUM22_WRITE( Count_CRSUM[22]);

	    IMPREG_SUM23_WRITE( Count_SUM[23] & 0x00ffffff);
	    IMPREG_SQSUM23_WRITE( Count_SQSUM[23]);
	    IMPREG_CRSUM23_WRITE( Count_CRSUM[23]);

	    Count_TMSUM[22] = (IMPREG_TMSUMT_READ() - Count_TMSUM[22]);
	    Count_TMSUM[23] = (IMPREG_TMSUMT_READ() - Count_TMSUM[23]);

	    IMPREG_SAD22_WRITE( abs(Count_TMSUM[22]));
	    IMPREG_SAD23_WRITE( abs(Count_TMSUM[23]));

	    work = (Count_TMSUM[23]&0x7fff) | ((Count_TMSUM[23]&0x00800000)>>8);
	    work = (work<<16) | ((Count_TMSUM[22]&0x7fff) | ((Count_TMSUM[22]&0x00800000)>>8));
	    IMPREG_TMSUM2223_WRITE( work);

	    IMPREG_SUM24_WRITE( Count_SUM[24] & 0x00ffffff);
	    IMPREG_SQSUM24_WRITE( Count_SQSUM[24]);
	    IMPREG_CRSUM24_WRITE( Count_CRSUM[24]);

	    Count_TMSUM[24] = (IMPREG_TMSUMT_READ() - Count_TMSUM[24]);

	    IMPREG_SAD24_WRITE( abs(Count_TMSUM[24]));

	    work = (Count_TMSUM[24]&0x7fff) | ((Count_TMSUM[24]&0x00800000)>>8);
	    IMPREG_TMSUM24_WRITE(work);
	}

    return(0);
}
