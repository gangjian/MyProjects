/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG2_0001.c                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif
#include "impsim_int.h"
#include "legacy_sim.h"
#include "legacy_micro_op.h"

static void IMG2_0001_Matrix();
static void IMG2_0001_Add32bit();
static void IMG2_0001_Euclid();

#define MATRXAC 25


/******************************************************************************/
/* IMG2_0001                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17 T.Sato                                               */
/*                         New                                                */
/******************************************************************************/
int IMG2_0001(){
	
	int subfun;
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	subfun = (((IMPREG_IPFUN_READ())>>24) & 0x0000000f); //get subfun bit
	
	switch (subfun) {
	case 0:
		IMG2_0001_Matrix();
		break;
	case 1:
		IMG2_0001_Add32bit();
		break;
	case 2:
		IMG2_0001_Euclid();
		break;
	default:
		SIMLOG(SL_LS, SL_ERR, "Error subfun=%d\n",subfun);
		Legacy_assert_error();
	}
	
	return 0;
}


/******************************************************************************/
/* IMG2_0001_Matrix                                                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17 T.Sato                                               */
/*                         copy & past (todo)                                 */
/******************************************************************************/
static void IMG2_0001_Matrix(){
	
	int64 data;
	int xlng, i, j, work, st, ylng, k;
	short *soura_id = psLM0;
	short *sourb_id = psLM1;
	int64 result[LINE_SIZE];
	int mode, Heightcnt, Widthcnt, loop, yloop;
	FILE *fp_deb_mtx;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	memset(result, 0, LINE_SIZE * sizeof(int64));
	
	xlng = IMPREG_APLNG_READ() & 0x3fff;
	ylng = (IMPREG_APLNG_READ()>>16) & 0x3fff;
	
	if(DEB_MATRIX_MODE){
		if ((fp_deb_mtx = fopen("calcMatrix.txt", "w")) == NULL)
		{
			SIMLOG(SL_LS, SL_ERR, "Cannot open file calcMatrix.txt\n");
			Legacy_assert_error();
		} else {
			SIMLOG(SL_LS, SL_L4, "Open file calcMatrix.txt\n");
		}
	}
	
	if(xlng>128) SIMLOG(SL_LS, SL_L4, "********** Warning xlng=%d **********\n", xlng);
	
#if 1
	loop = MATRXAC;
	if (!McomFlg) {
		SIMLOG(SL_LS, SL_ERR, "Matrix is not PIPE!!!\n");
		Legacy_assert_error();
	}
	if(((IMPREG_IPFORM_READ()>>20) & 0x0007) == 2) { /* srcb_ind_om = 16bpp */
		if((IMPREG_LMCTL_READ() & 0x0007) == 1){ /* lmw = 128 */
			st = 496;
			mode = 16;
		} else if ((IMPREG_LMCTL_READ() & 0x0007) == 2) { /* lmw = 256 */
			st = 480;
			mode = 32;
			loop = 15;
		} else { /* lmw = 512 */
			st = 448;
			mode = 64;
			loop = 7;
		}
	} else if (((IMPREG_IPFORM_READ()>>20) & 0x0007) == 1) { /* srcb_ind_om = 1bpp */
		st = 504;
		mode = 1;
	} else if ( (((IMPREG_IPFORM_READ()>>20) & 0x0007) == 0) && (((IMPREG_IPFUN_READ()>>20) & 0x0003) == 2) ) {
		st = 504;
		mode = 1;
	} else { /* srca_ind_om = 8bpp */
		if((IMPREG_LMCTL_READ() & 0x0007) == 1) { /* lmw = 128 */
			st = 504;
			mode = 8;
		} else if((IMPREG_LMCTL_READ() & 0x0007) == 2) { /* lmw = 256 */
			st = 496;
			mode = 16;
		} else { /* lmw = 512 */
			st = 480;
			mode = 32;
			loop = 15;
		}
	}
	
	yloop = 1;
	
	for (k=0;k<yloop;k++) {
		/* read M0 data */
		Read1LineLM256A(0, soura_id);
		for (j=0;j<loop;j++) {
			/* read M1 data */
			work = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B];
			MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] = st - j * mode;
			
			Read1LineLM256B(sourb_id);
			MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] = work;
			
			data = 0;
			for (i=0;i<xlng;i++) {
				if (DEB_MATRIX_MODE) {
					SIMLOG(SL_LS, SL_ERR, "DEB_MATRIX_MODE!!!\n");
					Legacy_assert_error();
				} else {
					data += ((int64)(soura_id[i]) * (int64)(sourb_id[i]));
				}
				
				//SIMLOG(SL_LS, SL_L4, "soura_id[i]=%016lx sourb_id[i]=%016lx   ", soura_id[i], sourb_id[i]);
				if ((data>(int64)(0x7fffffff))||(data<(int64)(0xffffffff80000000))) {
					SIMLOG(SL_LS, SL_L4, "********** Warning M2 32bit over x=%x dataA=%x dataB=%x data= %08lx%08lx********** \n", i, soura_id[i], sourb_id[i], (data>>32) & 0xffffffff, data & 0xffffffff);
					IMPREG_STS_WRITE( (IMPREG_STS_READ() | 0x00000080));
				}
			}
			//SIMLOG(SL_LS, SL_L4, "\n");
			if ( ((IMPREG_MTRXEN_READ()>>j) & 0x0001) ) {
				result[j] = data;
			}
		}
		Write1LineDst(k, result);
	}
	
#else
	loop = MATRXAC;
	if(((IMPREG_IPFORM_READ()>>20) & 0x0007) == 2) { /* srcb_ind_om = 16bpp */
		if((IMPREG_LMCTL_READ() & 0x0007) == 1){ /* lmw = 128 */
			st = 496;
			mode = 16;
		} else if ((IMPREG_LMCTL_READ() & 0x0007) == 2) { /* lmw = 256 */
			st = 480;
			mode = 32;
			if (McomFlg) {
				loop = 15;
			} else {
				loop = 16;
			}
		} else { /* lmw = 512 */
			st = 448;
			mode = 64;
			if (McomFlg) {
				loop = 7;
			} else {
				loop = 8;
			}
		}
	} else if (((IMPREG_IPFORM_READ()>>20) & 0x0007) == 1) { /* srcb_ind_om = 1bpp */
		st = 504;
		mode = 1;
	} else if ( (((IMPREG_IPFORM_READ()>>20) & 0x0007) == 0) && (((IMPREG_IPFUN_READ()>>20) & 0x0003) == 2) ) {
		st = 504;
		mode = 1;
	} else { /* srca_ind_om = 8bpp */
		if((IMPREG_LMCTL_READ() & 0x0007) == 1) { /* lmw = 128 */
			st = 504;
			mode = 8;
		} else if((IMPREG_LMCTL_READ() & 0x0007) == 2) { /* lmw = 256 */
			st = 496;
			mode = 16;
		} else { /* lmw = 512 */
			st = 480;
			mode = 32;
			if (McomFlg) {
				loop = 15;
			} else {
				loop = 16;
			}
		}
	}
	
	if (McomFlg) {
		yloop = 1;
	} else {
		yloop = ylng;
	}
	
	for (k=0;k<yloop;k++) {
		/* read M0 data */
		if (McomFlg) {
			Read1LineLM256A(0, soura_id);
		} else {
			Read1LineSrc0(k, soura_id);
		}
		for (j=0;j<loop;j++) {
			/* read M1 data */
			work = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B];
			MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] = st - j * mode;
			
			Read1LineLM256B(sourb_id);
			MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] = work;
			
			data = 0;
			for (i=0;i<xlng;i++) {
				if (DEB_MATRIX_MODE) {
					if (j>= MTX_JMIN && j<= MTX_JMAX) {
						fprintf(fp_deb_mtx, "((sa[%3d]=%016x * sb[%3d]=%016x)=%016lx)", i, soura_id[i], i, sourb_id[i], ((int64)(soura_id[i]) * (int64)(sourb_id[i])));
						fprintf(fp_deb_mtx, " + %016lx\n", data);
						data += ((int64)(soura_id[i]) * (int64)(sourb_id[i]));
						fprintf(fp_deb_mtx, "= %016lx\n", data);
					} else {
						data += ((int64)(soura_id[i]) * (int64)(sourb_id[i]));
					}
				} else {
					data += ((int64)(soura_id[i]) * (int64)(sourb_id[i]));
				}
				
				//SIMLOG(SL_LS, SL_L4, "soura_id[i]=%016lx sourb_id[i]=%016lx   ", soura_id[i], sourb_id[i]);
				if ((data>(int64)(0x7fffffff))||(data<(int64)(0xffffffff80000000))) {
					SIMLOG(SL_LS, SL_L4, "********** Warning M2 32bit over x=%x dataA=%x dataB=%x data= %08lx%08lx********** \n", i, soura_id[i], sourb_id[i], (data>>32) & 0xffffffff, data & 0xffffffff);
					IMPREG_STS_WRITE( (IMPREG_STS_READ() | 0x00000080));
				}
			}
			//SIMLOG(SL_LS, SL_L4, "\n");
			if ( ((IMPREG_MTRXEN_READ()>>j) & 0x0001) ) {
				result[j] = data;
			}
		}
		Write1LineDst(k, result);
	}
	
	if (DEB_MATRIX_MODE) {
		fclose(fp_deb_mtx);
	}
#endif
	
	return;
}


/******************************************************************************/
/* IMG2_0001_Add32bit                                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/07   T.Sato                                             */
/*                         not support                                        */
/******************************************************************************/
static void IMG2_0001_Add32bit(){
	
#if 0
	int xlng, j, work, ylng;
	short soura_id[LINE_SIZE],sourb_id[LINE_SIZE];
	int64 result[LINE_SIZE], f, g, addwork;
	int Heightcnt, Widthcnt, scale, cut_en;
	int64 b;
	double fa;
#endif
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	SIMLOG(SL_LS, SL_ERR, "ERROR, IMG2_0001_Add32bit is not supported.\n");
	Legacy_assert_error();
	
#if 0
	memset(result, 0, LINE_SIZE * sizeof(int64));
	
	xlng = IMPREG_APLNG_READ() & 0x3fff;
	ylng = (IMPREG_APLNG_READ()>>16) & 0x3fff;
	
	Heightcnt = 0;
	xlng &= 0x3ffe;
	
	/***** scale/cut *****/
	cut_en = ((IMPREG_IPFUN_READ() >> 10) & 0x0001);
	scale = (IMPREG_IPFUN_READ() & 0x000f);
	scale |= (IMPREG_IPFUN2_READ() & 0x0007) << 4;
	/* 2^scale */
	for (j=0,b=1;j<(unsigned int)scale;j++) {
		b = b * 2;
	}
	/***************/
	
	while (Heightcnt<ylng) {
		Read1LineSrc0(Heightcnt, soura_id);
		Read1LineSrc1(Heightcnt, sourb_id);
		
		Widthcnt = 0;
		while (Widthcnt<xlng) {
			f = ((soura_id[Widthcnt] & 0xffff)<<16) | ( soura_id[Widthcnt+1] & 0xffff);
			g = ((sourb_id[Widthcnt] & 0xffff)<<16) | ( sourb_id[Widthcnt+1] & 0xffff);
			if (f & 0x80000000) f |= 0xffffffff00000000l;
			if (g & 0x80000000) g |= 0xffffffff00000000l;
			
			addwork = f+g;
			/***** scale/cut *****/
			if (scale) {
				fa = (double)addwork;
				fa = fa/b;
				if (cut_en) { /*rounddown*/
					if(fa>=0) {
						addwork = (int64)fa;
					} else {
						addwork = !(addwork%b) ? (int64)(fa) : (int64)(fa-1);
					}
				} else { /* round */
					if (fa>=0) {
						addwork = (int64)(fa+0.5);
					} else {
						addwork = (!(addwork%b)||((addwork>>(scale-1))&0x01)) ? (int64)(fa) : (int64)(fa-1);
					}
				}
			}
			/***************/
			
			if (addwork>(int64)(0x7fffffff)) addwork = 0x7fffffff;
			if (addwork<(int64)(0xffffffff80000000)) addwork = 0xffffffff80000000;
			result[Widthcnt/2] = addwork;
			Widthcnt += 2;
		}
		Write1LineDst(Heightcnt, result);
		Heightcnt++;
	}
#endif
	return;
}


/******************************************************************************/
/* IMG2_0001_Euclid                                                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17 T.Sato                                               */
/******************************************************************************/
static void IMG2_0001_Euclid(){
	
	int64 data;
	int xlng, i, j, work, st, ylng;
	short *soura_id = psLM0;
	short *sourb_id = psLM1;
	int64 result[LINE_SIZE];
	int mode, Heightcnt, Widthcnt, loop;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	memset(result, 0, LINE_SIZE * sizeof(int64));
	
	xlng = IMPREG_APLNG_READ() & 0x3fff;
	ylng = (IMPREG_APLNG_READ()>>16) & 0x3fff;
	
	if(xlng>128) SIMLOG(SL_LS, SL_L4, "********** Warning xlng=%d **********\n", xlng);
	
	loop = MATRXAC;
	if(((IMPREG_IPFORM_READ()>>20) & 0x0007) == 2) {
		/* srcb_ind_om = 16bpp */
		if((IMPREG_LMCTL_READ() & 0x0007) == 1){
			/* lmw = 128 */
			st = 496;
			mode = 16;
		} else if ((IMPREG_LMCTL_READ() & 0x0007) == 2) {
			/* lmw = 256 */
			st = 480;
			mode = 32;
			loop = 15;
		} else {
			/* lmw = 512 */
			st = 448;
			mode = 64;
			loop = 7;
		}
	} else if (((IMPREG_IPFORM_READ()>>20) & 0x0007) == 1) {
		/* srcb_ind_om = 1bpp */
		st = 504;
		mode = 1;
	} else if ( (((IMPREG_IPFORM_READ()>>20) & 0x0007) == 0) && (((IMPREG_IPFUN_READ()>>20) & 0x0003) == 2) ) {
		st = 504;
		mode = 1;
	} else {
		/* srca_ind_om = 8bpp */
		if((IMPREG_LMCTL_READ() & 0x0007) == 1) {
			/* lmw = 128 */
			st = 504;
			mode = 8;
		} else if((IMPREG_LMCTL_READ() & 0x0007) == 2) {
			/* lmw = 256 */
			st = 496;
			mode = 16;
		} else {
			/* lmw = 512 */
			st = 480;
			mode = 32;
			loop = 15;
		}
	}
	
	Read1LineLM256A(0, soura_id);
	
	for (j=0;j<loop;j++) {
		work = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B];
		MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] = st - j * mode;
		
		Read1LineLM256B(sourb_id);
		MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] = work;
		
		data = 0;
		for (i=0; i<xlng; i++) {
			data += ((int64)(soura_id[i]) - (int64)(sourb_id[i])) * ((int64)(soura_id[i]) - (int64)(sourb_id[i]));
		}
		
		if ( ((IMPREG_MTRXEN_READ()>>j) & 0x0001) ) {
			result[j] = data;
		}
	}
	Write1LineDst(0, result);
	
	return;
}

