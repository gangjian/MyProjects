/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0110.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-01 : 2015/02/20   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif
#include "impsim_int.h"
#include "legacy_sim.h"

//int64 IMG_ConvEx(short mLU[], short mRU[], short mLD[], short mRD[], int64 w[] );
static int64 IMG_ConvEx(short mLU[], short mRU[], short mLD[], short mRD[], int64 w[], FILE *fp, long Heightcnt, long Widthcnt );

unsigned char v_mode, h_mode, LUenable, RUenable, LDenable, RDenable;

#define getreg1(regname, shift)  ((unsigned char)((IMPREG_ ## regname ## _READ()>>shift) & 0x0001))
#define getreg8(regname, shift)  ((IMPREG_ ## regname ## _READ()>>shift) & 0x00ff)


/******************************************************************************/
/* IMG_0110                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-01 : 2015/02/20   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
//	Assumption for using 6 LMs: set the half of LM0-2 to hypothesis LM3-5
int IMG_0110(){
	long xlng, ylng, Widthcnt, Heightcnt;
	int i, datatype;
	short *soura_id = psLM6;
	short mRU[CELL], mLU[9], mLD[CELL], mRD[CELL];	/* m[] */
	unsigned char kernel, edge, lm_mode, msk, kmsk[CELL], soura_dt;
	int64 result[LINE_SIZE], weight[CELL], scale;
	short (*pReadLM[7])(int adr) = {ReadLM0,ReadLM1,ReadLM2,ReadLM3,ReadLM4,ReadLM5,NULL};
	void (*pWriteLM[7])(int adr, short *data, int size) = {WriteLM0,WriteLM1,WriteLM2,WriteLM3,WriteLM4,WriteLM5,NULL};
	
    FILE *fp_calc;
    if(CONVOLUTION_DEBUG){
        if ((fp_calc = fopen("calc7x7.txt", "w")) == NULL)
        {
            SIMLOG(SL_LS, SL_L4, "Cannot open file calc7x7.txt\n");
            return(-1);
        }else{
            SIMLOG(SL_LS, SL_L4, "Open file calc7x7.txt\n");
	    }
    }

#ifdef DEBUG_OUTPUT
	ResetDebugGamen();
#endif

    datatype = ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
    if((IMPREG_IPFORM_READ() >> 16) & 0x0007){
        datatype = ((IMPREG_IPFORM_READ() >> 16) & 0x0007) + 4;
    }

	/* Load the resister values */
    xlng = IMPREG_APLNG_READ() & 0x3fff;
//	if(xlng>=1024)	xlng = 1024;	/* ? */
	ylng = (IMPREG_APLNG_READ() >>16) & 0x3fff;
	kernel = (char)((IMPREG_IPFUN_READ()>>27) & 0x0001);
	edge = (char)((IMPREG_IPFUN_READ()>>24) & 0x0003);
	v_mode = getreg1(KNLMSK, 31);
	h_mode = getreg1(KNLMSK, 30);
	lm_mode = getreg1(KNLMSK, 29);
	LUenable = getreg1(KNLMSK, 28);
	RUenable = getreg1(KNLMSK, 27);
	LDenable = getreg1(KNLMSK, 26);
	RDenable = getreg1(KNLMSK, 25);
	soura_dt = (char)((IMPREG_IPFUN_READ()>>22) & 0x0003);

    if(datatype==6){
        for(i=0, scale=1;i<(signed int)((IMPREG_IPFUN2_READ() & 0x000f)<<4 | (IMPREG_IPFUN_READ() & 0x000f));i++) scale *= 2;
    }else{
        for(i=0, scale=1;i<(signed int)(IMPREG_IPFUN_READ() & 0x000f);i++) scale *= 2;
    }

	/* ---getting 16 coefficients--- */
	weight[0] = getreg8(COEFF02, 18);
	weight[1] = getreg8(COEFF02, 9);
	weight[2] = getreg8(COEFF02, 0);
	weight[3] = getreg8(COEFF35, 18);
	weight[4] = getreg8(COEFF35, 9);
	weight[5] = getreg8(COEFF35, 0);
	weight[6] = getreg8(COEFF68, 18);
	weight[7] = getreg8(COEFF68, 9);
	weight[8] = getreg8(COEFF68, 0);
	weight[9] = getreg8(COEFF911, 18);
	weight[10] = getreg8(COEFF911, 9);
	weight[11] = getreg8(COEFF911, 0);
	weight[12] = getreg8(COEFF1214, 18);
	weight[13] = getreg8(COEFF1214, 9);
	weight[14] = getreg8(COEFF1214, 0);
	weight[15] = getreg8(COEFF15, 18);

    if(datatype==6){
	    weight[0] |= ((getreg8(COEFF02H, 16)<<8) & 0xff00);
	    weight[1] |= ((getreg8(COEFF02H, 8)<<8) & 0xff00);
	    weight[2] |= ((getreg8(COEFF02H, 0)<<8) & 0xff00);
	    weight[3] |= ((getreg8(COEFF35H, 16)<<8) & 0xff00);
	    weight[4] |= ((getreg8(COEFF35H, 8)<<8) & 0xff00);
	    weight[5] |= ((getreg8(COEFF35H, 0)<<8) & 0xff00);
	    weight[6] |= ((getreg8(COEFF68H, 16)<<8) & 0xff00);
	    weight[7] |= ((getreg8(COEFF68H, 8)<<8) & 0xff00);
	    weight[8] |= ((getreg8(COEFF68H, 0)<<8) & 0xff00);
	    weight[9] |= ((getreg8(COEFF911H, 16)<<8) & 0xff00);
	    weight[10] |= ((getreg8(COEFF911H, 8)<<8) & 0xff00);
	    weight[11] |= ((getreg8(COEFF911H, 0)<<8) & 0xff00);
	    weight[12] |= ((getreg8(COEFF1214H, 16)<<8) & 0xff00);
	    weight[13] |= ((getreg8(COEFF1214H, 8)<<8) & 0xff00);
	    weight[14] |= ((getreg8(COEFF1214H, 0)<<8) & 0xff00);
	    weight[15] |= ((getreg8(COEFF1517H, 16)<<8) & 0xff00);
	    if(getreg1(COEFF02H,23))	weight[0] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF02H,15))	weight[1] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF02H,7))	weight[2] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF35H,23))	weight[3] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF35H,15))	weight[4] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF35H,7))	weight[5] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF68H,23))	weight[6] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF68H,15))	weight[7] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF68H,7))	weight[8] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF911H,23))	weight[9] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF911H,15))	weight[10] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF911H,7))	weight[11] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF1214H,23))	weight[12] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF1214H,15))	weight[13] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF1214H,7))	weight[14] |= 0xffffffffffff0000l;
	    if(getreg1(COEFF1517H,23))	weight[15] |= 0xffffffffffff0000l;
    }else{
	    if(getreg1(COEFF02,26))	weight[0] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF02,17))	weight[1] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF02,8))	weight[2] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF35,26))	weight[3] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF35,17))	weight[4] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF35,8))	weight[5] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF68,26))	weight[6] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF68,17))	weight[7] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF68,8))	weight[8] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF911,26))	weight[9] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF911,17))	weight[10] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF911,8))	weight[11] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF1214,26))	weight[12] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF1214,17))	weight[13] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF1214,8))	weight[14] |= 0xffffffffffffff00l;
	    if(getreg1(COEFF15,26))	weight[15] |= 0xffffffffffffff00l;
    }

	msk = getreg1(IPFUN, 26);	/* 'Enable' or 'Disable' about kernel mask */
	if(msk==1){
		for(i=0;i<9;i++){
			kmsk[i] = getreg1(KNLMSK, (short)i);
			if(kmsk[i])	weight[i] = 0;
		}
		for(i=9;i<16;i++){
			kmsk[i] = getreg1(KNLMSK, (short)(i+7));
			if(kmsk[i])	weight[i] = 0;
		}
	}

    if(CONVOLUTION_DEBUG){
	    for(i=0;i<CELL;i++) {
		    fprintf(fp_calc, "w[%2d]=%016lx (%ld)\n", i, weight[i], weight[i]);
	    }
    }

//////////
	Heightcnt = 0;
#if USE_PIPE_FUNC
    if(McomFlg){
        Widthcnt = 0;

		while(Widthcnt < xlng){

				/* at middle lines --- read by 1 line and shift */
				switch(Widthcnt){
				case 0:
//read 3 raws of data at first
					mRU[15] = ReadLM256A(6, Widthcnt);
					mRU[14] = ReadLM256A(5, Widthcnt);
					mRU[13] = ReadLM256A(4, Widthcnt);
					mRD[9] = ReadLM256A(3, Widthcnt);
					mRD[13] = ReadLM256A(2, Widthcnt);
					mRD[14] = ReadLM256A(1, Widthcnt);
					mRD[15] = ReadLM256A(0, Widthcnt);

					mRU[6] = ReadLM256A(6, Widthcnt+1);
					mRU[3] = ReadLM256A(5, Widthcnt+1);
					mRU[0] = ReadLM256A(4, Widthcnt+1);
					mRD[10] = ReadLM256A(3, Widthcnt+1);
					mRD[0] = ReadLM256A(2, Widthcnt+1);
					mRD[3] = ReadLM256A(1, Widthcnt+1);
					mRD[6] = ReadLM256A(0, Widthcnt+1);

					mRU[7] = ReadLM256A(6, Widthcnt+2);
					mRU[4] = ReadLM256A(5, Widthcnt+2);
					mRU[1] = ReadLM256A(4, Widthcnt+2);
					mRD[11] = ReadLM256A(3, Widthcnt+2);
					mRD[1] = ReadLM256A(2, Widthcnt+2);
					mRD[4] = ReadLM256A(1, Widthcnt+2);
					mRD[7] = ReadLM256A(0, Widthcnt+2);

					mRU[8] = ReadLM256A(6, Widthcnt+3);
					mRU[5] = ReadLM256A(5, Widthcnt+3);
					mRU[2] = ReadLM256A(4, Widthcnt+3);
					mRD[12] = ReadLM256A(3, Widthcnt+3);
					mRD[2] = ReadLM256A(2, Widthcnt+3);
					mRD[5] = ReadLM256A(1, Widthcnt+3);
					mRD[8] = ReadLM256A(0, Widthcnt+3);

					if(edge==3)	result[Widthcnt] = 0;
					else	result[Widthcnt] = ReadLM256A(3, Widthcnt) * scale;
					break;
				case 1:
					mLU[6] = mRU[15];	mRU[15] = mRU[6];
					mRU[6] = mRU[7];	mRU[7] = mRU[8];
					mRU[8] = ReadLM256A(6, Widthcnt+3);
					
					mLU[3] = mRU[14];	mRU[14] = mRU[3];
					mRU[3] = mRU[4];	mRU[4] = mRU[5];
					mRU[5] = ReadLM256A(5, Widthcnt+3);
					
					mLU[0] = mRU[13];	mRU[13] = mRU[0];
					mRU[0] = mRU[1];	mRU[1] = mRU[2];
					mRU[2] = ReadLM256A(4, Widthcnt+3);
					
					mLD[10] = mRD[9];	mRD[9] = mRD[10];
					mRD[10] = mRD[11];	mRD[11] = mRD[12];
					mRD[12] = ReadLM256A(3, Widthcnt+3);
					
					mLD[0] = mRD[13];	mRD[13] = mRD[0];
					mRD[0] = mRD[1];	mRD[1] = mRD[2];
					mRD[2] = ReadLM256A(2, Widthcnt+3);
					
					mLD[3] = mRD[14];	mRD[14] = mRD[3];
					mRD[3] = mRD[4];	mRD[4] = mRD[5];
					mRD[5] = ReadLM256A(1, Widthcnt+3);
					
					mLD[6] = mRD[15];	mRD[15] = mRD[6];
					mRD[6] = mRD[7];	mRD[7] = mRD[8];
					mRD[8] = ReadLM256A(0, Widthcnt+3);
					
					if(edge==3)	result[Widthcnt] = 0;
					else	result[Widthcnt] = ReadLM256A(3, Widthcnt) * scale;
					break;
					
				case 2:
					mLU[7] = mLU[6];	mLU[6] = mRU[15];	mRU[15] = mRU[6];
					mRU[6] = mRU[7];	mRU[7] = mRU[8];
					mRU[8] = ReadLM256A(6, Widthcnt+3);
					
					mLU[4] = mLU[3];	mLU[3] = mRU[14];	mRU[14] = mRU[3];
					mRU[3] = mRU[4];	mRU[4] = mRU[5];
					mRU[5] = ReadLM256A(5, Widthcnt+3);
					
					mLU[1] = mLU[0];	mLU[0] = mRU[13];	mRU[13] = mRU[0];
					mRU[0] = mRU[1];	mRU[1] = mRU[2];
					mRU[2] = ReadLM256A(4, Widthcnt+3);
					
					mLD[11] = mLD[10];	mLD[10] = mRD[9];	mRD[9] = mRD[10];
					mRD[10] = mRD[11];	mRD[11] = mRD[12];
					mRD[12] = ReadLM256A(3, Widthcnt+3);
					
					mLD[1] = mLD[0];	mLD[0] = mRD[13];	mRD[13] = mRD[0];
					mRD[0] = mRD[1];	mRD[1] = mRD[2];
					mRD[2] = ReadLM256A(2, Widthcnt+3);
					
					mLD[4] = mLD[3];	mLD[3] = mRD[14];	mRD[14] = mRD[3];
					mRD[3] = mRD[4];	mRD[4] = mRD[5];
					mRD[5] = ReadLM256A(1, Widthcnt+3);
					
					mLD[7] = mLD[6];	mLD[6] = mRD[15];	mRD[15] = mRD[6];
					mRD[6] = mRD[7];	mRD[7] = mRD[8];
					mRD[8] = ReadLM256A(0, Widthcnt+3);

					if(edge==3)	result[Widthcnt] = 0;
					else	result[Widthcnt] = ReadLM256A(3, Widthcnt) * scale;
					break;
					
				default:
				/* only make edge process at the right side */
					if(Widthcnt>=xlng-3){
						if(edge==3)	result[Widthcnt] = 0;
						else	result[Widthcnt] = ReadLM256A(3, Widthcnt) * scale;
						break;
					}
					/* center area */
					mLU[8] = mLU[7];	mLU[7] = mLU[6];
					mLU[6] = mRU[15];	mRU[15] = mRU[6];
					mRU[6] = mRU[7];	mRU[7] = mRU[8];
					mRU[8] = ReadLM256A(6, Widthcnt+3);
					
					mLU[5] = mLU[4];	mLU[4] = mLU[3];
					mLU[3] = mRU[14];	mRU[14] = mRU[3];
					mRU[3] = mRU[4];	mRU[4] = mRU[5];
					mRU[5] = ReadLM256A(5, Widthcnt+3);
					
					mLU[2] = mLU[1];	mLU[1] = mLU[0];
					mLU[0] = mRU[13];	mRU[13] = mRU[0];
					mRU[0] = mRU[1];	mRU[1] = mRU[2];
					mRU[2] = ReadLM256A(4, Widthcnt+3);
					
					mLD[12] = mLD[11];	mLD[11] = mLD[10];
					mLD[10] = mRD[9];	mRD[9] = mRD[10];
					mRD[10] = mRD[11];	mRD[11] = mRD[12];
					mRD[12] = ReadLM256A(3, Widthcnt+3);
					
					mLD[2] = mLD[1];	mLD[1] = mLD[0];
					mLD[0] = mRD[13];	mRD[13] = mRD[0];
					mRD[0] = mRD[1];	mRD[1] = mRD[2];
					mRD[2] = ReadLM256A(2, Widthcnt+3);
					
					mLD[5] = mLD[4];	mLD[4] = mLD[3];
					mLD[3] = mRD[14];	mRD[14] = mRD[3];
					mRD[3] = mRD[4];	mRD[4] = mRD[5];
					mRD[5] = ReadLM256A(1, Widthcnt+3);
					
					mLD[8] = mLD[7];	mLD[7] = mLD[6];
					mLD[6] = mRD[15];	mRD[15] = mRD[6];
					mRD[6] = mRD[7];	mRD[7] = mRD[8];
					mRD[8] = ReadLM256A(0, Widthcnt+3);
					
//					result[Widthcnt] = IMG_ConvEx(mLU,mRU,mLD,mRD, weight);
					result[Widthcnt] = IMG_ConvEx(mLU,mRU,mLD,mRD, weight, fp_calc, Heightcnt, Widthcnt);
					break;
				}

    			Widthcnt++;
			}
            Write1LineDst(0, result);

    }else{
#endif 

//	if(kernel==0){	/* ? */
		while(Heightcnt < ylng+3){
			if (Heightcnt<ylng){
				Read1LineSrc0(Heightcnt, soura_id);
			}
			Widthcnt = 0;
			while(Widthcnt < xlng){
				if((Heightcnt>2 && Heightcnt<6) || Heightcnt>ylng-1){
				/* edge process */
					if(edge==3)	result[Widthcnt] = 0;
					else	result[Widthcnt] = pReadLM[3](Widthcnt) * scale;
				}else if(Heightcnt >=6){
					/* at middle lines --- read by 1 line and shift */
					switch(Widthcnt){
					case 0:
//					if(Widthcnt == 0)	/* make edge process at the left side */
//					{
//read 3 raws of data at first
						mRU[15] = pReadLM[0](Widthcnt);
						mRU[14] = pReadLM[5](Widthcnt);
						mRU[13] = pReadLM[4](Widthcnt);
						mRD[9] = pReadLM[3](Widthcnt);
						mRD[13] = pReadLM[2](Widthcnt);
						mRD[14] = pReadLM[1](Widthcnt);
						mRD[15] = soura_id[0];
						
						mRU[6] = pReadLM[0](Widthcnt+1);
						mRU[3] = pReadLM[5](Widthcnt+1);
						mRU[0] = pReadLM[4](Widthcnt+1);
						mRD[10] = pReadLM[3](Widthcnt+1);
						mRD[0] = pReadLM[2](Widthcnt+1);
						mRD[3] = pReadLM[1](Widthcnt+1);
						mRD[6] = soura_id[1];	/* =Widthcnt+1 */
						
						mRU[7] = pReadLM[0](Widthcnt+2);
						mRU[4] = pReadLM[5](Widthcnt+2);
						mRU[1] = pReadLM[4](Widthcnt+2);
						mRD[11] = pReadLM[3](Widthcnt+2);
						mRD[1] = pReadLM[2](Widthcnt+2);
						mRD[4] = pReadLM[1](Widthcnt+2);
						mRD[7] = soura_id[2];
						
						mRU[8] = pReadLM[0](Widthcnt+3);
						mRU[5] = pReadLM[5](Widthcnt+3);
						mRU[2] = pReadLM[4](Widthcnt+3);
						mRD[12] = pReadLM[3](Widthcnt+3);
						mRD[2] = pReadLM[2](Widthcnt+3);
						mRD[5] = pReadLM[1](Widthcnt+3);
						mRD[8] = soura_id[3];
						
						if(edge==3)	result[Widthcnt] = 0;
						else	result[Widthcnt] = pReadLM[3](Widthcnt) * scale;
						break;
//					} else if(Widthcnt == 1){
					case 1:
						mLU[6] = mRU[15];	mRU[15] = mRU[6];
						mRU[6] = mRU[7];	mRU[7] = mRU[8];
						mRU[8] = pReadLM[0](Widthcnt+3);
						
						mLU[3] = mRU[14];	mRU[14] = mRU[3];
						mRU[3] = mRU[4];	mRU[4] = mRU[5];
						mRU[5] = pReadLM[5](Widthcnt+3);
						
						mLU[0] = mRU[13];	mRU[13] = mRU[0];
						mRU[0] = mRU[1];	mRU[1] = mRU[2];
						mRU[2] = pReadLM[4](Widthcnt+3);
						
						mLD[10] = mRD[9];	mRD[9] = mRD[10];
						mRD[10] = mRD[11];	mRD[11] = mRD[12];
						mRD[12] = pReadLM[3](Widthcnt+3);
						
						mLD[0] = mRD[13];	mRD[13] = mRD[0];
						mRD[0] = mRD[1];	mRD[1] = mRD[2];
						mRD[2] = pReadLM[2](Widthcnt+3);
						
						mLD[3] = mRD[14];	mRD[14] = mRD[3];
						mRD[3] = mRD[4];	mRD[4] = mRD[5];
						mRD[5] = pReadLM[1](Widthcnt+3);
						
						mLD[6] = mRD[15];	mRD[15] = mRD[6];
						mRD[6] = mRD[7];	mRD[7] = mRD[8];
						mRD[8] = soura_id[Widthcnt+3];
						
						if(edge==3)	result[Widthcnt] = 0;
						else	result[Widthcnt] = pReadLM[3](Widthcnt) * scale;
						break;
						
					case 2:
						mLU[7] = mLU[6];	mLU[6] = mRU[15];	mRU[15] = mRU[6];
						mRU[6] = mRU[7];	mRU[7] = mRU[8];
						mRU[8] = pReadLM[0](Widthcnt+3);
						
						mLU[4] = mLU[3];	mLU[3] = mRU[14];	mRU[14] = mRU[3];
						mRU[3] = mRU[4];	mRU[4] = mRU[5];
						mRU[5] = pReadLM[5](Widthcnt+3);
						
						mLU[1] = mLU[0];	mLU[0] = mRU[13];	mRU[13] = mRU[0];
						mRU[0] = mRU[1];	mRU[1] = mRU[2];
						mRU[2] = pReadLM[4](Widthcnt+3);
						
						mLD[11] = mLD[10];	mLD[10] = mRD[9];	mRD[9] = mRD[10];
						mRD[10] = mRD[11];	mRD[11] = mRD[12];
						mRD[12] = pReadLM[3](Widthcnt+3);
						
						mLD[1] = mLD[0];	mLD[0] = mRD[13];	mRD[13] = mRD[0];
						mRD[0] = mRD[1];	mRD[1] = mRD[2];
						mRD[2] = pReadLM[2](Widthcnt+3);
						
						mLD[4] = mLD[3];	mLD[3] = mRD[14];	mRD[14] = mRD[3];
						mRD[3] = mRD[4];	mRD[4] = mRD[5];
						mRD[5] = pReadLM[1](Widthcnt+3);
						
						mLD[7] = mLD[6];	mLD[6] = mRD[15];	mRD[15] = mRD[6];
						mRD[6] = mRD[7];	mRD[7] = mRD[8];
						mRD[8] = soura_id[Widthcnt+3];

						if(edge==3)	result[Widthcnt] = 0;
						else	result[Widthcnt] = pReadLM[3](Widthcnt) * scale;
						break;
						
					default:
//					} else if(Widthcnt == xlng-1){
					/* only make edge process at the right side */
						if(Widthcnt>=xlng-3){
							if(edge==3)	result[Widthcnt] = 0;
							else	result[Widthcnt] = pReadLM[3](Widthcnt) * scale;
							break;
						}
//					} else {
						/* center area */
						mLU[8] = mLU[7];	mLU[7] = mLU[6];
						mLU[6] = mRU[15];	mRU[15] = mRU[6];
						mRU[6] = mRU[7];	mRU[7] = mRU[8];
						mRU[8] = pReadLM[0](Widthcnt+3);
						
						mLU[5] = mLU[4];	mLU[4] = mLU[3];
						mLU[3] = mRU[14];	mRU[14] = mRU[3];
						mRU[3] = mRU[4];	mRU[4] = mRU[5];
						mRU[5] = pReadLM[5](Widthcnt+3);
						
						mLU[2] = mLU[1];	mLU[1] = mLU[0];
						mLU[0] = mRU[13];	mRU[13] = mRU[0];
						mRU[0] = mRU[1];	mRU[1] = mRU[2];
						mRU[2] = pReadLM[4](Widthcnt+3);
						
						mLD[12] = mLD[11];	mLD[11] = mLD[10];
						mLD[10] = mRD[9];	mRD[9] = mRD[10];
						mRD[10] = mRD[11];	mRD[11] = mRD[12];
						mRD[12] = pReadLM[3](Widthcnt+3);
						
						mLD[2] = mLD[1];	mLD[1] = mLD[0];
						mLD[0] = mRD[13];	mRD[13] = mRD[0];
						mRD[0] = mRD[1];	mRD[1] = mRD[2];
						mRD[2] = pReadLM[2](Widthcnt+3);
						
						mLD[5] = mLD[4];	mLD[4] = mLD[3];
						mLD[3] = mRD[14];	mRD[14] = mRD[3];
						mRD[3] = mRD[4];	mRD[4] = mRD[5];
						mRD[5] = pReadLM[1](Widthcnt+3);
						
						mLD[8] = mLD[7];	mLD[7] = mLD[6];
						mLD[6] = mRD[15];	mRD[15] = mRD[6];
						mRD[6] = mRD[7];	mRD[7] = mRD[8];
						mRD[8] = soura_id[Widthcnt+3];
						
//						result[Widthcnt] = IMG_ConvEx(mLU,mRU,mLD,mRD, weight);
						result[Widthcnt] = IMG_ConvEx(mLU,mRU,mLD,mRD, weight, fp_calc, Heightcnt, Widthcnt);
						break;
					}
				}
				Widthcnt++;

			}
			if(Heightcnt > 2){
#ifdef DEBUG_OUTPUT
		DebugOutputGamen(result,0,xlng);
#endif
				Write1LineDst(Heightcnt-3, result);
			}
			if(Heightcnt < ylng)	pWriteLM[0](0, soura_id,xlng);

			pWriteLM[6] = pWriteLM[0];
			pWriteLM[0] = pWriteLM[5];
			pWriteLM[5] = pWriteLM[4];
			pWriteLM[4] = pWriteLM[3];
			pWriteLM[3] = pWriteLM[2];
			pWriteLM[2] = pWriteLM[1];
			pWriteLM[1] = pWriteLM[6];
			pReadLM[6] = pReadLM[0];
			pReadLM[0] = pReadLM[5];
			pReadLM[5] = pReadLM[4];
			pReadLM[4] = pReadLM[3];
			pReadLM[3] = pReadLM[2];
			pReadLM[2] = pReadLM[1];
			pReadLM[1] = pReadLM[6];

			Heightcnt++;
		}
#if USE_PIPE_FUNC
    }
#endif 
//	1x16 kernel (?)
//	}else if(kernel==1){
//	}

	return 0;
}
/******************************************************************************/
/* IMG_ConvEx                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/30                                                      */
/* 01-02-00 : 2007/06/21   S.Ishikawa                                         */
/*                         short w[] -> long w[]                              */
/* 01-02-00 : 2007/07/20 S.Ishikawa                                           */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/* 01-03-01 : 2007/08/01 S.Ishikawa                                           */
/*                       debug-fileoutput                                     */
/* 01-04-00 : 2007/08/08 S.Ishikawa                                           */
/*                       xxenable -> w0 to w8 only                            */
/******************************************************************************/
//int64 IMG_ConvEx(short mLU[], short mRU[], short mLD[], short mRD[], int64 w[])
static int64 IMG_ConvEx(short mLU[], short mRU[], short mLD[], short mRD[], int64 w[], FILE *fp, long Heightcnt, long Widthcnt)
{
	int i;
	int64 temp;

    if(CONVOLUTION_DEBUG){
        fprintf(fp, "--(%4ld, %4ld)--\n", Widthcnt, Heightcnt);
        fprintf(fp, "%02x %02x %02x %02x %02x %02x %02x\n", mLU[8], mLU[7], mLU[6], mRU[15], mRU[6], mRU[7], mRU[8]);
        fprintf(fp, "%02x %02x %02x %02x %02x %02x %02x\n", mLU[5], mLU[4], mLU[3], mRU[14], mRU[3], mRU[4], mRU[5]);
        fprintf(fp, "%02x %02x %02x %02x %02x %02x %02x\n", mLU[2], mLU[1], mLU[0], mRU[13], mRU[0], mRU[1], mRU[2]);
        fprintf(fp, "%02x %02x %02x %02x %02x %02x %02x\n", mLD[12], mLD[11], mLD[10], mRD[9], mRD[10], mRD[11], mRD[12]);
        fprintf(fp, "%02x %02x %02x %02x %02x %02x %02x\n", mLD[2], mLD[1], mLD[0], mRD[13], mRD[0], mRD[1], mRD[2]);
        fprintf(fp, "%02x %02x %02x %02x %02x %02x %02x\n", mLD[5], mLD[4], mLD[3], mRD[14], mRD[3], mRD[4], mRD[5]);
        fprintf(fp, "%02x %02x %02x %02x %02x %02x %02x\n", mLD[8], mLD[7], mLD[6], mRD[15], mRD[6], mRD[7], mRD[8]);
    }

	temp = 0;
	/* Upper left */
	if(LUenable!=0){
		for(i=0;i<9;i++){
			if((v_mode==1 && h_mode==1) || (v_mode==0 && h_mode==0))	temp += w[i] * (int64)mLU[i];
			else	temp -= w[i] * (int64)mLU[i];
		}
	}
	
	/* Upper right */
	if(RUenable!=0){
		for(i=0;i<9;i++){	/* 0�`8 */
			if(v_mode==0)	temp += w[i] * (int64)mRU[i];
			else	temp -= w[i] * (int64)mRU[i];
		}
    }
	for(i=13;i<16;i++){	/* 13,14,15 */
		if(v_mode==0)	temp += w[i] * (int64)mRU[i];
		else	temp -= w[i] * (int64)mRU[i];
	}
	
	/* Lower left */
	if(LDenable!=0){
		for(i=0;i<9;i++){	/* 0�`8 */
			if(h_mode==0)	temp+= w[i] * (int64)mLD[i];
			else	temp -= w[i] * (int64)mLD[i];
		}
	}
	for(i=10;i<13;i++){	/* 10�`12 */
		if(h_mode==0)	temp+= w[i] * (int64)mLD[i];
		else	temp -= w[i] * (int64)mLD[i];
	}
	
	/* Lower right */
	if(RDenable!=0){
		for(i=0;i<9;i++){	/* 0�`8 */
			temp += w[i] * (int64)mRD[i];
		}
	}
	for(i=9;i<CELL;i++){	/* 9�`15 */
		temp += w[i] * (int64)mRD[i];
	}

    if(CONVOLUTION_DEBUG){
	    fprintf(fp, "outd = %016lx (%6ld)\n", temp, temp);
    }

	return temp;
}

