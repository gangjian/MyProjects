/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_memaccess.c                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif
#include "impsim_int.h"
#include "legacy_sim.h"
#include "legacy_micro_op.h"

#define  RASTER_SCAN_MODE 0
#define  AFIN_SCAN_MODE   1
#define  BINARY_PACK_MODE 2

// unsupport  check
#define  AP_UNSUPPORT_CHECK 1 /* AP unsupport check  0:off, 1:on */
#define  AP_UNSUPPORT_CHECK_ASSERT_ERROR 0
#define  POST_UNSUPPORT_CHECK            1  /* POST unsupport check  0:off, 1:on */

#define  RESULT_UNUSED        1   /* bit:0   0:off, 1:on */
#define  RESULT_USED_DEBUG    2   /* bit:1   0:off, 1:on */
#define  RESULT_USED_REG      4   /* bit:2   0:off, 1:on */

static void GetAPDly(int *xdly, int *ydly);
static void GetMaskDly(int *x, int *y);
static int CheckRegisterOfAP();
static int CheckRegisterOfPOST();
static void IPtoAPwithLW(void);
static void CnvDataUctoUl(unsigned char Tbl[], unsigned long *data);
static void CnvDataUltoUc(unsigned long data, unsigned char Tbl[]);

unsigned char *pLM256[LM_NUM];


/******************************************************************************/
/* ReadLM256A                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
short ReadLM256A(int line, int adr) {
	
	int linework, linebottom, linetop, srca_ind_om, soura_dt;
	short ret;
	unsigned char work[2];
	unsigned char line_shift = 0;
	
	linework = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_A];
	linetop = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_TOP] << 3;       // 3bits shift is required by HW spec.
	linebottom = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_BOTTOM] << 3; // 3bits shift is required by HW spec.
	srca_ind_om = (IPFORM_BACKUP >>16 ) & 0x0007;
	soura_dt = (IMPREG_IPFUN_READ() >> 22) & 0x0003;
	
	if (line) {
		if ((IMPREG_LMCTL_READ() & 0x0007) == 1){ /* lmw = 128 */
			switch (srca_ind_om) {
			case 0:					/* srca_ind_om = 8bpp */
				line_shift = 3; break;
			case 1:					/* srca_ind_om = 1bpp */
				line_shift = 0; break;
			case 2:					/* srca_ind_om = 16bpp */
				line_shift = 4; break;
			case 4:					/* srca_ind_om = 8bpp x 2 */
				line_shift = 4; break;
			default:
				SIMLOG(SL_LS, SL_ERR, "ERROR, in ReadLM256A   line = %d\n",line);
				Legacy_assert_error();
			}
		} else if((IMPREG_LMCTL_READ() & 0x0007) == 2){ /* lmw = 256 */
			switch (srca_ind_om) {
			case 0:					/* srca_ind_om = 8bpp */
				line_shift = 2; break;
			case 1:					/* srca_ind_om = 1bpp */
				line_shift = 1; break;
			case 2:					/* srca_ind_om = 16bpp */
				line_shift = 5; break;
			case 4:					/* srca_ind_om = 8bpp x 2 */
				line_shift = 2; break;
			default:
				SIMLOG(SL_LS, SL_ERR, "ERROR, in ReadLM256A   line = %d\n",line);
				Legacy_assert_error();
			}
		} else if((IMPREG_LMCTL_READ() & 0x0007) == 4){ /* lmw = 512 */
			switch (srca_ind_om) {
			case 0:					/* srca_ind_om = 8bpp */
				line_shift = 5; break;
			case 1:					/* srca_ind_om = 1bpp */
				line_shift = 2; break;
			case 2:					/* srca_ind_om = 16bpp */
				line_shift = 6; break;
			case 4:					/* srca_ind_om = 8bpp x 2 */
				line_shift = 5; break;
			default:
				SIMLOG(SL_LS, SL_ERR, "ERROR, in ReadLM256A   line = %d\n",line);
				Legacy_assert_error();
			}
		} else {
			SIMLOG(SL_LS, SL_ERR, "ERROR, in ReadLM256A   line = %d\n",line);
			Legacy_assert_error();
		}
		
		line = line << line_shift;
		
		linework = linework - line;
		if (linework < linetop) {
			linework = linebottom - (linetop - linework - (1<<line_shift));
		}
	}
	
	work[0] = *(pLM256[linework]+adr*2  );
	work[1] = *(pLM256[linework]+adr*2+1);
	
	if(ENDIAN){ /* little */
		ret = (short)((work[1]<<8)|(work[0]));
	}else{ /* big */
		ret = (short)((work[0]<<8)|(work[1]));
	}
	
	// if 8bpp signed, write 0xFF on bit8-15.
	if (((srca_ind_om == 0) || (srca_ind_om == 4)) && (soura_dt == 0)) {
		if (ret & 0x0080) {
			ret |= 0xFF00;
		} else {
			ret &= 0x00FF;
		}
	}
	
	return(ret);
}


/******************************************************************************/
/* ReadLM256B                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
short ReadLM256B(int adr) {
	
	int srcb_ind_om, sourb_dt;
	unsigned char work[2];
	short ret;
	
	srcb_ind_om = (IPFORM_BACKUP >> 20) & 0x0007;
	sourb_dt = (IMPREG_IPFUN_READ() >> 20) & 0x0003;
	
	work[0] = *(pLM256[MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B]]+adr*2  );
	work[1] = *(pLM256[MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B]]+adr*2+1);
	
	if(ENDIAN){ /* little */
		ret = (short)((work[1]<<8)|(work[0]));
	}else{ /* big */
		ret = (short)((work[0]<<8)|(work[1]));
	}
	
	// if 8bpp signed, write 0xFF on bit8-15.
	if (((srcb_ind_om == 0) || (srcb_ind_om == 4)) && (sourb_dt == 0)) {
		if (ret & 0x0080) {
			ret |= 0xFF00;
		} else {
			ret &= 0x00FF;
		}
	}
	
	return(ret);
}

/******************************************************************************/
/* Read1LineLM256A                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/15   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
void Read1LineLM256A(int Height, short *data){
    long xlng, sa_lmsp;
    int i;
    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    sa_lmsp = ((IMPREG_LMCTL_READ()>>4) & 0x01ff);

    for(i=sa_lmsp;i<xlng+sa_lmsp;i++){
        data[i] = ReadLM256A(Height, i);
    }
    return;
}

/******************************************************************************/
/* Read1LineLM256B                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/15   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
void Read1LineLM256B(short *data){
    long xlng, sb_lmsp;
    int i;
	unsigned long fun, fun2;

/* IPFUN fun bit check */
	fun = (((IMPREG_IPFUN_READ())>>28) & 0x0f);
	fun2 = ((IMPREG_IPFUN2_READ() >> 28) & 0x000f);
	
	if((fun == 0xf) && (fun2==0x04)){
		xlng = FFT_LM_SIZE; // for differ from size of twiddle factor and data
	} else {
    	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	}
	sb_lmsp = ((IMPREG_LMCTL_READ()>>16) & 0x01ff);

    for(i=sb_lmsp;i<xlng+sb_lmsp;i++){
        data[i] = ReadLM256B(i);
    }
    return;
}

/******************************************************************************/
/* ReadLM0                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
short ReadLM0(int adr){
    unsigned char work[2];
    short ret;
    
    work[0] = *(pucLM0+adr*2  );
    work[1] = *(pucLM0+adr*2+1);

    if(ENDIAN){ /* little */
        ret = (short)((work[1]<<8)|(work[0]));
    }else{ /* big */
        ret = (short)((work[0]<<8)|(work[1]));
    }

    return(ret);
}

/******************************************************************************/
/* ReadLM1                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
short ReadLM1(int adr){
    unsigned char work[2];
    short ret;
    
    work[0] = *(pucLM1+adr*2  );
    work[1] = *(pucLM1+adr*2+1);

    if(ENDIAN){ /* little */
        ret = (short)((work[1]<<8)|(work[0]));
    }else{ /* big */
        ret = (short)((work[0]<<8)|(work[1]));
    }

    return(ret);
}

/******************************************************************************/
/* ReadLM2                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
short ReadLM2(int adr){
    unsigned char work[2];
    short ret;
    
    work[0] = *(pucLM2+adr*2  );
    work[1] = *(pucLM2+adr*2+1);

    if(ENDIAN){ /* little */
        ret = (short)((work[1]<<8)|(work[0]));
    }else{ /* big */
        ret = (short)((work[0]<<8)|(work[1]));
    }

    return(ret);
}


/******************************************************************************/
/* ReadLM3                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
short ReadLM3(int adr){
	unsigned char work[2];
	short ret;
	
	work[0] = *(pucLM3 + adr * 2);
	work[1] = *(pucLM3 + adr * 2 + 1);
	if(ENDIAN)	ret = (short)((work[1]<<8) | (work[0]));	/* little */
	else	ret = (short)((work[0]<<8) | (work[1]));	/* big */
	
	return ret;
}


/******************************************************************************/
/* ReadLM4                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
short ReadLM4(int adr){
	unsigned char work[2];
	short ret;
	
	work[0] = *(pucLM4 + adr * 2);
	work[1] = *(pucLM4 + adr * 2 + 1);
	if(ENDIAN)	ret = (short)((work[1]<<8) | (work[0]));	/* little */
	else	ret = (short)((work[0]<<8) | (work[1]));	/* big */
	
	return ret;
}


/******************************************************************************/
/* ReadLM5                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
short ReadLM5(int adr){
	unsigned char work[2];
	short ret;
	
	work[0] = *(pucLM5 + adr * 2);
	work[1] = *(pucLM5 + adr * 2 + 1);
	if(ENDIAN)	ret = (short)((work[1]<<8) | (work[0]));	/* little */
	else	ret = (short)((work[0]<<8) | (work[1]));	/* big */
	
	return ret;
}


/******************************************************************************/
/* WriteLM0                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
void WriteLM0(int adr, short *data, int size){
    int i;

    for(i=0;i<size;i++){
        if(ENDIAN){ /* little */
            *(pucLM0+(adr+i)*2  ) = (unsigned char)((*(data+i)   ) & 0xff);
            *(pucLM0+(adr+i)*2+1) = (unsigned char)((*(data+i)>>8) & 0xff);
        }else{ /* big */
            *(pucLM0+(adr+i)*2  ) = (unsigned char)((*(data+i)>>8) & 0xff);
            *(pucLM0+(adr+i)*2+1) = (unsigned char)((*(data+i)   ) & 0xff);
        }
    }

    return;
}


/******************************************************************************/
/* WriteLM1                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
void WriteLM1(int adr, short *data, int size){
    int i;

    for(i=0;i<size;i++){
        if(ENDIAN){ /* little */
            *(pucLM1+(adr+i)*2  ) = (unsigned char)((*(data+i)   ) & 0xff);
            *(pucLM1+(adr+i)*2+1) = (unsigned char)((*(data+i)>>8) & 0xff);
        }else{ /* big */
            *(pucLM1+(adr+i)*2  ) = (unsigned char)((*(data+i)>>8) & 0xff);
            *(pucLM1+(adr+i)*2+1) = (unsigned char)((*(data+i)   ) & 0xff);
        }
    }

    return;
}


/******************************************************************************/
/* WriteLM2                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
void WriteLM2(int adr, short *data, int size){
    int i;

    for(i=0;i<size;i++){
        if(ENDIAN){ /* little */
            *(pucLM2+(adr+i)*2  ) = (unsigned char)((*(data+i)   ) & 0xff);
            *(pucLM2+(adr+i)*2+1) = (unsigned char)((*(data+i)>>8) & 0xff);
        }else{ /* big */
            *(pucLM2+(adr+i)*2  ) = (unsigned char)((*(data+i)>>8) & 0xff);
            *(pucLM2+(adr+i)*2+1) = (unsigned char)((*(data+i)   ) & 0xff);
        }
    }

    return;
}


/******************************************************************************/
/* WriteLM3                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
void WriteLM3(int adr, short *data, int size){
	int i;
	for(i=0;i<size;i++){
		if(ENDIAN){
			*(pucLM3+(adr+i) * 2) = (unsigned char)((*(data + i)) & 0xff);
			*(pucLM3+(adr+i) * 2 + 1) = (unsigned char)((*(data +i)>>8) & 0xff);
		}else{
			*(pucLM3+(adr+i) * 2) = (unsigned char)((*(data+i)>>8) & 0xff);
			*(pucLM3+(adr+i) * 2 + 1) = (unsigned char)((*(data+i)) & 0xff);
		}
	}
	return;
}


/******************************************************************************/
/* WriteLM4                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
void WriteLM4(int adr, short *data, int size){
	int i;
	for(i=0;i<size;i++){
		if(ENDIAN){
			*(pucLM4+(adr+i) * 2) = (unsigned char)((*(data + i)) & 0xff);
			*(pucLM4+(adr+i) * 2 + 1) = (unsigned char)((*(data +i)>>8) & 0xff);
		}else{
			*(pucLM4+(adr+i) * 2) = (unsigned char)((*(data+i)>>8) & 0xff);
			*(pucLM4+(adr+i) * 2 + 1) = (unsigned char)((*(data+i)) & 0xff);
		}
	}
	return;
}


/******************************************************************************/
/* WriteLM5                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         should be removed                                  */
/******************************************************************************/
void WriteLM5(int adr, short *data, int size){
	int i;
	for(i=0;i<size;i++){
		if(ENDIAN){
			*(pucLM5+(adr+i) * 2) = (unsigned char)((*(data + i)) & 0xff);
			*(pucLM5+(adr+i) * 2 + 1) = (unsigned char)((*(data +i)>>8) & 0xff);
		}else{
			*(pucLM5+(adr+i) * 2) = (unsigned char)((*(data+i)>>8) & 0xff);
			*(pucLM5+(adr+i) * 2 + 1) = (unsigned char)((*(data+i)) & 0xff);
		}
	}
	return;
}



/******************************************************************************/
/* WriteLM256                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteLM256(int lmno, int adr, short *data, int size) {
	
    int i;

    for(i=0;i<size;i++){
        if(ENDIAN){ /* little */
            *(pLM256[lmno]+(adr+i)*2  ) = (unsigned char)((*(data+i)   ) & 0xff);
            *(pLM256[lmno]+(adr+i)*2+1) = (unsigned char)((*(data+i)>>8) & 0xff);
        }else{ /* big */
            *(pLM256[lmno]+(adr+i)*2  ) = (unsigned char)((*(data+i)>>8) & 0xff);
            *(pLM256[lmno]+(adr+i)*2+1) = (unsigned char)((*(data+i)   ) & 0xff);
        }
    }

    return;
}


/******************************************************************************/
/* Read1LineSrc0                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/11/17 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Read1LineSrc0(int Height, short *data){
	unsigned long xlng, ylng;
	unsigned int i, j, xpixel, pfsrca;
	int datatype, pmask, pcma, pcmb, pinv, HeightWork, fun, fun2, mdlab, datatypesb, apsize_sa, soura_dt, newfunc;
	int sy_mag_ctl, sy_mag, sx_mag_ctl, sx_mag, scan_mode, scancnt_sa, scancnt_sb;
	short workImg[LINE_SIZE], ReadDataWork[LINE_SIZE], SignBit[LINE_SIZE];
	int scale_pre, cmaddr_a_high, scale_msk_a;
	unsigned int srcb_pre_em, acscnt_sb, pfsrcb, srcb_datatype;
	unsigned char *read_p08;
	unsigned short *read_p16, read_data, *write_work, *write_data;
	unsigned long *read_p32;
	
#ifndef IMPSIM_INTEGRATED
//	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
	SIMLOG(SL_LS, SL_L5, "***** %s",__FUNCTION__);
	SIMLOG(SL_LS, SL_L5, "    Heigh = %d,  data_adder = 0x%08x\n",Height, data);
#endif

	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

	fun = ((IMPREG_IPFUN_READ() >> 28) & 0x000f);
	fun2 = ((IMPREG_IPFUN2_READ() >> 28) & 0x000f);
	soura_dt = ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
	datatype = ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
	datatypesb = ((IMPREG_IPFUN_READ() >> 20) & 0x0003);
	pfsrca = ((IMPREG_APCFG_READ()>>8) & 0x0007);  /* src0 */
	pfsrcb = ((IMPREG_APCFG_READ()>>12) & 0x0007);  /* src1 */
	newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
	scan_mode = ((IMPREG_APCMD_READ() >> 24) & 0x0003);

	xpixel = xlng;

	// Check Format
	if(soura_dt == 0){
		datatype = PXLS8BPP;
	} else if(soura_dt == 1){
		datatype = PXLU8BPP;
	} else if(soura_dt == 2){
		datatype = PXL2CHI;
	} else if(soura_dt == 3){
		datatype = PXLCOLDIFF;
	}

	srcb_datatype = PXL8BPP;
	if(newfunc == 1)
	{
		if(pfsrca == 2){
		    datatype = PXL16BPP;
		}
		else if (pfsrca == 0)
		{
			datatype = PXL1BPP;
		}
		else if (pfsrca == 1)
		{
			if (soura_dt == 0)
			{
				datatype = PXLS8BPP;
			}
			else if(soura_dt == 1)
			{
				datatype = PXLU8BPP;
			}
		}
		if (pfsrcb == 1) {
			srcb_datatype = PXL8BPP;
		} else if (pfsrcb == 2) {
		    srcb_datatype = PXL16BPP;
		}
	}
	else
	{
		if(scan_mode == 1)
		{
			datatype = PXL1BPP;
			srcb_datatype = PXL1BPP;
		}
		else if(scan_mode == 0)
		{
		}
		else
		{
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid scan_mode:%d \n", scan_mode);
			Legacy_assert_error();
		}
	}

	srcb_pre_em = ((IMPREG_IPFORM_READ() >> 4) & 0x0007);
	if((srcb_pre_em != 0) && (srcb_pre_em != 1)){
	    datatypesb = srcb_pre_em;
	}
	
	scale_msk_a = ((IMPREG_IPFUN2_READ() >> 3) & 0x0001);
	if (scale_msk_a) {
		scale_pre = 0;
	} else {
		scale_pre = ((IMPREG_IPFUN2_READ() >> 8) & 0x000F);
	}
	
	cmaddr_a_high = (IMPREG_CMCTL_READ() & 0x0007);

	pmask = ((IMPREG_IPFUN_READ() >> 15) & 0x0001);
	pcma = ((IMPREG_IPFUN_READ() >> 14) & 0x0001);
	pcmb = ((IMPREG_IPFUN_READ() >> 13) & 0x0001);
	pinv = ((IMPREG_IPFUN_READ() >> 12) & 0x0001);
	mdlab = (((IMPREG_IPFUN_READ())>>7) & 0x0001); /* 0:Normal,1:rcvFLT help(fun 0001 only) */

#ifdef IMP_X4_V2H
	sy_mag_ctl = ((IMPREG_APMAG_READ() >> 31) & 0x0001);
	sy_mag = ((IMPREG_APMAG_READ() >> 24) & 0x007F);
	sx_mag_ctl = ((IMPREG_APMAG_READ() >> 23) & 0x0001);
	sx_mag = ((IMPREG_APMAG_READ() >> 16) & 0x007F);
#else
	sy_mag_ctl = ((IMPREG_APMAG_READ() >> 28) & 0x0001);
	sy_mag = ((IMPREG_APMAG_READ() >> 24) & 0x000F);
	sx_mag_ctl = ((IMPREG_APMAG_READ() >> 20) & 0x0001);
	sx_mag = ((IMPREG_APMAG_READ() >> 16) & 0x000F);
#endif

	scancnt_sa = ((IMPREG_APCMD_READ() >> 23) & 0x0001);
	scancnt_sb = ((IMPREG_APCMD_READ() >> 22) & 0x0001);
	acscnt_sb =  ((IMPREG_APCMD_READ() >> 18) & 0x0001);

	apsize_sa = ((IMPREG_APSIZE_SA_READ()) & 0xffff0000);
	if ((apsize_sa != 0x00000000) && (apsize_sa != 0xFFFF0000)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, invalid apsize_sa:0x%x \n", IMPREG_APSIZE_SA_READ());
		Legacy_assert_error();
	}
	apsize_sa = IMPREG_APSIZE_SA_READ();
	if (apsize_sa < 0) {
		apsize_sa = apsize_sa * (-1);
	}

	if ((scancnt_sa==1)&&(scan_mode==1)){  /* 2ti UnPack */
		SIMLOG(SL_LS, SL_L4, " It does not support for 2ti UnPack Mode in SIM. \n");
		Legacy_assert_error();
	}

	if (sx_mag_ctl == 0) {
		if((sx_mag < 1)||(sx_mag > 8)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sx_mag:0x%x \n", sx_mag);
			Legacy_assert_error();
		}
	} else {
		if((sx_mag < 1)||(sx_mag > 40)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sx_mag:0x%x \n", sx_mag);
			Legacy_assert_error();
		}
	}

	if (sy_mag_ctl == 0) {
		if((sy_mag < 1)||(sy_mag > 8)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sy_mag:0x%x \n", sy_mag);
			Legacy_assert_error();
		}
	} else {
		if((sy_mag < 1)||(sy_mag > 40)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sy_mag:0x%x \n", sy_mag);
			Legacy_assert_error();
		}
	}
	
/* 1Line Read */
/* afin scan sy_mag*/
    HeightWork = Height;
    if((scancnt_sa)&&(scan_mode==0)){ /* afinscan */
        if(sy_mag_ctl){ /* ZoomIn */
            HeightWork = Height/sy_mag;
        }else{ /* ZoomOut */
//            HeightWork = Height*sy_mag;
            apsize_sa = apsize_sa/sy_mag;
        }
    }
	
	if ((0x08 == fun) || (0x09 == fun))
		{/* For IP corr, there is dummy read (out side SRC0), so the xpixel should be set to xlng * sx_mag */
		xpixel = xlng * sx_mag;
	}
	else if(apsize_sa > 0)
	{
		xpixel = (apsize_sa - (IMPREG_APSASP_READ() - SASP) % apsize_sa);
		if (datatype==PXL16BPP) xpixel = xpixel / 2;
	}

	write_work = (unsigned short *) ReadDataWork;
	write_data = (unsigned short *) data;
	if (datatype==PXL16BPP) {
		read_p16 = (unsigned short *)(pSrc0 + IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * HeightWork);
		for (i=0; i < xpixel; i++) {
			read_data = *read_p16++;
			*write_work++ = read_data;
			*write_data++ = read_data;
		}
	}
	else if (datatype==PXL1BPP)
	{
		unsigned short val = 0;
		read_p08 = pSrc0 + IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * HeightWork;
		for (i=0; i < xpixel/8; i++)
		{
			read_data = (unsigned short) *read_p08++;
			for (j=0; j<8; j++)
			{
				val = (read_data & (0x01 << (8 - j - 1)));
				if (0 != val)
				{
					val = 0xff;
				}
				else
				{
					val = 0x0;
				}
				*write_work++ = val;
				*write_data++ = val;
			}
		}
	}
	else
	{
		read_p08 = pSrc0 + IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * HeightWork;
		for (i=0; i < xpixel; i++) {
			read_data = (unsigned short) *read_p08++;
			*write_work++ = read_data;
			*write_data++ = read_data;
		}
	}
	
/* scale_pre */
	if ((scale_pre > 0) && (pcma == 0) && (datatype == PXL16BPP)) {
		for (i=0; i<xlng; i++) {
			/* scaling */
			data[i] = (short)(data[i] >> scale_pre);
		}
	}
	
/* afin scan sx_mag*/
    if((scancnt_sa)&&(scan_mode==0)){ /* afinscan */
        if(sx_mag_ctl){ /* ZoomIn */
            for(i=0;i<xlng;i++) data[i] = ReadDataWork[i/sx_mag];
        }else{ /* ZoomOut */
            for(i=0;i<xlng;i++) data[i] = ReadDataWork[i*sx_mag];
        }
    }


/** for MASK(pmask_en) **/
/* afin scan sy_mag*/
    HeightWork = Height;
    if((scancnt_sb)&&(scan_mode==0)){ /* afinscan */
        if(sy_mag_ctl){ /* ZoomIn */
//            HeightWork = Height/sy_mag;
        }else{ /* ZoomOut */
            HeightWork = Height*sy_mag;
        }
    }


/*==========================================*/
    if(((pmask)&&(pcma==0)&&(pcmb==0))||((fun==1)&&(mdlab==1))){
		write_work = (unsigned short *) ReadDataWork;
		write_data = (unsigned short *) workImg;
		if (srcb_datatype==PXL16BPP) {
			read_p16 = (unsigned short *)(pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * HeightWork);
			if (acscnt_sb == 1) {
				for (i=0; i < xlng; i++) {
					read_data = *read_p16++;
					*write_work++ = read_data;
					*write_data++ = read_data;
				}
			} else {
				for (i=0; i < xlng; i++) {
					*write_work++ = 0;
					*write_data++ = 0;
				}
			}
		} else {
			read_p08 = pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * HeightWork;
			if (acscnt_sb == 1) {
				for (i=0; i < xlng; i++) {
					read_data = (unsigned short) *read_p08++;
					*write_work++ = read_data;
					*write_data++ = read_data;
				}
			} else {
				for (i=0; i < xlng; i++) {
					*write_work++ = 0;
					*write_data++ = 0;
				}
			}
		}
		/* afin scan sx_mag*/
        if((scancnt_sb)&&(scan_mode==0)){ /* afinscan */
            if(sx_mag_ctl){ /* ZoomIn */
                for(i=0;i<xlng;i++) workImg[i] = ReadDataWork[i/sx_mag];
            }else{ /* ZoomOut */
                for(i=0;i<xlng;i++) workImg[i] = ReadDataWork[i*sx_mag];
            }
        }
    }
/************************/
/* rcvFLT help */
    if((fun==1)&&(mdlab==1)){
        for(i=0;i<xlng;i++){
            if( (datatype==0) && ((data[i])&0x80))  data[i] = (short)((data[i]) | 0xff00);
            if( (datatypesb==0) && ((workImg[i])&0x80))  workImg[i] = (short)((workImg[i]) | 0xff00);
            data[i] = (short)(data[i] - workImg[i]);
            SignBit[i] = (short)((data[i]<0) ? 1:0);
            data[i] = (short)(data[i] & 0x01ff);
        }
    }

/* pmask */
    if((pmask)&&(pcma==0)&&(pcmb==0)){
        for(i=0;i<xlng;i++){
            if (datatype==PXL16BPP) {
                data[i] = (short)((data[i]) & (workImg[i]<<8 | workImg[i]));
            } else {
                data[i] = (short)((data[i]) & workImg[i]);
            }
        }
    }
/* pcma */
    if(pcma){
        for(i=0;i<xlng;i++){
            /* scaling */
            data[i] = (short)((data[i]>>scale_pre) & 0x3ff);

            if (datatype==PXL16BPP) {
                data[i] = (unsigned short)((data[i] & 0x3ff) | (cmaddr_a_high & 0x006)<<9 );
            } else if (datatype==PXLS8BPP) {
                data[i] =(((unsigned char)(data[i] & 0x0ff)) | ((cmaddr_a_high & 0x007)<<9));
            } else {/* unsigned 8bpp */
                data[i] = (unsigned short)((data[i] & 0x0ff) | ((cmaddr_a_high & 0x007)<<9));
            }

            if (fun != 5) { /* exclude yuv color arithmetic */
        	data[i] = *(pCM0[IMP_WORK_CH]+4*(data[i] & 0xfff)); /* CM memory is accessed by 4 bytes */
            }
            //if ((datatype==PXLS8BPP)||(datatype==PXL16BPP))
            //{/* For signed 8 bpp or signed 16 bpp, should extend sign bit if value < 0 */
            if (datatype==PXLS8BPP)
            {/* For signed 8 bpp, should extend sign bit if value < 0 */
            	if(data[i] & 0x80)
            	{
            		data[i] = 0xff00 | data[i];
            	}
            }
        }
    }
/* pinv */
    if(pinv){
        for(i=0;i<xlng;i++){
            if (datatype==PXL16BPP) {
                data[i] = (short)(~(data[i]) & 0xffff);
            } else {
                data[i] = (short)(~(data[i]) & 0x00ff);
            }
        }
    }

    if((fun==1)&&(mdlab==1)){ /* rcvFLT */
        for(i=0;i<xlng;i++){
            if (SignBit[i]) data[i] = (short)((data[i]) | 0xff00);
        }
    }else{ /* Normal */
        if (datatype==PXLS8BPP) {
            for(i=0;i<xlng;i++){
                if((data[i])&0x80)  data[i] = (short)((data[i]) | 0xff00);
            }
    	} else if ((datatype==PXL1BPP) || (datatype==PXL2CHI)) {
            for(i=0;i<xlng;i++){
                if( fun==1 || fun==3 || fun==6 || ((fun == 0x0f) && (fun2 == 0x02)) || ((fun == 0x0f) && (fun2 == 0x03))){ /* Arithmetic process OR Convolution OR Ex. Convolution OR PIS */
                    if((data[i])&0x80) data[i] = 1;
                    else data[i] = 0;
                }else{
                    if((data[i])&0x80) data[i] = (short)((data[i]) | 0xff00);
                }
            }
        } else if (datatype==PXLCOLDIFF) {
            for(i=0;i<xlng;i++){
                data[i] -= 128;
            }
        }
    }
	
    return;
}
/******************************************************************************/
/* Read1LineSrc1                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/11/17 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Read1LineSrc1(int Height, short *data){
	unsigned long xlng, ylng;
	unsigned int i, xpixel, pfsrcb;
	int  datatype, pcmb, pinv, sy_mag_ctl, sy_mag, sx_mag_ctl, sx_mag, scan_mode, scancnt_sb, HeightWork, fun, apsize_sb, sourb_dt, newfunc;
	short ReadDataWork[LINE_SIZE];
	int scale_pre, cmaddr_b_high, scale_msk_b, acscnt_sb;
	unsigned short temp_usa, temp_usb;
	unsigned char *read_p08;
	unsigned short *read_p16, read_data, *write_work, *write_data;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif

	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

	fun = ((IMPREG_IPFUN_READ() >> 28) & 0x000f);
	sourb_dt = ((IMPREG_IPFUN_READ() >> 20) & 0x0003);
	pfsrcb = ((IMPREG_APCFG_READ()>>12) & 0x0007);  /* src1 */
	newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
	scan_mode = ((IMPREG_APCMD_READ() >> 24) & 0x0003);

	xpixel = xlng;
	
	// Check Format
	if (sourb_dt == 0) {
		datatype = PXLS8BPP;
	} else if (sourb_dt == 1) {
		datatype = PXLU8BPP;
	} else if (sourb_dt == 2) {
		datatype = PXL1BPP;
	} else if (sourb_dt == 3) {
		datatype = PXLCOLDIFF;
	}
	if(newfunc == 1)
	{
		if (pfsrcb == 2) {
			datatype = PXL16BPP;
		}
	}
	else
	{
		if(scan_mode == 1)
		{
			datatype = PXL1BPP;
		}
		else if(scan_mode == 0)
		{
		}
		else
		{
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid scan_mode:%d \n", scan_mode);
			Legacy_assert_error();
		}
	}

	scale_msk_b = ((IMPREG_IPFUN2_READ() >> 2) & 0x0001);
	if (scale_msk_b) {
		scale_pre = 0;
	} else {
		scale_pre = ((IMPREG_IPFUN2_READ() >> 8) & 0x000F);
	}
	cmaddr_b_high = ((IMPREG_CMCTL_READ() >> 8) & 0x0003);

	pcmb = ((IMPREG_IPFUN_READ() >> 13) & 0x0001);
	pinv = ((IMPREG_IPFUN_READ() >> 12) & 0x0001);

#ifdef IMP_X4_V2H
	sy_mag_ctl = ((IMPREG_APMAG_READ() >> 31) & 0x0001);
	sy_mag = ((IMPREG_APMAG_READ() >> 24) & 0x007F);
	sx_mag_ctl = ((IMPREG_APMAG_READ() >> 23) & 0x0001);
	sx_mag = ((IMPREG_APMAG_READ() >> 16) & 0x007F);
#else
	sy_mag_ctl = ((IMPREG_APMAG_READ() >> 28) & 0x0001);
	sy_mag = ((IMPREG_APMAG_READ() >> 24) & 0x000F);
	sx_mag_ctl = ((IMPREG_APMAG_READ() >> 20) & 0x0001);
	sx_mag = ((IMPREG_APMAG_READ() >> 16) & 0x000F);
#endif
	
	scancnt_sb = ((IMPREG_APCMD_READ() >> 22) & 0x0001);
	acscnt_sb =  ((IMPREG_APCMD_READ() >> 18) & 0x0001);
	
	apsize_sb = ((IMPREG_APSIZE_SB_READ()) & 0xffff);
	
	if (sx_mag_ctl == 0) {
		if((sx_mag < 1)||(sx_mag > 8)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sx_mag:0x%x \n", sx_mag);
			Legacy_assert_error();
		}
	} else {
		if((sx_mag < 1)||(sx_mag > 40)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sx_mag:0x%x \n", sx_mag);
			Legacy_assert_error();
		}
	}

	if (sy_mag_ctl == 0) {
		if((sy_mag < 1)||(sy_mag > 8)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sy_mag:0x%x \n", sy_mag);
			Legacy_assert_error();
		}
	} else {
		if((sy_mag < 1)||(sy_mag > 40)) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid sy_mag:0x%x \n", sy_mag);
			Legacy_assert_error();
		}
	}

/* 1Line Read */
/* afin scan sy_mag*/
    HeightWork = Height;
    if((scancnt_sb)&&(scan_mode==0)){ /* afinscan */
        if(sy_mag_ctl){ /* ZoomIn */
            HeightWork = Height/sy_mag;
        }else{ /* ZoomOut */
//            HeightWork = Height*sy_mag;
            apsize_sb = apsize_sb/sy_mag;
        }
    }

	if ((0x08 == fun) || (0x09 == fun))
	{/* For IP corr, there is dummy read (out side SRC0), so the xpixel should be set to xpixel (got from xlng) * sx_mag */
		xpixel = xlng * sx_mag;
	}
	
	write_work = (unsigned short *) ReadDataWork;
	write_data = (unsigned short *) data;
	if (datatype==PXL16BPP) {
		read_p16 = (unsigned short *)(pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * HeightWork);
		for (i=0; i < xpixel; i++) {
			if (acscnt_sb == 0) {
				read_data = 0;
			} else {
				read_data = *read_p16++;
			}
			*write_work++ = read_data;
			*write_data++ = read_data;
		}
	} else {
		read_p08 = pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * HeightWork;
		for (i=0; i < xpixel; i++) {
			if (acscnt_sb == 0) {
				read_data = 0;
			} else {
				read_data = (unsigned short) *read_p08++;
			}
			*write_work++ = read_data;
			*write_data++ = read_data;
		}
	}

/* scale_pre */
	if ((scale_pre > 0) && (pcmb == 0) && (datatype == PXL16BPP)) {
		for (i=0; i<xlng; i++) {
			/* scaling */
			data[i] = (short)(data[i] >> scale_pre);
		}
	}
	
/* afin scan */
/* afin scan sx_mag*/
    if((scancnt_sb)&&(scan_mode==0)){ /* afinscan */
        if(sx_mag_ctl){ /* ZoomIn */
            for(i=0;i<xlng;i++) data[i] = ReadDataWork[i/sx_mag];
        }else{ /* ZoomOut */
            for(i=0;i<xlng;i++) data[i] = ReadDataWork[i*sx_mag];
        }
    }

/* pcmb */
    if(pcmb){
        for(i=0;i<xlng;i++){
           /* scaling */
            data[i] = (short)((data[i]>>scale_pre) & 0x3ff);

            if (datatype==PXL16BPP) { 
            }else{
                data[i] = (short)((data[i] & 0x0ff) | (cmaddr_b_high & 0x003)<<8 );
            }

            if (fun != 5) { /* exclude yuv color arithmetic */
            	data[i] = *(pCM1[IMP_WORK_CH]+4*(data[i] & 0x3ff)); /* CM memory is accessed by 4 bytes */
            }
        }
    }
///* pinv */
//    if(pinv){
//        for(i=0;i<xlng;i++){
//            if(datatype==6){
//                data[i] = (short)(~(data[i]) & 0xffff);
//            }else{
//                data[i] = (short)(~(data[i]) & 0x00ff);
//            }
//        }
//    }

    if (datatype==PXLS8BPP) {
        for(i=0;i<xlng;i++){
            if((data[i])&0x80)  data[i] = (short)((data[i]) | 0xff00);
        }
    } else if (datatype==PXL1BPP) {
        for(i=0;i<xlng;i++){
            if( fun==1 ){ /* Arithmetic process */
                if((data[i])&0x80) data[i] = 1;
                else data[i] = 0;
            }else{
                if((data[i])&0x80) data[i] = (short)((data[i]) | 0xff00);
            }
        }
    } else if (datatype==PXLCOLDIFF) {
        for(i=0;i<xlng;i++){
            data[i] -= 128;
        }
    }

    return;
}


/******************************************************************************/
/* Read1LineSrcL0                                                             */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/26 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Read1LineSrcL0(int Height, long *data)
{
	unsigned int i, pfsrca, xlng, xpixel;
	int datatype = 0;
	int apsize_sa, soura_dt, newfunc, scan_mode;
	unsigned char *read_p08;
	char *read_ps08;
	short *pSrcL016, *read_ps16;
	unsigned long *pSrcL032, *read_p32, *write_p;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	apsize_sa = IMPREG_APSIZE_SA_READ();
	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	pfsrca = ((IMPREG_APCFG_READ()>>8) & 0x0007);  /* src0 */
	soura_dt =  ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
	newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
	scan_mode = ((IMPREG_APCMD_READ() >> 24) & 0x0003);
	
#ifdef LEGACY_SIM_DEBUG
	if (((apsize_sa & 0xffff0000) != 0x00000000) && ((apsize_sa & 0xffff0000) != 0xffff0000)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, Read1LineSrcL0() apsize_sa = 0x%08x failed.\n", apsize_sa);
		Legacy_assert_error();
	}
#endif
	
	xpixel = xlng;
	
	// Check Format
	if(soura_dt == 0){
		datatype = PXLS8BPP;
	} else if(soura_dt == 1){
		datatype = PXLU8BPP;
	} else if(soura_dt == 2){
		datatype = PXL1BPP;
	} else if(soura_dt == 3){
		datatype = PXLCOLDIFF;
	}
	if(newfunc == 1)
	{
		if (pfsrca == 2) {
			/* 16bpp */
			datatype = PXL16BPP;
		} else if (pfsrca == 3) {
			/* 32bpp */
			datatype = PXL32BPP;
		}
	}
	else
	{
		if(scan_mode == 1)
		{
			datatype = PXL1BPP;
		}
		else if(scan_mode == 0)
		{
		}
		else
		{
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid scan_mode:%d \n", scan_mode);
			Legacy_assert_error();
		}
	}

	// 1Line Read
	write_p = (unsigned long *) data;
	if (datatype == PXLU8BPP) {
		/* 8bpp */
		read_p08 = (unsigned char *)(pSrc0 + IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * Height);
		for (i=0; i < xpixel; i++) {
			*write_p++ = (unsigned long) (0x000000FF & *read_p08);
			read_p08++;
		}
	} else if (datatype == PXL16BPP) {
		/* 16bpp */
		pSrcL016 = (short *)pSrc0;
		read_ps16 = pSrcL016 + (IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * Height) / 2;
		for (i=0; i < xpixel; i++) {
			*write_p++ = (long) *read_ps16++;
		}
	} else if (datatype == PXL32BPP) {
		/* 32bpp */
		pSrcL032 = (unsigned long *)pSrc0;
		read_p32 = pSrcL032 + (IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * Height) / 4;
		for (i=0; i < xpixel; i++) {
			*write_p++ = *read_p32++;
		}
	} else { // PXLS8BPP  PXL1BPP PXLCOLDIFF
		read_ps08 = (char *)(pSrc0 + IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * Height);
		for (i=0; i < xpixel; i++) {
			*write_p++ = (long) *read_ps08++;
		}
	}
	return;
}


/******************************************************************************/
/* Read1LineSrcL1                                                             */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/26 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Read1LineSrcL1(int Height, long *data)
{
	unsigned int i, pfsrcb, xlng, xpixel;
	int datatype = 0;
	int apsize_sb, sourb_dt, newfunc, scan_mode;
	unsigned char *read_p08;
	short *pSrcL016, *read_ps16;
	unsigned long *pSrcL032, *read_p32, *write_p;
	char *read_ps08;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	apsize_sb = IMPREG_APSIZE_SB_READ();
	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	pfsrcb = ((IMPREG_APCFG_READ()>>12) & 0x0007);  /* src1 */
	sourb_dt =  ((IMPREG_IPFUN_READ() >> 20) & 0x0003);

	newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
	scan_mode = ((IMPREG_APCMD_READ() >> 24) & 0x0003);
	
#ifdef LEGACY_SIM_DEBUG
	if (((apsize_sb & 0xffff0000) != 0x00000000) && ((apsize_sb & 0xffff0000) != 0xffff0000)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, Read1LineSrcL1() apsize_sb = 0x%08x failed.\n", apsize_sb);
		Legacy_assert_error();
	}
#endif
	
	xpixel = xlng;
	
	if(sourb_dt == 0){
		datatype = PXLS8BPP;
	} else if(sourb_dt == 1){
		datatype = PXLU8BPP;
	} else if(sourb_dt == 2){
		datatype = PXL1BPP;
	} else if(sourb_dt == 3){
		datatype = PXLCOLDIFF;
    }
	if(newfunc == 1)
	{
		if (pfsrcb == 2) {
			/* 16bpp */
			datatype = PXL16BPP;
		} else if (pfsrcb == 3) {
			/* 32bpp */
			datatype = PXL32BPP;
		} 
	}
	else
	{
		if(scan_mode == 1)
		{
			datatype = PXL1BPP;
		}
		else if(scan_mode == 0)
		{
		}
		else
		{
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid scan_mode:%d \n", scan_mode);
			Legacy_assert_error();
		}
	}
	

/* 1Line Read */
	write_p = (unsigned long *) data;
	if (datatype == PXLU8BPP) {
		/* 8bpp */
		read_p08 = pSrc1 +  IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * Height;
		for (i=0; i < xpixel; i++) {
			*write_p++ = (unsigned long) (0x000000FF & *read_p08);
			read_p08++;
		}
	} else if (datatype == PXL16BPP) {
		/* 16bpp */
		pSrcL016 = (short *)pSrc1;
		read_ps16 = pSrcL016 + (IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * Height) / 2;
		for (i=0; i < xpixel; i++) {
			*write_p++ = (long) *read_ps16++;
		}
	} else if (datatype == PXL32BPP) {
		/* 32bpp */
		pSrcL032 = (unsigned long *)pSrc1;
		read_p32 = pSrcL032 +  (IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * Height) / 4;
		for (i=0; i < xpixel; i++) {
			 *write_p++ = *read_p32++;
		}
	} else {  // PXLS8BPP  PXL1BPP PXLCOLDIFF
		read_ps08 = (char *) (pSrc1 +  IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * Height );
		for (i=0; i < xpixel; i++) {
			*write_p++ = (long) *read_ps08++;
		}
	}	
	return;
}

/******************************************************************************/
/* Read1LineSrc0PIPE                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/10/22 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Read1LineSrc0PIPE(int Height, short *data)
{
	unsigned int i, pfsrca, xlng;
	int datatype = 0;
	int apsize_sa, soura_dt, newfunc, scan_mode;
	int scale_pre, scale_msk_a;
	unsigned char *read_p08;
	unsigned short *read_p16, *write_data;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	apsize_sa = IMPREG_APSIZE_SA_READ();
	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	pfsrca = ((IMPREG_APCFG_READ()>>8) & 0x0007);  /* src0 */
	soura_dt =  ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
	newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
	scan_mode = ((IMPREG_APCMD_READ() >> 24) & 0x0003);

	
#ifdef LEGACY_SIM_DEBUG
	if (((apsize_sa & 0xffff0000) != 0x00000000) && ((apsize_sa & 0xffff0000) != 0xffff0000)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, Read1LineSrc0PIPE() apsize_sa = 0x%08x failed.\n", apsize_sa);
		Legacy_assert_error();
	}
#endif

	scale_msk_a = ((IMPREG_IPFUN2_READ() >> 3) & 0x0001);
	if (scale_msk_a) {
		scale_pre = 0;
	} else {
		scale_pre = ((IMPREG_IPFUN2_READ() >> 8) & 0x000F);
	}

	if (apsize_sa < 0) {
		apsize_sa = apsize_sa * (-1);
	}
	if(newfunc == 1)
	{
		// Check Format
		if (pfsrca == 1) {
			/* 8bpp */
			datatype = PXL8BPP;
		} else if (pfsrca == 2) {
			/* 16bpp */
			datatype = PXL16BPP;
		} else if (pfsrca == 3) {
			/* 32bpp */
			datatype = PXL32BPP;
			SIMLOG(SL_LS, SL_ERR, "APCFG_pfsrca : 32bpp is not supported!!!\n");
			Legacy_assert_error();
		} else if (pfsrca == 5) {
			/* 8bpp + 8bpp */
			datatype = PXL8BPP;  // not 8bpp*2 for PIPE SIM
		} 
	}
	else
	{
		if(scan_mode == 1)
		{
			datatype = PXL1BPP;
		}
		else if(scan_mode == 0)
		{
		}
		else
		{
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid scan_mode:%d \n", scan_mode);
			Legacy_assert_error();
		}
	}
	
#ifdef LEGACY_SIM_DEBUG
	else if (pfsrca == 0) {
		/* 1bpp */
		datatype = PXL1BPP;
		SIMLOG(SL_LS, SL_ERR, "APCFG_pfsrca : 1bpp is not supported!!!\n");
		Legacy_assert_error();
	} else {
		/* Error */
		SIMLOG(SL_LS, SL_ERR, "APCFG_pfsrca is error!!!\n");
		Legacy_assert_error();
	}
#endif
	
// 1Line Read
	write_data = (unsigned short *) data;
	if (datatype==PXL16BPP) {
		read_p16 = (unsigned short *)(pSrc0 + IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * Height);
		for (i=0; i < xlng; i++) {
			*write_data++ = *read_p16 >> scale_pre;
			read_p16++;
			}
	} else {
		read_p08 = pSrc0 + IMPREG_APSASP_READ() - SASP + IMPREG_APSIZE_SA_READ() * Height;
		for (i=0; i < xlng; i++) {
			*write_data++ = (unsigned short) *read_p08++;
		} 
	}
	
	return;
}

/******************************************************************************/
/* Read1LineSrc1PIPE                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/10/22 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Read1LineSrc1PIPE(int Height, short *data)
{
	unsigned int i, pfsrcb, xlng, acscnt_sb;
	int datatype = 0;
	int apsize_sb, sourb_dt, newfunc, scan_mode;
	int scale_pre, scale_msk_b;
	unsigned char *read_p08;
	unsigned short *read_p16, *write_data;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	apsize_sb = IMPREG_APSIZE_SB_READ();
	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	pfsrcb = ((IMPREG_APCFG_READ()>>12) & 0x0007);  /* src1 */
	sourb_dt =  ((IMPREG_IPFUN_READ() >> 20) & 0x0003);
    acscnt_sb =  ((IMPREG_APCMD_READ() >> 18) & 0x0001);
	newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
	scan_mode = ((IMPREG_APCMD_READ() >> 24) & 0x0003);

	
#ifdef LEGACY_SIM_DEBUG
	if (((apsize_sb & 0xffff0000) != 0x00000000) && ((apsize_sb & 0xffff0000) != 0xffff0000)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, Read1LineSrc1PIPE() apsize_sb = 0x%08x failed.\n", apsize_sb);
		Legacy_assert_error();
	}
#endif
	
	scale_msk_b = ((IMPREG_IPFUN2_READ() >> 2) & 0x0001);
	if (scale_msk_b) {
		scale_pre = 0;
	} else {
		scale_pre = ((IMPREG_IPFUN2_READ() >> 8) & 0x000F);
	}

	if (apsize_sb < 0) {
		apsize_sb = apsize_sb * (-1);
	}
	if(newfunc == 1)
	{
		// Check Format
		if (pfsrcb == 1) {
			/* 8bpp */
			datatype = PXL8BPP;
		} else if (pfsrcb == 2) {
			/* 16bpp */
			datatype = PXL16BPP;
		} else if (pfsrcb == 3) {
			/* 32bpp */
			datatype = PXL32BPP;
			SIMLOG(SL_LS, SL_ERR, "APCFG_pfsrcb : 32bpp is not supported!!!\n");
			Legacy_assert_error();
		} else if (pfsrcb == 5) {
			/* 8bpp + 8bpp */
			datatype = PXL8BPP;  // not 8bpp*2 for PIPE SIM
		} 

	#ifdef LEGACY_SIM_DEBUG
		else if (pfsrcb == 0) {
			/* 1bpp */
			datatype = PXL1BPP;
			SIMLOG(SL_LS, SL_ERR, "APCFG_pfsrcb : 1bpp is not supported!!!\n");
			Legacy_assert_error();
		} else {
			/* Error */
			SIMLOG(SL_LS, SL_ERR, "APCFG_pfsrcb is error!!!\n");
			Legacy_assert_error();
		}
	#endif
	}
	else
	{
		if(scan_mode == 1)
		{
			datatype = PXL1BPP;
		}
		else if(scan_mode == 0)
		{
		}
		else
		{
			SIMLOG(SL_LS, SL_ERR, "ERROR, invalid scan_mode:%d \n", scan_mode);
			Legacy_assert_error();
		}
	}

/* 1Line Read */
	write_data = (unsigned short *) data;
	if (datatype==PXL16BPP) {
		read_p16 = (unsigned short *)(pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * Height);
		if (acscnt_sb == 0) {
			for (i=0; i < xlng; i++) {
				*write_data++ = 0;
			}
		} else {
			for (i=0; i < xlng; i++) {
				*write_data++ = *read_p16 >> scale_pre;
				read_p16++;
			}
		}
	} else {
		read_p08 = pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * Height;
		if (acscnt_sb == 0) {
			for (i=0; i < xlng; i++) {
				*write_data++ = 0;
			}
		} else {
			for (i=0; i < xlng; i++) {
				*write_data++ = (unsigned short) *read_p08++;
			}
		}
	}
	
	return;
}


/******************************************************************************/
/* Write1LineDst                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/29 T.Sato                                               */
/*                       New  (Todo check for order of bmask_en)              */
/******************************************************************************/
void Write1LineDst(int Height, int64 *data){
	unsigned long xlng, ylng;
	unsigned int i, j;
	int64 b;
	int datatype, datatypeClip, pfdst;
	unsigned int dest_dt, post_om, ex_dest_dt;
	int abs_en, sqrt_en;
	uint64 p_num, result, maincalc, subcalc;
	int cut_en, scale, bnr_en, ec_en;
	int dxclpmax, dxclpmin;
	int64 thr_max, thr_min;
	int bcm_en, fun, fun2, bmask_en, mdlab;
	double fa;
	short workImg[LINE_SIZE];
	int mskX, mskY, loop;
    unsigned int acscnt_sb;
	unsigned char *read_p08;
	unsigned short *read_p16, *write_p16;
	unsigned long *write_p32;
	int64 *read_p64;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s",__FUNCTION__);
	SIMLOG(SL_LS, SL_L5, "  Height = %d\n",Height);
#endif

	if(McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001)) ){
		xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
		ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
	}else{
		xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
		ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
	}

	fun = ((IMPREG_IPFUN_READ() >> 28) & 0x000f);
	fun2 = ((IMPREG_IPFUN2_READ() >> 28) & 0x000f);
	pfdst = ((IMPREG_APCFG_READ()>>16) & 0x0007);
	dest_dt = ((IMPREG_IPFUN_READ() >> 16) & 0x0003);
	post_om = ((IMPREG_IPFORM_READ() >> 28) & 0x0007);
	ex_dest_dt = ((IMPREG_IPFUN2_READ() >> 4) & 0x000C) | dest_dt;
	
	// Check Format
	if (pfdst == 3) {
		/* 32bpp */
		datatype = PXL32BPP;
	} else if (post_om == 1) {
		/* 1bpp */
		datatype = PXL1BPP;
// Issue #62515
//		SIMLOG(SL_LS, SL_ERR, "1bpp:post_om is not supported!!!\n");
//		Legacy_assert_error();
	} else if (post_om == 2) {
		/* 16bpp */
		datatype = PXL16BPP;
	} else if (post_om == 4) {
		/* 8bpp + 8bpp */
		datatype = PXL8BPPx2;
		SIMLOG(SL_LS, SL_ERR, " 8bpp + 8bpp:post_om is not supported!!!\n");
		Legacy_assert_error();
	} else if (ex_dest_dt == 0) {
		/* S8bpp */
		datatype = PXLS8BPP;
	} else if (ex_dest_dt == 1) {
		/* U8bpp */
		datatype = PXLU8BPP;
	} else if (ex_dest_dt == 3) {
		/* 12bpp */
		datatype = PXL12BPP;
	} else if (ex_dest_dt == 2) {
		/* S8bpp */
		datatype = PXLS8BPP;/* For implib_IP_ShiftUp(), though dest_dt is set to reserved value, it is handled as normal case of S8bpp */
	} else {
		if ((post_om == 0) && (ex_dest_dt == 8))
		{/* temp for test case 09_11_023 */
			/* U8bpp */
			datatype = PXLU8BPP;
		}
		else
		{
			/* Error */
			SIMLOG(SL_LS, SL_ERR, " Write1LineDst datatype is error!!!\n");
			Legacy_assert_error();
	    }
	}
	
	// In case of 32bpp, datatypeClip is NA
	if (ex_dest_dt == 0) {
		/* S8bpp */
		datatypeClip = PXLS8BPP;
	} else if (ex_dest_dt == 1) {
		/* U8bpp */
		datatypeClip = PXLU8BPP;
	} else if (ex_dest_dt == 2) {
		/* reserved */
		datatypeClip = PXLRESERVED;
	} else if (ex_dest_dt == 3) {
		/* 12bpp */
		datatypeClip = PXL12BPP;
	} else if (ex_dest_dt == 4) {
		/* 11bpp clip */
		datatypeClip = PXL11BPP;
	} else if (ex_dest_dt == 8) {
		/* 16bpp clip */
		datatypeClip = PXL16BPP;
	} else {
		/* Error */
		SIMLOG(SL_LS, SL_ERR, " Write1LineDst datatypeClip is error!!!\n");
		Legacy_assert_error();
	}
	
	memset(workImg, 0, LINE_SIZE  * sizeof(short)); // todo
	abs_en = ((IMPREG_IPFUN_READ() >> 11) & 0x0001);

	sqrt_en = ((IMPREG_IPFUN2_READ() >>12) & 0x0001);

	dxclpmax = (IMPREG_APCLPX_READ() & 0x1fff);
	dxclpmin = ((IMPREG_APCLPX_READ() >> 16) & 0x1fff);

	cut_en = ((IMPREG_IPFUN_READ() >> 10) & 0x0001);
	scale = (IMPREG_IPFUN_READ() & 0x000f);
	scale |= (IMPREG_IPFUN2_READ() & 0x0003) << 4;

	bcm_en = ((IMPREG_IPFUN_READ() >> 9) & 0x0001);

	bmask_en = ((IMPREG_IPFUN_READ() >> 8) & 0x0001);
	mdlab = (((IMPREG_IPFUN_READ())>>7) & 0x0001); /* 0:Normal,1:SobelFLT help(fun 0011 only) */
    acscnt_sb =  ((IMPREG_APCMD_READ() >> 18) & 0x0001);

	bnr_en = ((IMPREG_IPFUN_READ() >> 4) & 0x0003);
	ec_en = ((IMPREG_BINTHR_READ() >> 31) & 0x0001);
	thr_max = ((IMPREG_BINTHR_READ() >> 16) & 0x01FF);
	thr_min = (IMPREG_BINTHR_READ() & 0x01FF);
	if (datatype==PXL16BPP) {
		thr_max = ((IMPREG_BINTHR2_READ() >> 8) & 0xFF00) | (thr_max&0xff);
		thr_min = ((IMPREG_BINTHR2_READ() << 8) & 0xFF00) | (thr_min&0xff);
		if(thr_max & 0x8000) thr_max = thr_max | 0xFFFFFFFFFFFF0000l;
		if(thr_min & 0x8000) thr_min = thr_min | 0xFFFFFFFFFFFF0000l;
	} else {
		if(thr_max & 0x100) thr_max = thr_max | 0xFFFFFFFFFFFFFF00l;
		if(thr_min & 0x100) thr_min = thr_min | 0xFFFFFFFFFFFFFF00l;
	}

#if  POST_UNSUPPORT_CHECK
	if (CheckRegisterOfPOST() & RESULT_USED_REG) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, CheckRegisterOfPOST failed.\n");
		Legacy_assert_error();
	}
#endif

/* abs */
	if(abs_en){
		for(i=0;i<xlng;i++){
			if (data[i] < 0) data[i] = data[i] * (-1);
		}
	}

/* square root */
	if (sqrt_en==1){
		result = maincalc = subcalc = 0;
		for(i=0;i<xlng;i++){
			if (data[i] <= 0) {
				data[i] = 0;
			} else {
				p_num = (uint64) data[i];
				/* extraction of square root */
				for (j = 0; j < 32; j++) {
					maincalc = (maincalc << 2) | ((p_num >> 62) & 3);
					p_num = p_num << 2;
					result = result << 1;
					subcalc = subcalc << 1;
					if ((subcalc | 1) <= maincalc) {
						subcalc = subcalc | 1;
						maincalc = maincalc - subcalc;
						subcalc ++;
						result = result | 1;
					}
				}
				data[i] = (int64)result;
			}
		}
	}

// return in case of 32bpp
	if (datatype==PXL32BPP) { // 32bpp
	/* Write Dest1 */
		if(McomFlg) Height = MCOM_OutputLine_Dst;
		read_p64 = data + dxclpmin;
//		write_p32 = plDest1 + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * Height) / 4 + dxclpmin;
		write_p32 = plDest1 + DEST_LINE_PIX_L * Height + dxclpmin;
		for(i=dxclpmin;i < ((dxclpmax+1>xlng) ? xlng : dxclpmax+1 );i++){
			*write_p32++ =  (unsigned long) *read_p64++;
		}
		if(McomFlg) MCOM_OutputLine_Dst++;
		return;
	}
// Issue #62515
	else if (PXL1BPP == datatype)
	{
		int64 *pData = data;
		int64 value = 0;
		int64 tmp = 0;
		for (i=0; i<xlng; i++)
		{
//			*(pDest1 + (IMPREG_APDSP_READ() - DSP) + i + IMPREG_APSIZE_DST_READ() * Height) = 0;
			*(pDest1 + (IMPREG_APDSP_READ() - DSP) + i + DEST_LINE_PIX * Height) = 0;
		}
		for (i=0; i<xlng/8; i++)
		{
			value = 0;
			for (j=0; j<8; j++)
			{
				// MSB
				if (*pData & ((uint64)0x01 << 63))
				{
					tmp = 1;
				}
				else
				{
					tmp = 0;
				}
				value |= (tmp << (7 - j));
				pData++;
			}
//			*(pDest1 + (IMPREG_APDSP_READ() - DSP) + i + IMPREG_APSIZE_DST_READ() * Height) = (unsigned short)value;
			*(pDest1 + (IMPREG_APDSP_READ() - DSP) + i + DEST_LINE_PIX * Height) = (unsigned short)value;
		}
		return;
	}


/* for MASK(pmask_en) */
	if(bmask_en||((fun==3 || fun==6)&&(mdlab==1))){
		GetMaskDly(&mskX, &mskY);
		if( Height < ylng - mskY ) {
			if (datatype==PXL16BPP) {
				if(McomFlg){
					read_p16 = (unsigned short *)(pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * (MCOM_OutputLine_Dst + mskY));
				} else {
					read_p16 = (unsigned short *)(pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * (Height + mskY));
				}
				loop =  xlng / 2;
				for (i=mskX; i < loop; i++) {
					if (acscnt_sb == 0) {
						workImg[i-mskX] = 0;
					} else {
						workImg[i-mskX] = *read_p16++;
					}
				}
			} else {
				if(McomFlg){
					read_p08 = pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * (MCOM_OutputLine_Dst + mskY);
				} else {
					read_p08 = pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * (Height + mskY) + mskX;
				}
				for (i=mskX; i < xlng; i++) {
					if (acscnt_sb == 0) {
						workImg[i-mskX] = 0;
					} else {
						workImg[i-mskX] = (unsigned short) *read_p08++;
					}
				}
			}
		}
	}

/* SobelFLT help */
	if((fun==3)&&(mdlab==1)){
		for(i=0;i<xlng;i++){
			data[i] = data[i] + (workImg[i] >> scale);
		}
	}

/* cut */
	/* 2^scale */
	for(j=0,b=1;j<(unsigned int)scale;j++) b = b * 2;
	for(i=0;i<xlng;i++){
		if(scale){
			fa = (double)data[i];
			fa = fa/b;
			if(cut_en){ /*rounddown*/
				if(fa>=0) data[i] = (int64)fa;
				else data[i] = !(data[i]%b) ? (int64)(fa) : (int64)(fa-1);
			}else{ /* round */
				if(fa>=0) data[i] = (int64)(fa+0.5);
				else data[i] = (!(data[i]%b)||((data[i]>>(scale-1))&0x01)) ? (int64)(fa) : (int64)(fa-1);
			}
		}
		if ((fun == 6) && (mdlab == 1))
		{
			int sourb_dt = ((IMPREG_IPFUN_READ() >> 20) & 0x0003);
			unsigned int pfsrcb = ((IMPREG_APCFG_READ()>>12) & 0x0007);  /* src1 */
			int datatype_sb;

			// Check Format
			if (sourb_dt == 0) {
				datatype_sb = PXLS8BPP;
			} else if (sourb_dt == 1) {
				datatype_sb = PXLU8BPP;
			} else if (sourb_dt == 2) {
				datatype_sb = PXL1BPP;
			} else if (sourb_dt == 3) {
				datatype_sb = PXLCOLDIFF;
			}
			if (pfsrcb == 2) {
				datatype_sb = PXL16BPP;
			}

			if (PXLS8BPP == datatype_sb)
			{
				workImg[i] = (char)workImg[i];
			}
			else if (PXLU8BPP == datatype_sb)
			{
				workImg[i] = (unsigned char)workImg[i];;
			}
			data[i] = data[i] + workImg[i];
		}
        if( (fun==0x0a) || (fun==0x09) || ((fun == 0x0f) && (fun2 == 0x02)) )
		{
			/* labeling or SAD or PIS */
		}
		else
		{
			if(dest_dt == 2)
			{
				/* if dest_dt[1:0] == 2b'10, no clip */
			}
			else
			{
				if(datatypeClip==PXLS8BPP){
					if (data[i] > 127) data[i] =  127;
					if (data[i] <-128) data[i] = -128;
				}else if(datatypeClip==PXLU8BPP){
					int newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
					unsigned int pfsrca = ((IMPREG_APCFG_READ()>>8) & 0x0007);  /* src0 */
					if(newfunc == 1 && pfsrca == 0)
					{
						// src0 datatype is PXL1BPP
						// do nothing(do not clip)
					}
					else
					{
						if (data[i] > 255) data[i] =  255;
						if (data[i] <   0) data[i] =    0;
					}
					data[i] = data[i] & 0xff;
				}else if(datatypeClip==PXL12BPP){
					if (data[i] > 2047) data[i] =  2047;
					if (data[i] <-2048) data[i] = -2048;
				}else if(datatypeClip==PXL11BPP){
					if (data[i] > 1023) data[i] =  1023;
					if (data[i] <-1024) data[i] = -1024;
				}else if(datatypeClip==PXL16BPP){
					if (data[i] > 32767) data[i] =  32767;
					if (data[i] <-32768) data[i] = -32768;
				}
			}
		}
	}

/* Density conversion */
	if(bcm_en){
		for(i=0;i<xlng;i++){
			if(datatype == PXL16BPP)
			{
				data[i] = *(pCM0[IMP_WORK_CH] + 4 * (data[i] & 0xfff));/* According to HW specification, CM0 is used for back process;
            											CM memory is accessed by 4 bytes */
			}
			else
			{
				data[i] = *(pCM0[IMP_WORK_CH] + 4 * (data[i] & 0x3ff));/* According to HW specification, CM0 is used for back process;
				            											CM memory is accessed by 4 bytes */
			}
		}
	}

/* bmask */
	if(bmask_en){
		for(i=0;i<xlng;i++){
			if(datatype==PXL16BPP){
				data[i] = (data[i]) & (workImg[i]<<8 | workImg[i]);
			}else{
				data[i] = (data[i]) & workImg[i];
			}
		}
	}

/* binary conversion */
	if(ec_en==0){
		if(bnr_en==2){ /* 2ti */
			for(i=0;i<xlng;i++){
				if(datatype==PXL16BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0xffff;
					else data[i] = 0x0000;
				}
				else if(datatype==PXL12BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x0fff;
					else data[i] = 0x0000;
				}
				else {
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x00ff;
					else data[i] = 0x0000;
				}
			}
		}else if(bnr_en==1){ /* 3ti */
			for(i=0;i<xlng;i++){
				if(datatype==PXL16BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x7fff;
					else if(data[i] < thr_min) data[i] = 0x0000;
					else data[i] = 0xffff;
				}
				else if(datatype==PXL12BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x07ff;
					else if(data[i] < thr_min) data[i] = 0x0000;
					else data[i] = 0x0fff;
				}
				else {
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x007f;
					else if(data[i] < thr_min) data[i] = 0x0000;
					else data[i] = 0x00ff;
				}
			}
		}else if(bnr_en==3){ /* Hanten 2ti */
			for(i=0;i<xlng;i++){
				if(datatype==PXL16BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x0000;
					else data[i] = 0xffff;
				}
				else if(datatype==PXL12BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x0000;
					else data[i] = 0x0fff;
				}
				else {
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x0000;
					else data[i] = 0x00ff;
				}
			}
		}
	}

/* Write Dest1 */
//	for(i=dxclpmin;i < ((dxclpmax+1>xlng) ? xlng : dxclpmax+1 );i++)
//	bug fix regarding Harris Operator
	if (McomFlg) {
//		write_p16 = pDest1 + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * MCOM_OutputLine_Dst);
		write_p16 = pDest1 + ((IMPREG_APDSP_READ() - DSP) + DEST_LINE_PIX * MCOM_OutputLine_Dst);
	} else {
//		write_p16 = pDest1 + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * Height);
		write_p16 = pDest1 + ((IMPREG_APDSP_READ() - DSP) + DEST_LINE_PIX * Height);
	}
	for (i=0; i < xlng; i++) {
		if(McomFlg){
			if(((IMPREG_IPFUN2_READ())>>21) & 0x0001){
				if((MCOM_reg[MCOM_regselectEXC][MCOM_LM_RESULT_WT_PTR]>=0)&&(MCOM_reg[MCOM_regselectEXC][MCOM_LM_RESULT_WT_PTR]<LM_NUM)){
/* Write LM */
					if((datatype==PXLS8BPP) && ((data[i])&0x80)) {
						data[i] = (data[i]) | 0xffffffffffffff00l;
					}
					if((datatype==PXL12BPP) && ((data[i])&0x800)) {
						data[i] = (data[i]) | 0xfffffffffffff000l;
					}
					if((datatype==PXL16BPP) && ((data[i])&0x8000)) {
						data[i] = (data[i]) | 0xffffffffffff0000l;
					}				 	
					WriteLM256(MCOM_reg[MCOM_regselectEXC][MCOM_LM_RESULT_WT_PTR], i, (short *)(data + i), 1);
				}
			}

			if(((IMPREG_IPFUN2_READ())>>20) & 0x0001){
				*write_p16++ = (unsigned short) *data++;
			}
		}else{
			*write_p16++ = (unsigned short) *data++;
		}
	}

	if(((IMPREG_IPFUN2_READ())>>20) & 0x0001) MCOM_OutputLine_Dst++;

	return;
}


/******************************************************************************/
/* Read1LineDest1                                                             */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/02/08                                                      */
/* 01-02-00 : 2007/06/19  s.ishikawa                                          */
/*                        16bpp                                               */
/* 01-02-01 : 2007/06/27 S.Ishikawa                                           */
/*                       Labeling Max 0x03ff->0x0fff                          */
/* 01-02-02 : 2007/07/20 S.Ishikawa                                           */
/*                       warning                                              */
/* 01-03-00 : 2007/07/30 S.Ishikawa                                           */
/*                       Mcom APLNG->IPLEN                                    */
/* 01-05-00 : 2007/09/06 S.Ishikawa                                           */
/*                       Changed xlng, ylng                                   */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void Read1LineDest1(int Height, short *data){
    unsigned long xlng, ylng;
    unsigned int i;
    int datatype;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
    if(McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001)) ){
        xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
        ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
    }else{
        xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
        ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
    }

    datatype = ((IMPREG_HPCTL_READ()) & 0x0003);
    if((IMPREG_HPFORM_READ() >> 24) & 0x0001){
        datatype = ((IMPREG_HPFORM_READ() >> 16) & 0x0007) + 4;
    }

/* 1Line Read */
    for(i=0;i<xlng;i++){
//        *(data + i) = *(pDest1 + (IMPREG_APDSP_READ() - DSP) + i + IMPREG_APSIZE_DST_READ() * Height);
        *(data + i) = *(pDest1 + (IMPREG_APDSP_READ() - DSP) + i + DEST_LINE_PIX * Height);
        if(datatype==0){ /* signed8 */
            if(*(data + i)&0x80) *(data + i) = (short)(*(data + i) | 0xff00);
            else *(data + i) = (short)(*(data + i) & 0xff);
        }else if(datatype==1){ /* unsigned8/label */
            *(data + i) = (short)(*(data + i) & 0xff);
        }else if(datatype==2){ /* binary */
            if(*(data + i)&0x80) *(data + i) = 1;
            else *(data + i) = 0;
        }else if(datatype==3){ /* kari label */
            *(data + i) = (short)(*(data + i) & LABELINGMAX);
        }else if(datatype==6){ /* 16bpp */
            *(data + i) = (short)(*(data + i) & 0xffff);
        }
    }

    return;
}


/******************************************************************************/
/* Read1LineDest2                                                             */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/02/08                                                      */
/* 01-02-00 : 2007/06/19  s.ishikawa                                          */
/*                        16bpp                                               */
/* 01-02-01 : 2007/06/27 S.Ishikawa                                           */
/*                       Labeling Max 0x03ff->0x0fff                          */
/* 01-02-02 : 2007/07/20 S.Ishikawa                                           */
/*                       warning                                              */
/* 01-03-00 : 2007/07/30 S.Ishikawa                                           */
/*                       Mcom APLNG->IPLEN                                    */
/* 01-05-00 : 2007/09/06 S.Ishikawa                                           */
/*                       Changed xlng, ylng                                   */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void Read1LineDest2(int Height, short *data){
    unsigned long xlng, ylng;
    unsigned int i;
    int datatype;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
    if(McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001)) ){
        xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
        ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
    }else{
        xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
        ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
    }

    datatype = ((IMPREG_HPCTL_READ() >> 2) & 0x0003);
    if((IMPREG_HPFORM_READ() >> 24) & 0x0001){
        datatype = ((IMPREG_HPFORM_READ() >> 16) & 0x0007) + 4;
    }

/* 1Line Read */
    for(i=0;i<xlng;i++){
//        *(data + i) = *(pDest2 + (IMPREG_APDSP_READ() - DSP) + i + IMPREG_APSIZE_DST_READ() * Height);
        *(data + i) = *(pDest2 + (IMPREG_APDSP_READ() - DSP) + i + DEST_LINE_PIX * Height);
        if(datatype==0){ /* signed8 */
            if(*(data + i)&0x80) *(data + i) = (short)(*(data + i) | 0xff00);
            else *(data + i) = (short)(*(data + i) & 0xff);
        }else if(datatype==1){ /* unsigned8/label */
            *(data + i) = (short)(*(data + i) & 0xff);
        }else if(datatype==2){ /* binary */
            if(*(data + i)&0x80) *(data + i) = 1;
            else *(data + i) = 0;
        }else if(datatype==3){ /* kari label */
            *(data + i) = (short)(*(data + i) & LABELINGMAX);
        }else  if(datatype==6){
            *(data + i) = (short)(*(data + i) & 0xffff);
        }
    }

    return;
}


/******************************************************************************/
/* Write1LineDest2                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/29 T.Sato                                               */
/*                       New  (Todo check for order of bmask_en)              */
/******************************************************************************/
void Write1LineDest2(int Height, int64 *data){
	unsigned long xlng, ylng;
	unsigned int i, j;
	int64 b;
	int datatype, pfdst;
	unsigned int dest_dt, post_om, ex_dest_dt;
	int abs_en;
	int cut_en, scale, bnr_en, ec_en;
	int dxclpmax, dxclpmin;
	int64 thr_max, thr_min;
	int bcm_en, fun, bmask_en, mdlab;
	double fa;
	short workImg[LINE_SIZE];
	int mskX, mskY, loop;
    unsigned int acscnt_sb;
	unsigned char *read_p08;
	unsigned short *read_p16, *write_p16;
	int64 *read_p64;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif

	if(McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001)) ){
		xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
		ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
	}else{
		xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
		ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
	}

	fun = ((IMPREG_IPFUN_READ() >> 28) & 0x000f);
	pfdst = ((IMPREG_APCFG_READ()>>16) & 0x0007);
	dest_dt = ((IMPREG_IPFUN_READ() >> 16) & 0x0003);
	post_om = ((IMPREG_IPFORM_READ() >> 28) & 0x0007);
	ex_dest_dt = ((IMPREG_IPFUN2_READ() >> 4) & 0x000C) | dest_dt;

	// Check Format
	if (pfdst == 3) {
		/* 32bpp */
		datatype = PXL32BPP;
		SIMLOG(SL_LS, SL_ERR, "32bpp:pfdst is not supported for Write1LineDest2!!!\n");
		Legacy_assert_error();
	} else if (post_om == 1) {
		/* 1bpp */
		datatype = PXL1BPP;
		SIMLOG(SL_LS, SL_ERR, "1bpp:post_om is not supported!!!\n");
		Legacy_assert_error();
	} else if (post_om == 2) {
		/* 16bpp */
		datatype = PXL16BPP;
		SIMLOG(SL_LS, SL_ERR, "16bpp:post_om is not supported for Write1LineDest2!!!\n");
		Legacy_assert_error();
	} else if (post_om == 4) {
		/* 8bpp + 8bpp */
		datatype = PXL8BPPx2;
		SIMLOG(SL_LS, SL_ERR, " 8bpp + 8bpp:post_om is not supported!!!\n");
		Legacy_assert_error();
	} else if (ex_dest_dt == 0) {
		/* S8bpp */
		datatype = PXLS8BPP;
	} else if (ex_dest_dt == 1) {
		/* U8bpp */
		datatype = PXLU8BPP;
	} else if (ex_dest_dt == 3) {
		/* 12bpp */
		datatype = PXL12BPP;
	} else if (ex_dest_dt == 2) {
		/* S8bpp */
		datatype = PXLS8BPP;/* For implib_IP_ShiftUp(), though dest_dt is set to reserved value, it is handled as normal case of S8bpp */
	} else {
		/* Error */
		SIMLOG(SL_LS, SL_ERR, " Write1LineDst datatype is error!!!\n");
		Legacy_assert_error();
	}

	memset(workImg, 0, LINE_SIZE  * sizeof(short)); // todo
	abs_en = ((IMPREG_IPFUN_READ() >> 11) & 0x0001);

	dxclpmax = (IMPREG_APCLPX_READ() & 0x1fff);
	dxclpmin = ((IMPREG_APCLPX_READ() >> 16) & 0x1fff);

	cut_en = ((IMPREG_IPFUN_READ() >> 10) & 0x0001);
	scale = (IMPREG_IPFUN_READ() & 0x000f);
	scale |= (IMPREG_IPFUN2_READ() & 0x0003) << 4;

	bcm_en = ((IMPREG_IPFUN_READ() >> 9) & 0x0001);

	bmask_en = ((IMPREG_IPFUN_READ() >> 8) & 0x0001);
	mdlab = (((IMPREG_IPFUN_READ())>>7) & 0x0001); /* 0:Normal,1:SobelFLT help(fun 0011 only) */
    acscnt_sb =  ((IMPREG_APCMD_READ() >> 18) & 0x0001);

	bnr_en = ((IMPREG_IPFUN_READ() >> 4) & 0x0003);
	ec_en = ((IMPREG_BINTHR_READ() >> 31) & 0x0001);
	thr_max = ((IMPREG_BINTHR_READ() >> 16) & 0x01FF);
	thr_min = (IMPREG_BINTHR_READ() & 0x01FF);
	if(thr_max & 0x100) thr_max = thr_max | 0xFFFFFFFFFFFFFF00l;
	if(thr_min & 0x100) thr_min = thr_min | 0xFFFFFFFFFFFFFF00l;

/* abs */
	if(abs_en){
		for(i=0;i<xlng;i++){
			if (data[i] < 0) data[i] = data[i] * (-1);
		}
	}

/* cut */
	/* 2^scale */
	for(j=0,b=1;j<(unsigned int)scale;j++) b = b * 2;
	for(i=0;i<xlng;i++){
		if(scale){
			fa = (double)data[i];
			fa = fa/b;
			if(cut_en){ /*rounddown*/
				if(fa>=0) data[i] = (int64)fa;
				else data[i] = !(data[i]%b) ? (int64)(fa) : (int64)(fa-1);
			}else{ /* round */
				if(fa>=0) data[i] = (int64)(fa+0.5);
				else data[i] = (!(data[i]%b)||((data[i]>>(scale-1))&0x01)) ? (int64)(fa) : (int64)(fa-1);
			}
		}
		if( (fun==0x0a) || ((fun==0x09)) )
		{
			/* labeling or SAD */
		}
		else
		{
			if(dest_dt == 2)
			{
				/* if dest_dt[1:0] == 2b'10, no clip */
			}
			else
			{
				if(datatype==PXLS8BPP){
					if (data[i] > 127) data[i] =  127;
					if (data[i] <-128) data[i] = -128;
				}else if(datatype==PXLU8BPP){
					if (data[i] > 255) data[i] =  255;
					if (data[i] <   0) data[i] =    0;
					data[i] = data[i] & 0xff;
				}else if(datatype==PXL12BPP){
					if (data[i] > 2047) data[i] =  2047;
					if (data[i] <-2048) data[i] = -2048;
				}
			}
		}
	}

/* Density conversion */
	if(bcm_en){
		for(i=0;i<xlng;i++){
			data[i] = *(pCM0[IMP_WORK_CH] + 4 * (data[i] & 0x3ff));/* According to HW specification, CM0 is used for back process;
													  CM memory is accessed by 4 bytes */
		}
	}

/* bmask */
	if(bmask_en){
	/* for MASK(pmask_en) */
		GetMaskDly(&mskX, &mskY);
		
		if( Height < ylng - mskY ) {
			if (datatype==PXL16BPP) {
				read_p16 = (unsigned short *)(pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * (Height + mskY));
				loop =  xlng / 2;
				for (i=mskX; i < loop; i++) {
					if (acscnt_sb == 0) {
						workImg[i-mskX] = 0;
					} else {
						workImg[i-mskX] = *read_p16++;
					}
				}
			} else {
				read_p08 = pSrc1 + IMPREG_APSBSP_READ() - SBSP + IMPREG_APSIZE_SB_READ() * (Height + mskY);
				for (i=mskX; i < xlng; i++) {
					if (acscnt_sb == 0) {
						workImg[i-mskX] = 0;
					} else {
						workImg[i-mskX] = (unsigned short) *read_p08++;
					}
				}
			}
		}
		
		for(i=0;i<xlng;i++){
			data[i] = (data[i]) & workImg[i];
		}
	}

/* binary conversion */
	if(ec_en==0){
		if(bnr_en==2){ /* 2ti */
			for(i=0;i<xlng;i++){
				if(datatype==PXL12BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x0fff;
					else data[i] = 0x0000;
				}
				else {
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x00ff;
					else data[i] = 0x0000;
				}
			}
		} else if(bnr_en==1){ /* 3ti */
			for(i=0;i<xlng;i++){
				if(datatype==PXL12BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x07ff;
					else if(data[i] < thr_min) data[i] = 0x0000;
					else data[i] = 0x0fff;
				}
				else {
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x007f;
					else if(data[i] < thr_min) data[i] = 0x0000;
					else data[i] = 0x00ff;
				}
			}
		} else if(bnr_en==3){ /* Hanten 2ti */
			for(i=0;i<xlng;i++){
				if(datatype==PXL12BPP)
				{
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x0000;
					else data[i] = 0x0fff;
				}
				else {
					if((data[i] >= thr_min)&&(data[i] <= thr_max)) data[i] = 0x0000;
					else data[i] = 0x00ff;
				}
			}
		}
	}

/* Write Dest2 */
	read_p64 = data + dxclpmin;
//	write_p16 = pDest2 + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * Height) + dxclpmin;
	write_p16 = pDest2 + ((IMPREG_APDSP_READ() - DSP) + DEST_LINE_PIX * Height) + dxclpmin;
	for(i=dxclpmin;i < ((dxclpmax+1>xlng) ? xlng : dxclpmax+1 );i++){
		*write_p16++ = (unsigned short) *read_p64++;
	}

	return;
}

#if  POST_UNSUPPORT_CHECK
/******************************************************************************/
/* CheckRegisterOfPOST                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/11                                                      */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
static int CheckRegisterOfPOST() {
	int result = RESULT_UNUSED;
	unsigned int destext_dt, destmsk;

#if 0
	destext_dt = ((IMPREG_IPFUN_READ() >> 18) & 0x0003);
	if (destext_dt != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support in SIM.  (destext_dt=0x%08x) \n", destext_dt);
		result |= RESULT_USED_DEBUG;
	}
#endif
	destmsk = ((IMPREG_IPFUN_READ() >> 6) & 0x0001);
	if (destmsk != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support in SIM.  (destmsk=0x%08x) \n", destmsk);
		result |= RESULT_USED_DEBUG;
	}
	return result;
}
#endif

/******************************************************************************/
/* IPtoAPwithLW                                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/12/10 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
static void IPtoAPwithLW(void) {
	long xlng, ylng;
	unsigned long *plDst, *read_p, *write_p, *ppdest;
	int Height, i, xdly, ydly;
    int dxclpmax, dxclpmin, xlngclpmax, xlngclpmin;

/* not support APDLY for 32bpp */
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	plDst = (unsigned long *)pDst;
	Height = 0;

	if (McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001))) {
		xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
		ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
	}else{
		xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
		ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
	}
	
	dxclpmax = (IMPREG_APCLPX_READ() & 0x1fff);
	dxclpmin = ((IMPREG_APCLPX_READ() >> 16) & 0x1fff);
	// Clipping by APCLPX
	xlngclpmin = dxclpmin;
	xlngclpmax = dxclpmax + 1;
	if (xlngclpmax > xlng) {
		xlngclpmax = xlng;
	}
	
	/* APDLY */
	GetAPDly(&xdly, &ydly);
	
	if( xdly < 0) {
		xlngclpmax += xdly;
	}
	
	if (((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * Height) % 4) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, address error in IPtoAPwithLW  0x%08x\n", ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * Height));
		Legacy_assert_error();
	}
	
//	ppdest = plDest1 + ((IMPREG_APDSP_READ() - DSP) - IMPREG_APSIZE_DST_READ() * ydly ) / 4;
	ppdest = plDest1 + - DEST_LINE_PIX_L * ydly;

	while(Height < ylng){
		write_p = plDst + xlngclpmin + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * Height) / 4;
		
		if( (xdly>=xlng)||(xdly<= (-1*xlng)) ){
		}else if(xdly>=0){
			
//			read_p  = ppdest + xlngclpmin + xdly + (IMPREG_APSIZE_DST_READ() * Height) / 4;
			read_p  = ppdest + xlngclpmin + xdly + DEST_LINE_PIX_L * Height;
			xlngclpmax = (xlngclpmax > (xlng-xdly)) ?  xlng-xdly : xlngclpmax;
			if ((ydly>=0) && (Height<ydly)) {
				for (i = xlngclpmin; i < xlngclpmax; i++) {
					 *write_p++ = 0;
				}
			}else {
				for (i = xlngclpmin; i < xlngclpmax; i++) {
					*write_p++ = *read_p++;
				}
			}
		}else{
			
//			read_p  = ppdest  + xlngclpmin - xdly + (IMPREG_APSIZE_DST_READ() * Height) / 4;
			read_p  = ppdest  + xlngclpmin - xdly + DEST_LINE_PIX_L * Height;
			xlngclpmax = (xlngclpmax > (xlng+xdly)) ?  xlng+xdly : xlngclpmax;
			if ((ydly>=0) && (Height<ydly)) {
				for (i = xlngclpmin; i < xlngclpmax; i++) {
					 *write_p++ = 0;
				}
				
			} else {
				for (i = xlngclpmin; i < xlngclpmax; i++) {
					 *write_p++ = *read_p++;
				}
			}
		}
		
		Height++;
		IMPREG_APDLENCNT_WRITE( Height & 0x3fff );
	}

	// clear Execute bit
	IMPREG_APCMD_WRITE( IMPREG_APCMD_READ() & ~APCMDEX );
	return;
}



/******************************************************************************/
/* IPtoAP                                                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/12/10 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void IPtoAP(void){
	long xlng, ylng, xlngm;
	unsigned short APDLYdata[LINE_SIZE];
	int xdly, ydly, Height, HeightWork, adr, loop, dx_mag, dy_mag, type, i, bpp, ret;
	int scan_mode, dst_scan_mode, scancnt_bit;
	int fun, subfun, datatype, fun2, scale, pfdst;
    int dxclpmax, dxclpmin, xlngclpmax, xlngclpmin;
	int newfunc;
	unsigned short *write_p16, *read_p16;
	unsigned short *ppdest;
	unsigned char *write_p08;
	
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	// Check if destination is enabled by acscnt_ds bit of APCMD.
	// If not, no need to activate AP.
	if (((IMPREG_APCMD_READ() >> 16) & 0x0001) == 0) return;
	
	/* APDLY */
	GetAPDly(&xdly, &ydly);
	
	dx_mag = (IMPREG_APMAG_READ() & 0x000F);
	dy_mag = ((IMPREG_APMAG_READ() >> 8) & 0x000F);

	scan_mode = ((IMPREG_APCMD_READ() >> 24) & 0x0003);
	scancnt_bit = ((IMPREG_APCMD_READ() >> 20) & 0x0001);

	fun = ((IMPREG_IPFUN_READ() >> 28) & 0x000f);
	subfun = ((IMPREG_IPFUN_READ() >> 24) & 0x000f);
	datatype = ((IMPREG_IPFUN_READ() >> 16) & 0x0003);
	pfdst = ((IMPREG_APCFG_READ()>>16) & 0x0007);
	newfunc = ((IMPREG_APCFG_READ()>>24) & 0x0001);
	
	dxclpmax = (IMPREG_APCLPX_READ() & 0x1fff);
	dxclpmin = ((IMPREG_APCLPX_READ() >> 16) & 0x1fff);
	
	if(((IMPREG_IPFORM_READ() >> 28) & 0x0007)){
		datatype = ((IMPREG_IPFORM_READ() >> 28) & 0x0007) + 4;
	}
	fun2 = ((IMPREG_IPFUN2_READ() >> 28) & 0x000f);
	scale = (IMPREG_IPFUN_READ() & 0x000f);
    scale |= (IMPREG_IPFUN2_READ() & 0x0003) << 4;

	// check scan mode
	if (scancnt_bit==0) {
		dst_scan_mode = RASTER_SCAN_MODE;  // raster scan
	} else {
		if (scan_mode==0) dst_scan_mode = AFIN_SCAN_MODE;   // afin scan
		else if (scan_mode==1) dst_scan_mode = BINARY_PACK_MODE; // Binary pack_unpack_mode
	}

	// Check Format
	if ((newfunc ==1) && (dst_scan_mode!=BINARY_PACK_MODE)) {
		// Issue #62515
		if (pfdst == 0) {
			/* 1bpp */
			datatype = PXL1BPP;
		} else if (pfdst == 1) {
			/* 8bpp */
			datatype = PXL8BPP;
		} else if (pfdst == 2) {
			/* 16bpp */
			datatype = PXL16BPP;
		} else if (pfdst == 3) {
			/* 32bpp */
			datatype = PXL32BPP;
		} else {
			SIMLOG(SL_LS, SL_ERR, "ERROR, Format for IPtoAP failed.\n");
			Legacy_assert_error();
		}
//		} else if (pfdst == 5) {
//			/* 8bpp + 8bpp */
//			datatype = PXL8BPPx2;
//		} else if (pfdst == 0) {
//			/* 1bpp */
//			datatype = PXL1BPP;
//		}
	} else {		// legacy or binary_pack_unpack_mode
		if (((IMPREG_CNF_READ()>>25) & 0x0001) == 1) {
			/* 16bpp */
			datatype = PXL16BPP;
		} else {
			/* 8bpp */
			datatype = PXL8BPP;
		}
	}

#if  AP_UNSUPPORT_CHECK
	if (CheckRegisterOfAP() & RESULT_USED_REG) {
#if  AP_UNSUPPORT_CHECK_ASSERT_ERROR
		SIMLOG(SL_LS, SL_ERR, "ERROR, CheckRegisterOfAP failed.\n");
		Legacy_assert_error();
#endif
	}
#endif
	
	// tsato
	if ((fun == 0xf) && ((fun2 == 0x02) || (fun2 == 0x05) || (fun2 == 0x06) || (fun2 == 0x07)))
	{
		xdly = 0;
		ydly = 0;
	}
	// In case of PIPE, don't care APDLY
	if (McomFlg) {
		xdly = 0;
		ydly = 0;
	}
	
	// tsato for 32bpp
	if (pfdst==3) {
		IPtoAPwithLW();
		return;
	}
	
	if (McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001))) {
		xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
		ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
	}else{
		xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
		ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
	}
	
	if((dx_mag < 1)||(dx_mag > 8)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, invalid dx_mag:0x%x \n", dx_mag);
		Legacy_assert_error();
	}
	
	if((dy_mag < 1)||(dy_mag > 8)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, invalid dy_mag:0x%x \n", dy_mag);
		Legacy_assert_error();
	}
	
	Height = 0;
	if (scale==0 && fun==0xf && subfun==0 && fun2==1){ 
		xlng = xlng * 2;
	}
	
	// yuv color arithmetic
	if(fun == 5) { 
		if((IPFORM_BACKUP & 0x00000077) == 0x00000044) { // 8bppx2
			dx_mag++;
			dst_scan_mode = AFIN_SCAN_MODE;
		}
	}
	
//	ppdest = pDest1 + (IMPREG_APDSP_READ() - DSP) - IMPREG_APSIZE_DST_READ() * ydly;
	ppdest = pDest1 + (IMPREG_APDSP_READ() - DSP) - DEST_LINE_PIX * ydly;
	
	while (Height < ylng) {
		/* AP */
		/* afin scan */
		/* dy_mag -> Height changed */
		HeightWork = Height;
		if(dst_scan_mode==AFIN_SCAN_MODE){ /* afinscan */
			if((Height > 0) && (Height % dy_mag)){ /* skip */
				Height++;
				continue;
			}
			else HeightWork = Height/dy_mag;
		}
		
		if(dst_scan_mode==AFIN_SCAN_MODE){ /* afinscan */
			xlngm = (xlng % dx_mag) ? (xlng/dx_mag)+1 : xlng/dx_mag;
			if((datatype==PXL16BPP)&&(xlngm%2)) xlngm++;
			// Issue #62515
			if ((datatype==PXL8BPP) || (datatype==PXL1BPP)) { // PXL8BPP or PXL1BPP
				write_p08 = (unsigned char *)(pDst + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * HeightWork ));
				if ((ydly>=0) && (Height<ydly)) {
					for (i = 0; i < xlngm; i++) {
						 *write_p08++ = 0;
					}
				}else {
					if( (xdly>=xlng)||(xdly<= (-1*xlng)) ){
					}else if(xdly>=0){
//						read_p16  = ppdest +  xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest +  xdly + DEST_LINE_PIX * Height;
						xlngm = (xlngm > (xlng-xdly)) ?  xlng-xdly : xlngm;
						for (i = 0; i < xlngm; i++) {
							*write_p08++ = (unsigned char) read_p16[i*dx_mag];
						}
					}else{
//						read_p16  = ppdest -  xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest -  xdly + DEST_LINE_PIX * Height;
						xlngm = (xlngm > (xlng+xdly)) ?  xlng+xdly : xlngm;
						for (i = 0; i < xlngm; i++) {
							*write_p08++ = (unsigned char) read_p16[i*dx_mag];
						}
					}	
				}
			} else { // PXL16BPP
				write_p16 = (unsigned short *)(pDst +  ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * HeightWork ));
				if ((ydly>=0) && (Height<ydly)) {
					for (i = 0; i < xlngm; i++) {
						 *write_p16++ = 0;
					}
				}else {
					if( (xdly>=xlng)||(xdly<= (-1*xlng)) ){
					}else if(xdly>=0){
//						read_p16  = ppdest + xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest + xdly + DEST_LINE_PIX * Height;
						xlngm = (xlngm > (xlng-xdly)) ?  xlng-xdly : xlngm;
						for (i = 0; i < xlngm; i++) {
							*write_p16++ = read_p16[i*dx_mag];
						}
					}else{
//						read_p16  = ppdest - xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest - xdly + DEST_LINE_PIX * Height;
						xlngm = (xlngm > (xlng+xdly)) ?  xlng+xdly : xlngm;
						for (i = 0; i < xlngm; i++) {
							*write_p16++ = read_p16[i*dx_mag];
						}
					}
				}
			}
		} else {
			// Clipping by APCLPX
			xlngclpmin = dxclpmin;
			xlngclpmax = dxclpmax + 1;
			if (xlngclpmax > xlng) {
				xlngclpmax = xlng;
			}
			if( dxclpmax == 0 ) {
				xlngclpmax = ylng;
			}
			// Issue #62515
			if ((datatype==PXL8BPP) || (datatype==PXL1BPP)) { // PXL8BPP or PXL1BPP
				write_p08 = (unsigned char *)(pDst + xlngclpmin + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * HeightWork ));
				if ((ydly>=0) && (Height<ydly)) {
					for (i = xlngclpmin; i < xlngclpmax; i++) {
						 *write_p08++ = 0;
					}
				} else {
					if( (xdly>=xlng)||(xdly<= (-1*xlng)) ){
					}else if(xdly>=0){
//						read_p16  = ppdest + xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest + xdly + DEST_LINE_PIX * Height;
						xlngclpmax = (xlngclpmax > (xlng-xdly)) ?  xlng-xdly : xlngclpmax;
						for (i = xlngclpmin; i < xlngclpmax; i++) {
							*write_p08++ = (unsigned char) read_p16[i];
						}
					}else{
//						read_p16  = ppdest - xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest - xdly + DEST_LINE_PIX * Height;
						xlngclpmax = (xlngclpmax > (xlng+xdly)) ?  xlng+xdly : xlngclpmax;
						for (i = xlngclpmin; i < xlngclpmax; i++) {
							*write_p08++ = (unsigned char) read_p16[i];
						}
					}
				} 
			} 
			else if(datatype==PXL1BPP)
			{
				read_p16 = APDLYdata + xlngclpmin;
				write_p08 = (unsigned char *)(pDst + xlngclpmin + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * HeightWork));
				for (i = xlngclpmin; i < xlngclpmax; i++) {
					*write_p08++ = (unsigned char)(*read_p16++);
				}
			}
			else { // PXL16BPP
				write_p16 = (unsigned short *)(pDst + xlngclpmin * 2 + ((IMPREG_APDSP_READ() - DSP) + IMPREG_APSIZE_DST_READ() * HeightWork ));
				if ((ydly>=0) && (Height<ydly)) {
					for (i = xlngclpmin; i < xlngclpmax; i++) {
						 *write_p16++ = 0;
					}
				} else {
					if( (xdly>=xlng)||(xdly<= (-1*xlng)) ){
					}else if(xdly>=0){
//						read_p16  = ppdest + xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest + xdly + DEST_LINE_PIX * Height;
						xlngclpmax = (xlngclpmax > (xlng-xdly)) ?  xlng-xdly : xlngclpmax;
						for (i = xlngclpmin; i < xlngclpmax; i++) {
							*write_p16++ = read_p16[i];
						}
					}else{
//						read_p16  = ppdest - xdly + IMPREG_APSIZE_DST_READ() * Height;
						read_p16  = ppdest - xdly + DEST_LINE_PIX * Height;
						xlngclpmax = (xlngclpmax > (xlng+xdly)) ?  xlng+xdly : xlngclpmax;
						for (i = xlngclpmin; i < xlngclpmax; i++) {
							*write_p16++ = read_p16[i];
						}
					}
				}
			}
		}
		Height++;
		IMPREG_APDLENCNT_WRITE( Height & 0x3fff );
	}
	
	// clear Execute bit
	IMPREG_APCMD_WRITE( IMPREG_APCMD_READ() & ~APCMDEX );
	return;
}

/******************************************************************************/
/* CheckEndOfIntermediateBuffer                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/01/23                                                      */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
void CheckEndOfIntermediateBuffer() {
	unsigned char *ppp;
	
	ppp = (unsigned char *) pDest1;
	ppp += DEST_MEM_SIZE;
	ppp --;
	if (*ppp != DEST_MEM_POST_END1) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest1-1 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END1, *ppp);
		Legacy_assert_error();
	}
	ppp --;
	if (*ppp != DEST_MEM_POST_END2) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest1-2 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END2, *ppp);
		Legacy_assert_error();
	}
	ppp --;
	if (*ppp != DEST_MEM_POST_END3) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest1-3 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END3, *ppp);
		Legacy_assert_error();
	}
	ppp --;
	if (*ppp != DEST_MEM_POST_END4) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest1-4 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END4, *ppp);
		Legacy_assert_error();
	}
	
	ppp = (unsigned char *) pDest2;
	ppp += DT_MEM_SIZE;
	ppp --;
	if (*ppp != DEST_MEM_POST_END4) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest2-4 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END4, *ppp);
		Legacy_assert_error();
	}
	ppp --;
	if (*ppp != DEST_MEM_POST_END3) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest2-3 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END3, *ppp);
		Legacy_assert_error();
	}
	ppp --;
	if (*ppp != DEST_MEM_POST_END2) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest2-2 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END2, *ppp);
		Legacy_assert_error();
	}
	ppp --;
	if (*ppp != DEST_MEM_POST_END1) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest2-1 was overwrite 0x%x 0x%x\n", DEST_MEM_POST_END1, *ppp);
		Legacy_assert_error();
	}
	
	return;
}


#if  AP_UNSUPPORT_CHECK
/******************************************************************************/
/* CheckRegisterOfAP                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/11                                                      */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
static int CheckRegisterOfAP() {
   	int im_hm, dd_mode, chmcken, yuvds_sel, xdctl;
	int imhm_spc, imhm_add, apihtcr, st32_mode;
	int aplowlimit, aphighlimit;
	int match_en, ecode_out_ctl, match_cnt;
	int dest_ofs, dw_ctl;
	unsigned long sasp_ofs, sbsp_ofs, dsp_ofs, sf_ctl0;
	int cnt_ctl;
	unsigned long exe_ctl, readonly_cnt;
	int result = RESULT_UNUSED;

	im_hm = ((IMPREG_APCMD_READ() >> 29) & 0x0001);
	if (im_hm == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for IM,HM Memory Transfer Mode in SIM. \n");
		result |= RESULT_USED_REG;
	}
#if 0
	dd_mode = ((IMPREG_APCMD_READ() >> 2) & 0x0003);
	if (dd_mode != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for Destination Data Mode in SIM. 0x%08x \n", dd_mode);
		result |= RESULT_USED_REG;
	}
#endif
	chmcken = ((IMPREG_APCMD_READ() >> 1) & 0x0001);
	if (im_hm == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for CM,HM Clock Enable in SIM. \n");
		result |= RESULT_USED_REG;
	}
	yuvds_sel = (IMPREG_APCMD_READ() & 0x0001);
	if (yuvds_sel == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for YUV Data Select in SIM. \n");
		result |= RESULT_USED_REG;
	}
#if 0
	xdctl = ((IMPREG_APDLY_READ() >> 15) & 0x0001);
	if (xdctl == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for X Delay Control in SIM. \n");
		result |= RESULT_USED_REG;
	}
	imhm_spc = ((IMPREG_APIHSP_READ() >> 16) & 0x000f);
	if (imhm_spc != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for IM,HM Memory Space Select in SIM.  0x%08x \n", imhm_spc);
		result |= RESULT_USED_REG;
	}
#endif
	imhm_add = ((IMPREG_APIHSP_READ() >> 2) & 0x0fff);
	if (imhm_add != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for IM,HM Memory Transfer Start Address in SIM.  0x%08x \n", imhm_add);
		result |= RESULT_USED_REG;
	}
#if 0
	apihtcr = (IMPREG_APIHTCR_READ() & 0x0fff);
	if (apihtcr != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for IM,HM Memory Transfer count in SIM.  0x%08x \n", apihtcr);
		result |= RESULT_USED_REG;
	}
#endif
	st32_mode = ((IMPREG_APCFG_READ() >> 31) & 0x0001);
	if (st32_mode == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for ST32 mode in SIM. \n");
		result |= RESULT_USED_REG;
	}
	aplowlimit = ((IMPREG_APLLIM_READ() >> 10) & 0x3fffff);
	if (aplowlimit != 0x3fffff) {
		SIMLOG(SL_LS, SL_L4, " It does not support for APX Area Low Limit Address in SIM. 0x%08x \n", aplowlimit);
		result |= RESULT_USED_REG;
	}
	aphighlimit = ((IMPREG_APHLIM_READ() >> 10) & 0x3fffff);
	if (aphighlimit != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for APX Area High Limit Address in SIM. 0x%08x \n", aphighlimit);
		result |= RESULT_USED_REG;
	}
	match_en = ((IMPREG_APDLENINTC_READ() >> 31) & 0x0001);
	if (match_en == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for exec length match enable in SIM. \n");
		result |= RESULT_USED_REG;
	}
	ecode_out_ctl = ((IMPREG_APDLENINTC_READ() >> 24) & 0x0001);
	if (ecode_out_ctl == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for edge code output control in SIM. \n");
		result |= RESULT_USED_REG;
	}
	match_cnt = (IMPREG_APDLENINTC_READ() & 0x03ff);
	if (match_cnt != 0x03ff) {
		SIMLOG(SL_LS, SL_L4, " It does not support for matching count number in SIM. 0x%08x \n", match_cnt);
		result |= RESULT_USED_REG;
	}
	dest_ofs = ((IMPREG_APDP_OFS_READ() >> 10) & 0x3fffff);
	if (dest_ofs != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for Destination Pointer Offset  in SIM. 0x%08x \n", dest_ofs);
		result |= RESULT_USED_REG;
	}
	dw_ctl = (IMPREG_APDW_CTL_READ() & 0x0003);
	if (dw_ctl != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for Destination Write Control in SIM. 0x%08x \n", dw_ctl);
		result |= RESULT_USED_REG;
	}
	sasp_ofs = IMPREG_APSASP_OFS_READ();
	if (sasp_ofs != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for SourceA Start Pointer Offset  in SIM. 0x%08x \n", sasp_ofs);
		result |= RESULT_USED_REG;
	}
	sbsp_ofs = IMPREG_APSBSP_OFS_READ();
	if (sbsp_ofs != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for SourceB Start Pointer Offset  in SIM. 0x%08x \n", sbsp_ofs);
		result |= RESULT_USED_REG;
	}
	dsp_ofs = IMPREG_APDSP_OFS_READ();
	if ( dsp_ofs != 0 ) {
		SIMLOG(SL_LS, SL_L4, " It does not support for Destination Start Pointer Offset  in SIM. 0x%08x \n", dsp_ofs);
		result |= RESULT_USED_REG;
	}
	sf_ctl0 = IMPREG_APSFCTL0_READ();
	if (sf_ctl0 != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for Safty Control 0  in SIM. 0x%08x \n", sf_ctl0);
		result |= RESULT_USED_REG;
	}
	cnt_ctl = (IMPREG_CNTCLR_READ() & 0x0001);
	if (cnt_ctl == 0x0001) {
		SIMLOG(SL_LS, SL_L4, " It does not support for Performance Counter Initialize in SIM. \n");
		result |= RESULT_USED_REG;
	}
	exe_ctl = IMPREG_EXECCNT_READ();
	if (exe_ctl != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for APX Execute Cycle Count  in SIM. 0x%08x \n", exe_ctl);
		result |= RESULT_USED_REG;
	}
	readonly_cnt = IMPREG_SBEMPCNT_READ();
	if (readonly_cnt != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for APX Source Buffer Empty Cycle Count in SIM. 0x%08x \n", readonly_cnt);
		result |= RESULT_USED_REG;
	}
	readonly_cnt = IMPREG_DBFULCNT_READ();
	if (readonly_cnt != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for APX Dest Buffer Full Cycle Count in SIM. 0x%08x \n", readonly_cnt);
		result |= RESULT_USED_REG;
	}
	readonly_cnt = IMPREG_SHREQNUM_READ();
	if (readonly_cnt != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for SHwy Request Packet Number Count in SIM. 0x%08x \n", readonly_cnt);
		result |= RESULT_USED_REG;
	}
	readonly_cnt = IMPREG_SHWAITNUM_READ();
	if (readonly_cnt != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for SHwy Wait Cycle Count in SIM. 0x%08x \n", readonly_cnt);
		result |= RESULT_USED_REG;
	}

	
	if (IMPREG_DEB0_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 0 in SIM. 0x%08x \n", IMPREG_DEB0_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB1_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 1 in SIM. 0x%08x \n", IMPREG_DEB1_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB2_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 2 in SIM. 0x%08x \n", IMPREG_DEB2_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB3_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 3 in SIM. 0x%08x \n", IMPREG_DEB3_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB4_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 4 in SIM. 0x%08x \n", IMPREG_DEB4_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB5_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 5 in SIM. 0x%08x \n", IMPREG_DEB5_READ());
	}
	if (IMPREG_DEB6_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 6 in SIM. 0x%08x \n", IMPREG_DEB6_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB7_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 7 in SIM. 0x%08x \n", IMPREG_DEB7_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB8_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 8 in SIM. 0x%08x \n", IMPREG_DEB8_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB9_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 9 in SIM. 0x%08x \n", IMPREG_DEB9_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB10_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 10 in SIM. 0x%08x \n", IMPREG_DEB10_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB11_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 11 in SIM. 0x%08x \n", IMPREG_DEB11_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB12_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 12 in SIM. 0x%08x \n", IMPREG_DEB12_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB13_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 13 in SIM. 0x%08x \n", IMPREG_DEB13_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB14_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 14 in SIM. 0x%08x \n", IMPREG_DEB14_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB15_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 15 in SIM. 0x%08x \n", IMPREG_DEB15_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB16_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 16 in SIM. 0x%08x \n", IMPREG_DEB16_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB17_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 17 in SIM. 0x%08x \n", IMPREG_DEB17_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB18_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 18 in SIM. 0x%08x \n", IMPREG_DEB18_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB19_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 19 in SIM. 0x%08x \n", IMPREG_DEB19_READ());
		result |= RESULT_USED_DEBUG;
	}
	if (IMPREG_DEB20_READ() != 0) {
		SIMLOG(SL_LS, SL_L4, " It does not support for debug register 20 in SIM. 0x%08x \n", IMPREG_DEB20_READ());
		result |= RESULT_USED_DEBUG;
	}
	return result;
}
#endif
	
/******************************************************************************/
/* GetAPDly                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/12/10 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
static void GetAPDly(int *xdly, int *ydly){

    int fun, subfun, pcma, pcmb, bcm_en, p, b, dest_dt, outsel, bitsel, m5x5, fun2;
    int pre_en, post_en, sqrt_en;
    int x, y, ap_x, ap_y, post_om, kernel, mdlab, pfdst, ec_en, dual_en, ec_mode, ec_bin;
/*                       0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15 */
    int APDLYTbl_x[16]={ 1, 13, 13, 18, 20, 13, 20, 21,  0,  0, 11, 16, 14,  7, 22,  0 };
    int APDLYTbl_y[16]={ 0,  0,  0,  1,  1,  0,  3,  4,  0,  0,  0,  2,  1,  0,  1,  0 };
    unsigned char ipfun_b25 = 0;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
    fun = ((IMPREG_IPFUN_READ() >> 28) & 0x000f);
    fun2 = ((IMPREG_IPFUN2_READ() >> 28) & 0x000f);
    subfun = (((IMPREG_IPFUN_READ())>>24) & 0x000f);
    pre_en = (((IMPREG_IPFUN_READ())>>12) & 0x000f);
    post_en = ((IMPREG_IPFUN_READ()) & 0x0fff);
	sqrt_en = ((IMPREG_IPFUN2_READ() >>12) & 0x0001);
	
    pcma = ((IMPREG_IPFUN_READ() >> 14) & 0x0001);
    pcmb = ((IMPREG_IPFUN_READ() >> 13) & 0x0001);
    bcm_en = ((IMPREG_IPFUN_READ() >> 9) & 0x0001);
    p = ((IMPREG_IPFUN_READ() >> 12) & 0x000f);
    b = ((IMPREG_IPFUN_READ() >> 4) & 0x00ff);
    dest_dt = ((IMPREG_IPFUN_READ() >> 16) & 0x0003);
    outsel = (IMPREG_KNLMSK_READ() & 0x0003);
    bitsel = ((IMPREG_KNLMSK_READ() >> 4) & 0x0007);
    m5x5 = (((IMPREG_KNLMSK_READ())>>9) & 0x0003);
	post_om = (IPFORM_BACKUP >> 28) & 0x0007;
	kernel = ((IMPREG_IPFUN_READ()>>27) & 0x0001);

    ap_x = (IMPREG_APDLY_READ() & 0x007f);
    ap_y = ((IMPREG_APDLY_READ() >> 16) & 0x000f);
/* init */
    x = APDLYTbl_x[fun];
    y = APDLYTbl_y[fun];

	mdlab = (((IMPREG_IPFUN_READ())>>7) & 0x0001); /* 0�FNOP,1:sobel FLT */
	pfdst = ((IMPREG_APCFG_READ()>>16) & 0x0007);

	ec_en    = (unsigned char) ((IMPREG_BINTHR_READ() >> 31) & 0x0001);
	dual_en = (unsigned char) ((IMPREG_KNLMSK_READ() >> 11) & 0x0001);

	ec_mode  = (unsigned char) ((IMPREG_BINTHR_READ() >> 13) & 0x0007);
	ec_bin   = (unsigned char) ((IMPREG_BINTHR_READ() >> 29) & 0x0003);

    switch(fun){
	case 0:
		if( (subfun)||(pre_en)||(post_en) ) x = 13;
		
		if((pcma)||(pcmb)) x += 3;
		if(bcm_en) x += 3;
		if(dest_dt==3) x -= 1; 
		break;
	case 1:
		if( (subfun==2)||(subfun==3)||(subfun==7)||(subfun==8)||(subfun==9)||(subfun==10)  ) x = 14;
		
		if((pcma)||(pcmb)) x += 3;
		if(bcm_en) x += 3;
		if(dest_dt==3) x -= 1; 
    	
		break;
    	
	case 3:
		if ((mdlab == 1) && (post_om != 4)) {
			// sobel FLT Help
			x = 22;
			break;
		}
		if (kernel == 0) {
			/* 3x3 */
			x = 18;
			y = 1;
		}  else { // (kernel == 1)
			/* 1x9 */
			if (post_om == 4) { /* 8bpp + 8bpp */
				x = 19;
			} else {
				x = 21;
			}
			y = 0;
		}
		
		if((pcma)||(pcmb)) x += 3;
		if(bcm_en) x += 3;
		if(dest_dt==3) x -= 1; 
		
		if ((ec_en ==1) && (dual_en==1)) {
			if (ec_mode == 5) {
				if ( ec_bin == 0 ) {
					x += 2;
				} else {
					x += 1;
				}
			} else {
				x = 21;
			}
		}
		break;

	case 4:
		if (kernel == 1) {  /* 1x9 */
			x = 23;
			y = 0;
		} else if(kernel == 0) { /* 3x3 */
			x = 20;
			y = 1;
		}
		if((m5x5==1)||(m5x5==2)){
			x = 21;
			y = 2;
		}

    	if((pcma)||(pcmb)) x += 3;
		if(bcm_en) x += 3;
		if(dest_dt==3) x -= 1; 

		break;
#if 0
    case 5:
		if( (subfun==2)||(subfun==3)||(subfun==7)||(subfun==8)||(subfun==9)||(subfun==10) ) {
			if (post_om == 4) { /* 8bpp + 8bpp */
				x = 14;
				if (McomFlg) x = 1;
			} else {
				x = 15;
			}
		} else {
			if (post_om == 4) { /* 8bpp + 8bpp */
				x = 13;
			} else {
				x = 14;
				if (McomFlg) x = 1;
			}
		}
		break;
	case 6:
		if (kernel == 1) {  /* 1x16 */
			x = 0;
			y = 0;
		} else {
			x = 20;
			y = 3;
		}
		break;
#endif

	case 8:
		break;
	case 9:
		break;
	case 10:
		/* 0:ShinLabel,1:KariLabel */
		if (mdlab == 1) {
			x = 11;
		} else {
			x = 15;
		}
		break;
	case 11:
		if (McomFlg) {
			x = 2;
		}
		break;
	case 12:
		x = 14;
		y = 1;
		if(outsel==2){
			 x = 18;
			y = 4;
		}else if(outsel==1){
			if(bitsel==1) x = 15;
			else if(bitsel==2) x = 17;
			else if(bitsel==3) x = 18;
			else if(bitsel==4) x = 20;
			else if(bitsel==5) x = 21;
			else if(bitsel==6) x = 23;
			else if(bitsel==7) x = 24;
		 	y += bitsel;
		}
		break;
	case 13:
		if(subfun & 0x01){  //decode
			x = 6;  
		} else if (subfun==0) {  //encode
			x = 7;  
		}
		break;
	case 14:
		break;
    	
    case 15:
/****** IPFUN2 ******/
        switch(fun2){
		case 0:
			break;

        case 3: // Extended line memory for Convolution
			if(kernel == 0){ 
				/* 5x5 */
				if (post_om == 4) { /* 8bpp + 8bpp */
					x = 18;
				} else {
					x = 19;
				}
				y = 0; // 2line
			} else { // kernel == 1
				/* 1x25 */
				if (post_om == 4) { /* 8bpp + 8bpp */
			    	x = 23;
				} else {
			    	x = 29;
				}
				y = 0;
			}
			break;
		case 4:
			break;

		case 6:
			if ((subfun >= 1) && (subfun < 7)) {
				x = 4;
			}
			else if (subfun == 7) {
				x = 11;
			}
			else if ((subfun >= 8) && (subfun <= 12)) {
				x = 14;
			}
			if(	pfdst != 3) { // not 32bpp
				x += 4;
			}
			break;
		case 7:
			if ((subfun == 0) || (subfun == 1)) {
				x = 4;
			}
			else if (subfun == 3) {
				x = 11;
			}
			else if ((subfun = 10) || (subfun == 11)) {
				x = 14;
			}
			if(	pfdst != 3) { // not 32bpp
				x += 4;
			}
			break;
        default:
			x = ap_x;
			y = ap_y;
            break;
        }
        break;
    default:
		x = ap_x;
		y = ap_y;
    	break;
    }

	if(sqrt_en) x += 6;
	
    *xdly = x - ap_x;
    *ydly = y - ap_y;
    return;
}


/******************************************************************************/
/* GetMaskDly                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-05-00 : 2007/09/07                                                      */
/* 01-05-01 : 2007/09/11                                                      */
/*            Add Convolution5x5                                              */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
static void GetMaskDly(int *x, int *y){
    int fun, fun2, subfun, max5x5, min5x5;

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
    fun = ((IMPREG_IPFUN_READ() >> 28) & 0x000f);
    fun2 = ((IMPREG_IPFUN2_READ() >> 28) & 0x000f);
    subfun = ((IMPREG_IPFUN_READ() >> 24) & 0x000f);
    max5x5 = (((IMPREG_KNLMSK_READ())>>10) & 0x0001);
    min5x5 = (((IMPREG_KNLMSK_READ())>> 9) & 0x0001);

    *x = 0;
    *y = 0;

/* changed x,y */
    if(fun==0x3){ /* Convolution */
        if((subfun & 0x8)==0) {*x=1; *y=1;} /* 3x3 */
        else {*x=8; *y=0;} /* 1x9 */
    }
    if(fun==0x6) {*x=3; *y=3;} /* ExtConvolution */

    if(fun==0x4){ /* RankFLT */
        if( (max5x5==1) ||(min5x5==1) ) {*x=2; *y=2;} /* MIN/MAX */
        else if((subfun & 0x8)==0) {*x=1; *y=1;} /* 3x3 */
        else {*x=8; *y=0;} /* 1x9 */
    }

    if(fun==0x7) {*x=4; *y=4;} /* BinaryImageMatchingFLT */

    if(fun==0xf && fun2==3){ /* Convolution5x5 */
        if((subfun & 0x8)==0) {*x=2; *y=2;} /* 5x5 */
        else {*x=24; *y=0;} /* 1x25 */
    }

    return;
}


/******************************************************************************/
/* WriteHM                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteHM(int ch, int adr, unsigned long data)
{
    unsigned char Tbl[4];

    CnvDataUltoUc(data, Tbl);
    *(pHM[ch]+adr*4  ) = Tbl[0];
    *(pHM[ch]+adr*4+1) = Tbl[1];
    *(pHM[ch]+adr*4+2) = Tbl[2];
    *(pHM[ch]+adr*4+3) = Tbl[3];

    return;
}

/******************************************************************************/
/* ReadBaseAdr                                                                */
/*----------------------------------------------------------------------------*/
/* 02-00-00 : 2008/03/11                                                      */
/******************************************************************************/
void ReadBaseAdr(unsigned char *adr, unsigned long *data)
{
    unsigned char Tbl[4];

    Tbl[0] = *(adr  );
    Tbl[1] = *(adr+1);
    Tbl[2] = *(adr+2);
    Tbl[3] = *(adr+3);

    CnvDataUctoUl(Tbl, data);

    return;
}


/******************************************************************************/
/* WriteBaseAdr                                                               */
/*----------------------------------------------------------------------------*/
/* 02-00-00 : 2008/03/11                                                      */
/******************************************************************************/
void WriteBaseAdr(unsigned char *adr, unsigned long data)
{
    unsigned char Tbl[4];

    CnvDataUltoUc(data, Tbl);
    *(adr  ) = Tbl[0];
    *(adr+1) = Tbl[1];
    *(adr+2) = Tbl[2];
    *(adr+3) = Tbl[3];

    return;
}

/******************************************************************************/
/* ReadHM                                                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void ReadHM(int ch, int adr, unsigned long *data)
{
    unsigned char Tbl[4];

    Tbl[0] = *(pHM[ch]+adr*4  );
    Tbl[1] = *(pHM[ch]+adr*4+1);
    Tbl[2] = *(pHM[ch]+adr*4+2);
    Tbl[3] = *(pHM[ch]+adr*4+3);

    CnvDataUctoUl(Tbl, data);

    return;
}

/******************************************************************************/
/* CnvDataUctoUl                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/12/26                                                      */
/******************************************************************************/
static void CnvDataUctoUl(unsigned char Tbl[], unsigned long *data)
{
    if(ENDIAN){ /* little */
        *data = (unsigned long)( ((Tbl[3]<<24) & 0xff000000)|((Tbl[2]<<16) & 0x00ff0000)|
                                ((Tbl[1]<<8 ) & 0x0000ff00)|((Tbl[0]    ) & 0x000000ff) );
    }else{ /* big */
        *data = (unsigned long)( ((Tbl[0]<<24) & 0xff000000)|((Tbl[1]<<16) & 0x00ff0000)|
                                ((Tbl[2]<<8 ) & 0x0000ff00)|((Tbl[3]    ) & 0x000000ff) );
    }
    return;
}
/******************************************************************************/
/* CnvDataUltoUc                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/12/26                                                      */
/******************************************************************************/
static void CnvDataUltoUc(unsigned long data, unsigned char Tbl[])
{
    if(ENDIAN){ /* little */
        Tbl[3] = (unsigned char)((data>>24)&0xff);
        Tbl[2] = (unsigned char)((data>>16)&0xff);
        Tbl[1] = (unsigned char)((data>> 8)&0xff);
        Tbl[0] = (unsigned char)((data    )&0xff);
    }else{ /* big */
        Tbl[0] = (unsigned char)((data>>24)&0xff);
        Tbl[1] = (unsigned char)((data>>16)&0xff);
        Tbl[2] = (unsigned char)((data>> 8)&0xff);
        Tbl[3] = (unsigned char)((data    )&0xff);
    }
    return;
}

/******************************************************************************/
/* ReadCM0                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void ReadCM0(int ch, int adr, unsigned long *data)
{
    unsigned char Tbl[4];

    Tbl[0] = *(pCM0[ch]+adr*4  );
    Tbl[1] = *(pCM0[ch]+adr*4+1);
    Tbl[2] = *(pCM0[ch]+adr*4+2);
    Tbl[3] = *(pCM0[ch]+adr*4+3);

    CnvDataUctoUl(Tbl, data);

    return;
}
/******************************************************************************/
/* WriteCM0                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteCM0(int ch, int adr, unsigned long data)
{
    unsigned char Tbl[4];

    CnvDataUltoUc(data, Tbl);
    *(pCM0[ch]+adr*4  ) = Tbl[0];
    *(pCM0[ch]+adr*4+1) = Tbl[1];
    *(pCM0[ch]+adr*4+2) = Tbl[2];
    *(pCM0[ch]+adr*4+3) = Tbl[3];

    return;
}

/******************************************************************************/
/* ReadCM1                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void ReadCM1(int ch, int adr, unsigned long *data)
{
    unsigned char Tbl[4];

    Tbl[0] = *(pCM1[ch]+adr*4  );
    Tbl[1] = *(pCM1[ch]+adr*4+1);
    Tbl[2] = *(pCM1[ch]+adr*4+2);
    Tbl[3] = *(pCM1[ch]+adr*4+3);

    CnvDataUctoUl(Tbl, data);

    return;
}
/******************************************************************************/
/* WriteCM1                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteCM1(int ch, int adr, unsigned long data)
{
    unsigned char Tbl[4];

    CnvDataUltoUc(data, Tbl);
    *(pCM1[ch]+adr*4  ) = Tbl[0];
    *(pCM1[ch]+adr*4+1) = Tbl[1];
    *(pCM1[ch]+adr*4+2) = Tbl[2];
    *(pCM1[ch]+adr*4+3) = Tbl[3];

    return;
}


/******************************************************************************/
/* ReadTHTDATA0                                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void ReadTHTDATA0(int ch, int adr, unsigned long *data)
{
    unsigned char Tbl[4];

    Tbl[0] = *(pTHRM0[ch]+adr*4  );
    Tbl[1] = *(pTHRM0[ch]+adr*4+1);
    Tbl[2] = *(pTHRM0[ch]+adr*4+2);
    Tbl[3] = *(pTHRM0[ch]+adr*4+3);

    CnvDataUctoUl(Tbl, data);

    return;
}
/******************************************************************************/
/* WriteTHTDATA0                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteTHTDATA0(int ch, int adr, unsigned long data)
{
    unsigned char Tbl[4];

    CnvDataUltoUc(data, Tbl);
    *(pTHRM0[ch]+adr*4  ) = Tbl[0];
    *(pTHRM0[ch]+adr*4+1) = Tbl[1];
    *(pTHRM0[ch]+adr*4+2) = Tbl[2];
    *(pTHRM0[ch]+adr*4+3) = Tbl[3];

    return;
}

/******************************************************************************/
/* ReadTHTDATA1                                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void ReadTHTDATA1(int ch, int adr, unsigned long *data)
{
    unsigned char Tbl[4];

    Tbl[0] = *(pTHRM1[ch]+adr*4  );
    Tbl[1] = *(pTHRM1[ch]+adr*4+1);
    Tbl[2] = *(pTHRM1[ch]+adr*4+2);
    Tbl[3] = *(pTHRM1[ch]+adr*4+3);

    CnvDataUctoUl(Tbl, data);

    return;
}
/******************************************************************************/
/* WriteTHTDATA1                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteTHTDATA1(int ch, int adr, unsigned long data)
{
    unsigned char Tbl[4];

    CnvDataUltoUc(data, Tbl);
    *(pTHRM1[ch]+adr*4  ) = Tbl[0];
    *(pTHRM1[ch]+adr*4+1) = Tbl[1];
    *(pTHRM1[ch]+adr*4+2) = Tbl[2];
    *(pTHRM1[ch]+adr*4+3) = Tbl[3];

    return;
}
