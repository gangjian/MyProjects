/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG2_0011.c                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-01 : 2015/02/18   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "impsim_int.h"
#include "legacy_sim.h"

#define CELL5x5 25

static int64 IMG_Conv5x5(short m[], int w[]);

#define getreg1(regname, shift)  ((unsigned char)((IMPREG_ ## regname ## _READ()>>shift) & 0x0001))
#define getreg8(regname, shift)  ((IMPREG_ ## regname ## _READ()>>shift) & 0x00ff)


/******************************************************************************/
/* IMG2_0011                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-01 : 2015/02/18   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
int IMG2_0011(){
	long xlng, ylng, Widthcnt, Heightcnt;
	int i, datatype;
	short *soura_0 = psLM0;
	short *soura_1 = psLM1;
	short *soura_2 = psLM2;
	short *soura_3 = psLM3;
	short *soura_4 = psLM4;
	short *temp;
	short m[CELL5x5];
	unsigned char srca_ind_om;
	unsigned char kernel, edge, lm_mode, msk, kmsk[CELL5x5], soura_dt;
	int weight[CELL5x5];
	int64 result[LINE_SIZE], scale;
	
	/* Load resister values */
	xlng = IMPREG_APLNG_READ() & 0x3fff;
	ylng = (IMPREG_APLNG_READ() >>16) & 0x3fff;
	kernel = (char)((IMPREG_IPFUN_READ()>>27) & 0x0001);
	edge = (char)((IMPREG_IPFUN_READ()>>24) & 0x0003);
	lm_mode = getreg1(KNLMSK, 29);
	soura_dt = (char)((IMPREG_IPFUN_READ()>>22) & 0x0003);
	srca_ind_om = (unsigned char) ((IMPREG_IPFORM_READ() >> 16) & 0x0007);
	
	if(soura_dt == 0){
		datatype = PXLS8BPP;
	} else if(soura_dt == 1){
		datatype = PXLU8BPP;
	} else if(soura_dt == 2){
		datatype = PXL1BPP;
	} else if(soura_dt == 3){
		datatype = PXLCOLDIFF;
    }
	if (srca_ind_om == 2) {
		datatype = PXL16BPP;
	}

	if (datatype == PXL16BPP) {
		for (i=0, scale=1; i<(signed int)((IMPREG_IPFUN2_READ() & 0x000f)<<4 | (IMPREG_IPFUN_READ() & 0x000f)); i++) {
			scale *= 2;
		}
	} else {
		for (i=0, scale=1; i<(signed int)(IMPREG_IPFUN_READ() & 0x000f); i++) {
			scale *= 2;
		}
	}
	
	/* ---getting 16 coefficients--- */
	weight[0]  = getreg8(COEFF02, 18);
	weight[1]  = getreg8(COEFF02, 9);
	weight[2]  = getreg8(COEFF02, 0);
	weight[3]  = getreg8(COEFF35, 18);
	weight[4]  = getreg8(COEFF35, 9);
	weight[5]  = getreg8(COEFF35, 0);
	weight[6]  = getreg8(COEFF68, 18);
	weight[7]  = getreg8(COEFF68, 9);
	weight[8]  = getreg8(COEFF68, 0);
	weight[9]  = getreg8(COEFF911, 18);
	weight[10] = getreg8(COEFF911, 9);
	weight[11] = getreg8(COEFF911, 0);
	weight[12] = getreg8(COEFF1214, 18);
	weight[13] = getreg8(COEFF1214, 9);
	weight[14] = getreg8(COEFF1214, 0);
	weight[15] = getreg8(COEFF15, 18);
	weight[16] = getreg8(COEFF15, 9);
	weight[17] = getreg8(COEFF15, 0);
	weight[18] = getreg8(COEFF1820, 18);
	weight[19] = getreg8(COEFF1820, 9);
	weight[20] = getreg8(COEFF1820, 0);
	weight[21] = getreg8(COEFF2123, 18);
	weight[22] = getreg8(COEFF2123, 9);
	weight[23] = getreg8(COEFF2123, 0);
	weight[24] = getreg8(COEFF24, 18);

    if (datatype == PXL16BPP) {
	    weight[0]  |= ((getreg8(COEFF02H,   16)<<8) & 0xff00);
	    weight[1]  |= ((getreg8(COEFF02H,    8)<<8) & 0xff00);
	    weight[2]  |= ((getreg8(COEFF02H,    0)<<8) & 0xff00);
	    weight[3]  |= ((getreg8(COEFF35H,   16)<<8) & 0xff00);
	    weight[4]  |= ((getreg8(COEFF35H,    8)<<8) & 0xff00);
	    weight[5]  |= ((getreg8(COEFF35H,    0)<<8) & 0xff00);
	    weight[6]  |= ((getreg8(COEFF68H,   16)<<8) & 0xff00);
	    weight[7]  |= ((getreg8(COEFF68H,    8)<<8) & 0xff00);
	    weight[8]  |= ((getreg8(COEFF68H,    0)<<8) & 0xff00);
	    weight[9]  |= ((getreg8(COEFF911H,  16)<<8) & 0xff00);
	    weight[10] |= ((getreg8(COEFF911H,   8)<<8) & 0xff00);
	    weight[11] |= ((getreg8(COEFF911H,   0)<<8) & 0xff00);
	    weight[12] |= ((getreg8(COEFF1214H, 16)<<8) & 0xff00);
	    weight[13] |= ((getreg8(COEFF1214H,  8)<<8) & 0xff00);
	    weight[14] |= ((getreg8(COEFF1214H,  0)<<8) & 0xff00);
	    weight[15] |= ((getreg8(COEFF1517H, 16)<<8) & 0xff00);
	    weight[16] |= ((getreg8(COEFF1517H,  8)<<8) & 0xff00);
	    weight[17] |= ((getreg8(COEFF1517H,  0)<<8) & 0xff00);
	    weight[18] |= ((getreg8(COEFF1820H, 16)<<8) & 0xff00);
	    weight[19] |= ((getreg8(COEFF1820H,  8)<<8) & 0xff00);
	    weight[20] |= ((getreg8(COEFF1820H,  0)<<8) & 0xff00);
	    weight[21] |= ((getreg8(COEFF2123H, 16)<<8) & 0xff00);
	    weight[22] |= ((getreg8(COEFF2123H,  8)<<8) & 0xff00);
	    weight[23] |= ((getreg8(COEFF2123H,  0)<<8) & 0xff00);
	    weight[24] |= ((getreg8(COEFF24H,   16)<<8) & 0xff00);

	    if (getreg1(COEFF02H,23))   weight[0]  |= 0xffff0000;
	    if (getreg1(COEFF02H,15))   weight[1]  |= 0xffff0000;
	    if (getreg1(COEFF02H,7))    weight[2]  |= 0xffff0000;
	    if (getreg1(COEFF35H,23))   weight[3]  |= 0xffff0000;
	    if (getreg1(COEFF35H,15))   weight[4]  |= 0xffff0000;
	    if (getreg1(COEFF35H,7))    weight[5]  |= 0xffff0000;
	    if (getreg1(COEFF68H,23))   weight[6]  |= 0xffff0000;
	    if (getreg1(COEFF68H,15))   weight[7]  |= 0xffff0000;
	    if (getreg1(COEFF68H,7))    weight[8]  |= 0xffff0000;
	    if (getreg1(COEFF911H,23))  weight[9]  |= 0xffff0000;
	    if (getreg1(COEFF911H,15))  weight[10] |= 0xffff0000;
	    if (getreg1(COEFF911H,7))   weight[11] |= 0xffff0000;
	    if (getreg1(COEFF1214H,23)) weight[12] |= 0xffff0000;
	    if (getreg1(COEFF1214H,15)) weight[13] |= 0xffff0000;
	    if (getreg1(COEFF1214H,7))  weight[14] |= 0xffff0000;
	    if (getreg1(COEFF1517H,23)) weight[15] |= 0xffff0000;
	    if (getreg1(COEFF1517H,15)) weight[16] |= 0xffff0000;
	    if (getreg1(COEFF1517H,7))  weight[17] |= 0xffff0000;
	    if (getreg1(COEFF1820H,23)) weight[18] |= 0xffff0000;
	    if (getreg1(COEFF1820H,15)) weight[19] |= 0xffff0000;
	    if (getreg1(COEFF1820H,7))  weight[20] |= 0xffff0000;
	    if (getreg1(COEFF2123H,23)) weight[21] |= 0xffff0000;
	    if (getreg1(COEFF2123H,15)) weight[22] |= 0xffff0000;
	    if (getreg1(COEFF2123H,7))  weight[23] |= 0xffff0000;
	    if (getreg1(COEFF24H,23))   weight[24] |= 0xffff0000;
    } else {
	    if (getreg1(COEFF02,26))    weight[0]  |= 0xffffff00;
	    if (getreg1(COEFF02,17))    weight[1]  |= 0xffffff00;
	    if (getreg1(COEFF02,8))     weight[2]  |= 0xffffff00;
	    if (getreg1(COEFF35,26))    weight[3]  |= 0xffffff00;
	    if (getreg1(COEFF35,17))    weight[4]  |= 0xffffff00;
	    if (getreg1(COEFF35,8))     weight[5]  |= 0xffffff00;
	    if (getreg1(COEFF68,26))    weight[6]  |= 0xffffff00;
	    if (getreg1(COEFF68,17))    weight[7]  |= 0xffffff00;
	    if (getreg1(COEFF68,8))     weight[8]  |= 0xffffff00;
	    if (getreg1(COEFF911,26))   weight[9]  |= 0xffffff00;
	    if (getreg1(COEFF911,17))   weight[10] |= 0xffffff00;
	    if (getreg1(COEFF911,8))    weight[11] |= 0xffffff00;
	    if (getreg1(COEFF1214,26))  weight[12] |= 0xffffff00;
	    if (getreg1(COEFF1214,17))  weight[13] |= 0xffffff00;
	    if (getreg1(COEFF1214,8))   weight[14] |= 0xffffff00;
	    if (getreg1(COEFF15,26))    weight[15] |= 0xffffff00;
	    if (getreg1(COEFF15,17))    weight[16] |= 0xffffff00;
	    if (getreg1(COEFF15,8))     weight[17] |= 0xffffff00;
	    if (getreg1(COEFF1820,26))  weight[18] |= 0xffffff00;
	    if (getreg1(COEFF1820,17))  weight[19] |= 0xffffff00;
	    if (getreg1(COEFF1820,8))   weight[20] |= 0xffffff00;
	    if (getreg1(COEFF2123,26))  weight[21] |= 0xffffff00;
	    if (getreg1(COEFF2123,17))  weight[22] |= 0xffffff00;
	    if (getreg1(COEFF2123,8))   weight[23] |= 0xffffff00;
	    if (getreg1(COEFF24,26))    weight[24] |= 0xffffff00;
    }
	
	msk = getreg1(IPFUN, 26);	/* 'Enable' or 'Disable' about kernel mask */
	if(msk==1){
		for(i=0;i<9;i++){
			kmsk[i] = getreg1(KNLMSK, (short)i);
			if(kmsk[i])	weight[i] = 0;
		}
		for(i=9;i<18;i++){
			kmsk[i] = getreg1(KNLMSK, (short)(i+7));
			if(kmsk[i])	weight[i] = 0;
		}
		for(i=18;i<25;i++){
			kmsk[i] = getreg1(KNLMSK2, (short)(i-18));
			if(kmsk[i])	weight[i] = 0;
		}
	}
	
	Heightcnt = 0;
	
	if (kernel == 0) {
		/* 5x5 */
		if (McomFlg) {
			Widthcnt = 0;
			while (Widthcnt < xlng) {
			/* middle(center?) lines */
				if (Widthcnt == 0) {
					/* make edge process at the left side */
					m[18] = ReadLM256A(4, Widthcnt);
					m[10] = ReadLM256A(3, Widthcnt);
					m[0] = ReadLM256A(2, Widthcnt);
					m[3] = ReadLM256A(1, Widthcnt);
					m[6] = ReadLM256A(0, Widthcnt);
					m[19] = ReadLM256A(4, Widthcnt+1);
					m[11] = ReadLM256A(3, Widthcnt+1);
					m[1] = ReadLM256A(2, Widthcnt+1);
					m[4] = ReadLM256A(1, Widthcnt+1);
					m[7] = ReadLM256A(0, Widthcnt+1);
					m[20] = ReadLM256A(4, Widthcnt+2);
					m[12] = ReadLM256A(3, Widthcnt+2);
					m[2] = ReadLM256A(2, Widthcnt+2);
					m[5] = ReadLM256A(1, Widthcnt+2);
					m[8] = ReadLM256A(0, Widthcnt+2);
					
					if (edge == 3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)ReadLM256A(2, Widthcnt) * (int64)scale;
					}
				} else if (Widthcnt == 1) {
					m[17] = m[18];  m[18] = m[19];	m[19] = m[20];	m[20] = ReadLM256A(4, Widthcnt+2);
					m[9] = m[10];   m[10] = m[11];	m[11] = m[12];	m[12] = ReadLM256A(3, Widthcnt+2);
					m[13] = m[0];   m[0] = m[1];	m[1] = m[2];	m[2] = ReadLM256A(2, Widthcnt+2);
					m[14] = m[3];   m[3] = m[4];	m[4] = m[5];	m[5] = ReadLM256A(1, Widthcnt+2);
					m[15] = m[6];   m[6] = m[7];	m[7] = m[8];	m[8] = ReadLM256A(0, Widthcnt+2);
					
					if (edge == 3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)ReadLM256A(2, Widthcnt) * (int64)scale;
					}
				} else if ((Widthcnt == xlng-1) || (Widthcnt == xlng-2)) {
				/* only make edge process at the right side */
					if (edge==3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)ReadLM256A(2, Widthcnt) * (int64)scale;
					}
				} else {
					/* center */
					m[16] = m[17];   m[17] = m[18];  m[18] = m[19];  m[19] = m[20];  m[20] = ReadLM256A(4, Widthcnt+2);
					m[21] = m[9];    m[9] = m[10];   m[10] = m[11];  m[11] = m[12];  m[12] = ReadLM256A(3, Widthcnt+2);
					m[22] = m[13];   m[13] = m[0];   m[0] = m[1];    m[1] = m[2];    m[2] = ReadLM256A(2, Widthcnt+2);
					m[23] = m[14];   m[14] = m[3];   m[3] = m[4];    m[4] = m[5];    m[5] = ReadLM256A(1, Widthcnt+2);
					m[24] = m[15];   m[15] = m[6];   m[6] = m[7];    m[7] = m[8];    m[8] = ReadLM256A(0, Widthcnt+2);
					result[Widthcnt] = IMG_Conv5x5(m, weight);
				}
				Widthcnt++;
			}
			Write1LineDst(0, result);
		} else {
			while (Heightcnt <= ylng+1) {
				if (Heightcnt < ylng) {
					Read1LineSrc0(Heightcnt, soura_0);
				}
				Widthcnt = 0;
				while (Widthcnt < xlng) {
					if (Heightcnt == ylng+1) {
						if (edge == 3) {
							result[Widthcnt] = 0;
						} else if (edge == 1) {
							result[Widthcnt] = (int64)soura_1[Widthcnt] * (int64)scale;
						}
					} else if (Widthcnt == 0) {
					/* make edge process at the left side */
						m[18] = soura_4[Widthcnt];
						m[10] = soura_3[Widthcnt];
						m[0]  = soura_2[Widthcnt];
						m[3]  = soura_1[Widthcnt];
						m[6]  = soura_0[Widthcnt];
						m[19] = soura_4[Widthcnt+1];
						m[11] = soura_3[Widthcnt+1];
						m[1]  = soura_2[Widthcnt+1];
						m[4]  = soura_1[Widthcnt+1];
						m[7]  = soura_0[Widthcnt+1];
						m[20] = soura_4[Widthcnt+2];
						m[12] = soura_3[Widthcnt+2];
						m[2]  = soura_2[Widthcnt+2];
						m[5]  = soura_1[Widthcnt+2];
						m[8]  = soura_0[Widthcnt+2];
						if (edge == 3) {
							result[Widthcnt] = 0;
						} else if (edge == 1) {
							result[Widthcnt] = (int64)soura_2[Widthcnt] * (int64)scale;
						} else {
							result[Widthcnt] = IMG_Conv5x5(m, weight);
						}
					} else if (Widthcnt == 1) {
						m[17] = m[18];  m[18] = m[19];  m[19] = m[20];  m[20] = soura_4[Widthcnt+2];
						m[9] = m[10];   m[10] = m[11];  m[11] = m[12];  m[12] = soura_3[Widthcnt+2];
						m[13] = m[0];   m[0] = m[1];    m[1] = m[2];    m[2]  = soura_2[Widthcnt+2];
						m[14] = m[3];   m[3] = m[4];    m[4] = m[5];    m[5]  = soura_1[Widthcnt+2];
						m[15] = m[6];   m[6] = m[7];    m[7] = m[8];    m[8]  = soura_0[Widthcnt+2];	/* =[2] */
						if (edge == 3) {
							result[Widthcnt] = 0;
						} else if (edge == 1) {
							result[Widthcnt] = (int64)soura_2[Widthcnt] * (int64)scale;
						} else {
							result[Widthcnt] = IMG_Conv5x5(m, weight);
						}
					} else if ((Widthcnt == xlng-2) || (Widthcnt == xlng-1)) {
						/* only make edge process at the right side */
						if (edge == 3) {
							result[Widthcnt] = 0;
						} else if (edge == 1) {
							result[Widthcnt] = (int64)soura_2[Widthcnt] * (int64)scale;
						} else {
							result[Widthcnt] = IMG_Conv5x5(m, weight);
						}
					} else {
						/* center */
						m[16] = m[17];   m[17] = m[18];  m[18] = m[19];  m[19] = m[20];  m[20] = soura_4[Widthcnt+2];
 						m[21] = m[9];    m[9] = m[10];   m[10] = m[11];  m[11] = m[12];  m[12] = soura_3[Widthcnt+2];
 						m[22] = m[13];   m[13] = m[0];   m[0] = m[1];    m[1] = m[2];    m[2]  = soura_2[Widthcnt+2];
						m[23] = m[14];   m[14] = m[3];   m[3] = m[4];    m[4] = m[5];    m[5]  = soura_1[Widthcnt+2];
						m[24] = m[15];   m[15] = m[6];   m[6] = m[7];    m[7] = m[8];    m[8]  = soura_0[Widthcnt+2];
						if (Heightcnt <= 3 || Heightcnt >= ylng) {
							if (edge == 3) {
								result[Widthcnt] = 0;
							} else if (edge == 1) {
								result[Widthcnt] = (int64)soura_2[Widthcnt] * (int64)scale;
							} else {
								result[Widthcnt] = IMG_Conv5x5(m, weight);
							}
						} else {
							result[Widthcnt] = IMG_Conv5x5(m, weight);
						}
					}
					Widthcnt++;
				}
				if (Heightcnt < ylng) {
					// soura
					temp = soura_4;
					soura_4 = soura_3;
					soura_3 = soura_2;
					soura_2 = soura_1;
					soura_1 = soura_0;
					soura_0 = temp;
				}
				Write1LineDst(Heightcnt, result);
				Heightcnt++;
			}
		}
	} else if(kernel==1){
		/* 1x25 */
		if (McomFlg) {
			ylng = 1;
		}
		
		while (Heightcnt < ylng) {
			if (McomFlg) {
				Read1LineLM256A(Heightcnt, soura_0);
			} else{ 
				Read1LineSrc0(Heightcnt, soura_0);
			}
			
			Widthcnt = 0;
			while (Widthcnt < xlng) {
				/* make edge process at the left side */
				if (Widthcnt < 12) {
					if (Widthcnt == 11) {
						m[17] = soura_0[0];
						m[18] = soura_0[1];
						m[19] = soura_0[2];
						m[20] = soura_0[3];
						m[21] = soura_0[4];
						m[9] = soura_0[5];
						m[10] = soura_0[6];
						m[11] = soura_0[7];
						m[12] = soura_0[8];
						m[22] = soura_0[9];
						m[13] = soura_0[10];
						m[0] = soura_0[11];
						m[1] = soura_0[12];
						m[2] = soura_0[13];
						m[23] = soura_0[14];
						m[14] = soura_0[15];
						m[3] = soura_0[16];
						m[4] = soura_0[17];
						m[5] = soura_0[18];
						m[24] = soura_0[19];
						m[15] = soura_0[20];
						m[6] = soura_0[21];
						m[7] = soura_0[22];
						m[8] = soura_0[23];
					}
					if (edge==3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)soura_0[Widthcnt] * (int64)scale;
					}
				} else if (Widthcnt > xlng-13) {
					/* make edge process at the right side */
					if (edge == 3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)soura_0[Widthcnt] * (int64)scale;
					}
				} else {
					/* center */
					m[16] = m[17];
					m[17] = m[18];
					m[18] = m[19];
					m[19] = m[20];
					m[20] = m[21];
					m[21] = m[9];
					m[9] = m[10];
					m[10] = m[11];
					m[11] = m[12];
					m[12] = m[22];
					m[22] = m[13];
					m[13] = m[0];
					m[0] = m[1];
					m[1] = m[2];
					m[2] = m[23];
					m[23] = m[14];
					m[14] = m[3];
					m[3] = m[4];
					m[4] = m[5];
					m[5] = m[24];
					m[24] = m[15];
					m[15] = m[6];
					m[6] = m[7];
					m[7] = m[8];
					m[8] = soura_0[Widthcnt+12];
					
					result[Widthcnt] = IMG_Conv5x5(m, weight);
				}
				Widthcnt++;
			}
			Write1LineDst(Heightcnt, result);
			Heightcnt++;
		}
	}
	return 0;
}


/******************************************************************************/
/* IMG_Conv5x5                                                                */
/*----------------------------------------------------------------------------*/
/* 01-00-01 : 2015/02/18   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int64 IMG_Conv5x5(short m[], int w[])
{
	int i;
	int64 temp;
	
	temp = 0;
	for (i = 0; i < CELL5x5; i++) {
		temp += (int64)w[i] * (int64)m[i];
	}
	
	return temp;
}


