/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_1100.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif
#include "impsim_int.h"
#include "legacy_sim.h"

static short IMG_1100_Filter(short m[], int fun, int conect);
static int64 IMG_1100_logicfun(short ImgA, short ImgB, int logicfun);


/******************************************************************************/
/* IMG_1100                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16                                                      */
/******************************************************************************/
int IMG_1100(){
	long xlng, ylng;
	int kernel, pack, edgecnt, fun[9], conect[9];
	int divcnt, bitsel, logicfun, outsel;
	short m[9], data[6];
	int64 result[LINE_SIZE], resultwork;
	int cnt, cnt_i, cnt_j, cnt_k, cnt_x, cnt_pre, cnt_post;
	
	// PIPE is not supported
	if (McomFlg) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (PIPE) on IMG_1100.\n");
		Legacy_assert_error();
	}
	
	kernel   = (((IMPREG_IPFUN_READ())>>27) & 0x0001);
	if (kernel == 1) {
		SIMLOG(SL_LS, SL_L4, "Error kernel=%d on IMG_1100.\n",kernel);
		Legacy_assert_error();
	}
	
	pack     = (((IMPREG_IPFUN_READ())>>26) & 0x0001);
	edgecnt  = (((IMPREG_IPFUN_READ())>>24) & 0x0003);
	divcnt   = (((IMPREG_KNLMSK_READ())>>7) & 0x0001);
	bitsel   = (((IMPREG_KNLMSK_READ())>>4) & 0x0007);
	logicfun = (((IMPREG_KNLMSK_READ())>>2) & 0x0003);
	outsel   = (((IMPREG_KNLMSK_READ())   ) & 0x0003);
	SIMLOG(SL_LS, SL_L4, "kernel=%d pack=%d edgecnt=%d divcnt=%d bitsel=%d logicfun=%d outsel=%d\n",kernel,pack,edgecnt,divcnt,bitsel,logicfun,outsel);
	
	fun[0] = (((IMPREG_COEFF02_READ())>>19) & 0x000f); conect[0] = (((IMPREG_COEFF02_READ())>>18) & 0x0001);
	fun[1] = (((IMPREG_COEFF02_READ())>>10) & 0x000f); conect[1] = (((IMPREG_COEFF02_READ())>> 9) & 0x0001);
	fun[2] = (((IMPREG_COEFF02_READ())>> 1) & 0x000f); conect[2] = (((IMPREG_COEFF02_READ())    ) & 0x0001);
	fun[3] = (((IMPREG_COEFF35_READ())>>19) & 0x000f); conect[3] = (((IMPREG_COEFF35_READ())>>18) & 0x0001);
	fun[4] = (((IMPREG_COEFF35_READ())>>10) & 0x000f); conect[4] = (((IMPREG_COEFF35_READ())>> 9) & 0x0001);
	fun[5] = (((IMPREG_COEFF35_READ())>> 1) & 0x000f); conect[5] = (((IMPREG_COEFF35_READ())    ) & 0x0001);
	fun[6] = (((IMPREG_COEFF68_READ())>>19) & 0x000f); conect[6] = (((IMPREG_COEFF68_READ())>>18) & 0x0001);
	fun[7] = (((IMPREG_COEFF68_READ())>>10) & 0x000f); conect[7] = (((IMPREG_COEFF68_READ())>> 9) & 0x0001);
	
	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
	ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
	
	if (pack == 0) { // no pack data
		for (cnt_i=0; cnt_i<(ylng+8); cnt_i++) {
			
			// img 0 : Src
			if (cnt_i<ylng) {
				cnt_k = cnt_i % LINE_NUM;
				Read1LineSrc0(cnt_i, pLINE0[cnt_k]);
			}
			
			// img 1
			if ((cnt_i>=1) && (cnt_i<(ylng+1))) {
				cnt_j = cnt_i-1;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<1) || (cnt_j>=(ylng-1))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE1[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<1) || (cnt_x>=(xlng-1))) {
							*(pLINE1[cnt_k] + cnt_x) = 0;
						} else {
							m[0] = *(pLINE0[cnt_pre] + cnt_x-1);
							m[1] = *(pLINE0[cnt_pre] + cnt_x);
							m[2] = *(pLINE0[cnt_pre] + cnt_x+1);
							m[3] = *(pLINE0[cnt_k] + cnt_x-1);
							m[4] = *(pLINE0[cnt_k] + cnt_x);
							m[5] = *(pLINE0[cnt_k] + cnt_x+1);
							m[6] = *(pLINE0[cnt_post] + cnt_x-1);
							m[7] = *(pLINE0[cnt_post] + cnt_x);
							m[8] = *(pLINE0[cnt_post] + cnt_x+1);
							
							*(pLINE1[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[0], conect[0]);
						}
					}
				}
			}
			
			// img 2
			if ((cnt_i>=2) && (cnt_i<(ylng+2))) {
				cnt_j = cnt_i-2;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<2) || (cnt_j>=(ylng-2))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE2[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<2) || (cnt_x>=(xlng-2))) {
							*(pLINE2[cnt_k] + cnt_x) = 0;
						} else {
							m[0] = *(pLINE1[cnt_pre] + cnt_x-1);
							m[1] = *(pLINE1[cnt_pre] + cnt_x);
							m[2] = *(pLINE1[cnt_pre] + cnt_x+1);
							m[3] = *(pLINE1[cnt_k] + cnt_x-1);
							m[4] = *(pLINE1[cnt_k] + cnt_x);
							m[5] = *(pLINE1[cnt_k] + cnt_x+1);
							m[6] = *(pLINE1[cnt_post] + cnt_x-1);
							m[7] = *(pLINE1[cnt_post] + cnt_x);
							m[8] = *(pLINE1[cnt_post] + cnt_x+1);
							
							*(pLINE2[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[1], conect[1]);
						}
					}
				}
			}
			
			// img 3
			if ((cnt_i>=3) && (cnt_i<(ylng+3))) {
				cnt_j = cnt_i-3;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<3) || (cnt_j>=(ylng-3))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE3[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<3) || (cnt_x>=(xlng-3))) {
							*(pLINE3[cnt_k] + cnt_x) = 0;
						} else {
							m[0] = *(pLINE2[cnt_pre] + cnt_x-1);
							m[1] = *(pLINE2[cnt_pre] + cnt_x);
							m[2] = *(pLINE2[cnt_pre] + cnt_x+1);
							m[3] = *(pLINE2[cnt_k] + cnt_x-1);
							m[4] = *(pLINE2[cnt_k] + cnt_x);
							m[5] = *(pLINE2[cnt_k] + cnt_x+1);
							m[6] = *(pLINE2[cnt_post] + cnt_x-1);
							m[7] = *(pLINE2[cnt_post] + cnt_x);
							m[8] = *(pLINE2[cnt_post] + cnt_x+1);
							
							*(pLINE3[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[2], conect[2]);
						}
					}
				}
			}
			
			// img 4
			if ((cnt_i>=4) && (cnt_i<(ylng+4))) {
				cnt_j = cnt_i-4;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<4) || (cnt_j>=(ylng-4))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE4[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<4) || (cnt_x>=(xlng-4))) {
							*(pLINE4[cnt_k] + cnt_x) = 0;
						} else {
							m[0] = *(pLINE3[cnt_pre] + cnt_x-1);
							m[1] = *(pLINE3[cnt_pre] + cnt_x);
							m[2] = *(pLINE3[cnt_pre] + cnt_x+1);
							m[3] = *(pLINE3[cnt_k] + cnt_x-1);
							m[4] = *(pLINE3[cnt_k] + cnt_x);
							m[5] = *(pLINE3[cnt_k] + cnt_x+1);
							m[6] = *(pLINE3[cnt_post] + cnt_x-1);
							m[7] = *(pLINE3[cnt_post] + cnt_x);
							m[8] = *(pLINE3[cnt_post] + cnt_x+1);
							
							*(pLINE4[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[3], conect[3]);
						}
					}
				}
			}
			
			// img 5
			if ((cnt_i>=5) && (cnt_i<(ylng+5))) {
				cnt_j = cnt_i-5;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<5) || (cnt_j>=(ylng-5))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE5[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<5) || (cnt_x>=(xlng-5))) {
							*(pLINE5[cnt_k] + cnt_x) = 0;
						} else {
							if (divcnt == 1) {
								m[0] = *(pLINE0[cnt_pre] + cnt_x-1);
								m[1] = *(pLINE0[cnt_pre] + cnt_x);
								m[2] = *(pLINE0[cnt_pre] + cnt_x+1);
								m[3] = *(pLINE0[cnt_k] + cnt_x-1);
								m[4] = *(pLINE0[cnt_k] + cnt_x);
								m[5] = *(pLINE0[cnt_k] + cnt_x+1);
								m[6] = *(pLINE0[cnt_post] + cnt_x-1);
								m[7] = *(pLINE0[cnt_post] + cnt_x);
								m[8] = *(pLINE0[cnt_post] + cnt_x+1);
							} else {
								m[0] = *(pLINE4[cnt_pre] + cnt_x-1);
								m[1] = *(pLINE4[cnt_pre] + cnt_x);
								m[2] = *(pLINE4[cnt_pre] + cnt_x+1);
								m[3] = *(pLINE4[cnt_k] + cnt_x-1);
								m[4] = *(pLINE4[cnt_k] + cnt_x);
								m[5] = *(pLINE4[cnt_k] + cnt_x+1);
								m[6] = *(pLINE4[cnt_post] + cnt_x-1);
								m[7] = *(pLINE4[cnt_post] + cnt_x);
								m[8] = *(pLINE4[cnt_post] + cnt_x+1);
							}
							
							*(pLINE5[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[4], conect[4]);
						}
					}
				}
			}
			
			// img 6
			if ((cnt_i>=6) && (cnt_i<(ylng+6))) {
				cnt_j = cnt_i-6;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<6) || (cnt_j>=(ylng-6))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE6[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<6) || (cnt_x>=(xlng-6))) {
							*(pLINE6[cnt_k] + cnt_x) = 0;
						} else {
							m[0] = *(pLINE5[cnt_pre] + cnt_x-1);
							m[1] = *(pLINE5[cnt_pre] + cnt_x);
							m[2] = *(pLINE5[cnt_pre] + cnt_x+1);
							m[3] = *(pLINE5[cnt_k] + cnt_x-1);
							m[4] = *(pLINE5[cnt_k] + cnt_x);
							m[5] = *(pLINE5[cnt_k] + cnt_x+1);
							m[6] = *(pLINE5[cnt_post] + cnt_x-1);
							m[7] = *(pLINE5[cnt_post] + cnt_x);
							m[8] = *(pLINE5[cnt_post] + cnt_x+1);
							
							*(pLINE6[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[5], conect[5]);
						}
					}
				}
			}
			
			// img 7
			if ((cnt_i>=7) && (cnt_i<(ylng+7))) {
				cnt_j = cnt_i-7;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<7) || (cnt_j>=(ylng-7))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE7[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<7) || (cnt_x>=(xlng-7))) {
							*(pLINE7[cnt_k] + cnt_x) = 0;
						} else {
							m[0] = *(pLINE6[cnt_pre] + cnt_x-1);
							m[1] = *(pLINE6[cnt_pre] + cnt_x);
							m[2] = *(pLINE6[cnt_pre] + cnt_x+1);
							m[3] = *(pLINE6[cnt_k] + cnt_x-1);
							m[4] = *(pLINE6[cnt_k] + cnt_x);
							m[5] = *(pLINE6[cnt_k] + cnt_x+1);
							m[6] = *(pLINE6[cnt_post] + cnt_x-1);
							m[7] = *(pLINE6[cnt_post] + cnt_x);
							m[8] = *(pLINE6[cnt_post] + cnt_x+1);
							
							*(pLINE7[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[6], conect[6]);
						}
					}
				}
			}
			
			// img 8
			if ( cnt_i>=8 ) {  /* && (cnt_i<(ylng+8) */
				cnt_j = cnt_i-8;
				cnt_k = cnt_j % LINE_NUM;
				cnt_pre  = (cnt_k + LINE_NUM - 1) % LINE_NUM;
				cnt_post = (cnt_k + 1) % LINE_NUM;
				if ((cnt_j<8) || (cnt_j>=(ylng-8))) {
					// zero
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						*(pLINE8[cnt_k] + cnt_x) = 0;
					}
				} else {
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						if ((cnt_x<8) || (cnt_x>=(xlng-8))) {
							*(pLINE8[cnt_k] + cnt_x) = 0;
						} else {
							m[0] = *(pLINE7[cnt_pre] + cnt_x-1);
							m[1] = *(pLINE7[cnt_pre] + cnt_x);
							m[2] = *(pLINE7[cnt_pre] + cnt_x+1);
							m[3] = *(pLINE7[cnt_k] + cnt_x-1);
							m[4] = *(pLINE7[cnt_k] + cnt_x);
							m[5] = *(pLINE7[cnt_k] + cnt_x+1);
							m[6] = *(pLINE7[cnt_post] + cnt_x-1);
							m[7] = *(pLINE7[cnt_post] + cnt_x);
							m[8] = *(pLINE7[cnt_post] + cnt_x+1);
							
							*(pLINE8[cnt_k] + cnt_x) = IMG_1100_Filter(m, fun[7], conect[7]);
						}
					}
				}
				
				// result
				if (outsel == 0) { // 8bit
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						resultwork  = (*(pLINE1[cnt_k] + cnt_x) >> 7) & 0x0001;
						resultwork |= (*(pLINE2[cnt_k] + cnt_x) >> 6) & 0x0002;
						resultwork |= (*(pLINE3[cnt_k] + cnt_x) >> 5) & 0x0004;
						resultwork |= (*(pLINE4[cnt_k] + cnt_x) >> 4) & 0x0008;
						resultwork |= (*(pLINE5[cnt_k] + cnt_x) >> 3) & 0x0010;
						resultwork |= (*(pLINE6[cnt_k] + cnt_x) >> 2) & 0x0020;
						resultwork |= (*(pLINE7[cnt_k] + cnt_x) >> 1) & 0x0040;
						resultwork |= (*(pLINE8[cnt_k] + cnt_x)     ) & 0x0080;
						if (resultwork & 0x0080) {
							result[cnt_x] = resultwork | 0xffffffffffffff00l;
						} else {
							result[cnt_x] = resultwork;
						}
					}
					
					Write1LineDst(cnt_j, result);
					
				} else if (outsel == 1) { // bitsel
					if (bitsel == 0) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE1[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					} else if (bitsel == 1) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE2[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					} else if (bitsel == 2) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE3[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					} else if (bitsel == 3) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE4[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					} else if (bitsel == 4) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE5[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					} else if (bitsel == 5) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE6[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					} else if (bitsel == 6) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE7[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					} else if (bitsel == 7) {
						for (cnt_x=0; cnt_x<xlng; cnt_x++) {
							resultwork = *(pLINE8[cnt_k] + cnt_x);
							if (resultwork & 0x80) resultwork |= 0xffffffffffffff00l;
							result[cnt_x] = resultwork;
						}
					}
					
					Write1LineDst(cnt_j, result);
					
				} else if (outsel == 2) { // logicfun
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						result[cnt_x] = IMG_1100_logicfun(*(pLINE4[cnt_k] + cnt_x), *(pLINE8[cnt_k] + cnt_x), logicfun);
					}
					
					Write1LineDst(cnt_j, result);
					
				} else {  // (outsel == 3)  bit count
					for (cnt_x=0; cnt_x<xlng; cnt_x++) {
						cnt = 0;
						if ((*(pLINE1[cnt_k] + cnt_x) >> 7) & 0x0001) cnt ++;
						if ((*(pLINE2[cnt_k] + cnt_x) >> 6) & 0x0002) cnt ++;
						if ((*(pLINE3[cnt_k] + cnt_x) >> 5) & 0x0004) cnt ++;
						if ((*(pLINE4[cnt_k] + cnt_x) >> 4) & 0x0008) cnt ++;
						if ((*(pLINE5[cnt_k] + cnt_x) >> 3) & 0x0010) cnt ++;
						if ((*(pLINE6[cnt_k] + cnt_x) >> 2) & 0x0020) cnt ++;
						if ((*(pLINE7[cnt_k] + cnt_x) >> 1) & 0x0040) cnt ++;
						if ((*(pLINE8[cnt_k] + cnt_x)     ) & 0x0080) cnt ++;

						result[cnt_x] = (int64) cnt;
					}
					
					Write1LineDst(cnt_j, result);
					
				}
			}
		}
	} else { // pack data
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (pack data) ) on IMG_1100.\n");
		Legacy_assert_error();
	}
	
	return(0);
}


/******************************************************************************/
/* IMG_1100_Filter                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16                                                      */
/******************************************************************************/
static short IMG_1100_Filter(short m[], int fun, int conect){
    int i, ret, flg;
    short msk[26][9] ={
/* 4 */
        {0,1,0,1,0,1,0,1,0}, /* 0 */
        {0,1,0,1,0,1,0,1,0}, /* 1 */
        {0,1,0,1,0,1,0,1,0}, /* 2 */
        {0,1,0,1,0,1,0,1,0}, /* 3 */
        {0,1,0,1,0,1,0,1,0}, /* 4 */
        {0,0,0,1,0,1,0,0,0}, /* 5 */
        {0,0,0,1,0,1,0,0,0}, /* 6 */
        {0,1,0,0,0,0,0,1,0}, /* 7 */
        {0,1,0,0,0,0,0,1,0}, /* 8 */
        {0,0,1,0,0,0,1,0,0}, /* 9 */
        {0,0,1,0,0,0,1,0,0}, /* 10 */
        {1,0,0,0,0,0,0,0,1}, /* 11 */
        {1,0,0,0,0,0,0,0,1}, /* 12 */
/* 8 */
        {1,1,1,1,0,1,1,1,1}, /* 0 */
        {1,1,1,1,0,1,1,1,1}, /* 1 */
        {1,1,1,1,0,1,1,1,1}, /* 2 */
        {1,1,1,1,0,1,1,1,1}, /* 3 */
        {1,1,1,1,0,1,1,1,1}, /* 4 */
        {1,0,1,1,0,1,1,0,1}, /* 5 */
        {1,0,1,1,0,1,1,0,1}, /* 6 */
        {1,1,1,0,0,0,1,1,1}, /* 7 */
        {1,1,1,0,0,0,1,1,1}, /* 8 */
        {0,1,1,1,0,1,1,1,0}, /* 9 */
        {0,1,1,1,0,1,1,1,0}, /* 10 */
        {1,1,0,1,0,1,0,1,1}, /* 11 */
        {1,1,0,1,0,1,0,1,1}  /* 12 */
    };
    ret = flg = 0;

    switch(fun){
/* DELETENOISE */
    case 1:
    	flg = -1;// -1:init 0: all 0, 1: all 1, 2: with 0 and 1
        for(i=0;i<9;i++){
            if(msk[fun+conect*13][i]){
                if((m[i]>>7) & 0x01)
                {//1
                	if(flg == -1)
                	{
                		flg = 1;
                	}
                	else if(flg == 0)
                	{
                		flg = 2;
                		break;
                	}
                }
                else
                {//0
                	if(flg == -1)
                	{
                		flg = 0;
                	}
                	else if(flg == 1)
                	{
                		flg = 2;
                		break;
                	}
                }
            }
        }
        if(flg == 0)
        {
        	ret = 0;
        }
        else if(flg == 1)
        {
        	ret = 1;
        }
        else
        {
        	ret = m[4];
        }
        break;
/* DILATION(Boutyou) */
    case 2:
    case 5:
    case 7:
    case 9:
    case 11:
        for(i=0;i<9;i++){
            if(msk[fun+conect*13][i]){
                if((m[i]>>7) & 0x01) flg = 1;
            }
        }
        ret = (flg) ? 0xffffffff : m[4];
        break;
/* EROSION(Syuusyuku) */
    case 3:
    case 6:
    case 8:
    case 10:
    case 12:
        for(i=0;i<9;i++){
            if(msk[fun+conect*13][i]){
                if(!((m[i]>>7) & 0x01)) flg = 1;
            }
        }
        ret = (flg) ? 0 : m[4];
        break;
/* OUTLINE(Rinkakutyusyutu) */
    case 4:
        for(i=0;i<9;i++){
            if(msk[fun+conect*13][i]){
                if(!((m[i]>>7) & 0x01)) flg = 1;
            }
        }
        ret = (flg) ? m[4] : 0;
        break;
    default:
        ret = m[4];
        break;
    }

    return((short)ret);
}


/******************************************************************************/
/* IMG_1100_logicfun                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16                                                      */
/******************************************************************************/
static int64 IMG_1100_logicfun(short ImgA, short ImgB, int logicfun){
	int64 ret;
	
	if (logicfun == 0) { 			/* AND */
		ret = ((int64)ImgA & (int64)ImgB);
	} else if (logicfun == 1) { 	/* OR */
		ret = ((int64)ImgA | (int64)ImgB);
	} else if (logicfun == 2) { 	/* XOR */
		ret = ((int64)ImgA ^ (int64)ImgB);
	} else { 						/* XNOR */
		ret = (~((int64)ImgA ^ (int64)ImgB));
	}
	
	return(ret);
}



