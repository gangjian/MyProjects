/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG2_0101.c                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif
#include "legacy_sim.h"
#include "impsim_int.h"

static int Integral_Image_Normal();
static int Integral_Image_45deg();
static int Check_result(int64 result);


/******************************************************************************/
/* IMG2_0101                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
int IMG2_0101(){
	
	int ret=0;
	
	int subfun_1, subfun_2;
	unsigned int xlng, lm_mode, mc_dstw;
	int pfdst;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	xlng		 = IMPREG_APLNG_READ() & 0x00003fff;
	pfdst        = ((IMPREG_APCFG_READ()>>16) & 0x0007);
	subfun_1	 = (IMPREG_IPFUN_READ()>>25) & 0x00000001;
	subfun_2	 = (IMPREG_IPFUN_READ()>>26) & 0x00000001;
	lm_mode		 = (IMPREG_KNLMSK_READ() >>29) & 0x00000001;
	mc_dstw		 = (IMPREG_IPFUN2_READ() >>20) & 0x00000003;
	/* HW special specification */
	/* xlng 5-1024 */
	if ((xlng < 5) || (xlng > 1024)) {
		SIMLOG(SL_LS, SL_L4, "xlng = %d It is error!", xlng);
		return -1;
	}
	// Check lm_mode
	if (lm_mode != 1) {
		SIMLOG(SL_LS, SL_L4, "lm_mode = %d It is error!", lm_mode);
		return -1;
	}
	// Check mc_dstw
	if (mc_dstw != 3) {
		SIMLOG(SL_LS, SL_L4, "mc_dstw = %d It is error!", mc_dstw);
		return -1;
	}
	// dst 16bpp is not support on library
	if (subfun_2 != 0) {
		SIMLOG(SL_LS, SL_L4, "dst 16bpp is not support on library");
		return -1;
	}
	// Check dst format on AP
	if (pfdst != 3) {
		SIMLOG(SL_LS, SL_L4, "dst format(pfdst = %d) is not 32bpp on AP.", pfdst);
		return -1;
	}
	
	/* select the kind of Integral Image */
	if (subfun_1 == 0) {
		/* Normal */
		ret = Integral_Image_Normal();
	} else {
		/* angle of 45 degrees */
		ret = Integral_Image_45deg();
	}
	
	return ret;
}


/******************************************************************************/
/* Integral_Image_Normal                                                      */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int Integral_Image_Normal() {
	
	int sour_d, subfun_0, ret=0;
	int64 pre_d, ppre_d, result[1024]; // use max 1024 pix
	unsigned int xlng, ylng;
	unsigned int widthcnt, heightcnt;
	short *soura_id = psLM0;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	subfun_0	 = (IMPREG_IPFUN_READ()>>24) & 0x00000001;
	xlng		 = IMPREG_APLNG_READ() & 0x00003fff;
	ylng		 = (IMPREG_APLNG_READ() >>16) & 0x00003fff;
	
	heightcnt = 0;
	
	/* roop y-direction */
	while(heightcnt<ylng) {
		widthcnt = 0;
		/* read by 1 line data */
		Read1LineSrc0(heightcnt, soura_id);
		
		if (heightcnt == 0) {
			while (widthcnt<xlng) {
				// normal or square
				if (subfun_0 == 0) {
					sour_d = (int)soura_id[widthcnt];
				} else {
					sour_d = (int)soura_id[widthcnt] * (int)soura_id[widthcnt];
				}
				
				if (widthcnt == 0) {
					result[widthcnt] = (int64)sour_d;
				} else {
					result[widthcnt] = result[widthcnt-1] + (int64)sour_d;
				}
				// If Overflow occure return 2, else return 0.
				if (Check_result(result[widthcnt]) == 2) {
//					SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : wrap around\n", widthcnt, heightcnt, result[widthcnt]);
					ret = 2;
				}
//				SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : Normal\n", widthcnt, heightcnt, result[widthcnt]);
				widthcnt++;
			}
		} else {
			while (widthcnt<xlng) {
				// normal or square
				if (subfun_0 == 0) {
					sour_d = (int)soura_id[widthcnt];
				} else {
					sour_d = (int)soura_id[widthcnt] * (int)soura_id[widthcnt];
				}
				
				if (widthcnt == 0) {
					pre_d = result[widthcnt];
					result[widthcnt] = pre_d + (int64)sour_d;
					ppre_d = pre_d;
				} else {
					pre_d = result[widthcnt];
					result[widthcnt] = pre_d - ppre_d + result[widthcnt-1] + (int64)sour_d;
					ppre_d = pre_d;
				}
				// If Overflow occure return 2, else return 0.
				if (Check_result(result[widthcnt]) == 2) {
//					SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : wrap around\n", widthcnt, heightcnt, result[widthcnt]);
					ret = 2;
				}
//				SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : Normal\n", widthcnt, heightcnt, result[widthcnt]);
				widthcnt++;
			}
		}
		/* write Dst data */
		Write1LineDst(heightcnt, result);
		heightcnt++;
	}
	return ret;
}


/******************************************************************************/
/* Integral_Image_45deg                                                       */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/25   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int Integral_Image_45deg() {
	
	int sour_d, subfun_0, ret=0;
	int64 result[1024]; // use max 1024 pix
	unsigned int xlng, ylng;
	unsigned int widthcnt, heightcnt;
	short *soura_id = psLM0;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	subfun_0	 = (IMPREG_IPFUN_READ()>>24) & 0x00000001;
	xlng		 = IMPREG_APLNG_READ() & 0x00003fff;
	ylng		 = (IMPREG_APLNG_READ() >>16) & 0x00003fff;
	
	heightcnt = 0;
	
	// In case of bottom up(APSIZE_SA and APSIZE_DST are negative), 
	if (IMPREG_APSIZE_SA_READ() & 0x80000000) {
		if ((IMPREG_APSIZE_DST_READ() & 0x80000000)==0) {
			SIMLOG(SL_LS, SL_ERR, "Error in Integral_Image_45deg.\n");
			Legacy_assert_error();
		}
		// In case of combination operation environment, recalc pSrc0 SASP pDst DSP.
		if (pSrc0 == (unsigned char *)SASP) {
			SASP = IMPREG_APSASP_READ() + (ylng - 1) * IMPREG_APSIZE_SA_READ();
			pSrc0 = (unsigned char *)SASP;
			
			DSP = IMPREG_APDSP_READ() + (ylng - 1) * IMPREG_APSIZE_DST_READ();
			pDst = (unsigned char *)DSP;
		}
	}
	
	/* roop y-direction */
	while(heightcnt<ylng) {
		widthcnt = 0;
		/* read by 1 line data */
		Read1LineSrc0(heightcnt, soura_id);
		
		if (heightcnt == 0) {
			while (widthcnt<xlng) {
				// normal or square
				if (subfun_0 == 0) {
					sour_d = (int)soura_id[widthcnt];
				} else {
					sour_d = (int)soura_id[widthcnt] * (int)soura_id[widthcnt];
				}
				
				if (widthcnt == 0) {
					result[widthcnt] = (int64)sour_d;
				} else {
					result[widthcnt] = result[widthcnt-1] + (int64)sour_d;
				}
				// If Overflow occure return 2, else return 0.
				if (Check_result(result[widthcnt]) == 2) {
//					SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : wrap around\n", widthcnt, heightcnt, result[widthcnt]);
					ret = 2;
				}
//				SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : 45deg\n", widthcnt, heightcnt, result[widthcnt]);
				widthcnt++;
			}
		} else {
			while (widthcnt<xlng) {
				// normal or square
				if (subfun_0 == 0) {
					sour_d = (int)soura_id[widthcnt];
				} else {
					sour_d = (int)soura_id[widthcnt] * (int)soura_id[widthcnt];
				}
				
				if (widthcnt == 0) {
					result[widthcnt] = result[widthcnt+1] + (int64)sour_d;
				} else if (widthcnt == (xlng-1)) {
					result[widthcnt] = result[widthcnt-1] + (int64)sour_d;
				} else {
					result[widthcnt] = result[widthcnt+1] - result[widthcnt] + result[widthcnt-1] + (int64)sour_d;
				}
				// If Overflow occure return 2, else return 0.
				if (Check_result(result[widthcnt]) == 2) {
//					SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : wrap around\n", widthcnt, heightcnt, result[widthcnt]);
					ret = 2;
				}
//				SIMLOG(SL_LS, SL_L4, "  Value[%03d][%03d] = 0x%016llx : 45deg\n", widthcnt, heightcnt, result[widthcnt]);
				widthcnt++;
			}
		}
		/* write Dst data */
		Write1LineDst(heightcnt, result);
		heightcnt++;
	}
	return ret;
}


static int Check_result(int64 result) {
	
	result = result & (int64)0xFFFFFFFF80000000LL;
	
	if (result == (int64)0x0000000000000000LL) return 0;
	else if (result == (int64)0xFFFFFFFF80000000LL) return 0;
	else return 2;
}



