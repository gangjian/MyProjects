/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_exec.c                                      */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/

#include <stdio.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif

#include "legacy_sim.h"
#include "legacy_micro_op.h"
#include "legacy_micro_dec.h"
#include "impsim_int.h"
#include "legacy_sim_prot.h"
#include "distributer_sim_prot.h"

char 			*pcLM0, *pcLM1, *pcLM2, *pcLM3, *pcLM4, *pcLM5, *pcLM6, *pcLM7, *pcLM8;
short 			*psLM0, *psLM1, *psLM2, *psLM3, *psLM4, *psLM5, *psLM6, *psLM7, *psLM8;
int 			*plLM0, *plLM1, *plLM2, *plLM3, *plLM4, *plLM5, *plLM6, *plLM7, *plLM8;
unsigned char 	*pucLM0, *pucLM1, *pucLM2, *pucLM3, *pucLM4, *pucLM5, *pucLM6, *pucLM7, *pucLM8;
unsigned short 	*pusLM0, *pusLM1, *pusLM2, *pusLM3, *pusLM4, *pusLM5, *pusLM6, *pusLM7, *pusLM8;
unsigned int 	*pulLM0, *pulLM1, *pulLM2, *pulLM3, *pulLM4, *pulLM5, *pulLM6, *pulLM7, *pulLM8;

// ch_run_mode
#define  DP_NOUSE_BUF   0
#define  DP_READ_BUF    1
#define  DP_WRITE_BUF   2
#define  DP_PENDING     3

void illegal_ins(int ins, int pc);
static int DPExec();
static int DP_CheckCurrentStatus();
static void DP_CheckAndGo_PendingCh();

unsigned char *pSrc0, *pSrc1, *pDst;
int mem[IMP_CH_MAX][MCOM_MAX_MEM_ADDR+1];
unsigned int UseImg[3];

int MCOM_InputLine_SA, MCOM_InputLine_SB, MCOM_OutputLine_Dst;
int MCOM_regselectSET, MCOM_regselectEXC;
int McomFlg;
int MCOM_reg[MCOM_NUM_REGSETS][MCOM_NUM_REGS];
extern unsigned int Pending_ch[4];
extern unsigned int DP_Buffer;

/******************************************************************************/
/* IPExec																	  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato 											  */
/*						 new												  */
/******************************************************************************/
int IPExec(){
	
	int ret;
	unsigned long fun, fun2;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s",__FUNCTION__);
	SIMLOG(SL_LS, SL_L5, "  IPFUN  = 0x%08x",IMPREG_IPFUN_READ());
	SIMLOG(SL_LS, SL_L5, "  IPFUN2 = 0x%08x",IMPREG_IPFUN2_READ());
	SIMLOG(SL_LS, SL_L5, "  IPFORM = 0x%08x\n",IMPREG_IPFORM_READ());
#endif
	
	IMPREG_STS_WRITE( IMPREG_STS_READ() &(~_STS_MIS_MAT));/* clear mismatch status bit before new IP function */
	// tsato add
	Convert8bppParallel();
	AllocateLineMemory();
	
	ret = 0;
/* IPFUN fun bit check */
	fun = (((IMPREG_IPFUN_READ())>>28) & 0x0f);
	fun2 = ((IMPREG_IPFUN2_READ() >> 28) & 0x000f);
	
	switch(fun){
	case 0x0:
		ret = IMG_0000();  break;
	case 0x1:
		ret = IMG_0001();  break;
	case 0x2:
		ret = IMG_0010();  break;
	case 0x3:
		ret = IMG_0011();  break;
	case 0x4:
		ret = IMG_0100();  break;
	case 0x5:
		ret = IMG_0101();  break;
	case 0x6:
		ret = IMG_0110();  break;
	case 0x7:
		ret = IMG_0111();  break;
	case 0x8:
		ret = IMG_1000();  break;
	case 0x9:
		ret = IMG_1001();  break;
	case 0xa:
		ret = IMG_1010();  break;
	case 0xb:
		ret = IMG_1011();  break;
	case 0xc:
		ret = IMG_1100();  break;
	case 0xd:
		ret = IMG_1101();  break;
	case 0xe:
		ret = IMG_1110();  break;
	default:   /* 0xf */
/****** IPFUN2 ******/
		switch(fun2){
		case 0x01:
			ret = IMG2_0001();	break;
		case 0x02:
		 	ret = IMG2_0010();	break;
		case 0x03:
			ret = IMG2_0011();	break;
		case 0x04:
			ret = IMG2_0100();	break;
		case 0x05:
			ret = IMG2_0101();	break;
		case 0x06:
			ret = IMG2_0110();	break;
		case 0x07:
			ret = IMG2_0111();	break;
		default:
			break;
		}
		break;
	}

	if (ret < 0) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, IPExec() fun=0x%04x, fun2=0x%04x ret=%d failed.\n", fun, fun2, ret);
		Legacy_assert_error();
	}
	
	Check8bppParallel();
	
#if PIPE_HO_DEBUG
	if (McomFlg) {
		PIPE_HO_collect_linebuf();
	}
#endif
	
	return(0);
}

/******************************************************************************/
/* PIPEExec                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int PIPEExec(void) {

	uint32_t val;

	SIMLOG(SL_LS_ADPT, SL_L3, "PIPEExec(): Activate PIPE.\n");

#if PIPE_HO_DEBUG
   	PIPE_HO_debug_init();
#endif

	// Show busy status.
	// H.Shiota, TBD

	// Initialize some internal pointers. (Common procedure between APExec() and PIPEExec())
	SASP = IMPREG_APSASP_READ();
	pSrc0 = (unsigned char *)SASP;
	SBSP = IMPREG_APSBSP_READ();
	pSrc1 = (unsigned char *)SBSP;
	DSP = IMPREG_APDSP_READ();
	pDst = (unsigned char *)DSP;
	
	// PIPE mode.
	McomFlg = 1;	
	
	// clear  MCINIT 
	IMPREG_MCINIT_WRITE( IMPREG_MCINIT_READ() & ~(_MCINIT_MC_EN));
	
	// dump_pipe_mem();
	
	MCOM_InputLine_SA = 0;
	MCOM_InputLine_SB = 0;
	MCOM_OutputLine_Dst = 0;
	MCOM_regselectSET = 0;
	MCOM_regselectEXC = 0;


	/* Check if sources and destination are disbaled/enabled. */
	val = (uint32_t)IMPREG_APCMD_READ();
	if(val & IMGRUNCHECKSABIT){ UseImg[0]=1; } else UseImg[0]=0;
	if(val & IMGRUNCHECKSBBIT){ UseImg[1]=1; } else UseImg[1]=0;
	if(val & IMGRUNCHECKDSBIT){ UseImg[2]=1; } else UseImg[2]=0;

	/* initialize register file*/
	MCOM_reg[0][0] = 0x0; // Read only 
	MCOM_reg[0][1] = IMPREG_MCR1B0_READ();
	MCOM_reg[0][2] = IMPREG_MCR2B0_READ();
	MCOM_reg[0][3] = IMPREG_MCR3B0_READ();
	MCOM_reg[0][4] = IMPREG_MCR4B0_READ();
	MCOM_reg[0][5] = IMPREG_MCR5B0_READ();
	MCOM_reg[0][6] = IMPREG_MCR6B0_READ();
	MCOM_reg[0][7] = IMPREG_MCR7B0_READ();
	MCOM_reg[0][8] = IMPREG_MCR8B0_READ() & 0x000001ff;
	MCOM_reg[0][9] = IMPREG_MCR9B0_READ() & 0x000001ff;
	MCOM_reg[0][10] = IMPREG_MCR10B0_READ() & 0x000001ff;
	MCOM_reg[0][11] = IMPREG_MCR11B0_READ() & 0x000001ff;
	MCOM_reg[0][12] = IMPREG_MCR12B0_READ() & 0x000001ff;
	MCOM_reg[0][13] = IMPREG_MCR13B0_READ() & 0x000001ff;
	MCOM_reg[0][14] = IMPREG_MCR14B0_READ() & 0x000001ff;
	MCOM_reg[0][15] = IMPREG_MCR15B0_READ() & 0x000000ff;
	MCOM_reg[1][0] = 0x0; // Read only 
	MCOM_reg[1][1] = IMPREG_MCR1B1_READ();
	MCOM_reg[1][2] = IMPREG_MCR2B1_READ();
	MCOM_reg[1][3] = IMPREG_MCR3B1_READ();
	MCOM_reg[1][4] = IMPREG_MCR4B1_READ();
	MCOM_reg[1][5] = IMPREG_MCR5B1_READ();
	MCOM_reg[1][6] = IMPREG_MCR6B1_READ();
	MCOM_reg[1][7] = IMPREG_MCR7B1_READ();
	MCOM_reg[1][8] = IMPREG_MCR8B1_READ() & 0x000001ff;
	MCOM_reg[1][9] = IMPREG_MCR9B1_READ() & 0x000001ff;
	MCOM_reg[1][10] = IMPREG_MCR10B1_READ() & 0x000001ff;
	MCOM_reg[1][11] = IMPREG_MCR11B1_READ() & 0x000001ff;
	MCOM_reg[1][12] = IMPREG_MCR12B1_READ() & 0x000001ff;
	MCOM_reg[1][13] = IMPREG_MCR13B1_READ() & 0x000001ff;
	MCOM_reg[1][14] = IMPREG_MCR14B1_READ() & 0x000001ff;
	MCOM_reg[1][15] = IMPREG_MCR15B1_READ() & 0x000000ff;	 

	/* initialize stack pointer */
	MCOM_reg[0][MCOM_SP] = MCOM_MAX_MEM_ADDR - 1;
	MCOM_reg[1][MCOM_SP] = MCOM_MAX_MEM_ADDR - 1;

	/* Dump IMP registers for debug. */
	dump_pipe_regs(0); 
	dump_pipe_regs(1); 
	dump_imp_reg();

	PIPECommonProc();

	dump_pipe_regs(0); // bank0
	dump_pipe_regs(1); // bank1

	IPtoAP();

	CheckEndOfIntermediateBuffer();

	// H.Shiota
	// HPAccumulate() is not needed here? No HP execution after PIPE in original emulator.
	// To be filled.
	
#if PIPE_HO_DEBUG
 	PIPE_HO_save_file();
#endif

	return(0);	  

}

/******************************************************************************/
/* HPExec                                                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int HPExec(int command) {
	int ret = E_OK;
	uint32_t work;

	uint16_t hmadr;
	uint32_t hmdata;
	
	int adr_cnt;

	if (command == HPEXEC_HM_RESET) {
		SIMLOG(SL_LS_ADPT, SL_L5, "HM reset is activated.\n");
		
		// Non-PIPE mode.
		McomFlg = 0;	

		/* Set hp bit of STS register to show busy status */
		IMPREG_STS_WRITE( IMPREG_STS_READ() | _STS_HP);

		if (!(IMPREG_HMPTR_READ() & _HMPTR_MODE)) { // The mode bit should be asserted before writing to HMDATA.
			SIMLOG(SL_LS_ADPT, SL_L3, "HPExec(): INFO. HMDATA is written without asserting mode bit of HMPTR.\n");
			return E_OK;
		}

		/* Initialize histogram memory */
		hmadr = (uint16_t)(IMPREG_HMPTR_READ() & _HMPTR_HMADR);
		hmdata = IMPREG_HMDATA_READ();

		SIMLOG(SL_LS_ADPT, SL_L5, "Start address:%04x, initialize data:%08lx\n", hmadr, (unsigned long)hmdata);
		for (adr_cnt = 0; adr_cnt <= hmadr; adr_cnt++) {
			SIMLOG(SL_LS_ADPT, SL_L5, "address:%04x, data:%08lx\n", adr_cnt, (unsigned long)hmdata);		
			WriteHM(IMP_WORK_CH, adr_cnt, (unsigned long)hmdata);
		} 
	
		/* Mode bit and hmadr bits should be cleared by hardware. */	
		work = IMPREG_HMPTR_READ();
		IMPREG_HMPTR_WRITE( work & !(_HMPTR_MODE | _HMPTR_HMADR)); 
	
		/* Clear hp bit of STS register to show idle status */
		IMPREG_STS_WRITE( IMPREG_STS_READ() & ~(_STS_IP | _STS_HP));
		
	} else if (command == HPEXEC_HPEN){ // Asserting hpen causes reset of some other registers.
		SIMLOG(SL_LS_ADPT, SL_L5, "hpen of HPCTL is asserted.\n");

		// Reset HPSTS
		IMPREG_HPSTS_WRITE( 0x00000000);

		// Reset HPACC
		IMPREG_HPACC_WRITE( 0x00000000);

		if((IMPREG_HPSADCTL_READ() >>16) & 0x00000001)
		{
		}
		else
		{
			// Reset HPMINSP
			IMPREG_HPMINSP_WRITE( 0x00000000);
			// Reset HPSADMIN
			IMPREG_HPSADMIN_WRITE( 0x007fffff);
		}

		// Reset HPMAXEP
		IMPREG_HPMAXEP_WRITE( 0x00000000);

		// Reset HPMNMX
		// H.Shiota, Description of HW manual is ambiguous. Check hardware team to implement this.
		
		// Reset HMCNT
		// H.Shiota, Description of HW manual is ambiguous. Check hardware team to implement this.
		
		
	} else {
		SIMLOG(SL_LS_ADPT, SL_ERR, "Unknown command to HPExec()\n");
		Legacy_assert_error();
	}

	return ret;
}

/******************************************************************************/
/* APDMACExec                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int APDMACExec(void) {
    int ret = E_OK;

    uint32_t *apdmac_dst;
    uint32_t apdmac_src;
    uint8_t  imhm_spc;
    int apdmac_cnt;
    uint32_t val;

    SIMLOG(SL_LS_ADPT, SL_L3, "APDMACExec(): Activate APDMAC.\n");

    /* H.Shiota, Should show the busy status of IP in the case of APDMAC? */

    apdmac_dst = (uint32_t *)IMPREG_APDSP_READ();
    imhm_spc = (uint8_t)((IMPREG_APIHSP_READ() & 0xF0000)>>16);

    switch(imhm_spc)
    {
        case 0x01:/* 4'b0001->HPX register */
            apdmac_src = (uint32_t)((IMPREG_APIHSP_READ() & _APIHSP_IMHM_ADD));
    		if(apdmac_src < 0x500)
    		{
    			apdmac_src = apdmac_src + 0x500;
    		}
    		apdmac_cnt = IMPREG_APIHTCR_READ() + 1; // "+1" is needed to see actual transfer count. See the spec of APIHTCR reg.

            SIMLOG(SL_LS_ADPT, SL_L5, "APDMACExec(): DMAC parameters, src:%04x, dst:%08lx, cnt:%d\n",
                   apdmac_src, (unsigned long)apdmac_dst, apdmac_cnt);

            while (apdmac_cnt) {
              read_reg(IMP_WORK_CH, (uint32_t)apdmac_src, (uint32_t *)&val);

                *apdmac_dst = val; // Write destination memory by DMAC. No care for endian and bus width at the moment.

                /*
                  SIMLOG(SL_LS_ADPT, SL_L5, "APDMACExec(): Dump destination memory, adr:%08lx, val:%08lx\n",
                       (unsigned long)apdmac_dst, *apdmac_dst);
                */

                apdmac_src+=4; // incremented by 4
                apdmac_dst++; // incremented by 4
                apdmac_cnt--;
            }

              break;
        case 0x02:/* 4'b0010->HMEM */
            apdmac_src = (uint32_t)(((IMPREG_APIHSP_READ() & _APIHSP_IMHM_ADD))>>2);
            apdmac_cnt = IMPREG_APIHTCR_READ() + 1; // "+1" is needed to see actual transfer count. See the spec of APIHTCR reg.

            SIMLOG(SL_LS_ADPT, SL_L5, "APDMACExec(): DMAC parameters, src:%04x, dst:%08lx, cnt:%d\n",
                   apdmac_src, (unsigned long)apdmac_dst, apdmac_cnt);

            while (apdmac_cnt) {
                ReadHM(IMP_WORK_CH, (int)apdmac_src, (unsigned long *)&val);

                *apdmac_dst = val; // Write destination memory by DMAC. No care for endian and bus width at the moment.

                /*
                  SIMLOG(SL_LS_ADPT, SL_L5, "APDMACExec(): Dump destination memory, adr:%08lx, val:%08lx\n",
                       (unsigned long)apdmac_dst, *apdmac_dst);
                */

                apdmac_src++; // incremented by 1
                apdmac_dst++; // incremented by 4
                apdmac_cnt--;
            }
              break;
       case 0x03:/* 4'b0011->IPX register */
            apdmac_src = (uint32_t)((IMPREG_APIHSP_READ() & _APIHSP_IMHM_ADD));
            apdmac_cnt = IMPREG_APIHTCR_READ() + 1; // "+1" is needed to see actual transfer count. See the spec of APIHTCR reg.

            SIMLOG(SL_LS_ADPT, SL_L5, "APDMACExec(): DMAC parameters, src:%04x, dst:%08lx, cnt:%d\n",
                   apdmac_src, (unsigned long)apdmac_dst, apdmac_cnt);

            while (apdmac_cnt) {
              read_reg(IMP_WORK_CH, (uint32_t)apdmac_src, (uint32_t *)&val);

                *apdmac_dst = val; // Write destination memory by DMAC. No care for endian and bus width at the moment.

                /*
                  SIMLOG(SL_LS_ADPT, SL_L5, "APDMACExec(): Dump destination memory, adr:%08lx, val:%08lx\n",
                       (unsigned long)apdmac_dst, *apdmac_dst);
                */

                apdmac_src+=4; // incremented by 4
                apdmac_dst++; // incremented by 4
                apdmac_cnt--;
            }
              break;
        case 0x04: /*  4'b0100->CMA */
              SIMLOG(SL_LS_ADPT, SL_ERR, "0x04 DMAC is not supported!!!\n");
    		  Legacy_assert_error();
              break;
        case 0x05:/* 4'b0101->CMB */
              SIMLOG(SL_LS_ADPT, SL_ERR, "0x05 DMAC is not supported!!!\n");
    		  Legacy_assert_error();
              break;
        case 0x06:/* 4'b0110->TH0 */
              SIMLOG(SL_LS_ADPT, SL_ERR, "0x06 DMAC is not supported!!!\n");
    		  Legacy_assert_error();
              break;
        case 0x07: /*  4'b0111->TH1 */
              SIMLOG(SL_LS_ADPT, SL_ERR, "0x07 DMAC is not supported!!!\n");
    		  Legacy_assert_error();
              break;
        case 0x08: /* 4'b1000->FIFO */
              SIMLOG(SL_LS_ADPT, SL_ERR, "0x08 DMAC is not supported!!!\n");
    		  Legacy_assert_error();
              break;
        case 0x09:/* 4'b1001->RAM */
              SIMLOG(SL_LS_ADPT, SL_ERR, "0x09 DMAC is not supported!!!\n");
    		  Legacy_assert_error();
             break;
        case 0x0a:/* 4'b1010->LM */
              SIMLOG(SL_LS_ADPT, SL_ERR, "0x0a DMAC is not supported!!!\n");
    		  Legacy_assert_error();
              break;
        default: /* others->reserved */
              SIMLOG(SL_LS_ADPT, SL_ERR, "This DMAC is not supported!!!\n");
    		  Legacy_assert_error();
              break;
    }
    return ret;
}


/******************************************************************************/
/* APExec                                                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int APExec(void) {
	int ret = E_OK;
	
	uint32_t reg_val;
	unsigned int dp_newdrpenb;

	/* Set ip and hp bits of STS register to show busy status */
	IMPREG_STS_WRITE( IMPREG_STS_READ() | (_STS_IP | _STS_HP)); // H.Shiota: HP busy should be asserted at this timing? 
	
	dump_imp_reg();
			
	// Initialize some internal pointers. (Common procedure between APExec() and PIPEExec())
	SASP = IMPREG_APSASP_READ();
	pSrc0 = (unsigned char *)SASP;
	SBSP = IMPREG_APSBSP_READ();
	pSrc1 = (unsigned char *)SBSP;
	DSP = IMPREG_APDSP_READ();
	pDst = (unsigned char *)DSP;
    
	// Non-PIPE mode.
	McomFlg = 0;
	
	dp_newdrpenb = DIST_REG_READ(DP_DRPSEL) >> 31;
	if (dp_newdrpenb == 0) {
		Pending_ch[0] = 0;
		Pending_ch[1] = 0;
		Pending_ch[2] = 0;
		Pending_ch[3] = 0;
		DP_Buffer = 0xffffffff;

		read_reg(IMP_WORK_CH, (uint32_t)regtable[_APCMD].adr, (uint32_t *)&reg_val);
		
		if (reg_val & _APCMD_IM_HM) {
			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Kick APDMAC\n");
			ret = APDMACExec();
			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of APDMAC\n");
		} else {
			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Kick IP\n");
			ret = IPExec();
			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IP\n");

			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Start IPtoAP().\n");
			IPtoAP();
			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IPtoAP().\n");

			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Start HPAccumulate().\n");
			HPAccumulate();
			SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of HPAccumulate().\n");
			// dump_hp_mem();
		}
	} else {
		DPExec();
	}

	CheckEndOfIntermediateBuffer();

	/* Clear ip and hp bits of STS register to show idle status */
	IMPREG_STS_WRITE( IMPREG_STS_READ() & ~(_STS_IP | _STS_HP));
	
	return ret;
}

/******************************************************************************/
/* DPExec                                                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/11/07 T.Sato                                               */
/*                       New  (Todo Review)                                   */
/******************************************************************************/
static int DPExec(void) {
	int ret = E_OK;
	int ch_run_mode;

	ch_run_mode = DP_CheckCurrentStatus();

	if (ch_run_mode == DP_NOUSE_BUF) {
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Kick IP\n");
		ret = IPExec();
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IP\n");

		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Start IPtoAP().\n");
		IPtoAP();
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IPtoAP().\n");

	} else if (ch_run_mode == DP_READ_BUF) {
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Kick IP\n");
		ret = IPExec();
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IP\n");

		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Start IPtoAP().\n");
		IPtoAP();
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IPtoAP().\n");
		
		DP_Buffer = 0xffffffff;
		DP_CheckAndGo_PendingCh();
		
	} else if (ch_run_mode == DP_WRITE_BUF) {
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Kick IP\n");
		ret = IPExec();
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IP\n");

		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Start IPtoAP().\n");
		IPtoAP();
		SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IPtoAP().\n");
		
		DP_Buffer = IMP_WORK_CH;
		DP_CheckAndGo_PendingCh();
		
	} else if (ch_run_mode == DP_PENDING) {
		Pending_ch[IMP_WORK_CH] = 1;
	}

	CheckEndOfIntermediateBuffer();
	
	return ret;
}

/******************************************************************************/
/* DP_CheckCurrentStatus                                                      */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/11/07 T.Sato                                               */
/*                       New  (Todo Review)                                   */
/******************************************************************************/
static int DP_CheckCurrentStatus() {
	int ret;
	unsigned int drpctl, srca, srcb, dst;
	
	switch (IMP_WORK_CH) {
	case 0:
		drpctl = DIST_REG_READ(DP_IMP0DRPCTL);
		break;
	case 1:
		drpctl = DIST_REG_READ(DP_IMP1DRPCTL);
		break;
	case 2:
		drpctl = DIST_REG_READ(DP_IMP2DRPCTL);
		break;
	case 3:
		drpctl = DIST_REG_READ(DP_IMP3DRPCTL);
		break;
	}
	
	dst = (drpctl >> 16) & 0x00000003;
	srcb = (drpctl >> 8) & 0x0000000f;
	srca = drpctl & 0x0000000f;
	
	if (dst == 0x00000002) {
		if (DP_Buffer == 0xffffffff) {
			pDst = pDR;
			ret = DP_WRITE_BUF;
		} else {
			ret = DP_PENDING;
		}
	} else if (((srca >= 8) && ((srca & 0x00000007) != DP_Buffer)) || ((srcb >= 8) && ((srcb & 0x00000007) != DP_Buffer))) {
		ret = DP_PENDING;
	} else {
		ret = DP_NOUSE_BUF;
		if ((srca >= 8) && ((srca & 0x00000007) == DP_Buffer)) {
			pSrc0 = pDR;
			ret = DP_READ_BUF;
		} 
		if ((srcb >= 8) && ((srcb & 0x00000007) == DP_Buffer)) {
			pSrc1 = pDR;
			ret = DP_READ_BUF;
		}
	}
	
	return ret;
}

/******************************************************************************/
/* DP_CheckAndGo_PendingCh                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/11/07 T.Sato                                               */
/*                       New  (Todo Review)                                   */
/******************************************************************************/
static void DP_CheckAndGo_PendingCh() {
	int backup_ch, i;
	int ch_run_mode;
	
	backup_ch = IMP_WORK_CH;
	
	for (i=0; i<4; i++) {
		IMP_WORK_CH = i;
		if (Pending_ch[i] == 1) {
			ch_run_mode = DP_CheckCurrentStatus();
			if (ch_run_mode == DP_NOUSE_BUF) {
				SIMLOG(SL_LS, SL_ERR, " DP_CheckCurrentStatus ch_run_mode is error!!!\n");
				Legacy_assert_error();
				
			} else if (ch_run_mode == DP_READ_BUF) {
				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Kick IP\n");
				IPExec();
				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IP\n");

				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Start IPtoAP().\n");
				IPtoAP();
				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IPtoAP().\n");

				DP_Buffer = 0xffffffff;
				Pending_ch[i] = 0;
			} else if (ch_run_mode == DP_WRITE_BUF) {
				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Kick IP\n");
				IPExec();
				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IP\n");

				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): Start IPtoAP().\n");
				IPtoAP();
				SIMLOG(SL_LS_ADPT, SL_L3, "APExec(): End of IPtoAP().\n");

				Pending_ch[i] = 0;
			}
		}
	}

	IMP_WORK_CH = backup_ch;
	return;
}

/******************************************************************************/
/* PipeCommonProc															  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato 											  */
/*						 todo  (to need clear PIPE_MODIFY)					  */
/******************************************************************************/
#define PIPE_MODIFY 1
void PIPECommonProc()
{
	short sour_id[LINE_SIZE], sour_id_work[LINE_SIZE];
	long xlng;
	int ret, ret2;
	int *work1, *work2;
	int b;
	int src,dst;
	unsigned long read_tmp;
	int cbit; /* Control bit */
	int pc; /* Program Counter */
	int ins; /* current instruction */
	int i, j; /* loop variable */
	int sleep; /* end bit */
	unsigned int uint_temp; /* unsigned temp */

#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	cbit = 0;
	sleep = 0;
	
	/* load inital PC */
	pc = IMPREG_MCINIT_READ() & 0xfe;
	
	while(sleep == 0)
	{
		/* Read an instruction */
		ins = mem[IMP_WORK_CH][pc];

		/* for debugging */
		//		SIMLOG(SL_LS,PIPE_LOGLEVEL,"current ins = 0x%x, PC:%d\n", ins, pc);
		SIMLOG(SL_LS,  PIPE_LOGLEVEL,"PC %d: ",pc);
		/* get op-code */

		switch(op(ins))
		{
		/* R type instruction 1 */
		case(OP_R):

			switch(op2(ins))
			{
			/* MOVE */
			case(OP2_MV):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"MV R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] = MCOM_reg[MCOM_regselectSET][source(ins)];
			break;

			/* ADD */
			case(OP2_ADD):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"ADD R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] += MCOM_reg[MCOM_regselectSET][source(ins)];
				cbit = (MCOM_reg[MCOM_regselectSET][dest(ins)] & 0x10000) >> 16;
			break;

			/* ADDC */
			case(OP2_ADDC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"ADDC R%d, R%d(c=%d)\n", dest(ins), source(ins), cbit);
				MCOM_reg[MCOM_regselectSET][dest(ins)] += (MCOM_reg[MCOM_regselectSET][source(ins)]+cbit);
				cbit = (MCOM_reg[MCOM_regselectSET][dest(ins)] & 0x10000) >> 16;
			break;

			/* SUB */
			case(OP2_SUB):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"SUB R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] -= MCOM_reg[MCOM_regselectSET][source(ins)];
				cbit = (MCOM_reg[MCOM_regselectSET][dest(ins)] & 0x10000) >> 16;
			break;

			/* SUBC */
			case(OP2_SUBC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"SUBC R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] -= (MCOM_reg[MCOM_regselectSET][source(ins)]+cbit);
				cbit = (MCOM_reg[MCOM_regselectSET][dest(ins)] & 0x10000) >> 16;
			break;

			/* two's complement number */
			case(OP2_NEG):		  
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"NEG R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] = -MCOM_reg[MCOM_regselectSET][source(ins)];
			break;

			/* 16 bit mutiplier */
			case(OP2_MULT16):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"MULT16 R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] = (MCOM_reg[MCOM_regselectSET][dest(ins)] & 0x00ff) * 
				(MCOM_reg[MCOM_regselectSET][source(ins)] & 0x00ff);
			break;

			default:
				illegal_ins(ins ,pc);
			break;
			}//switch(op(ins))

		break;

		/* R type instructions 2 */
		case(OP_R2):
			switch(op2(ins))
			{
			/* Logical Left Shift */
			case(OP2_SHL_L):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"SHL_L R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] <<= MCOM_reg[MCOM_regselectSET][source(ins)];
				cbit = ((MCOM_reg[MCOM_regselectSET][dest(ins)] & 0xffff0000) != 0);
			break;

			/* Logical Right Shift */
			case(OP2_SHR_L):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"SHR_L R%d, R%d\n", dest(ins), source(ins));
				uint_temp = MCOM_reg[MCOM_regselectSET][dest(ins)];

				for(i=0,b=1;i<MCOM_reg[MCOM_regselectSET][source(ins)];i++) b = b * 2;

				cbit = ((uint_temp & (b-1)) != 0); 
				uint_temp >>= MCOM_reg[MCOM_regselectSET][source(ins)];
				MCOM_reg[MCOM_regselectSET][dest(ins)] = uint_temp;
			break;

			/* Arithmetic Right Shift */
			case(OP2_SHR_A):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"SHR_A R%d, R%d\n", dest(ins), source(ins));

				for(i=0,b=1;i<MCOM_reg[MCOM_regselectSET][source(ins)];i++) b = b * 2;

				cbit = ((MCOM_reg[MCOM_regselectSET][dest(ins)] & (b-1)) != 0); 
				MCOM_reg[MCOM_regselectSET][dest(ins)] >>= MCOM_reg[MCOM_regselectSET][source(ins)];
			break;

			/* Compare */
			case(OP2_CMP):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"CMP R%d, R%d\n", dest(ins), source(ins));
				cbit = (MCOM_reg[MCOM_regselectSET][dest(ins)] == MCOM_reg[MCOM_regselectSET][source(ins)]);
			break;

			/* Cat */
			case(OP2_CAT):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"CAT R%d, R%d\n", dest(ins), source(ins));
				MCOM_reg[MCOM_regselectSET][dest(ins)] = ((MCOM_reg[MCOM_regselectSET][dest(ins)] & 0xffff) << 16) | (MCOM_reg[MCOM_regselectSET][source(ins)] & 0xffff);
			break;

			default:
				illegal_ins(ins ,pc);
			break;

			}//switch(op2(ins))

		break;

		/* MOVE with immediate */
		case(OP_MI):
			SIMLOG(SL_LS,PIPE_LOGLEVEL,"MVi R%d, %d\n", dest(ins), imm(ins));
			MCOM_reg[MCOM_regselectSET][dest(ins)] = imm(ins);
		break;

		/* ADD with immediate */
		case(OP_ADDI):
			SIMLOG(SL_LS,PIPE_LOGLEVEL,"ADDi R%d, %d\n", dest(ins), imm(ins));
			MCOM_reg[MCOM_regselectSET][dest(ins)] += imm(ins);
		break;

		/* SUB with immediate */
		case(OP_SUBI):
			SIMLOG(SL_LS,PIPE_LOGLEVEL,"SUBi R%d, %d\n", dest(ins), imm(ins));
			MCOM_reg[MCOM_regselectSET][dest(ins)] -= imm(ins);
		break;

		/* Compare with immediate */
		case(OP_CMPI):
			SIMLOG(SL_LS,PIPE_LOGLEVEL,"CMPi R%d, %d\n", dest(ins), imm(ins));
			cbit = (MCOM_reg[MCOM_regselectSET][dest(ins)] == imm(ins));
		break;

		/***************** �� AP/IP/HP Register Syori �� ******************/
		case(OP_I):
			switch(op2(ins))
			{
			/* Store */
			case(OP2_ST):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST @R%d, R%d\n", dest(ins), source(ins));
				//			mem[MCOM_reg[dest(ins)]] = MCOM_reg[source(ins)];
				ret = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][dest(ins)], &work1);
				if(ret==0){ /* Mcom */
					/*
					*work1 = (MCOM_reg[source(ins)]>>16) & 0xffff;
					*(work1+1) = MCOM_reg[source(ins)] & 0xffff;
					*/
					*work1 = MCOM_reg[MCOM_regselectSET][source(ins)] & 0xffff;
					*(work1+1) = (MCOM_reg[MCOM_regselectSET][source(ins)]>>16) & 0xffff;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST %x %x\n", *work1, *(work1+1));
				}else if(ret==1){ /* Img */
					*work1 = MCOM_reg[MCOM_regselectSET][source(ins)];
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST %x \n", *work1);
				}else if(ret==3){ /* HM,CM */
					WriteBaseAdr((unsigned char*)work1, MCOM_reg[MCOM_regselectSET][source(ins)]);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST %x \n", *work1);
				}else{
					illegal_ins(ins ,pc);
				}

			break;

			/* Store(relative address of PC) */
			/*		case(OP2_ST_PC):
			mem[reg[dest(ins)] + pc] = reg[source(ins)]; */
			/* 	  break; */

			/* Storing PC */
			case(OP2_ST_PC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST @R%d, PC:%d", dest(ins), pc);
				//		  mem[MCOM_reg[dest(ins)]] = pc;
				ret = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][dest(ins)], &work1);
				if(ret==0){ /* Mcom */
					/*
					*work1 = (pc>>16) & 0xffff;
					*(work1+1) = pc & 0xffff;
					*/
					*work1 = pc & 0xffff;
					*(work1+1) = (pc>>16) & 0xffff;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST %x %x\n", *work1, *(work1+1));
				}else if(ret==1){ /* Img */
					*work1 = pc;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST %x \n", *work1);
				}else if(ret==3){ /* HM,CM */
					WriteBaseAdr((unsigned char*)work1, pc);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST %x %x \n", *work1,pc);
				}else{
					illegal_ins(ins ,pc);
				}
			break;

			/* Load */
			case(OP2_LD):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD R%d, @R%d\n", dest(ins), source(ins));
				//		  MCOM_reg[dest(ins)] = mem[MCOM_reg[source(ins)]];
				ret = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][source(ins)], &work1);
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"   McomGetRegAdr ret = %d \n", ret);  // tsato
				if(ret==0){ /* Mcom */
					//MCOM_reg[dest(ins)] = ((*work1<<16) & 0xffff0000) | (*(work1+1) & 0xffff);
					MCOM_reg[MCOM_regselectSET][dest(ins)] = ((*(work1)<<16) & 0xffff0000) | (*(work1+1) & 0xffff); // H.Shiota
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD %x %x %x\n", *work1, *(work1+1), MCOM_reg[MCOM_regselectSET][dest(ins)]);
				}else if(ret==1){ /* Img */
					MCOM_reg[MCOM_regselectSET][dest(ins)] = *work1;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD %x %x\n", *work1, MCOM_reg[MCOM_regselectSET][dest(ins)]);
				}else if(ret==3){ /* HM,CM */
					ReadBaseAdr((unsigned char*)work1, (unsigned long *)&MCOM_reg[MCOM_regselectSET][dest(ins)]);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD %x %x\n", *work1, MCOM_reg[MCOM_regselectSET][dest(ins)]);
				}else{
					illegal_ins(ins ,pc);
				}
			break;

			/* Load(relative address of PC) */
			case(OP2_LD_PC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD R%d, @(pc+R%d)\n", dest(ins), source(ins));
				//		  MCOM_reg[dest(ins)] = mem[MCOM_reg[source(ins)] + pc];
				ret = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][source(ins)] + pc, &work1);
				if(ret==0){ /* Mcom */

					//			  MCOM_reg[dest(ins)] = ((*work1<<16) & 0xffff0000) | (*(work1+1) & 0xffff);
					//			  MCOM_reg[MCOM_regselectSET][dest(ins)] = ((*(work1+1)<<16) & 0xffff0000) | (*work1 & 0xffff);
#if PIPE_MODIFY
					MCOM_reg[MCOM_regselectSET][dest(ins)] = ((*(work1+1)<<16) & 0xffff0000) | (*work1 & 0xffff);
#else
					MCOM_reg[MCOM_regselectSET][dest(ins)] = ((*(work1)<<16) & 0xffff0000) | (*(work1+1) & 0xffff); 		 					  
#endif
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD %x \n", MCOM_reg[MCOM_regselectSET][dest(ins)]);
				}else if(ret==1){ /* Img */
					MCOM_reg[MCOM_regselectSET][dest(ins)] = *work1;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD %x \n", MCOM_reg[MCOM_regselectSET][dest(ins)]);
				}else if(ret==3){ /* HM,CM */
					ReadBaseAdr((unsigned char*)work1, (unsigned long *)&MCOM_reg[MCOM_regselectSET][dest(ins)]);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"LD %x %x \n", *work1, MCOM_reg[MCOM_regselectSET][dest(ins)]);
				}else{
					illegal_ins(ins ,pc);
				}
			break;

			/* Memory to Memory Copy */
			case(OP2_CP):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP @R%d, @R%d\n", dest(ins), source(ins));
				//		  mem[MCOM_reg[dest(ins)]] = mem[MCOM_reg[source(ins)]];
				ret = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][source(ins)], &work1);
				ret2 = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][dest(ins)], &work2);
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"ret=%x ret2=%x\n", ret, ret2);
				if( (ret==0)&&(ret2==0) ){ /* Mcom1 Mcom2 */
					*work2 = *work1;
					*(work2+1) = *(work1+1);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x \n", *work2, *(work2+1));
				}else if( (ret==1)&&(ret2==0) ){ /* Img1 Mcom2 */
					/*
					*work2 = (*work1>>16) & 0xffff;
					*(work2+1) = *work1 & 0xffff;
					*/
					*work2 = *work1 & 0xffff;
					*(work2+1) = (*work1>>16) & 0xffff;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x \n", *work2, *(work2+1));
				}else if( (ret==0)&&(ret2==1) ){ /* Mcom1 Img2 */
					//			  *work2 = ((*work1<<16) & 0xffff0000) | (*(work1+1) & 0xffff);
					*work2 = ((*(work1+1)<<16) & 0xffff0000) | (*work1 & 0xffff);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x \n", *work2);
				}else if( (ret==1)&&(ret2==1) ){ /* Img1 Img2 */
					*work2 = *work1;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x \n", *work2);
				}else if( (ret==0)&&(ret2==3) ){ /* Mcom1 (HM,CM)2 */
					WriteBaseAdr((unsigned char*)work2, (unsigned long)((*(work1+1)<<16) & 0xffff0000) | (*work1 & 0xffff));
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x \n", *work2);
				}else if( (ret==1)&&(ret2==3) ){ /* Img1 (HM,CM)2 */
					WriteBaseAdr((unsigned char*)work2, (unsigned long)*work1);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x  \n", *work2, *work1);
				}else if( (ret==3)&&(ret2==0) ){ /* (HM,CM)1 Mcom2 */
					ReadBaseAdr((unsigned char*)work1, &read_tmp);
					*work2 = read_tmp & 0xffff;
					*(work2+1) = (read_tmp>>16) & 0xffff;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x  \n", *(work2+1), *work2);
				}else if( (ret==3)&&(ret2==1) ){ /* (HM,CM)1 Img2 */
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"%x", *work1);
					ReadBaseAdr((unsigned char*)work1, (unsigned long *)work2);
				}else{
					illegal_ins(ins ,pc);
				}
			break;

			/* Memory to Memory Copy(Reg1:relative address of PC) */
			/*		case(OP2_CP1):
			mem[reg[dest(ins)] + pc] = mem[reg[source(ins)]];*/
			/*break; */

			/* Memory to Memory Copy(relative address of PC) */
			case(OP2_CP_PC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP @%d, @(pc+R%d)\n", dest(ins), source(ins));
				//		  mem[MCOM_reg[dest(ins)]] = mem[MCOM_reg[source(ins)] + pc];
				ret = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][source(ins)] + pc, &work1);
				ret2 = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][dest(ins)], &work2);
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"ret=%x ret2=%x\n", ret, ret2);
				if( (ret==0)&&(ret2==0) ){ /* Mcom1 Mcom2 */
					*work2 = *work1;
					*(work2+1) = *(work1+1);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x \n", *work2, *(work2+1));
				}else if( (ret==1)&&(ret2==0) ){ /* Img1 Mcom2 */
					/*
					*work2 = (*work1>>16) & 0xffff;
					*(work2+1) = *work1 & 0xffff;
					*/
					*work2 = *work1 & 0xffff;
					*(work2+1) = (*work1>>16) & 0xffff;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x \n", *work2, *(work2+1));
				}else if( (ret==0)&&(ret2==1) ){ /* Mcom1 Img2 */
					//			  *work2 = ((*work1<<16) & 0xffff0000) | (*(work1+1) & 0xffff);
					*work2 = ((*(work1+1)<<16) & 0xffff0000) | (*work1 & 0xffff);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x \n", *work2);
				}else if( (ret==1)&&(ret2==1) ){ /* Img1 Img2 */
					*work2 = *work1;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x \n", *work2);
				}else if( (ret==0)&&(ret2==3) ){ /* Mcom1 (HM,CM)2 */
					WriteBaseAdr((unsigned char*)work2, (unsigned long)((*(work1+1)<<16) & 0xffff0000) | (*work1 & 0xffff));
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x \n", *work2);
				}else if( (ret==1)&&(ret2==3) ){ /* Img1 (HM,CM)2 */
					WriteBaseAdr((unsigned char*)work2, (unsigned long)*work1);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x \n", *work2);
				}else if( (ret==3)&&(ret2==0) ){ /* (HM,CM)1 Mcom2 */
					ReadBaseAdr((unsigned char*)work1, &read_tmp);
					*work2 = read_tmp & 0xffff;
					*(work2+1) = (read_tmp>>16) & 0xffff;
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x \n", *work2, *(work2+1));
				}else if( (ret==3)&&(ret2==1) ){ /* (HM,CM)1 Img2 */
					ReadBaseAdr((unsigned char*)work1, (unsigned long *)work2);
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"CP %x %x \n", *work1, *work2);
				}else{
					illegal_ins(ins ,pc);
				}
			break;


			default:
				illegal_ins(ins ,pc);
			break;

			}//switch(op2(ins))

		break;

		/* Store immediate value */
		case(OP_STI):
			SIMLOG(SL_LS,PIPE_LOGLEVEL,"ST @R%d, %d\n", dest(ins), imm(ins));
			//	  mem[MCOM_reg[dest(ins)]] = imm(ins);
			ret = McomGetRegAdr(MCOM_reg[MCOM_regselectSET][dest(ins)], &work1);
			SIMLOG(SL_LS,PIPE_LOGLEVEL,"ret=%x\n", ret);
			if(ret==0){ /* Mcom */
				/*
				*work1 = 0;
				*(work1+1) = imm(ins) & 0x00ff;
				*/
				*work1 = imm(ins) & 0x00ff;
				*(work1+1) = 0;
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"STI %x %x \n", *work1, *(work1+1));
			}else if(ret==1){ /* Img */
				*work1 = imm(ins);
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"STI %x \n", *work1);
			}else if(ret==3){ /* HM,CM */
				WriteBaseAdr((unsigned char*)work1, imm(ins));
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"STI %x \n", *work1);
			}else{
				illegal_ins(ins ,pc);
			}
		break;
		/***************** �� AP/IP/HP Register Syori �� ******************/

		/* J type instructions */
		case(OP_J):
			switch(op2(ins))
			{
			/* Branch True */	  
			case(OP2_BT):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"BT %d\n", disp(ins));
				if(cbit)
				pc = disp(ins) - 1;
			break;

			/* Branch True(PC relative) */
			case(OP2_BT_PC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"BT pc + %d\n", disp_pc(ins));
				if(cbit)
				pc += disp_pc(ins) - 1;
			break;

			/*Branch True(R relative) */
			case(OP2_BT_R):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"BT R%d + %d\n", dest(ins), disp_r(ins));
				if(cbit)
				pc = MCOM_reg[MCOM_regselectSET][dest(ins)] + disp_r(ins) - 1;
			break;

			/* Branch False */
			case(OP2_BF):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"BF %d\n", disp(ins));
				if(!cbit)
				pc = disp(ins) - 1;
			break;

			/* Branch False(PC relative) */
			case(OP2_BF_PC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"BF pc + %d\n", disp_pc(ins));
				if(!cbit)
				pc += disp_pc(ins) - 1;
			break;

			/*Branch False(R relative) */
			case(OP2_BF_R):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"BF R%d + %d\n", dest(ins), disp_r(ins));
				if(!cbit)
				pc = MCOM_reg[MCOM_regselectSET][dest(ins)] + disp_r(ins) - 1;
			break;

			/* non-conditional JUMP */
			case(OP2_JMP):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"JMP %d\n", disp(ins));
				pc = disp(ins) - 1;
			break;

			/* non-conditional JUMP(PC relative) */
			case(OP2_JMP_PC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"JMP pc + %d\n", disp_pc(ins));
				pc += disp_pc(ins) - 1;
			break;

			/* non-conditional JUMP(R relative) */
			case(OP2_JMP_R):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"JMP R%d + %d\n", dest(ins), disp_r(ins));
				pc = MCOM_reg[MCOM_regselectSET][dest(ins)] + disp_r(ins) - 1;
			break;

			/* go to subroutine */
			case(OP2_GOSUB):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"GOSUB %d\n", disp(ins));
				/*
				mem[MCOM_reg[MCOM_SP]  ] = (pc>>16) & 0xffff;
				mem[MCOM_reg[MCOM_SP]+1] = pc & 0xffff;
				*/
				mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]  ] = pc & 0xffff;
				mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]+1] = (pc>>16) & 0xffff;
				MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] - 2;
				pc = disp(ins) - 1;
				SIMLOG(SL_LS,PIPE_LOGLEVEL," -> pc=%d\n",pc);  // tsato
			break;

			/* go to subroutine(PC relative) */
			case(OP2_GOSUB_PC):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"GOSUB pc + %d\n", disp_pc(ins));
				/*
				mem[MCOM_reg[MCOM_SP]  ] = (pc>>16) & 0xffff;
				mem[MCOM_reg[MCOM_SP]+1] = pc & 0xffff;
				*/
				mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]  ] = pc & 0xffff;
				mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]+1] = (pc>>16) & 0xffff;
				MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] - 2;
				pc += disp_pc(ins) - 1;
				SIMLOG(SL_LS,PIPE_LOGLEVEL," -> pc=%d\n",pc);
			break;

			/* go to subroutine(R relative) */
			case(OP2_GOSUB_R):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"GOSUB R%d + %d\n", dest(ins), disp_r(ins));
				/*
				mem[MCOM_reg[MCOM_SP]  ] = (pc>>16) & 0xffff;
				mem[MCOM_reg[MCOM_SP]+1] = pc & 0xffff;
				*/
				mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]  ] = pc & 0xffff;
				mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]+1] = (pc>>16) & 0xffff;
				MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] - 2;
				pc = MCOM_reg[MCOM_regselectSET][dest(ins)] + disp_r(ins) - 1;
				SIMLOG(SL_LS,PIPE_LOGLEVEL," -> pc=%d\n",pc);
			break;

			case(OP2_RTS):
				//		  SIMLOG(SL_LS,PIPE_LOGLEVEL,"RTS %d, %d\n", MCOM_reg[MCOM_SP], mem[MCOM_reg[MCOM_SP]]);
				MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] + 2;
				//			pc = ((mem[MCOM_reg[MCOM_SP]]<<16) & 0xffff0000) | (mem[MCOM_reg[MCOM_SP]+1] & 0xffff);
				pc = ((mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]+1]<<16) & 0xffff0000) | (mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]] & 0xffff);
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"RTS %d, %d\n", MCOM_reg[MCOM_regselectSET][MCOM_SP], pc);
			break;

			default:
				illegal_ins(ins ,pc);
			break;

			}//switch(op2(ins))

		break;

		/* EXE/SNC instruction */
		case(OP_SYNC): 
			if(sync(ins))
			{
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"SNC instruction for IP:%d, AP:%d\n", ip(ins), ap(ins));
			}
			else
			{
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"EXE instruction for IP:%d, AP:%d\n", ip(ins), ap(ins));
				/* AP EXEC */
				if(ap(ins))
				{
					xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
					if(UseImg[0])
					{
						SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC   %d %d\n", MCOM_InputLine_SA, MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A]);
						
//needlessly			if((MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A]>=0)&&(MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A]<LM_NUM))
//						{
							SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %d\n", xlng, MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A]);
							Read1LineSrc0PIPE(MCOM_InputLine_SA, sour_id_work);
							MCOM_InputLine_SA++;
							for(i=0;i<xlng;i++)
							{
								sour_id[
										pffta_wadr(	/*IMPREG_FFTCTL_READ(),*/
													IMPREG_PFFTASEL1_READ(),
													IMPREG_PFFTASEL2_READ(),
													IMPREG_PFFTAMSK_READ(), i)
										] = sour_id_work[i];
							}
							/* IPFORM  srca_pre_em==0 && srca_ind_em==2 -> convert 8bpp to 16bpp */
							if( (((IMPREG_IPFORM_READ()) & 0x0007)==0) && (((IMPREG_IPFORM_READ()>>8) & 0x0007)==2) )
							{
								SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %x\n", xlng, IMPREG_IPFORM_READ());
								/* signed 16bpp */
								if((IMPREG_FFTCTL_READ()>>16) & 0x0001)
								{
									SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %x\n", xlng, IMPREG_FFTCTL_READ());
									for(i=0;i<xlng;i++)
									{
										if(sour_id[i]&0x80) sour_id[i] = (short)((sour_id[i]) | 0xff00);
									}
								}
							}

							WriteLM256(MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A], 0, sour_id, xlng);
//						}
//						else
//						{
//							SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %d\n", xlng, MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A]);
//						}//if((MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A]>=0)&&(MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_A]<LM_NUM))

					}//if(UseImg[0])

					if(UseImg[1])
					{
						SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC   %d %d\n", MCOM_InputLine_SB, MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B]);
						
//needlessly			if((MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B]>=0)&&(MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B]<LM_NUM))
//						{
							SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %d\n", xlng, MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B]);
							Read1LineSrc1PIPE(MCOM_InputLine_SB, sour_id_work);
							MCOM_InputLine_SB++;
							for(i=0;i<xlng;i++)
							{
								sour_id[
										pfftb_wadr(	/*IMPREG_FFTCTL_READ(),*/
													IMPREG_PFFTBSEL1_READ(),
													IMPREG_PFFTBSEL2_READ(),
													IMPREG_PFFTBMSK_READ(), i)
										] = sour_id_work[i];
							}

							/* IPFORM  srcb_pre_em==0 && srcb_ind_em==2 -> convert 8bpp to 16bpp */
							if( (((IMPREG_IPFORM_READ()>>4) & 0x0007)==0) && (((IMPREG_IPFORM_READ()>>12) & 0x0007)==2) )
							{
								SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %x\n", xlng, IMPREG_IPFORM_READ());
								/* signed 16bpp */
								if((IMPREG_FFTCTL_READ()>>17) & 0x0001)
								{
									SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %x\n", xlng, IMPREG_FFTCTL_READ());
									for(i=0;i<xlng;i++)
									{
										if(sour_id[i]&0x80) sour_id[i] = (short)((sour_id[i]) | 0xff00);
									}
								}
							}

							WriteLM256(MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B], 0, sour_id, xlng);
						
//						}
//						else
//						{
//							SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d %d\n", xlng, MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B]);
//						}//if((MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B]>=0)&&(MCOM_reg[MCOM_regselectEXC][MCOM_LM_INPUT_WT_PTR_B]<LM_NUM))
					
					}//if(UseImg[1])

				}//if(ap(ins))
			
				/* IP EXEC */
				if(ip(ins)){
					SIMLOG(SL_LS,PIPE_LOGLEVEL,"APEXEC %d \n", ip(ins));
					ret = IPExec();
//					ret is always zero. // if(ret) illegal_ins(ins ,pc);
				}

			}//if(sync(ins))

		break;

		/* Stack Instcution */
		case(OP_STACK):
			/* POP */
			if(pop(ins)) 
			{
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"POP R%d, R%d\n", stack_start_pop(ins), 
				stack_end_pop(ins));
				MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] + 2;
				for(j = stack_start_pop(ins);j >= stack_end_pop(ins); j--)
				{
					//		  MCOM_reg[j] = (((mem[MCOM_reg[MCOM_SP]]<<16) & 0xffff0000) | (mem[MCOM_reg[MCOM_SP]+1] & 0xffff));
					MCOM_reg[MCOM_regselectSET][j] = (((mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]+1]<<16) & 0xffff0000) | (mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]] & 0xffff));
					MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] + 2;
				}
				MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] - 2;
			}
			/* PUSH */
			else 
			{
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"PUSH R%d, R%d\n", stack_start_push(ins),
				stack_end_push(ins));
				for(j = stack_start_push(ins); j <= stack_end_push(ins);j ++) 
				{
					/*
					mem[MCOM_reg[MCOM_SP]  ] = (MCOM_reg[j]>>16) & 0xffff;
					mem[MCOM_reg[MCOM_SP]+1] = MCOM_reg[j] & 0xffff;
					*/
					mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]  ] = MCOM_reg[MCOM_regselectSET][j] & 0xffff;
					mem[IMP_WORK_CH][MCOM_reg[MCOM_regselectSET][MCOM_SP]+1] = (MCOM_reg[MCOM_regselectSET][j]>>16) & 0xffff;

					MCOM_reg[MCOM_regselectSET][MCOM_SP] = MCOM_reg[MCOM_regselectSET][MCOM_SP] - 2;
				}
			}
		break;

		case(OP_NOP):
			switch(flip(ins))
			{
			case(OPNOP_NOP):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"NOP decoded\n");
			break;
			case(OPNOP_INT):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"INT decoded\n");
			break;
			case(OPNOP_FLIP):
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"FLIP LM=%d MC=%d\n", flip_lm(ins), flip_mc(ins));
				if(flip_mc(ins)){
					MCOM_regselectSET++;
					if(MCOM_regselectSET==MCOM_NUM_REGSETS) MCOM_regselectSET = 0;

					SIMLOG(SL_LS,PIPE_LOGLEVEL,"FLIP LM=%d MC=%d MCOM_regselectSET=%d \n", flip_lm(ins), flip_mc(ins), MCOM_regselectSET);
				
				}
				if(flip_lm(ins)){
					MCOM_regselectEXC++;
					if(MCOM_regselectEXC==MCOM_NUM_REGSETS) MCOM_regselectEXC = 0;

					SIMLOG(SL_LS,PIPE_LOGLEVEL,"FLIP LM=%d MC=%d MCOM_regselectEXC=%d \n", flip_lm(ins), flip_mc(ins), MCOM_regselectEXC);

				}
			break;
			default:/* case(OPNOP_MVB) */
				SIMLOG(SL_LS,PIPE_LOGLEVEL,"MVB LM=%x R=%02x SP=%x DIR=%x\n", mvb_lm(ins), mvb_r(ins), mvb_sp(ins),  mvb_dir(ins));
				/* dir 0:SET1->SET0 1:SET0->SET1  */
				if(mvb_dir(ins)){ 
					src=0;
					dst=1;
				}else{
					src=1;
					dst=0;
				}
				/* R8-R14 */
				if(mvb_lm(ins)){
					for(i=8;i<=14;i++) MCOM_reg[dst][i] = MCOM_reg[src][i];
				}
				/* R1-R7 */
				for(i=0;i<7;i++){
					if(((mvb_r(ins))>>i)&0x1) MCOM_reg[dst][i+1] = MCOM_reg[src][i+1];
				}
				/* R15 */
				if(mvb_sp(ins)){
					MCOM_reg[dst][MCOM_SP] = MCOM_reg[src][MCOM_SP];
				}
			break;
//			default:
//				illegal_ins(ins ,pc);
//			break;
			}//switch(flip(ins))

		break;

		case(OP_SLEEP):
			SIMLOG(SL_LS,PIPE_LOGLEVEL,"SLEEP decoded\n");
			sleep = 1;
		break;

		default:
			illegal_ins(ins ,pc);
		break;
		}
		pc++;
	}//while(sleep == 0)

}//void PipeCommonProc()



/******************************************************************************/
/* Convert8bppParallel														  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato 											  */
/*						 new												  */
/******************************************************************************/
void Convert8bppParallel()
{
	unsigned long read_tmp;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	// IPFORM need for PIPE in ReadLM256A. So have to back up.
	IPFORM_BACKUP = IMPREG_IPFORM_READ();
	
	// Convert 8bppParallel to 8bppSerial
	// Reverse for implib_TwoPara of ipxdrv1_implib.c
	read_tmp = IMPREG_IPFORM_READ();
	if (((read_tmp & 0x00000077) == 0x00000044) && ((IMPREG_IPFUN_READ() & 0xFF000000) == 0x57000000)) {
		IMPREG_IPFORM_WRITE( IMPREG_IPFORM_READ() & ~0x00000077);
		IMPREG_APCFG_WRITE( (IMPREG_APCFG_READ() & ~0x01077700) | 0x01011100);
		// SIMLOG(SL_LS, SL_L6, "Convert8bppParallel Route 1\n");
	} else if ((read_tmp & 0x70777777) == 0x40444444) {
		IMPREG_IPFORM_WRITE( IMPREG_IPFORM_READ() & ~0x70777777);
		IMPREG_APCFG_WRITE( (IMPREG_APCFG_READ() & ~0x01077700) | 0x01011100);
		// SIMLOG(SL_LS, SL_L6, "Convert8bppParallel Route 2\n");
	}
	
	return;
}


/******************************************************************************/
/* Check8bppParallel														  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/24 T.Sato 											  */
/*						 todo	  (Error occurred for this check cord!) 	  */
/******************************************************************************/
int Check8bppParallel()
{
	unsigned long read_tmp;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s  todo\n",__FUNCTION__);
#endif
	
	// IPFORM need for PIPE in ReadLM256A. So have to back up.
	IMPREG_IPFORM_WRITE( IPFORM_BACKUP);
	
	return(0); // todo
	
#if 0	
	// Check 8bppParallel
	read_tmp = IMPREG_IPFORM_READ();
	if (read_tmp == 0x40444444) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -1;
	} else if (read_tmp == 0x00000044) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -1;
	} else if ((read_tmp & 0x00000007) == 0x00000004) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -2;
	} else if ((read_tmp & 0x00000070) == 0x00000040) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -2;
	} else if ((read_tmp & 0x00000700) == 0x00000400) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -2;
	} else if ((read_tmp & 0x00007000) == 0x00004000) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -2;
	} else if ((read_tmp & 0x00070000) == 0x00040000) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -2;
	} else if ((read_tmp & 0x00700000) == 0x00400000) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -2;
	} else if ((read_tmp & 0x70000000) == 0x40000000) {
		SIMLOG(SL_LS, SL_L4, " ->IPFORM = 0x%08x is not supported!!!\n", read_tmp);
		return -2;
	}
	
	read_tmp = IMPREG_APCFG_READ();
	if ((read_tmp & 0x00000700) == 0x00000500) {
		SIMLOG(SL_LS, SL_L4, " ->APCFG = 0x%08x is not supported!!!\n", read_tmp);
		return -4;
	} else if ((read_tmp & 0x00007000) == 0x00005000) {
		SIMLOG(SL_LS, SL_L4, " ->APCFG = 0x%08x is not supported!!!\n", read_tmp);
		return -4;
	} else if ((read_tmp & 0x00070000) == 0x00050000) {
		SIMLOG(SL_LS, SL_L4, " ->APCFG = 0x%08x is not supported!!!\n", read_tmp);
		return -4;
	}
	
	return(0);
#endif

}

void illegal_ins(int ins, int pc)
{
  SIMLOG(SL_LS, SL_L4, "illegal instruction:%x, pc = %d\n", ins, pc);
  return;
}

/******************************************************************************/
/* McomGetRegAdr                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int McomGetRegAdr(int no, int **adr){
	int i, j, mcptr_no;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L6, "****** %s  no=%d\n",__FUNCTION__, no);
#endif
	
	*adr = 0;
	if ( no >= 0 && no < MCOM_MAX_MEM_ADDR){ /* Mcom Register */
		no = no & 0xfffffffe;
		*adr = &mem[IMP_WORK_CH][no];
		return(0);
	}else if ( no >= MCOM_IPREG_S && no <= MCOM_IPREG_E ){ /* Img Register */
		/* check Adr  */
		for(i=0;i<REGMAX;i++){
			if( regtable[i].adr == (unsigned long)(no&0x00000fff) ){
				if(regtable[i].regbank==1){
					*adr = (int *)&IMPREG[IMP_WORK_CH][Get_regselectSET(IMP_WORK_CH)][regtable[i].No];
				}else if(regtable[i].regbank==2){
					*adr = (int *)&IMPREG[IMP_WORK_CH][Get_COEFFregselectSET(IMP_WORK_CH)][regtable[i].No];
				}else{
					if(!(strcmp((const char *)regtable[i].regname, "MCINDACC"))) { /* MCINDACC */
						mcptr_no = IMPREG_MCPTR_READ();
						SIMLOG(SL_LS, SL_L4, "no=%x %x\n",no,mcptr_no);

						/* MCPTR inc */
						IMPREG_MCPTR_WRITE( IMPREG_MCPTR_READ() + 4);

						 /* check Adr(MCPTR)  */
/* HM */
						if(mcptr_no >= DL_IPREG_HM_S && mcptr_no <= DL_IPREG_HM_E){
							*adr = (int *)(pHM[IMP_WORK_CH] + ( mcptr_no - DL_IPREG_HM_S ));
							return(3);
/* CM0 */
						}else if(mcptr_no >= DL_IPREG_CMA_S && mcptr_no <= DL_IPREG_CMA_E){
							*adr = (int *)(pCM0[IMP_WORK_CH] + ( mcptr_no - DL_IPREG_CMA_S ));
							return(3);
/* CM1 */
						}else if(mcptr_no >= DL_IPREG_CMB_S && mcptr_no <= DL_IPREG_CMB_E){
							*adr = (int *)(pCM1[IMP_WORK_CH] + ( mcptr_no - DL_IPREG_CMB_S ));
							return(3);
/* Img Register */
						}else{
							for(j=0;j<REGMAX;j++){
								if( regtable[j].adr == (unsigned long)(mcptr_no&0x00000fff) ){
									if(regtable[j].regbank==1){
										*adr = (int *)&IMPREG[IMP_WORK_CH][Get_regselectSET(IMP_WORK_CH)][regtable[j].No];
									}else if(regtable[j].regbank==2){
										*adr = (int *)&IMPREG[IMP_WORK_CH][Get_COEFFregselectSET(IMP_WORK_CH)][regtable[j].No];
									}else{
										*adr = (int *)&IMPREG[IMP_WORK_CH][REGSETS_DEFAULT][regtable[j].No];
									}
								}
							}
						}

						SIMLOG(SL_LS, SL_L4, "adr=%x\n", **adr);
					}else{ /* not MCINDACC */
						*adr = (int *)&IMPREG[IMP_WORK_CH][REGSETS_DEFAULT][regtable[i].No];
					}
				}
			}
		}
		if(*adr==0){ /* Error */
			return(2);
		}else{
			return(1);
		}
	}

	return(2);
}


/******************************************************************************/
/* AllocateLineMemory														  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20  T.Sato 											  */
/*						  new												  */
/******************************************************************************/
void AllocateLineMemory()
{
	unsigned long xlng, ylng;
	
#ifndef IMPSIM_INTEGRATED
	SIMLOG(SL_LS, SL_L5, "***** %s\n",__FUNCTION__);
#endif
	
	// size check
	xlng = IMPREG_APLNG_READ() & 0x3fff;
	ylng = (IMPREG_APLNG_READ() >> 16) & 0x3fff;
	if ((xlng > XSIZE) || (ylng > YSIZE)) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, AllocateLineMemory() xlng = %d, ylng = %d failed.\n", xlng, ylng);
		Legacy_assert_error();
	}
	
	// line 0
	pcLM0 = (char *) pLINE0[IMP_WORK_CH];
	psLM0 = (short *) pLINE0[IMP_WORK_CH];
	plLM0 = (int *) pLINE0[IMP_WORK_CH];
	pucLM0 = (unsigned char *) pLINE0[IMP_WORK_CH];
	pusLM0 = (unsigned short *) pLINE0[IMP_WORK_CH];
	pulLM0 = (unsigned int *) pLINE0[IMP_WORK_CH];
	
	// line 1
	pcLM1 = (char *) pLINE1[IMP_WORK_CH];
	psLM1 = (short *) pLINE1[IMP_WORK_CH];
	plLM1 = (int *) pLINE1[IMP_WORK_CH];
	pucLM1 = (unsigned char *) pLINE1[IMP_WORK_CH];
	pusLM1 = (unsigned short *) pLINE1[IMP_WORK_CH];
	pulLM1 = (unsigned int *) pLINE1[IMP_WORK_CH];
	
	// line 2
	pcLM2 = (char *) pLINE2[IMP_WORK_CH];
	psLM2 = (short *) pLINE2[IMP_WORK_CH];
	plLM2 = (int *) pLINE2[IMP_WORK_CH];
	pucLM2 = (unsigned char *) pLINE2[IMP_WORK_CH];
	pusLM2 = (unsigned short *) pLINE2[IMP_WORK_CH];
	pulLM2 = (unsigned int *) pLINE2[IMP_WORK_CH];
	
	// line 3
	pcLM3 = (char *) pLINE3[IMP_WORK_CH];
	psLM3 = (short *) pLINE3[IMP_WORK_CH];
	plLM3 = (int *) pLINE3[IMP_WORK_CH];
	pucLM3 = (unsigned char *) pLINE3[IMP_WORK_CH];
	pusLM3 = (unsigned short *) pLINE3[IMP_WORK_CH];
	pulLM3 = (unsigned int *) pLINE3[IMP_WORK_CH];
	
	// line 4
	pcLM4 = (char *) pLINE4[IMP_WORK_CH];
	psLM4 = (short *) pLINE4[IMP_WORK_CH];
	plLM4 = (int *) pLINE4[IMP_WORK_CH];
	pucLM4 = (unsigned char *) pLINE4[IMP_WORK_CH];
	pusLM4 = (unsigned short *) pLINE4[IMP_WORK_CH];
	pulLM4 = (unsigned int *) pLINE4[IMP_WORK_CH];
	
	// line 5
	pcLM5 = (char *) pLINE5[IMP_WORK_CH];
	psLM5 = (short *) pLINE5[IMP_WORK_CH];
	plLM5 = (int *) pLINE5[IMP_WORK_CH];
	pucLM5 = (unsigned char *) pLINE5[IMP_WORK_CH];
	pusLM5 = (unsigned short *) pLINE5[IMP_WORK_CH];
	pulLM5 = (unsigned int *) pLINE5[IMP_WORK_CH];
	
	// line 6
	pcLM6 = (char *) pLINE6[IMP_WORK_CH];
	psLM6 = (short *) pLINE6[IMP_WORK_CH];
	plLM6 = (int *) pLINE6[IMP_WORK_CH];
	pucLM6 = (unsigned char *) pLINE6[IMP_WORK_CH];
	pusLM6 = (unsigned short *) pLINE6[IMP_WORK_CH];
	pulLM6 = (unsigned int *) pLINE6[IMP_WORK_CH];
	
	// line 7
	pcLM7 = (char *) pLINE7[IMP_WORK_CH];
	psLM7 = (short *) pLINE7[IMP_WORK_CH];
	plLM7 = (int *) pLINE7[IMP_WORK_CH];
	pucLM7 = (unsigned char *) pLINE7[IMP_WORK_CH];
	pusLM7 = (unsigned short *) pLINE7[IMP_WORK_CH];
	pulLM7 = (unsigned int *) pLINE7[IMP_WORK_CH];
	
	// line 8
	pcLM8 = (char *) pLINE8[IMP_WORK_CH];
	psLM8 = (short *) pLINE8[IMP_WORK_CH];
	plLM8 = (int *) pLINE8[IMP_WORK_CH];
	pucLM8 = (unsigned char *) pLINE8[IMP_WORK_CH];
	pusLM8 = (unsigned short *) pLINE8[IMP_WORK_CH];
	pulLM8 = (unsigned int *) pLINE8[IMP_WORK_CH];
	
	return;
}


