/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG2_0100.c                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-01 : 2015/02/17   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"
#include "legacy_micro_op.h"

static int ffta_radr(/*int fftctl, */int fftasel1, int fftasel2, int fftamsk, int in_adr);
static int fftb_radr(/*int fftctl, */int fftbsel1, int fftbsel2, int fftbmsk, int in_adr);
static int fftd_wadr(/*int fftctl, */int fftdsel1, int fftdsel2, int fftdmsk, int in_adr);

/******************************************************************************/
/* IMG2_0100                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-01 : 2015/02/17   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
int IMG2_0100(){

    int64 Xr, Yr, Xi, Yi, xr, xi, yr, yi, wr, wi;
	short *sour_id1 = psLM1;
	short *sour_id2 = psLM2;
	short *sour_id3 = psLM3;
	short *sour_id4 = psLM4;
    int64 result1[FFT_LM_SIZE], result2[FFT_LM_SIZE];
    int work, order, preorder, twpre, twpre_shift, fftaim_msk, mask, xlng, i;

    memset(sour_id1, 0, FFT_LM_SIZE * sizeof(short));
    memset(sour_id2, 0, FFT_LM_SIZE * sizeof(short));
    memset(sour_id3, 0, FFT_LM_SIZE * sizeof(short));
    memset(sour_id4, 0, FFT_LM_SIZE * sizeof(short));
    memset(result1, 0, FFT_LM_SIZE * sizeof(int64));
    memset(result2, 0, FFT_LM_SIZE * sizeof(int64));

    preorder = ((IMPREG_FFTCTL_READ() >> 4) & 0x0007);
    order = ((IMPREG_FFTCTL_READ() ) & 0x0007);
    twpre = ((IMPREG_FFTCTL_READ() >> 19) & 0x0003); /* 0:15bit shift, 1:14bit shift, 2:13bit shift, 3:12bit shift */
    fftaim_msk = ((IMPREG_FFTCTL_READ() >> 18) & 0x0001);
    mask = ((IMPREG_FFTCTL_READ() >> 8) & 0x00ff);

    xlng = (IMPREG_APLNG_READ() & 0x3fff);
    
    twpre_shift = 15 - twpre;

/* Read srcA 2Line, srcB 2Line */
/* FFTCTL fftaim_msk=1 -> srcA(sour_id2) data=0  */

    /* MCOM_LM_RD_START_A Check */
    work = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_A];
    if( (work+32)>LM_NUM){
        SIMLOG(SL_LS, SL_L4, "error  MCOM_LM_RD_START_A=%d\n", work);
        return(-1);
    }
    /* read srcA data */
    Read1LineLM256A(0, sour_id1);
    if(fftaim_msk==0){
        MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_A] +=32;
        Read1LineLM256A(0, sour_id2);
        MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_A] -=32;
    }

    /* MCOM_LM_RD_START_B Check */
    work = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B];
    if( (work+32)>LM_NUM){
        SIMLOG(SL_LS, SL_L4, "error  MCOM_LM_RD_START_B=%d\n", work);
        return(-1);
    }
    /* read srcB data */
    Read1LineLM256B(sour_id3);
    MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] +=32;
    Read1LineLM256B(sour_id4);
    MCOM_reg[MCOM_regselectEXC][MCOM_LM_RD_START_B] -=32;

/* FFT Exec */
    for(i=0;i<xlng;i+=2){

        xr = (int64)sour_id1[ffta_radr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTASEL1_READ(), IMPREG_FFTASEL2_READ(), IMPREG_PFFTAMSK_READ(), i  )];
        xi = (int64)sour_id2[ffta_radr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTASEL1_READ(), IMPREG_FFTASEL2_READ(), IMPREG_PFFTAMSK_READ(), i  )];
        yr = (int64)sour_id1[ffta_radr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTASEL1_READ(), IMPREG_FFTASEL2_READ(), IMPREG_PFFTAMSK_READ(), i+1)];
        yi = (int64)sour_id2[ffta_radr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTASEL1_READ(), IMPREG_FFTASEL2_READ(), IMPREG_PFFTAMSK_READ(), i+1)];
        wr = (int64)sour_id3[fftb_radr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTBSEL1_READ(), IMPREG_FFTBSEL2_READ(), IMPREG_FFTBMSK_READ(), i  )];
        wi = (int64)sour_id4[fftb_radr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTBSEL1_READ(), IMPREG_FFTBSEL2_READ(), IMPREG_FFTBMSK_READ(), i  )];

        Xr = (int64)((xr<<twpre_shift) + (yr*wr - yi*wi));
        Xi = (int64)((xi<<twpre_shift) + (yr*wi + yi*wr));
        Yr = (int64)((xr<<twpre_shift) - (yr*wr - yi*wi));
        Yi = (int64)((xi<<twpre_shift) - (yr*wi + yi*wr));

        result1[fftd_wadr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTDSEL1_READ(), IMPREG_FFTDSEL2_READ(), IMPREG_FFTDMSK_READ(), i  )] = Xr;
        result1[fftd_wadr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTDSEL1_READ(), IMPREG_FFTDSEL2_READ(), IMPREG_FFTDMSK_READ(), i+1)] = Yr;
        result2[fftd_wadr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTDSEL1_READ(), IMPREG_FFTDSEL2_READ(), IMPREG_FFTDMSK_READ(), i  )] = Xi;
        result2[fftd_wadr(/*IMPREG_FFTCTL_READ(), */IMPREG_FFTDSEL1_READ(), IMPREG_FFTDSEL2_READ(), IMPREG_FFTDMSK_READ(), i+1)] = Yi;

    }

    /* MCOM_LM_RESULT_WT_PTR Check */
    work = MCOM_reg[MCOM_regselectEXC][MCOM_LM_RESULT_WT_PTR];
    if( (work+32)>LM_NUM){
        SIMLOG(SL_LS, SL_L4, "error  MCOM_LM_RESULT_WT_PTR=%d\n", work);
        return(-1);
    }
    /* Write Dest data */
    Write1LineDst(0, result1);
    MCOM_reg[MCOM_regselectEXC][MCOM_LM_RESULT_WT_PTR] +=32;
    Write1LineDst(1, result2);
    MCOM_reg[MCOM_regselectEXC][MCOM_LM_RESULT_WT_PTR] -=32;

    return 0;
}

/******************************************************************************/
/* pffta_wadr                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/15   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
int pffta_wadr(/*int fftctl, */int pfftasel1, int pfftasel2, int pfftamsk, int in_adr) {

    int ta[12];
    int oa[12];
    int i;
    int asel[12];
    int out_adr;

    for(i=0; i< 12; i++) {
        ta[i] = (in_adr >> i) & 0x1;
    }
    for(i=0; i< 8; i++) {
        asel[i] = (pfftasel1 >> (i*4) ) & 0xf;
    }
    for(i=0; i< 4; i++) {
        asel[i+8] = (pfftasel2 >> (i*4) ) & 0xf;
    }

    for(i=0; i< 12; i++) {
        if ( (pfftamsk >> i) & 0x1) {
            if ( (pfftamsk >> (i+16)) & 0x1) {
                oa[i] = 1;
            } else {
                oa[i] = 0;
            }
        } else {
            oa[i] = ta[asel[i]];
        }
    }

    out_adr = (in_adr & 0xfffff000);
    for(i=0; i< 12; i++) {
        out_adr = out_adr  | ( (oa[i] & 0x1) << i);
    }

    return out_adr;
}


/******************************************************************************/
/* pfftb_wadr                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/15   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
int pfftb_wadr(/*int fftctl, */int pfftbsel1, int pfftbsel2, int pfftbmsk, int in_adr) { 

    int ta[12];
    int oa[12];
    int i;
    int asel[12];
    int out_adr;

    for(i=0; i< 12; i++) {
        ta[i] = (in_adr >> i) & 0x1;
    }
    for(i=0; i< 8; i++) {
        asel[i] = (pfftbsel1 >> (i*4) ) & 0xf;
    }
    for(i=0; i< 4; i++) {
        asel[i+8] = (pfftbsel2 >> (i*4) ) & 0xf;
    }

    for(i=0; i< 12; i++) {
        if ( (pfftbmsk >> i) & 0x1) {
            if ( (pfftbmsk >> (i+16)) & 0x1) {
                oa[i] = 1;
            } else {
                oa[i] = 0;
            }
        } else {
            oa[i] = ta[asel[i]];
        }
    }

    out_adr = (in_adr & 0xfffff000);
    for(i=0; i< 12; i++) {
        out_adr = out_adr  | ( (oa[i] & 0x1) << i);
    }

    return out_adr;
}

/******************************************************************************/
/* ffta_radr                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/15   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int ffta_radr(/*int fftctl, */int fftasel1, int fftasel2, int fftamsk, int in_adr) { 

    int ta[12];
    int oa[12];
    int i;
    int asel[12];
    int out_adr;

    for(i=0; i< 12; i++) {
        ta[i] = (in_adr >> i) & 0x1;
    }
    for(i=0; i< 8; i++) {
        asel[i] = (fftasel1 >> (i*4) ) & 0xf;
    }
    for(i=0; i< 4; i++) {
        asel[i+8] = (fftasel2 >> (i*4) ) & 0xf;
    }

    for(i=0; i< 12; i++) {
        if ( (fftamsk >> i) & 0x1) {
            if ( (fftamsk >> (i+16)) & 0x1) {
                oa[i] = 1;
            } else {
                oa[i] = 0;
            }
        } else {
            oa[i] = ta[asel[i]];
        }
    }

    out_adr = (in_adr & 0xfffff000);
    for(i=0; i< 12; i++) {
        out_adr = out_adr  | ( (oa[i] & 0x1) << i);
    }

    return out_adr;
}

/******************************************************************************/
/* fftb_radr                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/15   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int fftb_radr(/*int fftctl, */int fftbsel1, int fftbsel2, int fftbmsk, int in_adr) { 

    int ta[12];
    int oa[12];
    int i;
    int asel[12];
    int out_adr;

    for(i=0; i< 12; i++) {
        ta[i] = (in_adr >> i) & 0x1;
    }
    for(i=0; i< 8; i++) {
        asel[i] = (fftbsel1 >> (i*4) ) & 0xf;
    }
    for(i=0; i< 4; i++) {
        asel[i+8] = (fftbsel2 >> (i*4) ) & 0xf;
    }

    for(i=0; i< 12; i++) {
        if ( (fftbmsk >> i) & 0x1) {
            if ( (fftbmsk >> (i+16)) & 0x1) {
                oa[i] = 1;
            } else {
                oa[i] = 0;
            }
        } else {
            oa[i] = ta[asel[i]];
        }
    }

    out_adr = (in_adr & 0xfffff000);
    for(i=0; i< 12; i++) {
        out_adr = out_adr  | ( (oa[i] & 0x1) << i);
    }
    return out_adr;
}

/******************************************************************************/
/* fftd_wadr                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/15   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int fftd_wadr(/*int fftctl, */int fftdsel1, int fftdsel2, int fftdmsk, int in_adr) { 

    int ta[12];
    int oa[12];
    int i;
    int asel[12];
    int out_adr;

    for(i=0; i< 12; i++) {
        ta[i] = (in_adr >> i) & 0x1;
    }
    for(i=0; i< 8; i++) {
        asel[i] = (fftdsel1 >> (i*4) ) & 0xf;
    }
    for(i=0; i< 4; i++) {
        asel[i+8] = (fftdsel2 >> (i*4) ) & 0xf;
    }

    for(i=0; i< 12; i++) {
        if ( (fftdmsk >> i) & 0x1) {
            if ( (fftdmsk >> (i+16)) & 0x1) {
                oa[i] = 1;
            } else {
                oa[i] = 0;
            }
        } else {
            oa[i] = ta[asel[i]];
        }
    }

    out_adr = (in_adr & 0xfffff000);
    for(i=0; i< 12; i++) {
        out_adr = out_adr  | ( (oa[i] & 0x1) << i);
    }

    return out_adr;
}


