/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0001.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/19 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include "legacy_sim.h"


static int64 IMG_ADD(short f, short g);
static int64 IMG_SUB(short f, short g);
static int64 IMG_COMB(short f, short g, short consta, short constb);
static int64 IMG_MULT(short f, short g);
static int64 IMG_MIN(short f,short g);
static int64 IMG_MAX(short f, short g);
static int64 IMG_SUADD(short f, short g, short consta, short constb);
static int64 IMG_SQUADD(short f, short g, short consta, short constb);
static int64 IMG_SMULT(short f, short g, short consta, short constb);
static int64 IMG_SUBSQ(short f, short g);
static int64 IMG_ADDSQ(short f, short g);

/******************************************************************************/
/* IMG_0001                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/19 T.Sato                                               */
/******************************************************************************/
int IMG_0001(){
	unsigned long xlng, ylng;
	unsigned int widthcnt, heightcnt;
	short *soura_id = psLM0;
	short *sourb_id = psLM1;
	int64 result[LINE_SIZE];
	short consta, constb;
	unsigned char subfun, soura_dt, sourb_dt;
	int datatype, datatypesb;

    datatype = ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
    datatypesb = ((IMPREG_IPFUN_READ() >> 20) & 0x0003);

	if((IMPREG_IPFORM_READ() >> 16) & 0x0007){
        datatype = ((IMPREG_IPFORM_READ() >> 16) & 0x0007) + 4;
    }
    if((IMPREG_IPFORM_READ() >> 20) & 0x0007){
        datatypesb = ((IMPREG_IPFORM_READ() >> 20) & 0x0007) + 4;
    }

	xlng = IMPREG_APLNG_READ() & 0x3fff;
//	ylng = (IMPREG_APLNG_READ() >>16) & 0x3fff;
    ylng = (McomFlg) ? 1 : (((IMPREG_APLNG_READ())>>16) & 0x3fff);
	heightcnt = 0;
	subfun = (char)((IMPREG_IPFUN_READ()>>24)&0x000f);
	if((datatype == 6) || (datatypesb == 6))
	{/* If one of src0 and src1 is 16bpp, const should be 16bpp */
	    GET_CNSTA16(consta);
	    GET_CNSTB16(constb);
    }
	else
	{
	    GET_CNSTA(consta);
	    GET_CNSTB(constb);
    }
	soura_dt = (char)((IMPREG_IPFUN_READ()>>22) & 0x0003);
	sourb_dt = (char)((IMPREG_IPFUN_READ()>>20) & 0x0003);
#ifdef DEBUG_OUTPUT
	ResetDebugGamen();
#endif
	
	/* roop y-direction */
	while(heightcnt<ylng){
		widthcnt = 0;
		/* read by 1 line data */
        if(McomFlg){
            Read1LineLM256A(heightcnt, soura_id);
            Read1LineLM256B(sourb_id);
        }else{
		    Read1LineSrc0(heightcnt, soura_id);
		    Read1LineSrc1(heightcnt, sourb_id);
        }
		/* write by 1line data to the Dst file */
		while(widthcnt<xlng){

			/* select the kind of arithmetic process */
			switch(subfun){
				case 0:	/* srcA + srcB */
					result[widthcnt] = IMG_ADD(soura_id[widthcnt], sourb_id[widthcnt]);
					break;
				case 1:	/* srcA - srcB */
					result[widthcnt] = IMG_SUB(soura_id[widthcnt], sourb_id[widthcnt]);
					break;
				case 2:	/* a*srcA + b*srcB */
					result[widthcnt] = IMG_COMB(soura_id[widthcnt], sourb_id[widthcnt], consta, constb);
					break;
				case 3:	/* srcA * srcB */
					result[widthcnt] = IMG_MULT(soura_id[widthcnt], sourb_id[widthcnt]);
					break;
				case 4:	/* min(srcA,srcB) */
					result[widthcnt] = IMG_MIN(soura_id[widthcnt], sourb_id[widthcnt]);
					break;
				case 5:	/* max(srcA,srcB) */
					result[widthcnt] = IMG_MAX(soura_id[widthcnt], sourb_id[widthcnt]);
					break;
				case 6:	/* |srcA-a| + |srcB-b| */
					result[widthcnt] = IMG_SUADD(soura_id[widthcnt], sourb_id[widthcnt], consta, constb);
					break;
				case 7:	/* (srcA-a)^2 + (srcB-b)^2 */
					result[widthcnt] = IMG_SQUADD(soura_id[widthcnt], sourb_id[widthcnt], consta, constb);
					break;
				case 8:	/* (srcA-a) * (srcB-b) */
					result[widthcnt] = IMG_SMULT(soura_id[widthcnt], sourb_id[widthcnt], consta, constb);
					break;
				case 9:	/* (srcA-srcB) * (srcA-srcB) */
					result[widthcnt] = IMG_SUBSQ(soura_id[widthcnt], sourb_id[widthcnt]);
					break;
				case 10:	/* (srcA+srcB) * (srcA+srcB) */
					result[widthcnt] = IMG_ADDSQ(soura_id[widthcnt], sourb_id[widthcnt]);
					break;
				case 15:	/* color-supporting process (not operated) */
					result[widthcnt] = soura_id[widthcnt];
					break;
				default:	/* error */
					return -1;
					break;
			}
			widthcnt++;

		}
#ifdef DEBUG_OUTPUT
		DebugOutputGamen(result,3,xlng);
#endif
		/* write Dst data */
        Write1LineDst(heightcnt, result);
		heightcnt++;
	}
	return 0;
}

static int64 IMG_ADD(short f, short g)
{
	return (int64)f+(int64)g;
}

static int64 IMG_SUB(short f, short g)
{
	return (int64)f-(int64)g;
}

static int64 IMG_COMB(short f, short g, short consta, short constb)
{
	return (int64)f * (int64)consta + (int64)g * (int64)constb;
}

static int64 IMG_MULT(short f, short g)
{
	return (int64)f*(int64)g;
}

static int64 IMG_MIN(short f,short g)
{
	return (int64)MIN(f,g);
}

static int64 IMG_MAX(short f, short g)
{
	return (int64)MAX(f,g);
}

/******************************************************************************/
/* IMG_SUADD                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18                                                      */
/* 01-02-00 : 2007/07/12   S.Ishikawa                                         */
/*                         short -> long                                      */
/* 01-02-01 : 2007/07/20 S.Ishikawa                                           */
/*                       changed ret                                          */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_SUADD(short f, short g, short consta, short constb)
{
//	short ret;
//	ret = (short)(abs(f-consta) + abs(g-constb));
	return (int64)((abs((int)f-(int)consta) + abs((int)g-(int)constb)));
}
/******************************************************************************/
/* IMG_SQUADD                                                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18                                                      */
/* 01-02-00 : 2007/07/12   S.Ishikawa                                         */
/*                         short -> long                                      */
/* 01-02-01 : 2007/07/20 S.Ishikawa                                           */
/*                       changed ret                                          */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_SQUADD(short f, short g, short consta, short constb)
{
//	short ret;
//	ret = (f-consta) * (f-consta) + (g-constb) * (g-constb);
	return((((int64)f-(int64)consta) * ((int64)f-(int64)consta) + ((int64)g-(int64)constb) * ((int64)g-(int64)constb)));
}

static int64 IMG_SMULT(short f, short g, short consta, short constb)
{
//    SIMLOG(SL_LS, SL_L4, "%x %x %x %x  ",f,g,consta,constb);
//    SIMLOG(SL_LS, SL_L4, "%x ",(((int64)f-(int64)consta) * ((int64)g-(int64)constb)));
	return ((int64)(((int64)f-(int64)consta) * ((int64)g-(int64)constb)));
}

static int64 IMG_SUBSQ(short f, short g)
{
	return ((int64)f - (int64)g) * ((int64)f - (int64)g);
}

static int64 IMG_ADDSQ(short f, short g)
{
	return ((int64)f + (int64)g) * ((int64)f + (int64)g);
}

