/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG2_0010.c                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>      // for free
#include <string.h>	     // for memset
#include <stdint.h>      // for int32_t uint32_t
#include <stdbool.h>
#include "impsim_int.h"
#include "legacy_sim.h"

#define KERNEL_MAX  7
static short* pLineMem[KERNEL_MAX];
static bool IsNearTopLeftEdge(bool _8or16, long rowORcol);
static void GetPeripheralData(bool _8or16, long row, long col, int64 *result, short* soura_id, long thresholdVal);
static void UpdateKernelMatrixOneLine(int adr, short *data, int size);
static short ReadKernelMatrixOnePix(int offset, int adr);
static void GetPeripheralData(bool _8or16, long row, long col, int64 *result, short* soura_id, long thresholdVal);

static int g_KernelSize;
static int g_ValidDataIndex;

static void UpdateKernelMatrixOneLine(int adr, short *data, int size)
{
    short* pLineMemTemp;
	int i;
	int LineIndex;

	if(g_ValidDataIndex < g_KernelSize)
	{
		for(i=0;i<size;i++)
		{
			if(ENDIAN)
			{ /* little */
				*(pLineMem[g_ValidDataIndex]+(adr+i)*2  ) = (unsigned char)((*(data+i)   ) & 0xff);
				*(pLineMem[g_ValidDataIndex]+(adr+i)*2+1) = (unsigned char)((*(data+i)>>8) & 0xff);
			}
			else
			{ /* big */
				*(pLineMem[g_ValidDataIndex]+(adr+i)*2  ) = (unsigned char)((*(data+i)>>8) & 0xff);
				*(pLineMem[g_ValidDataIndex]+(adr+i)*2+1) = (unsigned char)((*(data+i)   ) & 0xff);
			}
		}
		g_ValidDataIndex++;
	}
	else
	{
		for(i=0;i<size;i++)
		{
			if(ENDIAN)
			{ /* little */
				*(pLineMem[0]+(adr+i)*2  ) = (unsigned char)((*(data+i)   ) & 0xff);
				*(pLineMem[0]+(adr+i)*2+1) = (unsigned char)((*(data+i)>>8) & 0xff);
			}
			else
			{ /* big */
				*(pLineMem[0]+(adr+i)*2  ) = (unsigned char)((*(data+i)>>8) & 0xff);
				*(pLineMem[0]+(adr+i)*2+1) = (unsigned char)((*(data+i)   ) & 0xff);
			}
		}
		pLineMemTemp = pLineMem[0];

		for(LineIndex = 0; LineIndex < g_KernelSize -1;LineIndex++)
		{
			pLineMem[LineIndex] = pLineMem[LineIndex+1];
		}
		pLineMem[g_KernelSize -1] = pLineMemTemp;
	}
 
    return;
}


static short ReadKernelMatrixOnePix(int offset, int adr)
{
    unsigned char work[2];
    short ret;
    int idx;

   	idx = g_ValidDataIndex - 1 + offset;

    work[0] = *(pLineMem[idx]+adr*2  );
    work[1] = *(pLineMem[idx]+adr*2+1);

    if(ENDIAN){ /* little */
        ret = (short)((work[1]<<8)|(work[0]));
    }else{ /* big */
        ret = (short)((work[0]<<8)|(work[1]));
    }

    return(ret);
}


#ifndef true
#define true	1
#define false	0
#endif

/******************************************************************************/
/* IMG2_0010                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/01/29   K.Cho                                              */
/* 01-00-01 : 2015/02/17   T.Sato                                             */
/*                       PIS                                                  */
/******************************************************************************/
int IMG2_0010()
{
	unsigned char ipfun_b25;	/* IPFUN[25]�E�E�E0��3x3�J�[�l���i����8��f)�A1��5x5�J�[�l��(����16��f) */
	unsigned char ipfun_b24;	/* IPFUN[24]�E�E�E臒l�ݒ�@0��臒l�Ȃ����[�h�@1��臒l���胂�[�h */
	unsigned short consta;		/* �P�x�l�̍��Ɣ�r����臒l(��������16bit) */
	int datatype;				/* source-a ind execute mode */
	long xlng, ylng, row, col;
	int64 result[LINE_SIZE];
	short *soura_id = psLM7;
	long thresholdVal = -1;
	int offset;

	ipfun_b25 = (unsigned char)((IMPREG_IPFUN_READ() >> 25) & 0x0001);
	ipfun_b24 = (unsigned char)((IMPREG_IPFUN_READ() >> 24) & 0x0001);
	if (ipfun_b24 == 0x01)
	{
		datatype = (IMPREG_IPFORM_READ() >> 8) & 0x0007;
		consta = (unsigned short)((IMPREG_CNST_READ()>>16)&0xffff);
		thresholdVal = consta;
	}

	if (!ipfun_b25)
	{/* ����8��f�̏ꍇ */
		offset = 1;
	}
	else
	{/* ����16��f�̏ꍇ */
		offset = 2;
	}

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

	g_KernelSize = 5;
	g_ValidDataIndex = 0;
	pLineMem[0] = psLM0;
	pLineMem[1] = psLM1;
	pLineMem[2] = psLM2;
	pLineMem[3] = psLM3;
	pLineMem[4] = psLM4;
	pLineMem[5] = psLM5;
	pLineMem[6] = psLM6;
	
	for (row=0; row<ylng; row++)
	{
		Read1LineSrc0(row, soura_id);
		UpdateKernelMatrixOneLine(0, soura_id, xlng);
		memset(result, 0, sizeof(result));
		if (	IsNearTopLeftEdge(ipfun_b25, row))
		{
			continue;
		}

		for (col=0; col<xlng; col++)
		{
			if (IsNearTopLeftEdge(ipfun_b25, col))
			{
				continue;
			}
			else
			{
				GetPeripheralData(ipfun_b25, row, col, result, soura_id, thresholdVal);
			}
		}
		Write1LineDst(row - offset, result);
	}
	
	g_KernelSize = 5;
	g_ValidDataIndex = 0;
	
	return 0;
}


static bool IsNearTopLeftEdge(bool _8or16, long rowORcol)
{
	/* _8or16 = 0:����8��f 1:����16��f */

	if (!_8or16)
	{	/* ����8��f�̏ꍇ */
		if (rowORcol < 2)
		{
			return true;
		}
	}
	else
	{	/* ����16��f�̏ꍇ */
		if (rowORcol < 4)
		{
			return true;
		}
	}
	return false;
}

static void GetPeripheralData(bool _8or16, long row, long col, int64 *result, short* soura_id, long thresholdVal)
{
	short m[25];
	int cnt = 8;
	int i = 0;
	int64 mask = 0;
	unsigned int PeripheralData = 0;
	int offset = 1;
	int abs = 0;

	memset(m, 0, sizeof(m));

	if (!_8or16)
	{	/* ����8��f�̏ꍇ */
		cnt = 8;
		offset = 1;
		if (-1 != thresholdVal)
		{
			mask = 0x00010000;
		}
		else
		{
			mask = 0x00000100;
		}

		// #6 #7 #8
		// #5 #0 #1
		// #4 #3 #2
		m[6] = ReadKernelMatrixOnePix(-2, col - 2);	m[7] = ReadKernelMatrixOnePix(-2, col - 1);	m[8]  = ReadKernelMatrixOnePix(-2, col);
		m[5] = ReadKernelMatrixOnePix(-1, col - 2);	m[0] = ReadKernelMatrixOnePix(-1, col - 1);	m[1]  = ReadKernelMatrixOnePix(-1, col);
		m[4]  = soura_id[col - 2];  m[3]  = soura_id[col - 1];  m[2]  = soura_id[col];
	}
	else
	{	/* ����16��f�̏ꍇ */
		cnt = 16;
		offset = 2;
		if (-1 != thresholdVal)
		{
			mask = 0x0000000100000000;
		}
		else
		{
			mask = 0x00010000;
		}

		// #11 #12 #13 #14 #15
		// #10 #22 #23 #24 #16
		// #9  #21 #0  #17 #1
		// #8  #20 #19 #18 #2
		// #7  #6  #5  #4  #3
		m[11] = ReadKernelMatrixOnePix(- 4, col - 4);	m[12] = ReadKernelMatrixOnePix(- 4, col - 3);   m[13]	= ReadKernelMatrixOnePix(-4, col - 2);	m[14] = ReadKernelMatrixOnePix(-4, col - 1);	m[15]	= ReadKernelMatrixOnePix(-4, col);
		m[10] = ReadKernelMatrixOnePix(- 3, col - 4);	m[22] = ReadKernelMatrixOnePix(- 3, col - 3);   m[23]	= ReadKernelMatrixOnePix(-3, col - 2);	m[24] = ReadKernelMatrixOnePix(-3, col - 1);	m[16]	= ReadKernelMatrixOnePix(-3, col);
		m[9]  = ReadKernelMatrixOnePix(- 2, col - 4);	m[21] = ReadKernelMatrixOnePix(- 2, col - 3);   m[0]	= ReadKernelMatrixOnePix(-2, col - 2);	m[17] = ReadKernelMatrixOnePix(-2, col - 1);	m[1]		= ReadKernelMatrixOnePix(-2, col);
		m[8]  = ReadKernelMatrixOnePix(- 1, col - 4);	m[20] = ReadKernelMatrixOnePix(- 1, col - 3);   m[19]	= ReadKernelMatrixOnePix(-1, col - 2);	m[18] = ReadKernelMatrixOnePix(-1, col - 1);	m[2]		= ReadKernelMatrixOnePix(-1, col);
		m[7]  = soura_id[col - 4];  m[6]  = soura_id[col - 3];  m[5]  = soura_id[col - 2];  m[4]  = soura_id[col - 1];  m[3]  = soura_id[col];
	}
	if (-1 != thresholdVal)
	{//臒l����
		for(i=cnt; i>0; i--)
		{
			if (m[i] > m[0])
			{
				abs = m[i] - m[0];
			}
			else
			{
				abs = m[0] - m[i];
			}
			if(abs >= thresholdVal)
			{
				PeripheralData |= (mask >> 2*i);
			}
			if(m[i] >= m[0])
			{
				PeripheralData |= (mask >> (2*i - 1));
			}
		}
	}
	else
	{//臒l�Ȃ�
		for(i=cnt; i>0; i--)
		{
			if(m[i] >= m[0])
			{
				PeripheralData |= (mask >> i);
			}
		}
	}
	result[col - offset] = PeripheralData;
}

