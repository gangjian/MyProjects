/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0011.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"

#define CELL9   9
#define CELL16 16

static int IMG_0011_KernelDual();
static unsigned int IMG_Edgecode(unsigned int rho, unsigned int theta, unsigned int x_point, unsigned int y_point);
static int Calculate_Rho(int rhoa, int rhob);
static unsigned int Calculate_Theta(int rhoa, int rhob, unsigned char type);
static int RoundingOff(int sourceValue, unsigned char scale, int cutEnable);
static int IMG_ConvDual(short m[], short w[]);
static int64 IMG_Conv3x3(int m[], int w[]);

#define getreg1(regname, shift)  ((unsigned char)((IMPREG_ ## regname ## _READ()>>shift) & 0x0001))
#define getreg8(regname, shift)  ((IMPREG_ ## regname ## _READ()>>shift) & 0x00ff)


/******************************************************************************/
/* IMG_0011                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int IMG_0011(){
	long xlng, ylng, Widthcnt, Heightcnt;
	int i, dim, datatype;
	short *soura_0 = psLM0;
	short *soura_1 = psLM1;
	short *soura_2 = psLM2;
	short *temp;
	int m[CELL16], weight[CELL16];
	unsigned char srca_ind_om;
	unsigned char kernel, edge, lm_mode, msk, kmsk, soura_dt, dual_en;
	int64 result[LINE_SIZE];
	int64 scale;
	if ( !USE_PIPE_FUNC && McomFlg ) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (PIPE). turn on USE_PIPE_FUNC when use PIPE for IMG_0011.\n");
		Legacy_assert_error();
	}
	
	dual_en = getreg1(KNLMSK, 11);
	if (dual_en) {
		return IMG_0011_KernelDual();
	}
	
	/* Load resister values */
	xlng = IMPREG_APLNG_READ() & 0x3fff;
	ylng = (IMPREG_APLNG_READ() >>16) & 0x3fff;
	kernel = (char)((IMPREG_IPFUN_READ()>>27) & 0x0001);
	edge = (char)((IMPREG_IPFUN_READ()>>24) & 0x0003);
	lm_mode = getreg1(KNLMSK, 29);
	soura_dt = (char)((IMPREG_IPFUN_READ()>>22) & 0x0003);
	srca_ind_om = (unsigned char) ((IMPREG_IPFORM_READ() >> 16) & 0x0007);

	// Check Format
	if(soura_dt == 0){
		datatype = PXLS8BPP;
	} else if(soura_dt == 1){
		datatype = PXLU8BPP;
	} else if(soura_dt == 2){
		datatype = PXL1BPP;
	} else { /* (soura_dt == 3) */
		datatype = PXLCOLDIFF;
    }
	if (srca_ind_om == 2) {
		datatype = PXL16BPP;
	}

	if (datatype == PXL16BPP) {
		for (i=0, scale=1; i<(signed int)((IMPREG_IPFUN2_READ() & 0x000f)<<4 | (IMPREG_IPFUN_READ() & 0x000f)); i++) {
			scale *= 2;
		}
	} else {
		for (i=0, scale=1; i<(signed int)(IMPREG_IPFUN_READ() & 0x000f); i++) {
			scale *= 2;
		}
	}
	
	/* ---getting 9 coefficients--- */
	weight[0]  = getreg8(COEFF02, 18);
	weight[1]  = getreg8(COEFF02, 9);
	weight[2]  = getreg8(COEFF02, 0);
	weight[3]  = getreg8(COEFF35, 18);
	weight[4]  = getreg8(COEFF35, 9);
	weight[5]  = getreg8(COEFF35, 0);
	weight[6]  = getreg8(COEFF68, 18);
	weight[7]  = getreg8(COEFF68, 9);
	weight[8]  = getreg8(COEFF68, 0);
	weight[9]  = getreg8(COEFF911, 18);
	weight[10] = getreg8(COEFF911, 9);
	weight[11] = getreg8(COEFF911, 0);
	weight[12] = getreg8(COEFF1214, 18);
	weight[13] = getreg8(COEFF1214, 9);
	weight[14] = getreg8(COEFF1214, 0);
	weight[15] = getreg8(COEFF15, 18);
	
	if (datatype == PXL16BPP) {
		weight[0]  |= ((getreg8(COEFF02H, 16)<<8)   & 0x0000ff00);
		weight[1]  |= ((getreg8(COEFF02H, 8)<<8)    & 0x0000ff00);
		weight[2]  |= ((getreg8(COEFF02H, 0)<<8)    & 0x0000ff00);
		weight[3]  |= ((getreg8(COEFF35H, 16)<<8)   & 0x0000ff00);
		weight[4]  |= ((getreg8(COEFF35H, 8)<<8)    & 0x0000ff00);
		weight[5]  |= ((getreg8(COEFF35H, 0)<<8)    & 0x0000ff00);
		weight[6]  |= ((getreg8(COEFF68H, 16)<<8)   & 0x0000ff00);
		weight[7]  |= ((getreg8(COEFF68H, 8)<<8)    & 0x0000ff00);
		weight[8]  |= ((getreg8(COEFF68H, 0)<<8)    & 0x0000ff00);
		weight[9]  |= ((getreg8(COEFF911H, 16)<<8)  & 0x0000ff00);
		weight[10] |= ((getreg8(COEFF911H, 8)<<8)   & 0x0000ff00);
		weight[11] |= ((getreg8(COEFF911H, 0)<<8)   & 0x0000ff00);
		weight[12] |= ((getreg8(COEFF1214H, 16)<<8) & 0x0000ff00);
		weight[13] |= ((getreg8(COEFF1214H, 8)<<8)  & 0x0000ff00);
		weight[14] |= ((getreg8(COEFF1214H, 0)<<8)  & 0x0000ff00);
		weight[15] |= ((getreg8(COEFF1517H, 16)<<8) & 0x0000ff00);
		if (getreg1(COEFF02H,23))  weight[0]  |= 0xffff0000;
		if (getreg1(COEFF02H,15))  weight[1]  |= 0xffff0000;
		if (getreg1(COEFF02H,7))   weight[2]  |= 0xffff0000;
		if (getreg1(COEFF35H,23))  weight[3]  |= 0xffff0000;
		if (getreg1(COEFF35H,15))  weight[4]  |= 0xffff0000;
		if (getreg1(COEFF35H,7))   weight[5]  |= 0xffff0000;
		if (getreg1(COEFF68H,23))  weight[6]  |= 0xffff0000;
		if (getreg1(COEFF68H,15))  weight[7]  |= 0xffff0000;
		if (getreg1(COEFF68H,7))   weight[8]  |= 0xffff0000;
		if(getreg1(COEFF911H,23))  weight[9]  |= 0xffff0000;
		if(getreg1(COEFF911H,15))  weight[10] |= 0xffff0000;
		if(getreg1(COEFF911H,7))   weight[11] |= 0xffff0000;
		if(getreg1(COEFF1214H,23)) weight[12] |= 0xffff0000;
		if(getreg1(COEFF1214H,15)) weight[13] |= 0xffff0000;
		if(getreg1(COEFF1214H,7))  weight[14] |= 0xffff0000;
		if(getreg1(COEFF1517H,23)) weight[15] |= 0xffff0000;
	} else {
		if (getreg1(COEFF02,26))  weight[0]  |= 0xffffff00;
		if (getreg1(COEFF02,17))  weight[1]  |= 0xffffff00;
		if (getreg1(COEFF02,8))   weight[2]  |= 0xffffff00;
		if (getreg1(COEFF35,26))  weight[3]  |= 0xffffff00;
		if (getreg1(COEFF35,17))  weight[4]  |= 0xffffff00;
		if (getreg1(COEFF35,8))   weight[5]  |= 0xffffff00;
		if (getreg1(COEFF68,26))  weight[6]  |= 0xffffff00;
		if (getreg1(COEFF68,17))  weight[7]  |= 0xffffff00;
		if (getreg1(COEFF68,8))   weight[8]  |= 0xffffff00;
		if(getreg1(COEFF911,26))  weight[9]  |= 0xffffff00;
		if(getreg1(COEFF911,17))  weight[10] |= 0xffffff00;
		if(getreg1(COEFF911,8))   weight[11] |= 0xffffff00;
		if(getreg1(COEFF1214,26)) weight[12] |= 0xffffff00;
		if(getreg1(COEFF1214,17)) weight[13] |= 0xffffff00;
		if(getreg1(COEFF1214,8))  weight[14] |= 0xffffff00;
		if(getreg1(COEFF15,26))   weight[15] |= 0xffffff00;
	}

	msk = getreg1(IPFUN, 26);	/* 'Enable' or 'Disable' about kernel mask */
	if (msk == 1) {
		for (i=0; i < 9; i++) {
			kmsk = getreg1(KNLMSK, (short)i);
			if (kmsk) weight[i] = 0;
		}
		for (i=9; i < 16; i++) {
			kmsk = getreg1(KNLMSK, (short)(i+7));
			if (kmsk) weight[i] = 0;
		}
	}
	
//////////
	Heightcnt = 0;
	
	if (kernel == 0) {

#if USE_PIPE_FUNC
		/* 3x3 */
		if (McomFlg) {
			Widthcnt = 0;
			while (Widthcnt < xlng) {
			/* middle(center?) lines */
				if (Widthcnt == 0) {
					/* make edge process at the left side */
					m[1] = ReadLM256A(2, Widthcnt);
					m[4] = ReadLM256A(1, Widthcnt);
					m[7] = ReadLM256A(0, Widthcnt);
					m[2] = ReadLM256A(2, Widthcnt+1);
					m[5] = ReadLM256A(1, Widthcnt+1);
					m[8] = ReadLM256A(0, Widthcnt+1);
					
					if (edge == 3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)ReadLM256A(1, Widthcnt) * (int64)scale;
					}
				} else if (Widthcnt == xlng-1){
					/* only make edge process at the right side */
					if (edge == 3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)ReadLM256A(1, Widthcnt) * (int64)scale;
					}
				} else {
					/* center */
					m[0] = m[1]; m[1] = m[2]; m[2] = ReadLM256A(2, Widthcnt+1);
					m[3] = m[4]; m[4] = m[5]; m[5] = ReadLM256A(1, Widthcnt+1);
					m[6] = m[7]; m[7] = m[8]; m[8] = ReadLM256A(0, Widthcnt+1);
					result[Widthcnt] = IMG_Conv3x3(m, weight);
				}
				Widthcnt++;
			}
			Write1LineDst(0, result);
		} 
		else {
#endif
			while (Heightcnt <= ylng) {
				if (Heightcnt < ylng) {
					Read1LineSrc0(Heightcnt, soura_0);
				}

				Widthcnt = 0;
				while (Widthcnt < xlng) {
					if ((Heightcnt == 1) || (Heightcnt == ylng)) {
						/* make edge process on the top or bottom line */
						if (edge == 3) {
							result[Widthcnt] = 0;
						} else {
							result[Widthcnt] = (int64)soura_1[Widthcnt] * (int64)scale;
						}
					} else if (Heightcnt != 0) {
						/* middle(center?) lines */
						if (Widthcnt == 0) {
							/* make edge process at the left side */
							m[1] = soura_2[0]; m[2] = soura_2[1];
							m[4] = soura_1[0]; m[5] = soura_1[1];
							m[7] = soura_0[0]; m[8] = soura_0[1];
							if (edge == 3) {
								result[Widthcnt] = 0;
							} else {
								result[Widthcnt] = (int64) soura_1[Widthcnt] * (int64)scale;
							}
						} else if (Widthcnt == (xlng - 1)) {
							/* only make edge process at the right side */
							if (edge == 3) {
								result[Widthcnt] = 0;
							} else {
								result[Widthcnt] = (int64)soura_1[Widthcnt] * (int64)scale;
							}
						} else {
							/* center */
							m[0] = m[1]; m[1] = m[2]; m[2] = soura_2[Widthcnt+1];
							m[3] = m[4]; m[4] = m[5]; m[5] = soura_1[Widthcnt+1];
							m[6] = m[7]; m[7] = m[8]; m[8] = soura_0[Widthcnt+1];
							result[Widthcnt] = IMG_Conv3x3(m, weight);
						}
					}
					Widthcnt++;
				}
				if (Heightcnt < ylng) {
					// soura
					temp = soura_2;
					soura_2 = soura_1;
					soura_1 = soura_0;
					soura_0 = temp;
				}
				if (Heightcnt > 0) {
					Write1LineDst(Heightcnt-1, result);
				}
				Heightcnt++;
			}
#if USE_PIPE_FUNC
		}
#endif
		
	} else { // kernel == 1
		/* 1x9 */
		/* use  2, 14, 3, 4, 5, 15, 6, 7, 8 */
		weight[0] = weight[2];
		weight[1] = weight[14];
		weight[2] = weight[3];
		weight[3] = weight[4];
		weight[4] = weight[5];
		weight[5] = weight[15];
		
#if USE_PIPE_FUNC
		if (McomFlg) {
			ylng = 1;
		}
#endif
		
		Heightcnt = 0;
		while (Heightcnt < ylng) {
#if USE_PIPE_FUNC
			if (McomFlg) {
				Read1LineLM256A(Heightcnt, soura_0);
			} else {
#endif
				Read1LineSrc0(Heightcnt, soura_0);
#if USE_PIPE_FUNC
			}
#endif
			Widthcnt = 0;
			while (Widthcnt < xlng) {
				/* make edge process at the left side */
				if (Widthcnt < 4) {
					if (Widthcnt == 3) {
						m[1] = soura_0[0];
						m[2] = soura_0[1];
						m[3] = soura_0[2];
						m[4] = soura_0[3];
						m[5] = soura_0[4];
						m[6] = soura_0[5];
						m[7] = soura_0[6];
						m[8] = soura_0[7];
					}
					if (edge == 3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)soura_0[Widthcnt] * (int64)scale;
					}
				} else if (Widthcnt > (xlng - 5)) {
					/* make edge process at the right side */
					if (edge == 3) {
						result[Widthcnt] = 0;
					} else {
						result[Widthcnt] = (int64)soura_0[Widthcnt] * (int64)scale;
					}
				} else {
					/* center */
					m[0] = m[1];
					m[1] = m[2];
					m[2] = m[3];
					m[3] = m[4];
					m[4] = m[5];
					m[5] = m[6];
					m[6] = m[7];
					m[7] = m[8];
					m[8] = soura_0[Widthcnt+4];
					result[Widthcnt] = IMG_Conv3x3(m, weight);
				}
				Widthcnt++;
			}
			Write1LineDst(Heightcnt, result);
			Heightcnt++;
		}
	}
	return 0;
}

/******************************************************************************/
/* IMG_Conv3x3                                                                */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/10/17   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int64 IMG_Conv3x3(int m[], int w[])
{
	int i;
	int64 temp;
	
	temp = 0;
	for (i=0; i<CELL9; i++) {
		temp += (int64) (w[i] * m[i]);
	}
	
	return temp;
}


/******************************************************************************/
/* IMG_0011_KernelDual                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New                                                */
/******************************************************************************/
static int IMG_0011_KernelDual() {
	
	unsigned long xlng, ylng, Widthcnt, Heightcnt, Resultcnt;
	unsigned char kernel, soura_dt, sourb_dt, msk, edgecnt, lm_mode, kmsk, scale, srca_ind_om, srcb_ind_om;
	unsigned char ec_en, ec_bin, bin_rep, ec_mode, bnr_en, cut_en, dest_dt;
	unsigned short calc_thr;
	short thr_max, thr_min;
	int pre_rho, peak_flg, set_flg, peak_del_flg;
	unsigned int theta;
	long rho, rho_A, rho_B;

// tsato for debug
//	long result_A[LINE_SIZE], result_B[LINE_SIZE], result_rho[LINE_SIZE], result_theta[LINE_SIZE];
	
	int64 result[LINE_SIZE];
	short m[CELL9], weightA[CELL9], weightB[CELL9];
	short *soura_0 = psLM0;
	short *soura_1 = psLM1;
	short *soura_2 = psLM2;
	short *temp;
	int i;

	soura_dt = (unsigned char) ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
	sourb_dt = (unsigned char) ((IMPREG_IPFUN_READ() >> 20) & 0x0003);
	
	xlng     = IMPREG_APLNG_READ() & 0x3fff;
	ylng     = (IMPREG_APLNG_READ() >>16) & 0x3fff;
	kernel   = (unsigned char) ((IMPREG_IPFUN_READ() >> 27) & 0x0001);
	msk      = (unsigned char) ((IMPREG_IPFUN_READ() >> 26) & 0x0001);
	edgecnt  = (unsigned char) ((IMPREG_IPFUN_READ() >> 24) & 0x0003);
	dest_dt  = (unsigned char) ((IMPREG_IPFUN_READ() >> 16) & 0x0003);
	bnr_en   = (unsigned char) ((IMPREG_IPFUN_READ() >>  4) & 0x0003);
	lm_mode  = (unsigned char) ((IMPREG_KNLMSK_READ() >> 29) & 0x0001);
	
	ec_en    = (unsigned char) ((IMPREG_BINTHR_READ() >> 31) & 0x0001);
	ec_bin   = (unsigned char) ((IMPREG_BINTHR_READ() >> 29) & 0x0003);
	bin_rep  = (unsigned char) ((IMPREG_BINTHR_READ() >> 28) & 0x0001);
	ec_mode  = (unsigned char) ((IMPREG_BINTHR_READ() >> 13) & 0x0007);
	
	calc_thr = (unsigned short) ((IMPREG_BINTHR_READ() >> 16) & 0x01FF);
	if (calc_thr & 0x0100) calc_thr |= 0xFE00;
	thr_max = (short) calc_thr;
	
	calc_thr  = (unsigned short) (IMPREG_BINTHR_READ() & 0x01FF);
	if (calc_thr & 0x0100) calc_thr |= 0xFE00;
	thr_min = (short) calc_thr;
	
	cut_en   = (unsigned char)((IMPREG_IPFUN_READ() >> 10) & 0x0001);
	scale    = (unsigned char) (IMPREG_IPFUN_READ() & 0x000F);
	srca_ind_om = (unsigned char) ((IMPREG_IPFORM_READ() >> 16) & 0x0007);
	srcb_ind_om = (unsigned char) ((IMPREG_IPFORM_READ() >> 20) & 0x0007);
	
// tsato for debug
/*
	SIMLOG(SL_LS, SL_L4, "soura_dt = %d\n",soura_dt);
	SIMLOG(SL_LS, SL_L4, "sourb_dt = %d\n",sourb_dt);
	SIMLOG(SL_LS, SL_L4, "xlng     = %d\n",xlng);
	SIMLOG(SL_LS, SL_L4, "ylng     = %d\n",ylng);
	SIMLOG(SL_LS, SL_L4, "kernel   = %d\n",kernel);
	SIMLOG(SL_LS, SL_L4, "msk      = %d\n",msk);
	SIMLOG(SL_LS, SL_L4, "edgecnt  = %d\n",edgecnt);
	SIMLOG(SL_LS, SL_L4, "lm_mode  = %d\n",lm_mode);
	SIMLOG(SL_LS, SL_L4, "ec_mode  = %d\n",ec_mode);
	SIMLOG(SL_LS, SL_L4, "scale    = %d\n",scale);
	SIMLOG(SL_LS, SL_L4, "srca_ind_om = %d\n",srca_ind_om);
	SIMLOG(SL_LS, SL_L4, "srcb_ind_om = %d\n",srcb_ind_om);
	SIMLOG(SL_LS, SL_L4, "ec_bin  = %d\n",ec_bin);
	SIMLOG(SL_LS, SL_L4, "cut_en  = %d\n",cut_en);
*/
	if (kernel) {
		// error
		SIMLOG(SL_LS, SL_ERR, "kernel is error\n");
		Legacy_assert_error();
	}
	
#if USE_PIPE_FUNC	
	if (McomFlg) {
		// not support
		SIMLOG(SL_LS, SL_ERR, "McomFlg is error\n");
		Legacy_assert_error();
	}
#endif 
	
	// check srca_ind_om & srcb_ind_om
//	if (16bpp) {
//		// error
//	}
	
	/* ---getting 9 coefficients--- */
	weightA[0] = getreg8(COEFF02, 18);
	weightA[1] = getreg8(COEFF02, 9);
	weightA[2] = getreg8(COEFF02, 0);
	weightA[3] = getreg8(COEFF35, 18);
	weightA[4] = getreg8(COEFF35, 9);
	weightA[5] = getreg8(COEFF35, 0);
	weightA[6] = getreg8(COEFF68, 18);
	weightA[7] = getreg8(COEFF68, 9);
	weightA[8] = getreg8(COEFF68, 0);
	
	weightB[0] = getreg8(COEFF911, 18);
	weightB[1] = getreg8(COEFF911, 9);
	weightB[2] = getreg8(COEFF911, 0);
	weightB[3] = getreg8(COEFF1214, 18);
	weightB[4] = getreg8(COEFF1214, 9);
	weightB[5] = getreg8(COEFF1214, 0);
	weightB[6] = getreg8(COEFF15, 18);
	weightB[7] = getreg8(COEFF15, 9);
	weightB[8] = getreg8(COEFF15, 0);
	
	if (getreg1(COEFF02,26)) weightA[0] |= 0xff00;
	if (getreg1(COEFF02,17)) weightA[1] |= 0xff00;
	if (getreg1(COEFF02,8))  weightA[2] |= 0xff00;
	if (getreg1(COEFF35,26)) weightA[3] |= 0xff00;
	if (getreg1(COEFF35,17)) weightA[4] |= 0xff00;
	if (getreg1(COEFF35,8))  weightA[5] |= 0xff00;
	if (getreg1(COEFF68,26)) weightA[6] |= 0xff00;
	if (getreg1(COEFF68,17)) weightA[7] |= 0xff00;
	if (getreg1(COEFF68,8))  weightA[8] |= 0xff00;
	
	if (getreg1(COEFF911,26))  weightB[0] |= 0xff00;
	if (getreg1(COEFF911,17))  weightB[1] |= 0xff00;
	if (getreg1(COEFF911,8))   weightB[2] |= 0xff00;
	if (getreg1(COEFF1214,26)) weightB[3] |= 0xff00;
	if (getreg1(COEFF1214,17)) weightB[4] |= 0xff00;
	if (getreg1(COEFF1214,8))  weightB[5] |= 0xff00;
	if (getreg1(COEFF15,26))   weightB[6] |= 0xff00;
	if (getreg1(COEFF15,17))   weightB[7] |= 0xff00;
	if (getreg1(COEFF15,8))    weightB[8] |= 0xff00;
	
// tsato for debug
#if 0
	SIMLOG(SL_LS, SL_L4, "*****weightA*****\n");
	SIMLOG(SL_LS, SL_L4, "  %3d %3d %3d\n", weightA[0], weightA[1], weightA[2]);
	SIMLOG(SL_LS, SL_L4, "  %3d %3d %3d\n", weightA[3], weightA[4], weightA[5]);
	SIMLOG(SL_LS, SL_L4, "  %3d %3d %3d\n", weightA[6], weightA[7], weightA[8]);
	SIMLOG(SL_LS, SL_L4, "*****weightB*****\n");
	SIMLOG(SL_LS, SL_L4, "  %3d %3d %3d\n", weightB[0], weightB[1], weightB[2]);
	SIMLOG(SL_LS, SL_L4, "  %3d %3d %3d\n", weightB[3], weightB[4], weightB[5]);
	SIMLOG(SL_LS, SL_L4, "  %3d %3d %3d\n", weightB[6], weightB[7], weightB[8]);
#endif
	
	if (msk) {
		for (i=0; i < CELL9; i++) {
			kmsk = getreg1(KNLMSK, (short)i);
			if (kmsk) weightA[i] = 0;
			kmsk = getreg1(KNLMSK, (short)(i+16));
			if (kmsk) weightB[i] = 0;
		}
	}
	
	Heightcnt = 0;
	
	/* 3x3 */
	while (Heightcnt <= ylng) {
		if (Heightcnt < ylng){
			Read1LineSrc0(Heightcnt, soura_0);
		}
		Widthcnt = 0;
		Resultcnt = 0;
		peak_flg = 0;
		set_flg = 0;
		peak_del_flg = 0;
		
		while (Widthcnt < xlng) {
			if ((Heightcnt == 1) || (Heightcnt == ylng)) {
				/* make edgecnt process on the top or bottom line */
				if (edgecnt == 3) {
					rho_A = 0;
					rho_B = 0;
				} else {
					rho_A = (long) soura_1[Widthcnt];
					rho_B = (long) soura_1[Widthcnt];
				}
			} else if (Heightcnt != 0) {
				/* middle(center?) lines */
				if (Widthcnt == 0)	/* make edgecnt process at the left side */
				{
					m[1] = soura_2[0]; m[2] = soura_2[1];
					m[4] = soura_1[0]; m[5] = soura_1[1];
					m[7] = soura_0[0]; m[8] = soura_0[1];
					if (edgecnt == 3) {
						rho_A = 0;
						rho_B = 0;
					} else {
						rho_A = (long) soura_1[Widthcnt];
						rho_B = (long) soura_1[Widthcnt];
					}
				} else if (Widthcnt == xlng-1) {
					/* only make edgecnt process at the right side */
					if (edgecnt == 3) {
						rho_A = 0;
						rho_B = 0;
					} else {
						rho_A = (long) soura_1[Widthcnt];
						rho_B = (long) soura_1[Widthcnt];
					}
				} else {
					/* center */
					m[0] = m[1]; m[1] = m[2]; m[2] = soura_2[Widthcnt+1];
					m[3] = m[4]; m[4] = m[5]; m[5] = soura_1[Widthcnt+1];
					m[6] = m[7]; m[7] = m[8]; m[8] = soura_0[Widthcnt+1];
					
					rho_A = IMG_ConvDual(m, weightA);
					rho_B = IMG_ConvDual(m, weightB);
				}
			}
			
			// Calc edgecode
			if (Heightcnt == 0) {
				result[Widthcnt] = 0x00000000AAAAAAAALL; // NA
			} else if ((Heightcnt == 1) || (Heightcnt == ylng)) {
				rho   = 0;
				theta = 0;
				result[Widthcnt] = 0;
			} else {
				// Post processor Start *********************************************************
				rho   = Calculate_Rho(rho_A, rho_B);
				theta = Calculate_Theta(rho_A, rho_B, 9);
				
				if (ec_bin > 1) {
					// error
					SIMLOG(SL_LS, SL_ERR, "ec_bin is error\n");
					Legacy_assert_error();
				}
				
				// Search peak
				if (ec_bin == 1) {
					if (Widthcnt == 0) {
						peak_flg = 0;
						rho = 0;
					} else if (Widthcnt == xlng-1) {
						peak_flg = 0;
						peak_del_flg = 1;
					} else {
						if (peak_flg == 0) {
							if ((rho > pre_rho) && (rho >= 0)) {
								peak_flg = 1;
							} else if ((rho < pre_rho) && (rho < 0)) {
								peak_flg = -1;
							}
						} else if (peak_flg == 1) {
							if (rho < pre_rho) {
								peak_flg = 2;
							}
						} else if (peak_flg == -1) {
							if (rho > pre_rho) {
								peak_flg = -2;
							}
						}
						
						// decide peak
						if ((peak_flg == 2) || (peak_flg == -2)) {
							if ((rho > pre_rho) && (rho >= 0)) {
								peak_flg = 1;
							} else if ((rho < pre_rho) && (rho < 0)) {
								peak_flg = -1;
							} else {
								peak_flg = 0;
							}
						} else {
							peak_del_flg = 1;
						}
					}
					pre_rho = rho;
					
					// check delete flg & init set flg
					if (set_flg == 0) {
						peak_del_flg = 0;
					}
					set_flg = 0;
					
					// delete
					if (peak_del_flg) {
						result[Widthcnt-1] = 0; // todo set value of ECPADV
						if (bin_rep == 0) {
							Resultcnt --;
							result[Resultcnt] = 0; // todo set value of ECPADV
						}
						peak_del_flg = 0;
					}
				}
				
				// Scale:counting fractions over 1/2 as one and disregarding the rest
//				rho = rho >> scale;
				rho = RoundingOff(rho, scale, (int)cut_en);

				// saturate
				if (dest_dt == 0) {
					if (rho > 127) rho = 127;
					if (rho < -128) rho = -128;
				} else if (dest_dt == 1) {
					if (rho > 255) rho = 255;
					if (rho < 0) rho = 0;
				} else {
					SIMLOG(SL_LS, SL_ERR, "dest_dt is error\n");
					Legacy_assert_error();
				}
				
				// Check threshold & decide set flg
				if (bnr_en == 2) {
					if ((rho > (int)thr_max) || (rho < (int)thr_min) || (Widthcnt == 0) || (Widthcnt == xlng-1)) {
						rho = 0;
						theta = 0;
						set_flg = 0;
					} else {
						set_flg = 1;
					}
				} else if (bnr_en == 3) {
					if ((Widthcnt == 0) || (Widthcnt == xlng-1)) {
						rho = 0;
						theta = 0;
						set_flg = 0;
					} else if ((rho > (int)thr_max) || (rho < (int)thr_min)) {
						set_flg = 1;
					} else {
						rho = 0;
						theta = 0;
						set_flg = 0;
					}
				} else {
					SIMLOG(SL_LS, SL_ERR, "bnr_en is error\n");
					Legacy_assert_error();
				}
				
				// Calc result
				if (bin_rep) {
					if (set_flg) result[Widthcnt] = (int64) IMG_Edgecode((unsigned char)rho, theta, Widthcnt, Heightcnt-1);
					else result[Widthcnt] = 0;  // todo set value of ECPADV
				} else {
					if (Widthcnt == xlng-1) result[Resultcnt] = 0; // end mark
					if (set_flg) {
						result[Resultcnt] = (int64) IMG_Edgecode((unsigned char)rho, theta, Widthcnt, Heightcnt-1);
						Resultcnt++;
					}
				}
				
				// Post processor End *********************************************************
			}
			
// tsato for debug
#if 0
			if (Heightcnt > 0) {
				result_A[Widthcnt] = rho_A;
				result_B[Widthcnt] = rho_B;
				result_rho[Widthcnt] = rho;
				result_theta[Widthcnt] = theta;
			}
#endif

			Widthcnt++;
		}
		
		if (Heightcnt < ylng) {
			// soura
			temp = soura_2;
			soura_2 = soura_1;
			soura_1 = soura_0;
			soura_0 = temp;
			
			if (Heightcnt > 1) {
				Write1LineDst(Heightcnt-1, result);
			}
		}

		Heightcnt++;
	}

	return 0;
}

/******************************************************************************/
/* RoundingOff                                                                */
/*        Scale:counting fractions over 1/2 as one and disregarding the rest  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/04   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int RoundingOff(int sourceValue, unsigned char scale, int cutEnable) {
	int i, b;
	double fa;
	long resultvalue = sourceValue;

	if (scale) {
		/* 2^scale */
		for (i=0, b=1; i<(unsigned int)scale; i++) b = b * 2;
		
		fa = (double)sourceValue;
		fa = fa/b;
		if (cutEnable) { /*rounddown*/
			if(fa>=0) resultvalue = (int)fa;
			else resultvalue = !(sourceValue%b) ? (int)(fa) : (int)(fa-1);
		} else { /* round */
			if(fa>=0) resultvalue = (int)(fa+0.5);
			else resultvalue = (!(sourceValue%b)||((sourceValue>>(scale-1))&0x01)) ? (int)(fa) : (int)(fa-1);
		}
	}
	return resultvalue;
}

/******************************************************************************/
/* IMG_ConvDual                                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/07/10   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int IMG_ConvDual(short m[], short w[])
{
	int i, temp;
	
	temp = 0;
	for (i=0; i<CELL9; i++) {
		temp += (w[i] * m[i]);
	}
	
	return temp;
}

/******************************************************************************/
/* IMG_Edgecode                                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/07/14   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static unsigned int IMG_Edgecode(unsigned int rho, unsigned int theta, unsigned int x_point, unsigned int y_point)
{
	unsigned int edgecode, a, b, c, d;
	unsigned char ec_mode;
	
	ec_mode   = (unsigned char) ((IMPREG_BINTHR_READ() >> 13) & 0x0007);
	
	// Edgecode
	switch (ec_mode) {
		case 0: // rho(8)+theta(8)+X(16)
		rho      &= 0x000000FF;
		theta    &= 0x000000FF;
		x_point  &= 0x0000FFFF;
		edgecode = (rho << 24) | (theta << 16) | x_point;
		break;
		
		case 1: // rho(8)+Y(8)+X(16)
		rho      &= 0x000000FF;
		y_point  &= 0x000000FF;
		x_point  &= 0x0000FFFF;
		edgecode = (rho << 24) | (y_point << 16) | x_point;
		break;
		
		case 2: // theta(8)+Y(8)+X(16)
		theta    &= 0x000000FF;
		y_point  &= 0x000000FF;
		x_point  &= 0x0000FFFF;
		edgecode = (theta << 24) | (y_point << 16) | x_point;
		break;
		
		case 3: // rho(8)+theta(8)+Y(8)+X(8)
		rho      &= 0x000000FF;
		theta    &= 0x000000FF;
		y_point  &= 0x000000FF;
		x_point  &= 0x000000FF;
		edgecode = (rho << 24) | (theta << 16) | (y_point << 8) | x_point;
		break;
		
		case 4: // rho(8)+0(2)+theta(9)+X(13)
		rho      &= 0x000000FF;
		theta    &= 0x000001FF;
		x_point  &= 0x00001FFF;
		edgecode = (rho << 24) | (theta << 13) | x_point;
		break;
		
		case 5: // 0(8)+rho(8)+0(7)+theta(9)
		rho      &= 0x000000FF;
		theta    &= 0x000001FF;
		edgecode = (rho << 16) | theta;
		break;
		
		case 6: // 0(6)+Y(10)+0(3)+X(13)
		y_point  &= 0x000003FF;
		x_point  &= 0x00001FFF;
		edgecode = (y_point << 16) | x_point;
		break;
		
		case 7: // rho(8)+0(7)+theta(9)+X(8)
		rho      &= 0x000000FF;
		theta    &= 0x000001FF;
		x_point  &= 0x000000FF;
		edgecode = (rho << 24) | (theta << 8) | x_point;
		break;
	}

	return edgecode;
}

/******************************************************************************/
/* Calculate_Rho                                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/07/14   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static int Calculate_Rho(int rhoa, int rhob)
{
	int abs_rhoa, abs_rhob, rho;
	unsigned char edge_mode;
	
	edge_mode = (unsigned char) ((IMPREG_COEFF15_READ() >> 29) & 0x0007);
	
	if (rhoa < 0) abs_rhoa = -1 * rhoa;
	else abs_rhoa = rhoa;
	
	if (rhob < 0) abs_rhob = -1 * rhob;
	else abs_rhob = rhob;
	
	// Calculate rho
	switch (edge_mode) {
	case 0:
		rho = rhoa;
		break;
	case 1:
		rho = abs_rhoa;
		break;
	case 2:
		rho = rhob;
		break;
	case 3:
		rho = abs_rhob;
		break;
	case 4:
		rho = abs_rhoa + abs_rhob;
		break;
	case 5:
		if (abs_rhoa > abs_rhob) rho = abs_rhoa + (abs_rhob * 3) / 8;
		else rho = abs_rhob + (abs_rhoa * 3) / 8;
		break;
	default:
		// error
		SIMLOG(SL_LS, SL_ERR, "ERROR, invalid edge_mode:0x%x \n", edge_mode);
		Legacy_assert_error();
		break;
	}
	
	return rho;
}

/******************************************************************************/
/* Calculate_Theta                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/07/14   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
static unsigned int Calculate_Theta(int rhoa, int rhob, unsigned char type)
{
	unsigned int abs_rhoa, abs_rhob, max_rho, i, thrm0_addr, thrm1_addr, theta;
	unsigned int *tbl_THRM0, *tbl_THRM1;
	unsigned int comp_angle_thr1, comp_angle_thr2;
	unsigned char comp_angle_enb;
	
	comp_angle_enb  = (unsigned char) ((IMPREG_ECCAET_READ() >> 31) & 0x0001);
	comp_angle_thr1 = (unsigned int) (IMPREG_ECCAET_READ() & 0x01FF);
	comp_angle_thr2 = (unsigned int) ((IMPREG_ECCAET_READ() >> 16) & 0x01FF);
	
	tbl_THRM0 = (unsigned int *)pTHRM0[IMP_WORK_CH];
	tbl_THRM1 = (unsigned int *)pTHRM1[IMP_WORK_CH];
	
	// Calculate addr of THRM0
	thrm1_addr = 0;
	if (rhoa < 0) {
		abs_rhoa = (unsigned int)(-1 * rhoa);
		thrm1_addr = thrm1_addr | 0x00000100;
	} else {
		abs_rhoa = (unsigned int)rhoa;
	}
	
	if (rhob < 0) {
		abs_rhob = (unsigned int)(-1 * rhob);
		thrm1_addr = thrm1_addr | 0x00000080;
	} else {
		abs_rhob = (unsigned int)rhob;
	}
	
	if (abs_rhoa > abs_rhob) {
		max_rho = abs_rhoa;
	} else {
		max_rho = abs_rhob;
	}
	
	i = 0;
	while (max_rho) {
		max_rho = max_rho >> 1;
		i++;
	}
	
	if (i > 6) {
		abs_rhoa = abs_rhoa >> (i-6);
		abs_rhob = abs_rhob >> (i-6);
	}
	thrm0_addr = (abs_rhoa << 6) | abs_rhob;

	// Get value from table of THRM0, and Calculate addr of THRM1
	thrm1_addr = thrm1_addr | tbl_THRM0[thrm0_addr];

	// Get value from table of THRM1
	theta = tbl_THRM1[thrm1_addr];
	
	if (comp_angle_enb) {
		SIMLOG(SL_LS, SL_L4, "  comp_angle_enb is 1, we must study more!!!\n");
		SIMLOG(SL_LS, SL_L4, "   ECCAET      -> %08x\n",IMPREG_ECCAET_READ());
		if ((theta >= comp_angle_thr2) || (theta <= comp_angle_thr1)) {
			theta = 0xFFFFFFFF;
			SIMLOG(SL_LS, SL_L4, "  theta = %d, so skip edgecode !!!", theta);
		}
	}

	return theta;
}
