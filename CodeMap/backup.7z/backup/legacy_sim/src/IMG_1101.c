/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_1101.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"


/******************************************************************************/
/* IMG_1101                                                                   */
/*       Runlength                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/30                                                      */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
int IMG_1101(){
    long xlng, ylng, Heightcnt;
    int i, subfun, cnt, search, Wpt, St;
    short sour_id[LINE_SIZE];
    int64 result[LINE_SIZE];

	SIMLOG(SL_LS, SL_ERR, "ERROR, IMG_1101 is not supported.\n");
	Legacy_assert_error();
	
#if SKIP_FOR_COVERAGE
		/* skip */
#else
    subfun = (((IMPREG_IPFUN_READ())>>24) & 0x000f);
    if((subfun>1)||(subfun<0)){
        SIMLOG(SL_LS, SL_L4, "Error subfun=%d\n",subfun);
        return(-1);
    }

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

    if(subfun==0){ /* Encode */
        Heightcnt = 0;

    /* All Line loop */
        while(Heightcnt < ylng){
    /* 1Line */
            Read1LineSrc0(Heightcnt, sour_id);

            St = Wpt = 0;
            memset(result, 0, LINE_SIZE * sizeof(int64));

            if(Get8b(sour_id[0])){ /* 1 */
                if(Get8b(sour_id[1])){ /* 1 */
                    result[Wpt] = 0xFF;
                    search = 1; cnt = 2;
                }else{ /* 0 */
                    result[Wpt] = 0xFE;
                    search = 0; cnt = 1;
                }
                St = 2;
                Wpt++;
            }else{ /* 0 */
                search = 0; cnt = 1;
                St = 1;
            }

            for(i=St;i<xlng;i++){
                if(Get8b(sour_id[i])==search){
                    cnt++;
                    if(cnt>0xF0){
                        result[Wpt] = 0xF1;
                        Wpt++; cnt -= 0xF0;
                    }
                }else{
                    result[Wpt] = cnt;
                    Wpt++; cnt=1;
                    if(search) search = 0;
                    else search = 1;
                }

            }
            result[Wpt] = 0;
            Write1LineDst(Heightcnt, result);
    /* Next Line */
            Heightcnt++;
        }
    }else{  /* Decode */
        Heightcnt = 0;

    /* All Line loop */
        while(Heightcnt < ylng){
    /* 1Line */
            Read1LineSrc0(Heightcnt, sour_id);

            search = 0;
            for(i=0;i<xlng;i++){
                if(sour_id[i]==0){
                }else if(sour_id[i]==0xFF){
                    search = 0;
                }else{
                    search = sour_id[i];
                }
                result[i] = search;
            }
            Write1LineDst(Heightcnt, result);
    /* Next Line */
            Heightcnt++;
        }
    }
#endif

    return(0);
}

