/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_adpt.c                                      */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif

#include "impsim_int.h"
#include "legacy_sim.h"
#include "legacy_sim_prot.h"

unsigned char  *pCM0[IMP_CH_MAX], *pCM1[IMP_CH_MAX], *pHM[IMP_CH_MAX], *pTHRM0[IMP_CH_MAX], *pTHRM1[IMP_CH_MAX], *pFIFO;

unsigned short *pLINE0[LINE_NUM], *pLINE1[LINE_NUM], *pLINE2[LINE_NUM], *pLINE3[LINE_NUM], *pLINE4[LINE_NUM], *pLINE5[LINE_NUM], *pLINE6[LINE_NUM], *pLINE7[LINE_NUM], *pLINE8[LINE_NUM];

unsigned short *pDest1, *pDest2;
unsigned long *plDest1;

unsigned char  *pDR;

unsigned int IMP_WORK_CH = IMP_CH_0;

// Direct Path
unsigned int Pending_ch[4];
unsigned int DP_Buffer;

/******************************************************************************/
/* legacy_sim_init                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                       new                                                  */
/******************************************************************************/
int legacy_sim_init(void) {
	int cnt, ch, i, j;
	int rc = E_OK;
	unsigned int memsize = 0;
	unsigned char *ppp;
	
	SIMLOG(SL_LS_ADPT, SL_L3, "Initialize simulation environment.\n");
	
	// malloc
	SIMLOG(SL_LS_ADPT, SL_L5, "legacy_sim_init malloc start.\n");
	for (ch = 0; ch < IMP_CH_MAX; ch++) {
		pCM0[ch] = malloc(CM0_MEM_SIZE);
		memsize += CM0_MEM_SIZE;
		if(pCM0[ch]==NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pCM0 = malloc(CM0_MEM_SIZE).\n");
			Legacy_assert_error();
		}
		pCM1[ch] = malloc(CM1_MEM_SIZE);
		memsize += CM1_MEM_SIZE;
		if(pCM1[ch]==NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pCM1 = malloc(CM1_MEM_SIZE).\n");
			Legacy_assert_error();
		}
		pHM[ch] = malloc(HM_MEM_SIZE);
		memsize += HM_MEM_SIZE;
		if(pHM[ch]==NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pHM = malloc(HM_MEM_SIZE).\n");
			Legacy_assert_error();
		}
		pTHRM0[ch] = malloc(THRM0_MEM_SIZE);
		memsize += THRM0_MEM_SIZE;
		if(pTHRM0[ch]==NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pTHRM0 = malloc(THRM0_MEM_SIZE).\n");
			Legacy_assert_error();
		}
		pTHRM1[ch] = malloc(THRM1_MEM_SIZE);
		memsize += THRM1_MEM_SIZE;
		if(pTHRM1[ch]==NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pTHRM1 = malloc(THRM1_MEM_SIZE).\n");
			Legacy_assert_error();
		}
	}
	
	pFIFO = malloc(FIFO_MEM_SIZE);
	memsize += FIFO_MEM_SIZE;
	if (pFIFO==NULL) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pFIFO = malloc(FIFO_MEM_SIZE).\n");
		Legacy_assert_error();
	}
	
	plDest1 = malloc(DEST_MEM_SIZE);
	memsize += DEST_MEM_SIZE;
	if (plDest1==NULL) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, plDest1 = malloc(DEST_MEM_SIZE*2).\n");
		Legacy_assert_error();
	}
	pDest1 = (unsigned short *)plDest1;
	
	pDest2 = malloc(DT_MEM_SIZE);
	memsize += DT_MEM_SIZE;
	if (pDest2==NULL) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, pDest2 = malloc(DT_MEM_SIZE).\n");
		Legacy_assert_error();
	}
	
	for (cnt=0; cnt<LM_NUM; cnt++) {
		pLM256[cnt] = malloc(LM256_MEM_SIZE);
		memsize += LM256_MEM_SIZE;
		if(pLM256[cnt]==NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLM256[cnt] = malloc(LM256_MEM_SIZE).\n");
			Legacy_assert_error();
		}
	}
	
	// pLINE0
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE0[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE0[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE0[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE1
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE1[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE1[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE1[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE2
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE2[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE2[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE2[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE3
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE3[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE3[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE3[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE4
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE4[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE4[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE4[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE5
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE5[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE5[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE5[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE6
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE6[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE6[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE6[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE7
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE7[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE7[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE7[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	// pLINE8
	for (cnt = 0; cnt < LINE_NUM; cnt++) {
		pLINE8[cnt] = malloc(LINE_MEM_SIZE);
		memsize += LINE_MEM_SIZE;
		if (pLINE8[cnt] == NULL) {
			SIMLOG(SL_LS, SL_ERR, "ERROR, pLINE8[%d] = malloc(LINE_MEM_SIZE) = NULL.\n", cnt);
			Legacy_assert_error();
		}
	}
	
	memsize = (memsize + 512) / 1024;
	SIMLOG(SL_LS_ADPT, SL_L5, "legacy_sim_init malloc size = %d kB.\n", memsize);
	memsize = (memsize + 512) / 1024;
	SIMLOG(SL_LS_ADPT, SL_L5, "legacy_sim_init malloc size = %d MB.\n", memsize);
	
	// The following are set at the time IMP is kicked.
	pSrc0 = NULL;
	pSrc1 = NULL;
	pDst = NULL;
	SASP = SBSP = DSP = 0x0UL;
	
	// memset
	SIMLOG(SL_LS_ADPT, SL_L5, "legacy_sim_init memset start.\n");
	
	for (ch = 0; ch < IMP_CH_MAX; ch++) {
		memset(pCM0[ch], 0, CM0_MEM_SIZE);
		memset(pCM1[ch], 0, CM1_MEM_SIZE);    
		memset(pHM[ch], 0, HM_MEM_SIZE);
		memset(pTHRM0[ch], 0, THRM0_MEM_SIZE);
		memset(pTHRM1[ch], 0, THRM1_MEM_SIZE);
	}
	
	memset(pFIFO, 0, FIFO_MEM_SIZE);
	
	memset(plDest1, 0, DEST_MEM_SIZE);
	memset(pDest2, 0, DT_MEM_SIZE);
	
	for (cnt=0; cnt<LM_NUM; cnt++){
		memset(pLM256[cnt], 0, LM256_MEM_SIZE);
	}
	
	for (cnt=0; cnt<LINE_NUM; cnt++) {
		memset(pLINE0[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE1[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE2[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE3[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE4[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE5[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE6[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE7[cnt], 0, LINE_MEM_SIZE);
		memset(pLINE8[cnt], 0, LINE_MEM_SIZE);
	}
	
	// for Direct Path
	pDR = pDest2;
	Pending_ch[0] = 0;
	Pending_ch[1] = 0;
	Pending_ch[2] = 0;
	Pending_ch[3] = 0;
	DP_Buffer = 0xffffffff;
	
	// Copy regtable[] to IMPREG[][] 
	SIMLOG(SL_LS_ADPT, SL_L5, "Read register initial values from regtable to IMPREG table.\n");
	for (ch = 0; ch < IMP_CH_MAX; ch++) {
		for (i = 0; i < REGSETS_MAX; i++) {
			for (j = 0; j < REGMAX; j++) {
				if (regtable[j].No >= REGMAX) {
					SIMLOG(SL_LS_ADPT, SL_ERR, "Unexpected register initialization. Check regtable[], cnt:%d, regtable[].No:%d\n", j, regtable[j].No);
				} else {
					IMPREG[ch][i][regtable[j].No] = regtable[j].initnum;
				}
			}
		}
	}
	
	// default
	AllocateLineMemory();
	
	// to check memory over write
	ppp = (unsigned char *) pDest1;
	ppp += DEST_MEM_SIZE;
	ppp --;
	*ppp = DEST_MEM_POST_END1;
	ppp --;
	*ppp = DEST_MEM_POST_END2;
	ppp --;
	*ppp = DEST_MEM_POST_END3;
	ppp --;
	*ppp = DEST_MEM_POST_END4;
	
	ppp = (unsigned char *) pDest2;
	ppp += DT_MEM_SIZE;
	ppp --;
	*ppp = DEST_MEM_POST_END4;
	ppp --;
	*ppp = DEST_MEM_POST_END3;
	ppp --;
	*ppp = DEST_MEM_POST_END2;
	ppp --;
	*ppp = DEST_MEM_POST_END1;
	
	return rc;
}


/******************************************************************************/
/* legacy_sim_close                                                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20   T.Sato                                             */
/*                       new                                                  */
/******************************************************************************/
int legacy_sim_close(void) {
	int ch, cnt;
	int rc = E_OK;
	
	for (cnt=0; cnt<LINE_NUM; cnt++) {
		free(pLINE0[cnt]);
		free(pLINE1[cnt]);
		free(pLINE2[cnt]);
		free(pLINE3[cnt]);
		free(pLINE4[cnt]);
		free(pLINE5[cnt]);
		free(pLINE6[cnt]);
		free(pLINE7[cnt]);
		free(pLINE8[cnt]);
	}
	
	for (cnt=0; cnt<LM_NUM; cnt++) {
		free(pLM256[cnt]);
	}
	
	free(pDest2);
	free(plDest1);
	free(pFIFO);
	
	for (ch = 0; ch < IMP_CH_MAX; ch++) {
		free(pTHRM1[ch]);
		free(pTHRM0[ch]);
		free(pHM[ch]);
		free(pCM1[ch]);
		free(pCM0[ch]);
	}
	
	return rc;
}


/******************************************************************************/
/* legacy_sim_write_reg                                                       */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void legacy_sim_write_reg(uint32_t offset_ch, uint32_t next_reg_val) {
    int cnt;
    unsigned long reg_id = 0; // Not uint32_t, because "unsigned long" is specified in the sh3emu.h of legacy core simulator.
    uint32_t current_reg_val;
    uint32_t offset, check_offset;

	offset = offset_ch & 0x0001ffff;
	if (offset == offset_ch) {
		IMP_WORK_CH = IMP_CH_0;
	} else if (offset_ch >= IMPX4_LEGACY_CH0_S && offset_ch <= IMPX4_LEGACY_CH0_E ) {
		IMP_WORK_CH = IMP_CH_0;
	} else if (offset_ch >= IMPX4_LEGACY_CH1_S && offset_ch <= IMPX4_LEGACY_CH1_E ) {
		IMP_WORK_CH = IMP_CH_1;
	} else if (offset_ch >= IMPX4_LEGACY_CH2_S && offset_ch <= IMPX4_LEGACY_CH2_E ) {
		IMP_WORK_CH = IMP_CH_2;
	} else if (offset_ch >= IMPX4_LEGACY_CH3_S && offset_ch <= IMPX4_LEGACY_CH3_E ) {
		IMP_WORK_CH = IMP_CH_3;
	} else {
		SIMLOG(SL_LS, SL_ERR, "ERROR, offset_ch(0x%08lx) is not supported! \n", (unsigned long)offset_ch);
		Legacy_assert_error();
	}
	
    // Check if the access is to HM
    if (offset >= DL_IPREG_HM_S && offset < DL_IPREG_HM_E) {
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_write_reg():  [HM] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)next_reg_val);
        WriteHM(IMP_WORK_CH, (int)((offset - DL_IPREG_HM_S)/4), next_reg_val);  
        return;
    }

    // Check if the access is to CM0
    if (offset >= DL_IPREG_CMA_S && offset < DL_IPREG_CMA_E) {
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_write_reg():  [CM0] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)next_reg_val);
        WriteCM0(IMP_WORK_CH, (int)((offset - DL_IPREG_CMA_S)/4), next_reg_val);  
        return;
    }

    // Check if the access is to CM1
    if (offset >= DL_IPREG_CMB_S && offset < DL_IPREG_CMB_E) {
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_write_reg():  [CM1] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)next_reg_val);
        WriteCM1(IMP_WORK_CH, (int)((offset - DL_IPREG_CMB_S)/4), next_reg_val);  
        return;
    }

    // Check if the access is to THTDATA0
    if (offset >= DL_IPREG_THTDATA0_S && offset < DL_IPREG_THTDATA0_E) {
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_write_reg():  [THTDATA0] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)next_reg_val);
        WriteTHTDATA0(IMP_WORK_CH, (int)((offset - DL_IPREG_THTDATA0_S)/4), next_reg_val);  
        return;
    }

    // Check if the access is to THTDATA1
    if (offset >= DL_IPREG_THTDATA1_S && offset < DL_IPREG_THTDATA1_E) {
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_write_reg():  [THTDATA1] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)next_reg_val);
        WriteTHTDATA1(IMP_WORK_CH, (int)((offset - DL_IPREG_THTDATA1_S)/4), next_reg_val);  
        return;
    }

    // Check if the access is to PIPE
    if (offset >= DL_IPREG_PIPEM_S && offset < DL_IPREG_PIPEM_E) {
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_write_reg():  [mem] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)next_reg_val);

        mem[IMP_WORK_CH][(offset - DL_IPREG_PIPEM_S)/2    ] = (next_reg_val & 0xffff0000) >> 16; // Copy upper 16 bits as 1 PIPE code to PIPE memory.
        mem[IMP_WORK_CH][(offset - DL_IPREG_PIPEM_S)/2 + 1] = (next_reg_val & 0x0000ffff);       // Copy lower 16 bits as 1 PIPE code to PIPE memory.
    	return;
    }

    /* Check if the register is known. */
    for(cnt=0; cnt<REGMAX; cnt++) {
        if (regtable[cnt].adr == offset) {
            reg_id = regtable[cnt].No;
            break;
        }
    }
        
    if (cnt == REGMAX) {
        SIMLOG(SL_LS_ADPT, SL_L1, "legacy_sim_write_reg():  [WARNING:unknown] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)next_reg_val);
    } else {
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_write_reg():  [%s] address:%08lx, val:%08lx\n",
               regtable[cnt].regname, (unsigned long)offset, (unsigned long)next_reg_val);
    }

    /* Exclude register access from other thread. */
    // To be filled.

    /* Read register value first. (offset has been checked) */
    read_reg(IMP_WORK_CH, offset, &current_reg_val);
   
    /* If IMP is working already, register writing is very limited. */
    if (is_imp_working()) {
        if ((reg_id == _IFCTL) && (next_reg_val & _IFCTL_IF_STOP)) {
            // To be filled.
        } else {
            SIMLOG(SL_LS_ADPT, SL_L1,
                   "legacy_sim_write_reg(): WARNING. Access register during IMP is working. [%s] address:%08lx, val:%08lx\n",
               regtable[cnt].regname, (unsigned long)offset, (unsigned long)next_reg_val);
            SIMLOG(SL_LS_ADPT, SL_L1, "legacy_sim_write_reg(): Write access is ignored.\n");
        }
    } else { // IMP is calm. Write the value to the register.
        /* Check if immediate action is required or just write the value to the register. */
        if ((reg_id == _IFCTL) && (next_reg_val & _IFCTL_IF_EXEC)) {
            start_thread(kick_ifid_with_dl);
            /* No write to IFCTL, because read of IFCTL shows always zero. */
        } else if ((reg_id == _APCMD) && (next_reg_val & _APCMD_EX)) {
            //start, temperory for Issue #58128
        	write_reg(IMP_WORK_CH, offset, next_reg_val);
            //end, temperory for Issue #58128

            start_thread(kick_ap);
        } else if ((reg_id == _CNF) && (next_reg_val & _CNF_RST)) {
            //            start_thread(kick_software_reset);
            kick_software_reset();
        } else if (0) {
            /** H.Shiota Need to be filled for the case HP memory clear and initializing by hpen */
        } else { // Just write the value to the register. 
            write_reg(IMP_WORK_CH, offset, next_reg_val);
        }
    }

    /* Permit other thread to access register. */
    // To be filled.

    return;
}

/******************************************************************************/
/* legacy_sim_read_reg                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
uint32_t legacy_sim_read_reg(uint32_t offset_ch) {
    int rc;
    uint32_t reg_val = 0;
    uint32_t offset;

	offset = offset_ch & 0x0001ffff;
	if (offset == offset_ch) {
		IMP_WORK_CH = IMP_CH_0;
	} else if (offset_ch >= IMPX4_LEGACY_CH0_S && offset_ch <= IMPX4_LEGACY_CH0_E ) {
		IMP_WORK_CH = IMP_CH_0;
	} else if (offset_ch >= IMPX4_LEGACY_CH1_S && offset_ch <= IMPX4_LEGACY_CH1_E ) {
		IMP_WORK_CH = IMP_CH_1;
	} else if (offset_ch >= IMPX4_LEGACY_CH2_S && offset_ch <= IMPX4_LEGACY_CH2_E ) {
		IMP_WORK_CH = IMP_CH_2;
	} else if (offset_ch >= IMPX4_LEGACY_CH3_S && offset_ch <= IMPX4_LEGACY_CH3_E ) {
		IMP_WORK_CH = IMP_CH_3;
	} else {
		SIMLOG(SL_LS, SL_ERR, "ERROR, offset_ch(0x%08lx) is not supported! \n", (unsigned long)offset_ch);
		Legacy_assert_error();
	}

    // Check if the access is to HM
    if (offset >= DL_IPREG_HM_S && offset < DL_IPREG_HM_E) {
        ReadHM(IMP_WORK_CH, (int)((offset - DL_IPREG_HM_S)/4), (unsigned long *)&reg_val);
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_read_reg():  [HM] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)reg_val);
        return reg_val;
    }
    
    // Check if the access is to CM0
    if (offset >= DL_IPREG_CMA_S && offset < DL_IPREG_CMA_E) {
        ReadCM0(IMP_WORK_CH, (int)((offset - DL_IPREG_CMA_S)/4), (unsigned long *)&reg_val);
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_read_reg():  [CM0] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)reg_val);
        return reg_val;
    }

    // Check if the access is to CM1
    if (offset >= DL_IPREG_CMB_S && offset < DL_IPREG_CMB_E) {
        ReadCM1(IMP_WORK_CH, (int)((offset - DL_IPREG_CMB_S)/4), (unsigned long *)&reg_val);
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_read_reg():  [CM1] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)reg_val);
        return reg_val;
    }

    // Check if the access is to THTDATA0
    if (offset >= DL_IPREG_THTDATA0_S && offset < DL_IPREG_THTDATA0_E) {
        ReadTHTDATA0(IMP_WORK_CH, (int)((offset - DL_IPREG_THTDATA0_S)/4), (unsigned long *)&reg_val);
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_read_reg():  [THTDATA0] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)reg_val);
        return reg_val;
    }

    // Check if the access is to THTDATA1
    if (offset >= DL_IPREG_THTDATA1_S && offset < DL_IPREG_THTDATA1_E) {
        ReadTHTDATA1(IMP_WORK_CH, (int)((offset - DL_IPREG_THTDATA1_S)/4), (unsigned long *)&reg_val);
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_read_reg():  [THTDATA1] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)reg_val);
        return reg_val;
    }

    // Check if the access is to PIPE
    if (offset >= DL_IPREG_PIPEM_S && offset < DL_IPREG_PIPEM_E) {
        reg_val = (mem[IMP_WORK_CH][(offset - DL_IPREG_PIPEM_S)/2 ] << 16) | (mem[IMP_WORK_CH][(offset - DL_IPREG_PIPEM_S)/2 + 1]);
        SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_read_reg():  [mem] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)reg_val);
        return reg_val;
    }

    rc = read_reg(IMP_WORK_CH, offset, &reg_val);

    if (rc == E_OK) {
        int cnt;
        for (cnt=0; cnt<REGMAX; cnt++) {
            if (regtable[cnt].adr == (offset & 0x0000ffff)) {
                SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_read_reg():  [%s] address:%08lx, val:%08lx\n",
                       regtable[cnt].regname, (unsigned long)offset, (unsigned long)reg_val);
                break;
            }
        }
    } else {
        SIMLOG(SL_LS_ADPT, SL_L1, "legacy_sim_read_reg():  [WARNIG:unknown] address:%08lx, val:%08lx\n",
               (unsigned long)offset, (unsigned long)reg_val);
    }
    
    /* IMP is activated. For example, zero clearing of register value. */
    //rc = legacy_sim_activate_imp_by_write_reg(offset, val);

    return reg_val;
}

/******************************************************************************/
/* legacy_sim_wait_imp                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int legacy_sim_wait_imp(void) {
    int rc;
    
    SIMLOG(SL_LS_ADPT, SL_L3, "legacy_sim_wait_imp(): Wait end of IMP process.\n");

    rc = wait_thread();
    return rc;
}

