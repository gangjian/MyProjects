/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_1011.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"

static int64 IMG_1011_SharpConv(short m[]);

/******************************************************************************/
/* IMG_1011                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
int IMG_1011(){
    long xlng, ylng, Widthcnt, Heightcnt;
    int i, kernel;
    short m[25];
	short *sour_id1 = psLM6;
	short *sour_id2 = psLM7;
	int64 result[LINE_SIZE];
	
    kernel = (((IMPREG_IPFUN_READ())>>27) & 0x0001); /* 1 only */
	
	if ( !USE_PIPE_FUNC && McomFlg ) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (PIPE). turn on USE_PIPE_FUNC when use PIPE for IMG_1011.\n");
		Legacy_assert_error();
	}
	
    if(kernel!=1){
        SIMLOG(SL_LS, SL_L4, "Error kernel=%d\n",kernel);
        return(-1);
    }

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

#if USE_PIPE_FUNC
    if(McomFlg){
        Widthcnt = 0;

        for(i=0;i<xlng;i++){
            if((Widthcnt==0)||(Widthcnt==1)||(Widthcnt==xlng-2)||(Widthcnt==xlng-1)){
                result[i] = 0;
            }else{
                m[ 0] = ReadLM256A(4, Widthcnt-2);
                m[ 1] = ReadLM256A(4, Widthcnt-1);
                m[ 2] = ReadLM256A(4, Widthcnt  );
                m[ 3] = ReadLM256A(4, Widthcnt+1);
                m[ 4] = ReadLM256A(4, Widthcnt+2);
                m[ 5] = ReadLM256A(3, Widthcnt-2);
                m[ 6] = ReadLM256A(3, Widthcnt-1);
                m[ 7] = ReadLM256A(3, Widthcnt  );
                m[ 8] = ReadLM256A(3, Widthcnt+1);
                m[ 9] = ReadLM256A(3, Widthcnt+2);
                m[10] = ReadLM256A(2, Widthcnt-2);
                m[11] = ReadLM256A(2, Widthcnt-1);
                m[12] = ReadLM256A(2, Widthcnt  );
                m[13] = ReadLM256A(2, Widthcnt+1);
                m[14] = ReadLM256A(2, Widthcnt+2);
                m[15] = ReadLM256A(1, Widthcnt-2);
                m[16] = ReadLM256A(1, Widthcnt-1);
                m[17] = ReadLM256A(1, Widthcnt  );
                m[18] = ReadLM256A(1, Widthcnt+1);
                m[19] = ReadLM256A(1, Widthcnt+2);
                m[20] = ReadLM256A(0, Widthcnt-2);
                m[21] = ReadLM256A(0, Widthcnt-1);
                m[22] = ReadLM256A(0, Widthcnt  );
                m[23] = ReadLM256A(0, Widthcnt+1);
                m[24] = ReadLM256A(0, Widthcnt+2);

                result[i] = IMG_1011_SharpConv(m);
            }
            Widthcnt++;

        }

        Write1LineDst(0, result);

    }else{
#endif 
    /* First Line */
        for(i=0;i<xlng;i++){
            result[i] = 0;
        }
        Write1LineDst(0, result);
        Write1LineDst(1, result);

    /* Middle Line */
        Heightcnt = 2;

    /* All Line loop */
        while(Heightcnt < ylng - 2){
    /* 1Line */
            Read1LineSrc0(Heightcnt - 2, sour_id2);
            WriteLM0(0, sour_id2, xlng);
            Read1LineSrc0(Heightcnt - 1, sour_id2);
            WriteLM1(0, sour_id2, xlng);
            Read1LineSrc0(Heightcnt    , sour_id2);
            WriteLM2(0, sour_id2, xlng);
            Read1LineSrc0(Heightcnt + 1, sour_id1);
            Read1LineSrc0(Heightcnt + 2, sour_id2);

            Widthcnt = 0;

            for(i=0;i<xlng;i++){
                if((Widthcnt==0)||(Widthcnt==1)||(Widthcnt==xlng-2)||(Widthcnt==xlng-1)){
                    result[i] = 0;
                }else{
                    m[ 0] = ReadLM0(Widthcnt-2);
                    m[ 1] = ReadLM0(Widthcnt-1);
                    m[ 2] = ReadLM0(Widthcnt  );
                    m[ 3] = ReadLM0(Widthcnt+1);
                    m[ 4] = ReadLM0(Widthcnt+2);
                    m[ 5] = ReadLM1(Widthcnt-2);
                    m[ 6] = ReadLM1(Widthcnt-1);
                    m[ 7] = ReadLM1(Widthcnt  );
                    m[ 8] = ReadLM1(Widthcnt+1);
                    m[ 9] = ReadLM1(Widthcnt+2);
                    m[10] = ReadLM2(Widthcnt-2);
                    m[11] = ReadLM2(Widthcnt-1);
                    m[12] = ReadLM2(Widthcnt  );
                    m[13] = ReadLM2(Widthcnt+1);
                    m[14] = ReadLM2(Widthcnt+2);
                    m[15] = sour_id1[Widthcnt-2];
                    m[16] = sour_id1[Widthcnt-1];
                    m[17] = sour_id1[Widthcnt  ];
                    m[18] = sour_id1[Widthcnt+1];
                    m[19] = sour_id1[Widthcnt+2];
                    m[20] = sour_id2[Widthcnt-2];
                    m[21] = sour_id2[Widthcnt-1];
                    m[22] = sour_id2[Widthcnt  ];
                    m[23] = sour_id2[Widthcnt+1];
                    m[24] = sour_id2[Widthcnt+2];

                    result[i] = IMG_1011_SharpConv(m);
                }
                Widthcnt++;

            }

            Write1LineDst(Heightcnt, result);
    /* Next Line */
            Heightcnt++;

        }

    /* Last 2 Line */
        for(i=0;i<xlng;i++){
            result[i] = 0;
        }
        if(Heightcnt < ylng-1) Write1LineDst(Heightcnt, result);
        if(Heightcnt < ylng  ) Write1LineDst(Heightcnt+1, result);
#if USE_PIPE_FUNC
    }
#endif 

    return(0);
}


/******************************************************************************/
/* IMG_1011_SharpConv                                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
static int64 IMG_1011_SharpConv(short m[]){
    int morphic;
    int64 ret;

    if(m[12]==0) return(0);

    ret = -1;

/* syori mode */
/* 0:Saisen 4renketu 1:Saisen 8renketu 2:Syukutai 4renketu 3:Syukutai 8renketu */
    morphic   = (((IMPREG_IPFUN_READ())>>24) & 0x0003);

/********* Saisen & Syukutai 4renketu *********/
    if((morphic==0)||(morphic==2)){
/* Pattern 1 */
        if( (m[7]==0)&(m[11]==0)&(m[13]!=0)&(m[17]!=0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[7])&(~m[11])&m[13]&m[17]&m[18]&(m[19]|m[23])) ) == 0 ) ret=0;
        }
/* Pattern 2 */
        if( (m[7]==0)&(m[11]!=0)&(m[13]==0)&(m[16]!=0)&(m[17]!=0) ){
            if (( ( m[12] & ~((~m[7])&(~m[13])&m[11]&m[16]&m[17]&( m[15]|(m[10]&m[21])|(m[20]&m[21])|(~m[22]&m[21]) )  )) ) == 0 ) ret=0;
        }
/* Pattern 3 */
        if( (m[6]!=0)&(m[7]!=0)&(m[11]!=0)&(m[13]==0)&(m[17]==0) ){
            if ( ( m[12] & ~(m[6]&m[7]&m[11]&(~m[13])&(~m[17])&( m[0]|(m[2]&m[10])|(m[2]&m[5])|(m[1]&m[10])|(~m[2]&~m[10])  )) ) == 0 ) ret=0;
        }
/* Pattern 4 */
        if( (m[7]!=0)&(m[8]!=0)&(m[11]==0)&(m[13]!=0)&(m[17]==0) ){
            if ( ( m[12] & ~(m[7]&m[8]&m[13]&(~m[11])&(~m[17])&( (~m[14])|m[2]|m[3]|m[4]|m[9] )) ) == 0 ) ret=0;
        }
/* Pattern 5 */
        if( (m[6]!=0)&(m[7]!=0)&(m[8]!=0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[6]&m[7]&m[8]&(~m[11])&(~m[13])&(~m[16])&(~m[17])&(~m[18]) ) ) == 0 ) ret=0;
        }
/* Pattern 6 */
        if( (m[6]!=0)&(m[7]==0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]!=0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[6]&m[11]&m[16]&(~m[7])&(~m[8])&(~m[13])&(~m[17])&(~m[18]) ) ) == 0 ) ret=0;
        }
/* Pattern 7 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[16]!=0)&(m[17]!=0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&m[16]&m[17]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 8 */
        if( (m[6]==0)&(m[8]!=0)&(m[11]==0)&(m[13]!=0)&(m[16]==0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[11])&(~m[16])&m[8]&m[13]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 9 */
        if( (m[1]!=0)&(m[2]!=0)&(m[3]!=0)&(m[6]!=0)&(m[7]!=0)&(m[8]!=0)&(m[11]!=0)&(m[13]!=0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[1]&m[2]&m[3]&m[6]&m[7]&m[8]&m[11]&m[13]&(~m[16])&(~m[17])&(~m[18]) ) ) == 0 ) ret=0;
        }
/* Pattern 10 */
        if( (m[5]!=0)&(m[6]!=0)&(m[7]!=0)&(m[8]==0)&(m[10]!=0)&(m[11]!=0)&(m[13]==0)&(m[15]!=0)&(m[16]!=0)&(m[17]!=0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[5]&m[6]&m[10]&m[11]&m[15]&m[16]&m[7]&m[17]&(~m[8])&(~m[13])&(~m[18]) ) ) == 0 ) ret=0;
        }
    }
/********* Saisen & Syukutai 8renketu *********/
    if((morphic==1)||(morphic==3)){
/* Pattern 1 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]!=0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[13])&(~m[17])&(~m[18])&m[11]&m[16] ) ) == 0 ) ret=0;
        }
/* Pattern 2 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[16]!=0)&(m[17]!=0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[13])&(~m[18])&m[16]&m[17] ) ) == 0 ) ret=0;
        }
/* Pattern 3 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]!=0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[13])&(~m[16])&m[17]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 4 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]!=0)&(m[16]==0)&(m[17]==0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[16])&(~m[17])&m[13]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 5 */
        if( (m[6]==0)&(m[7]==0)&(m[11]==0)&(m[13]!=0)&(m[17]!=0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[11])&m[13]&m[17]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 6 */
        if( (m[7]==0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]!=0)&(m[17]!=0) ){
            if ( ( m[12] & ~((~m[7])&(~m[8])&(~m[13])&m[11]&m[16]&m[17]&(m[6]|m[18]) ) ) == 0 ) ret=0;
        }
/* Pattern 7 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]!=0)&(m[17]!=0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[13])&(~m[18])&m[11]&m[16]&m[17]&(m[5]|m[10]|m[15]|m[20]|m[21]|m[22]|m[23]) ) ) == 0 ) ret=0;
        }
/* Pattern 8 */
        if( (m[6]!=0)&(m[7]!=0)&(m[11]!=0)&(m[13]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[6]&m[7]&m[11]&(~m[13])&(~m[17])&(~m[18]) ) ) == 0 ) ret=0;
        }
/* Pattern 9 */
        if( (m[7]!=0)&(m[8]!=0)&(m[13]!=0)&(m[11]==0)&(m[16]==0)&(m[17]==0) ){
            if ( ( m[12] & ~(m[7]&m[8]&m[13]&(~m[11])&(~m[16])&(~m[17]) ) ) == 0 ) ret=0;
        }
/* Pattern 10 */
        if( (m[6]!=0)&(m[7]!=0)&(m[8]!=0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[6]&m[7]&m[8]&(~m[16])&(~m[17])&(~m[18])&(~m[11]|~m[13]) ) ) == 0 ) ret=0;
        }
/* Pattern 11 */
        if( (m[6]!=0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]!=0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[6]&m[11]&m[16]&(~m[8])&(~m[13])&(~m[18])&(~m[7]|~m[17]) ) ) == 0 ) ret=0;
        }
/* Pattern 12 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[16]!=0)&(m[17]!=0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&m[16]&m[17]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 13 */
        if( (m[6]==0)&(m[8]!=0)&(m[11]==0)&(m[13]!=0)&(m[16]==0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[11])&(~m[16])&m[8]&m[13]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 14 */
        if( (m[6]==0)&(m[7]!=0)&(m[8]==0)&(m[11]==0)&(m[13]!=0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[8])&(~m[11])&(~m[16])&(~m[17])&(~m[18])&m[7]&m[13] ) ) == 0 ) ret=0;
        }
/* Pattern 15 */
        if( (m[6]==0)&(m[7]!=0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[8])&(~m[13])&(~m[16])&(~m[17])&(~m[18])&m[7]&m[11] ) ) == 0 ) ret=0;
        }
/* Pattern 16 */
        if( (m[7]==0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]==0)&(m[17]!=0) ){
            if ( ( m[12] & ~((~m[7])&(~m[8])&(~m[13])&(~m[16])&m[11]&m[17] ) ) == 0 ) ret=0;
        }
/* Pattern 17 */
        if( (m[6]==0)&(m[7]==0)&(m[11]==0)&(m[13]!=0)&(m[17]!=0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[11])&(~m[18])&m[13]&m[17] ) ) == 0 ) ret=0;
        }
/* Pattern 18 */
        if( (m[1]!=0)&(m[2]!=0)&(m[3]!=0)&(m[6]!=0)&(m[7]!=0)&(m[8]!=0)&(m[11]!=0)&(m[13]!=0)&(m[17]==0) ){
            if ( ( m[12] & ~(m[1]&m[2]&m[3]&m[6]&m[7]&m[8]&m[11]&m[13]&(~m[17]) ) ) == 0 ) ret=0;
        }
/* Pattern 19 */
        if( (m[5]!=0)&(m[6]!=0)&(m[7]!=0)&(m[10]!=0)&(m[11]!=0)&(m[13]==0)&(m[15]!=0)&(m[16]!=0)&(m[17]!=0) ){
            if ( ( m[12] & ~(m[5]&m[6]&m[10]&m[11]&m[15]&m[16]&m[7]&m[17]&(~m[13]) ) ) == 0 ) ret=0;
        }
/* Pattern 20 */
        if( (m[7]==0)&(m[11]!=0)&(m[13]!=0)&(m[16]!=0)&(m[17]!=0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[7])&m[11]&m[13]&m[16]&m[17]&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 21 */
        if( (m[7]!=0)&(m[8]!=0)&(m[11]==0)&(m[13]!=0)&(m[17]!=0)&(m[18]!=0) ){
            if ( ( m[12] & ~(m[7]&m[8]&m[13]&m[17]&m[18]&(~m[11]) ) ) == 0 ) ret=0;
        }
    }

/********* Syukutai 4renketu *********/
    if(morphic==2){
/* Pattern 1 */
        if( (m[7]!=0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[7]&(~m[11])&(~m[13])&(~m[16])&(~m[17])&(~m[18])&(m[6]^m[8]) ) ) == 0 ) ret=0;
        }
/* Pattern 2 */
        if( (m[6]==0)&(m[7]==0)&(m[11]==0)&(m[13]!=0)&(m[16]==0)&(m[17]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[11])&(~m[16])&(~m[17])&m[13]&(m[8]^m[18]) ) ) == 0 ) ret=0;
        }
/* Pattern 3 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[17]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[13])&m[17]&(m[16]^m[18]) ) ) == 0 ) ret=0;
        }
/* Pattern 4 */
        if( (m[7]==0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[7])&(~m[8])&(~m[13])&(~m[17])&(~m[18])&m[11]&(m[6]^m[16]) ) ) == 0 ) ret=0;
        }
/* Pattern 5 */
        if( (m[7]==0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]!=0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[7])&(~m[11])&(~m[13])&(~m[16])&(~m[18])&m[17] ) ) == 0 ) ret=0;
        }
/* Pattern 6 */
        if( (m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]!=0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[7])&(~m[8])&(~m[11])&(~m[17])&(~m[18])&m[13] ) ) == 0 ) ret=0;
        }
/* Pattern 7 */
        if( (m[2]!=0)&(m[6]==0)&(m[7]!=0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[17]==0) ){
            if ( ( m[12] & ~(m[2]&m[7]&(~m[6])&(~m[8])&(~m[11])&(~m[13])&(~m[17]) ) ) == 0 ) ret=0;
        }
/* Pattern 8 */
        if( (m[6]==0)&(m[7]==0)&(m[10]!=0)&(m[11]!=0)&(m[13]==0)&(m[16]==0)&(m[17]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[13])&(~m[16])&(~m[17])&m[10]&m[11] ) ) == 0 ) ret=0;
        }
    }

/********* Syukutai 8renketu *********/
    if(morphic==3){
/* Pattern 1 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]!=0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[13])&(~m[16])&(~m[17])&m[18] ) ) == 0 ) ret=0;
        }
/* Pattern 2 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[16]!=0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[13])&(~m[17])&(~m[18])&m[16] ) ) == 0 ) ret=0;
        }
/* Pattern 3 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]!=0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[13])&(~m[16])&(~m[18])&m[17] ) ) == 0 ) ret=0;
        }
/* Pattern 4 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]!=0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&(~m[11])&(~m[16])&(~m[17])&(~m[18])&m[13] ) ) == 0 ) ret=0;
        }
/* Pattern 5 */
        if( (m[6]!=0)&(m[7]==0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~(m[6]&(~m[7])&(~m[8])&(~m[11])&(~m[13])&(~m[16])&(~m[17])&(~m[18])&(m[0]|m[1]|m[2]|m[5]|m[10]) ) ) == 0 ) ret=0;
        }
/* Pattern 6 */
        if( (m[6]==0)&(m[7]==0)&(m[8]!=0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&m[8]&(~m[11])&(~m[13])&(~m[16])&(~m[17])&(~m[18])&(m[2]|m[3]|m[4]|m[9]|m[14]) ) ) == 0 ) ret=0;
        }
/* Pattern 7 */
        if( (m[6]==0)&(m[7]!=0)&(m[8]==0)&(m[11]==0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&m[7]&(~m[8])&(~m[11])&(~m[13])&(~m[16])&(~m[17])&(~m[18])&(m[1]|m[2]|m[3]) ) ) == 0 ) ret=0;
        }
/* Pattern 8 */
        if( (m[6]==0)&(m[7]==0)&(m[8]==0)&(m[11]!=0)&(m[13]==0)&(m[16]==0)&(m[17]==0)&(m[18]==0) ){
            if ( ( m[12] & ~((~m[6])&(~m[7])&(~m[8])&m[11]&(~m[13])&(~m[16])&(~m[17])&(~m[18])&(m[5]|m[10]|m[15]) ) ) == 0 ) ret=0;
        }
    }

    return(ret);
}


