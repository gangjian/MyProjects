/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG2_0111.c                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"

static int64 IMG_ADD32(int f, int g);
static int64 IMG_SUB32(int f, int g);
static int64 IMG_MUL32(int f, int g);
static int64 IMG_DIV32(int f, int g);
static int64 IMG_MOD32(int f, int g);


/******************************************************************************/
/* IMG2_0111                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/17   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/
int IMG2_0111(){
	unsigned int xlng, ylng;
	unsigned int widthcnt, heightcnt;
	int *souraL_id = plLM0;
	int *sourbL_id = plLM1;
	int souraL, sourbL;
	int64 result_64;
	int64 result[LINE_SIZE];
	unsigned char subfun;
	int nosatur32bpp, shifto, shifta, shiftb;
	int dest_dt, pfdst;
	
	nosatur32bpp = (IMPREG_IPFUN2_READ() >> 14) & 0x00000001;
	shifto		 = (IMPREG_PFFTAMSK_READ() >> 16) & 0x0000003F;
	shiftb		 = (IMPREG_PFFTAMSK_READ() >> 8) & 0x0000001F;
	shifta		 = IMPREG_PFFTAMSK_READ() & 0x0000001F;
	subfun		 = (char)((IMPREG_IPFUN_READ()>>24) & 0x0000000f);
	xlng		 = IMPREG_APLNG_READ() & 0x00003fff;
	ylng		 = (IMPREG_APLNG_READ() >>16) & 0x00003fff;
	subfun		 = (char)((IMPREG_IPFUN_READ()>>24) & 0x0000000f);
	dest_dt      = ((IMPREG_IPFUN_READ() >> 16) & 0x0003);
	pfdst        = ((IMPREG_APCFG_READ()>>16) & 0x0007);
	
	heightcnt = 0;
	
	/* roop y-direction */
	while(heightcnt<ylng) {
		widthcnt = 0;
		/* read by 1 line data */
	    Read1LineSrcL0(heightcnt, souraL_id);
	    Read1LineSrcL1(heightcnt, sourbL_id);
		
		/* write by 1line data to the Dst file */
		while(widthcnt<xlng) {
			souraL = souraL_id[widthcnt] << shifta;
			sourbL = sourbL_id[widthcnt] >> shiftb;
			/* select the kind of arithmetic process */
			switch(subfun) {
				case 0:	/* srcA + srcB */
					result_64 = IMG_ADD32(souraL, sourbL);
					break;
				case 1:	/* srcA - srcB */
					result_64 = IMG_SUB32(souraL, sourbL);
					break;
				case 3:	/* srcA * srcB */
					result_64 = IMG_MUL32(souraL, sourbL);
					break;
				case 10:	/* srcA / srcB) */
					result_64 = IMG_DIV32(souraL, sourbL);
					break;
				case 11:	/* srcA % srcB) */
					result_64 = IMG_MOD32(souraL, sourbL);
					break;
				default:	/* error */
					return -1;
					break;
			}
			
			result_64 = result_64 >> shifto;
			
			/* HW special specification */
			/* signed 64bit data -> signed 37bit data. */
			if (result_64 & (int64)0x0000001000000000LL) {
				result_64 = result_64 | (int64)0xFFFFFFE000000000LL;
			} else {
				result_64 = result_64 & (int64)0x0000001FFFFFFFFFLL;
			}
			
			/* The saturation in signed 32bit data. */
			if (!nosatur32bpp) {
				if (result_64 >= (int64)0x000000007FFFFFFFLL) {
					result_64 = (int64)0x000000007FFFFFFFLL;
				}
				else if (result_64 <= (int64)0xFFFFFFFF80000000LL) {
					result_64 = (int64)0xFFFFFFFF80000000LL;
				}
			}
#if 0
			if (!nosatur32bpp) {
				if (pfdst == 1) { // 8bpp
					if (dest_dt == 0) { // signed
						if (result_64 >= (int64)0x000000000000007FLL) {
							result_64 = (int64)0x000000000000007FLL;
						} else if (result_64 <= (int64)0xFFFFFFFFFFFFFF80LL) {
							result_64 = (int64)0xFFFFFFFFFFFFFF80LL;
						}
					} else if (dest_dt == 1) { // unsigned
						if (result_64 >= (int64)0x00000000000000FFLL) {
							result_64 = (int64)0x00000000000000FFLL;
 						} else if (result_64 <= 0) {
							result_64 = 0;
						}
					} else { // error
						SIMLOG(SL_LS, SL_L4, " 32bpp format error!!! APCFG = 0x%08x  IPFUN = 0x%08x???\n",IMPREG_APCFG_READ(), IMPREG_IPFUN_READ());
						return -2;
					}
				} else if (pfdst == 2) { // 16bpp
					if (result_64 >= (int64)0x0000000000007FFFLL) {
						result_64 = (int64)0x0000000000007FFFLL;
					} else if (result_64 <= (int64)0xFFFFFFFFFFFF8000LL) {
						result_64 = (int64)0xFFFFFFFFFFFF8000LL;
					}
				} else if (pfdst == 3) { // 32bpp
					if (result_64 >= (int64)0x000000007FFFFFFFLL) {
						result_64 = (int64)0x000000007FFFFFFFLL;
					} else if (result_64 <= (int64)0xFFFFFFFF80000000LL) {
						result_64 = (int64)0xFFFFFFFF80000000LL;
					}
				} else { // error
					SIMLOG(SL_LS, SL_L4, " 32bpp format error!!! APCFG = 0x%08x???  IPFUN = 0x%08x\n",IMPREG_APCFG_READ(), IMPREG_IPFUN_READ());
					return -3;
				}
			}
#endif
	
			result[widthcnt] = result_64;
			widthcnt++;
		}
		
		/* write Dst data */
        Write1LineDst(heightcnt, result);
		heightcnt++;
	}
	return 0;
}


static int64 IMG_ADD32(int f, int g)
{
	return (int64)f + (int64)g;
}


static int64 IMG_SUB32(int f, int g)
{
	return (int64)f - (int64)g;
}


static int64 IMG_MUL32(int f, int g)
{
	return (int64)f * (int64)g;
}


static int64 IMG_DIV32(int f, int g)
{
	/* HW special specification */
	/* The denominator is set to signed 16bit data. */
	g = (g << 16) >> 16;
	
	/* HW special specification in case to be divided by zoro */
	if (g == 0) {
		if ( f >= 0) {
			return (int64)0x000000007FFFFFFFLL;
		} else {
			return (int64)0xFFFFFFFF80000000LL;
		}
	}
	
	/* HW special specification in case of 0x80000000 / -1 */
	else if ((f == (int)0x80000000) && (g == (int)0xFFFFFFFF)) {
		return (int64)0xFFFFFFFF80000000LL;
	}
	
	return (int64)f / (int64)g;
}


static int64 IMG_MOD32(int f, int g)
{
	/* HW special specification */
	/* The denominator is set to signed 16bit data. */
	g = (g << 16) >> 16;
	
	/* HW special specification in case to be divided by zoro */
	if (g == 0) {
		return (int64) ((f << 16) >> 16);
	}
	
	/* HW special specification in case of 0x80000000 % -1 */
	else if ((f == (int)0x80000000) && (g == (int)0xFFFFFFFF)) {
		return 0;
	}
	
#if 0
	if ((f % g) != (f - (f/g) * g)) {
		SIMLOG(SL_LS, SL_L4, "  Error!!! f = 0x%08x    g = 0x%08x\n", f, g);
		SIMLOG(SL_LS, SL_L4, "  Error!!! (f % g)         = 0x%08x\n", (f % g));
		SIMLOG(SL_LS, SL_L4, "  Error!!! (f - (f/g) * g) = 0x%08x\n", (f - (f/g) * g));
	}
#endif
	
	return (int64)f % (int64)g;
}


