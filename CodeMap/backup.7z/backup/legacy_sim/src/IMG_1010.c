/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_1010.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"

static short IMG_LabelingCheck(short m[], int *cnt, int *max, int *min);


/******************************************************************************/
/* IMG_1010                                                                   */
/*       Labeling                                                             */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
int IMG_1010(){
    long xlng, ylng, Heightcnt;
    int i, conect, mdlab, lb_im, labelcnt, max, min, Wpt;
    short m[11];
	short *sour_lb = psLM6;
	short *sour_id = psLM7;
	int64 result[LINE_SIZE];
	int64 result2[LINE_SIZE];

    conect = (((IMPREG_IPFUN_READ())>>24) & 0x0001); /* 0:4renketu,1:8renketu */
    if((conect>1)||(conect<0)){
        SIMLOG(SL_LS, SL_L4, "Error conect=%d\n",conect);
        return(-1);
    }
    mdlab = (((IMPREG_IPFUN_READ())>>7) & 0x0001); /* 0:ShinLabel,1:KariLabel */
    if((mdlab>1)||(mdlab<0)){
        SIMLOG(SL_LS, SL_L4, "Error mdlab=%d\n",mdlab);
        return(-1);
    }
    lb_im = (((IMPREG_IPFUN_READ())>>27) & 0x0001); /* 0:HM,1:IM */
    if((lb_im>1)||(lb_im<0)){
        SIMLOG(SL_LS, SL_L4, "Error lb_im=%d\n",lb_im);
        return(-1);
    }

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
    labelcnt = Heightcnt = 0;
    Wpt = 0;
    IMPREG_LABCNT_WRITE( 0);

    /* First Line */
        for(i=0;i<LINE_SIZE;i++){
            sour_lb[i] = 0;
        }
        WriteLM0(0,sour_lb,xlng);
	
    /* All Line loop */
        while(Heightcnt < ylng){
    /* 1Line */
            Read1LineSrc0(Heightcnt, sour_id);
            m[0] = 0;
            m[1] = ReadLM0(0);
            m[2] = ReadLM0(1);
            m[3] = ReadLM0(2);
            m[4] = ReadLM0(3);
            m[5] = ReadLM0(4);
            m[6] = 0;
            m[7] = sour_id[0];
            m[8] = sour_id[1];
            m[9] = sour_id[2];
            m[10] = sour_id[3];

            if((lb_im)&&(lb_im)) Wpt = 0;
            memset(result, 0, LINE_SIZE * sizeof(int64));
            memset(result2, 0, LINE_SIZE * sizeof(int64));

            for(i=0;i<xlng;i++){
/* LabelCreateMask */
                sour_id[i] = m[7] = IMG_LabelingCheck(m, &labelcnt, &max, &min);
/* Write to IM or HM */
//start, temperory for Issue #56159            	
#if 0
            	if((min)&&(mdlab)){
                    if(lb_im){ /* IM */
                        result[Wpt  ] = (int64)min;
                        result[Wpt+1] = (int64)max;
                        Wpt=Wpt+2;
                    }else{ /* HM */
                        result[i] = (int64)min;
                        result2[i] = (int64)max;
                    }
                }
                if(mdlab==0){
#endif
                if (mdlab)
                {//KariLabel
                	if((((IMPREG_HPCMD_READ())>>15) & 0x00000001) == 0)
                	{//Check HPCMD.wmsk, HPCMD.wmsk==1:calculating area for kari-labeling
                		if (m[7] != 0)
                		{
							if(lb_im)
							{ /* IM */
							//IM is not used by IMPLIB. If IMPLIB use IM case, need to add related handling here.
							}
							else
							{ /* HM */
								result[i] = (int64)m[7];
								result2[i] = (int64)m[7];
							}
                		}
                	}
                	else if(min)
                	{//Check HPCMD.wmsk, HPCMD.wmsk==0:kari-labeling
						if(lb_im){ /* IM */
							result[Wpt  ] = (int64)min;
							result[Wpt+1] = (int64)max;
							Wpt=Wpt+2;
						}else{ /* HM */
							result[i] = (int64)min;
							result2[i] = (int64)max;
						}
                	}
                }
                else
                {//ShinLabel
                    result[i] = (int64)sour_id[i];
//start, temperory for Issue #56163
#if 0
                    result[i] = (int64)(*(pCM0[IMP_WORK_CH]+(result[i])));
#endif
                    result[i] = (int64)(*(pCM0[IMP_WORK_CH]+4*(result[i])));//accessed by 4 bytes
//end, temperory for Issue #56163
                }
//end, temperory for Issue #56159
                m[0] = m[1];
                m[1] = m[2];
                m[2] = m[3];
                m[3] = m[4];
                m[4] = m[5];
                m[5] = (short)((i+5<xlng) ? ReadLM0(i+5): 0);
                m[6] = m[7];
                m[7] = m[8];
                m[8] = m[9];
                m[9] = m[10];
                m[10] = (short)((i+4<xlng) ? sour_id[i+4]: 0);

            }

/* ShinLabel */
            if(mdlab==0){
                Write1LineDst(Heightcnt, result);
            }
/* KariLabel & IM */
            else if((mdlab==1)&&(lb_im==1)){
                result[Wpt] = 0;
                Write1LineDst(Heightcnt, result);
            }
/* KariLabel & HM */
            else{
                Write1LineDst(Heightcnt, result);
                Write1LineDest2(Heightcnt, result2);
            }

            WriteLM0(0,sour_id,xlng);
        /* Next Line */
            Heightcnt++;

        }

        if(mdlab==1) IMPREG_LABCNT_WRITE( labelcnt);

    return(0);
}


/******************************************************************************/
/* IMG_1010                                                                   */
/*       IMG_LabelingCheck                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
static short IMG_LabelingCheck(short m[], int *cnt, int *max, int *min){
    int conect;

    conect = (((IMPREG_IPFUN_READ())>>24) & 0x0001); /* 0:4renketu,1:8renketu */
    *max = *min = 0;

    if(conect==0){ /* 4renketu */
/* Code0 */
        if(m[7]==0) return(0);
/* Code1 */
        if( (m[0]==0)&&(m[1]!=0)&&(m[6]!=0) ){
            if(m[1] < m[6]){
                *max = m[6]; *min = m[1];
            }else if(m[1] > m[6]){
                *max = m[1]; *min = m[6];
            }else{
                return(m[6]);
            }
            return((short)*min);
        }
/* Code2 */
        if( (m[6]!=0) ) return( m[6]);
/* Code3 */
        if( (m[1]!=0)&&(m[6]==0) ) return(m[1]);
/* Code4 */
        if( (m[2]!=0)&&(m[6]==0)&&(Get8b(m[8])!=0) ) return(m[2]);
/* Code5 */
        if( (m[3]!=0)&&(m[6]==0)&&(Get8b(m[8])!=0)&&(Get8b(m[9])!=0) ) return(m[3]);
/* Code6 */
        if( (m[4]!=0)&&(m[6]==0)&&(Get8b(m[8])!=0)&&(Get8b(m[9])!=0)&&(Get8b(m[10])!=0) ) return(m[4]);
/* Code7 */
        if( (m[1]==0)&&(m[6]==0) ){
            (*cnt)++;
            if( (*cnt)>LABELINGMAX ){
                (*cnt)=LABELINGMAX;
            }
            return((short)*cnt);
        }
    }else{ /* 8renketu */
/* Code0 */
        if(m[7]==0) return(0);
/* Code1 */
        if( (m[1]==0)&&(m[2]!=0)&&(m[6]!=0) ){
            if(m[2] < m[6]){
                *max = m[6]; *min = m[2];
            }else if(m[2] > m[6]){
                *max = m[2]; *min = m[6];
            }else{
                return(m[6]);
            }
            return((short)*min);
        }
/* Code2 */
        if( (m[0]!=0)&&(m[6]!=0) ) return( (short)((m[0] < m[6]) ? m[0] : m[6]));
/* Code3 */
        if( (m[1]!=0)&&(m[6]!=0) ) return( (short)((m[1] < m[6]) ? m[1] : m[6]));
/* Code4 */
        if( (m[6]!=0) ) return( m[6]);
/* Code5 */
        if( (m[0]!=0)&&(m[1]==0)&&(m[2]!=0)&&(m[6]==0) ){
            if(m[0] < m[2]){
                *max = m[2]; *min = m[0];
            }else if(m[0] > m[2]){
                *max = m[0]; *min = m[2];
            }else{
                return(m[0]);
            }
            return((short)*min);
        }
/* Code6 */
        if( (m[0]!=0)&&(m[6]==0) ) return(m[0]);
/* Code7 */
        if( (m[1]!=0)&&(m[6]==0) ) return(m[1]);
/* Code8 */
        if( (m[2]!=0)&&(m[6]==0) ) return(m[2]);
/* Code9 */
        if( (m[3]!=0)&&(m[6]==0)&&(Get8b(m[8])!=0) ) return(m[3]);
/* Code10 */
        if( (m[4]!=0)&&(m[6]==0)&&(Get8b(m[8])!=0)&&(Get8b(m[9])!=0) ) return(m[4]);
/* Code11 */
        if( (m[5]!=0)&&(m[6]==0)&&(Get8b(m[8])!=0)&&(Get8b(m[9])!=0)&&(Get8b(m[10])!=0) ) return(m[5]);
/* Code12 */
        if( (m[0]==0)&&(m[1]==0)&&(m[2]==0)&&(m[6]==0) ){
            (*cnt)++;
            if( (*cnt)>LABELINGMAX ){
                (*cnt)=LABELINGMAX;
            }
            return((short)*cnt);
        }
    }

    return(0);
}

