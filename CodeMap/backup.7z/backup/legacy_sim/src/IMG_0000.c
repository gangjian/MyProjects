/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0000.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/19 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "impsim_int.h"
#include "legacy_sim.h"

static int64 IMG_THROUH(short f);				  //no operation	     0000
static int64 IMG_CONST(short constant);   //constant             0001
static int64 IMG_ADDcnst(short f, short constant); //constant addition 	 0010
static int64 IMG_SUBcnst(short f, short constant); //constant subtraction 0011
static int64 IMG_MINcnst(short f, short constant); //output minimum value 0100
static int64 IMG_MAXcnst(short f, short constant); //output maximum value 0101


#define get_consta(consta) {/*get consta bit*/\
	consta= (short)((IMPREG_CNST_READ()>>16) & 0x000000ff);\
	if(IMPREG_CNST_READ() & 0x01000000) consta |= 0xff00;\
}
#define get_consta16(consta) {/*get consta bit*/\
	consta= (short)((IMPREG_CNST_READ()>>16) & 0x0000ffff);\
}

/******************************************************************************/
/* IMG_0000  (image tranceform�j                                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/19 T.Sato                                               */
/******************************************************************************/
int IMG_0000(){
    unsigned long xlng, ylng;
    unsigned int Widthcnt, Heightcnt, subfun;
	short *soura_id = psLM0;
	int64 result[LINE_SIZE];
	short consta;
    int datatype;

    datatype = ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
    if((IMPREG_IPFORM_READ() >> 16) & 0x0007){
        datatype = ((IMPREG_IPFORM_READ() >> 16) & 0x0007) + 4;
    }

    if(datatype!=6){
  	    get_consta(consta)//get constant
    }else{
  	    get_consta16(consta)//get constant 16bpp
    }

	xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (McomFlg) ? 1 : (((IMPREG_APLNG_READ())>>16) & 0x3fff);

	subfun = (((IMPREG_IPFUN_READ())>>24) & 0x0000000f);//get subfun bit 


#ifdef DEBUG_OUTPUT
	ResetDebugGamen();
#endif

    Heightcnt = 0;

// All Line loop 
    while(Heightcnt < ylng)
	{
		if(subfun != 1) {
			if(McomFlg) {
				Read1LineLM256A(Heightcnt, soura_id);
			} else {
				Read1LineSrc0(Heightcnt, soura_id);
			}
		}
		
		Widthcnt = 0;
		
		while(Widthcnt < xlng)
		{
			switch(subfun)//branch subfun bit
			{
				case 0:	//no operation
					result[Widthcnt] = IMG_THROUH(soura_id[Widthcnt]);
					break;
				case 1:	//constant
					result[Widthcnt] = IMG_CONST(consta);
					break;
				case 2:	//constant addition 
					result[Widthcnt] = IMG_ADDcnst(soura_id[Widthcnt],consta);
					break;
				case 3:	//constant subtraction 
					result[Widthcnt] = IMG_SUBcnst(soura_id[Widthcnt],consta);
					break;
				case 4:	//output minimum value
					result[Widthcnt] = IMG_MINcnst(soura_id[Widthcnt],consta);
					break;
				case 5:	//output maximum value 
					result[Widthcnt] = IMG_MAXcnst(soura_id[Widthcnt],consta);
					break;
				default:
					SIMLOG(SL_LS, SL_ERR, "subfun=%x, besides reserved bit!\n", subfun);
					Legacy_assert_error();
					break;
		    }
            Widthcnt++;

        }
// Next Line
#ifdef DEBUG_OUTPUT
		DebugOutputGamen(result,3,xlng);
#endif
        Write1LineDst(Heightcnt, result);
        Heightcnt++;
    }
    return(0);
}
/******************************************************************************/
/* IMG_THROUH (no operation / subfun:0000)                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18  T.Kumabe                                            */
/******************************************************************************/
int64 IMG_THROUH(short f)
{
	return (int64)f;
}

/******************************************************************************/
/* IMG_CONST (constant / subfun:0001)                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18   T.Kumabe                                           */
/******************************************************************************/
int64 IMG_CONST(short constant)
{	
	return (int64)constant;
}

/******************************************************************************/
/* IMG_ADDcnst (constant addition / subfun:0010)                              */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18  T.Kumabe                                            */
/******************************************************************************/
int64 IMG_ADDcnst(short f, short constant)
{
	return (int64)(f+constant);
}

/******************************************************************************/
/* IMG_SUBcnst (constant subtraction / subfun:0011)                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18   T.Kumabe                                           */
/******************************************************************************/
int64 IMG_SUBcnst(short f, short constant)
{
	return (int64)(f-constant);
}

/******************************************************************************/
/* IMG_MINcnst (output minimum value / subfun:0100)                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18   T.Kumabe                                           */
/******************************************************************************/
int64 IMG_MINcnst(short f, short constant)
{
	return (int64)MIN(f,constant);
}

/******************************************************************************/
/* IMG_MAXcnst (output maximum value / subfun:0101)                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/18  T.Kumabe                                            */
/******************************************************************************/
int64 IMG_MAXcnst(short f, short constant)
{
	return (int64)MAX(f,constant);
}

//subfun 0110,0111:reserved bit
