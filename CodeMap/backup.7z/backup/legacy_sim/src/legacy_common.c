/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_common.c                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New                                                */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif

#include "impsim_int.h"
#include "legacy_sim.h"
#include "legacy_sim_prot.h"

/******************************************************************************/
/* is_imp_working                                                             */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
bool is_imp_working() {
    // To be filled.
    return FALSE;
}

/******************************************************************************/
/* write_reg                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int write_reg(int ch, uint32_t offset, uint32_t reg_val) {
    int cnt;
    
    for (cnt=0; cnt<REGMAX; cnt++) {
    	if ((offset & 0x0000ffff) == regtable[cnt].adr) break;
    }

    if (cnt != REGMAX) {
    	if(cnt == _HPSADCTL)
    	{/* According to HW spec, if hpx_clr is 1, need to clear g_Widthcnt and set hpx_clr to 0 */
    		if(((reg_val>>17)&0x1) == 1)
    		{
    			g_Widthcnt = 0;
    			reg_val = (reg_val & (~0x200));
    		}
    	}
     	if (regtable[cnt].regbank==0) {
	        IMPREGBNK0_WRITE_CH(ch, regtable[cnt].No, reg_val);
     	} else if (regtable[cnt].regbank==1) {
	        IMPREGBNK1_WRITE_CH(ch, regtable[cnt].No, reg_val);
     	} else {
	        IMPREGBNK2_WRITE_CH(ch, regtable[cnt].No, reg_val);
     	}
        return E_OK;
    } else {
        return E_PAR;
    }
}

/******************************************************************************/
/* read_reg                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
int read_reg(int ch, uint32_t offset, uint32_t *reg_val) {
    int cnt;
    
    for (cnt=0; cnt<REGMAX; cnt++) {
        if ((offset & 0x0000ffff) == regtable[cnt].adr) break;
    } 

    if (cnt != REGMAX) {
    	if (regtable[cnt].regbank==0) {
    		*reg_val = IMPREGBNK0_READ_CH(ch, regtable[cnt].No);
    	} else if (regtable[cnt].regbank==1) {
    		*reg_val = IMPREGBNK1_READ_CH(ch, regtable[cnt].No);
    	} else {
    		*reg_val = IMPREGBNK2_READ_CH(ch, regtable[cnt].No);
    	}
        return E_OK;
    } else {
        return E_PAR;
    }
}

/******************************************************************************/
/* reg_offset_to_name                                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
const char *reg_offset_to_name(uint32_t offset) {
    int cnt;
    for (cnt=0; cnt<REGMAX; cnt++) {
        if (regtable[cnt].adr == (offset & 0x0000ffff)) {
            return regtable[cnt].regname;
        }
    }

    return "unknown";
}
