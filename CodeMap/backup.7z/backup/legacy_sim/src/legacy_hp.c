/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_hp.c                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/02/07                                                      */
/* 01-01-00 : 2007/05/23 S.Ishikawa                                           */
/*                       changed define _get_hp_xs,_get_hp_ys                 */
/* 01-02-00 : 2007/07/10 S.Ishikawa                                           */
/*                       changed  _get_cnt 3ff->7ff                           */
/* 01-03-00 : 2007/07/30 S.Ishikawa                                           */
/*                       Mcom APLNG->IPLEN                                    */
/* 02-00-00 : 2008/03/06 S.Ishikawa                                           */
/*                       changed for SAD                                      */
/* 02-00-01 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif

#include "impsim_int.h"
#include "legacy_sim.h"

void Read1LineDest1(int Height, short *data);
void Read1LineDest2(int Height, short *data);
int GetImgAccessTypeHP(int *datatype);
    
#define _get_hpx_clr	((IMPREG_HPSADCTL_READ() >>17) & 0x00000001)

#define _get_scan_mode	((IMPREG_APCMD_READ() >>24) & 0x00000003)
#define _get_scancnt_ds	((IMPREG_APCMD_READ() >>20) & 0x00000001)
#define _get_xlng		((IMPREG_APLNG_READ()     ) & 0x00003fff)
#define _get_ylng		((IMPREG_APLNG_READ() >>16) & 0x00003fff)
#define _get_hp_xs		((IMPREG_HPWINSP_READ()     ) & 0x00001fff)
#define _get_hp_ys		((IMPREG_HPWINSP_READ() >>16) & 0x00001fff)
#define _get_hp_xlng	((IMPREG_HPWINLNG_READ()     ) & 0x00001fff)
#define _get_hp_ylng	((IMPREG_HPWINLNG_READ() >>16) & 0x00001fff)

#define _get_xlngiplen	((IMPREG_IPLEN_READ()     ) & 0x00003fff)
#define _get_ylngiplen	((IMPREG_IPLEN_READ() >>16) & 0x00003fff)

#define _get_hpen		(((IMPREG_HPCTL_READ())>>15) & 0x00000001)
#define _get_xyctl		(((IMPREG_HPCTL_READ())>>12) & 0x00000007)
#define _get_hmcnf		(((IMPREG_HPCTL_READ())>>11) & 0x00000001)
#define _get_dinsel 	(((IMPREG_HPCTL_READ())>> 8) & 0x00000007)
#define _get_soura_dt	(((IMPREG_HPCTL_READ())>> 6) & 0x00000003)
#define _get_sourb_dt	(((IMPREG_HPCTL_READ())>> 4) & 0x00000003)
#define _get_destext_dt	(((IMPREG_HPCTL_READ())>> 2) & 0x00000003)
#define _get_dest_dt	(((IMPREG_HPCTL_READ())    ) & 0x00000003)

#define _get_wmsk		(((IMPREG_HPCMD_READ())>>15) & 0x00000001)
#define _get_con		(((IMPREG_HPCMD_READ())>>14) & 0x00000001)
#define _get_asel_u		(((IMPREG_HPCMD_READ())>>12) & 0x00000003)
#define _get_asel_l		(((IMPREG_HPCMD_READ())>> 4) & 0x00000003)
#define _get_dsel_u		(((IMPREG_HPCMD_READ())>>10) & 0x00000003)
#define _get_dsel_l		(((IMPREG_HPCMD_READ())>> 2) & 0x00000003)
#define _get_fun_u		(((IMPREG_HPCMD_READ())>> 8) & 0x00000003)
#define _get_fun_l		(((IMPREG_HPCMD_READ())    ) & 0x00000003)

#define _get_cnt		(((IMPREG_HMCNT_READ())    ) & 0x000007ff)

#define _get_cntmode	(((IMPREG_HMCNT_READ())>>14) & 0x00000003)

#define _get_xsft       (((IMPREG_HPRGN_READ())    ) & 0x0000000f)
#define _get_ysft       (((IMPREG_HPRGN_READ())>> 4) & 0x0000000f)

#define _flg_hpbsy		(IMPREG_HPSTS_READ() & 0x8000)
#define _flg_ovf		(IMPREG_HPSTS_READ() & 0x0800)
#define _flg_cntovf		(IMPREG_HPSTS_READ() & 0x0400)
#define _flg_hm_u_ovf	(IMPREG_HPSTS_READ() & 0x0200)
#define _flg_hm_l_ovf	(IMPREG_HPSTS_READ() & 0x0100)

#define _set_hpbsy		{IMPREG_HPSTS_WRITE( (IMPREG_HPSTS_READ() | 0x8000));}
#define _set_ovf		{IMPREG_HPSTS_WRITE( (IMPREG_HPSTS_READ() | 0x0800));}
#define _set_cntovf		{IMPREG_HPSTS_WRITE( (IMPREG_HPSTS_READ() | 0x0400)); _set_ovf}
#define _set_hm_u_ovf	{IMPREG_HPSTS_WRITE( (IMPREG_HPSTS_READ() | 0x0200)); _set_ovf}
#define _set_hm_l_ovf	{IMPREG_HPSTS_WRITE( (IMPREG_HPSTS_READ() | 0x0100)); _set_ovf}

extern short g_sad_updata[25];
extern short g_sad_lowdata[25];

unsigned char AU[4];
int g_Widthcnt, g_HPadr;

/******************************************************************************/
/* ReadHM_U                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
short ReadHM_U(int adr)
{
    if((_get_xyctl==5)&&( (adr < 0) && (adr > (-1 * (HM_SIZE/2)-1) ) )) adr += HM_SIZE;

	if((adr < 0) || (adr > 2048))
	{
		return 0;
	}
	
    if(ENDIAN){ /* little */
        return (short)(((*(pHM[IMP_WORK_CH]+adr*4+3) << 8) & 0x0000ff00)|((*(pHM[IMP_WORK_CH]+adr*4+2)) & 0x000000ff));
    }else{ /* big */
        return (short)(((*(pHM[IMP_WORK_CH]+adr*4  ) << 8) & 0x0000ff00)|((*(pHM[IMP_WORK_CH]+adr*4+1)) & 0x000000ff));
    }
}

int ReadHM_AU(int adr)
{
    if((_get_xyctl==5)&&( (adr < 0) && (adr > (-1 * (HM_SIZE/2)-1) ) )) adr += HM_SIZE;

	if((adr < 0) || (adr > 2048))
	{
		return 0;
	}

    if(ENDIAN){ /* little */
        return (int)(((*(pHM[IMP_WORK_CH]+adr*4+3) << 24) & 0xff000000)|
        		      ((*(pHM[IMP_WORK_CH]+adr*4+2) << 16) & 0x00ff0000) |
        		      ((*(pHM[IMP_WORK_CH]+adr*4+1) << 8) & 0x0000ff00)|
        		      ((*(pHM[IMP_WORK_CH]+adr*4  )) & 0x000000ff));
    }else{ /* big */
        return (int)(((*(pHM[IMP_WORK_CH]+adr*4  ) << 24) & 0xff000000)|
        		      ((*(pHM[IMP_WORK_CH]+adr*4+1) << 16) & 0x00ff0000)|
        		      ((*(pHM[IMP_WORK_CH]+adr*4+2) << 8) & 0x0000ff00)|
        		      ((*(pHM[IMP_WORK_CH]+adr*4+3)) & 0x000000ff));
    }
}


/******************************************************************************/
/* ReadHM_L                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
short ReadHM_L(int adr)
{
    if((_get_xyctl==5)&&( (adr < 0) && (adr > (-1 * (HM_SIZE/2)-1) ) )) adr += HM_SIZE;

	if((adr < 0) || (adr > 2048))
	{
		return 0;
	}

    if(ENDIAN){ /* little */
        return (short)(((*(pHM[IMP_WORK_CH]+adr*4+1) << 8) & 0x0000ff00)|((*(pHM[IMP_WORK_CH]+adr*4  )) & 0x000000ff));
    }else{ /* big */
        return (short)(((*(pHM[IMP_WORK_CH]+adr*4+2) << 8) & 0x0000ff00)|((*(pHM[IMP_WORK_CH]+adr*4+3)) & 0x000000ff));
    }
}

/******************************************************************************/
/* WriteHM_U                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteHM_U(int adr, short data)
{
    if((_get_xyctl==5)&&( (adr < 0) && (adr > (-1 * (HM_SIZE/2)-1) ) )) adr += HM_SIZE;

	if(adr < 0 || adr*4 > HM_MEM_SIZE-4) return;

    if((_get_cntmode==0)&&(_flg_cntovf)) return;

    if(ENDIAN){ /* little */
        *(pHM[IMP_WORK_CH]+adr*4+3) = (unsigned char)((data>> 8)&0xff);
        *(pHM[IMP_WORK_CH]+adr*4+2) = (unsigned char)((data    )&0xff);
    }else{ /* big */
        *(pHM[IMP_WORK_CH]+adr*4  ) = (unsigned char)((data>> 8)&0xff);
        *(pHM[IMP_WORK_CH]+adr*4+1) = (unsigned char)((data    )&0xff);
    }
    
    return;
}

/******************************************************************************/
/* WriteHM_L                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/19 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void WriteHM_L(int adr, short data)
{
	if((_get_xyctl==5)&&( (adr < 0) && (adr > (-1 * (HM_SIZE/2)-1) ) )) adr += HM_SIZE;

    if(adr < 0 || adr*4 > HM_MEM_SIZE-4) return;

    if((_get_cntmode==0)&&(_flg_cntovf)) return;

    if(ENDIAN){ /* little */
        *(pHM[IMP_WORK_CH]+adr*4+1) = (unsigned char)((data>> 8)&0xff);
        *(pHM[IMP_WORK_CH]+adr*4  ) = (unsigned char)((data    )&0xff);
    }else{ /* big */
        *(pHM[IMP_WORK_CH]+adr*4+2) = (unsigned char)((data>> 8)&0xff);
        *(pHM[IMP_WORK_CH]+adr*4+3) = (unsigned char)((data    )&0xff);
    }

    return;
}

/******************************************************************************/
/* ReadAU_U                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/7    j.ishii                                             */
/******************************************************************************/
short ReadAU_U()
{
    if(ENDIAN){ /* little */
        return (short)(((AU[3] << 8) & 0x0000ff00)|(AU[2] & 0x000000ff));
    }else{ /* big */
        return (short)(((AU[0] << 8) & 0x0000ff00)|(AU[1] & 0x000000ff));
    }
}

/******************************************************************************/
/* ReadAU_L                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/7    j.ishii                                             */
/******************************************************************************/
short ReadAU_L()
{
    if(ENDIAN){ /* little */
        return (short)(((AU[1] << 8) & 0x0000ff00)|(AU[0] & 0x000000ff));
    }else{ /* big */
        return (short)(((AU[2] << 8) & 0x0000ff00)|(AU[3] & 0x000000ff));
    }
}

/******************************************************************************/
/* WriteAU_U                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/7    j.ishii                                             */
/* 01-00-01 : 2007/3/7    s.ishikawa                                          */
/* 01-01-00 : 2007/5/31   s.ishikawa                                          */
/* 01-01-01 : 2007/6/4    s.ishikawa                                          */
/******************************************************************************/
void WriteAU_U(short Ain,short Bin,short carry)
{
	long data, work, work2;
	
	switch(_get_fun_u)
	{
	case 0:	/* Ain through */
		data = Ain;
		break;
	case 1:	/* Bin(HM) + Ain */
        if((_get_dsel_u == 1) && ( ((_get_dinsel==0)&&(_get_dest_dt==0))||((_get_dinsel==2)&&(_get_soura_dt==0))||
            ((_get_dinsel==6)&&(_get_soura_dt==0))||((_get_dinsel==7)&&(_get_sourb_dt==0)) ))
        {
            work = Bin;
            work2 = Ain;
            data = work + work2 + carry;
            if(_get_con)
            {

            }
            else
            {
				if((data > 32767) || (data < -32768))
				{
					data = Bin;
				}
            }
        }
        else
        {
            if(Bin<0) work = Bin + 65536;
            else work = Bin;
            if(Ain<0) work2 = Ain + 65536;
            else work2 = Ain;

            data = work + work2 + carry;
            if(data>=65536)
            {
            	data = Bin;
            }
        }
		break;
	case 2:	/* Min( Bin(HM)�Ain ) */
        data = MIN(Bin,Ain) + carry;
		break;
	case 3: /* Max( Bin(HM)�Ain ) */
		data = MAX(Bin,Ain) + carry;
		break;
	default:
		return;
	}

	if(ENDIAN){ /* little */
		AU[3] = (unsigned char)((data>> 8)&0xff);
		AU[2] = (unsigned char)((data    )&0xff);
	}else{ /* big */
		AU[0] = (unsigned char)((data>> 8)&0xff);
		AU[1] = (unsigned char)((data    )&0xff);
	}
    
    return;
}

/******************************************************************************/
/* WriteAU_L                                                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/7    j.ishii                                             */
/* 01-00-01 : 2007/3/7    s.ishikawa                                          */
/* 01-01-00 : 2007/5/31   s.ishikawa                                          */
/* 01-01-01 : 2007/6/4    s.ishikawa                                          */
/******************************************************************************/
void WriteAU_L(short Ain,short Bin,int Bin_all,short *carry)
{
	int work;
	long data, work2;
	double data_cal;
	unsigned short a, b;
	*carry = 0;
	
	switch(_get_fun_l)
	{
	case 0:	/* Ain through */
		data = Ain;
		break;
	case 1:	/* Bin(HM) + Ain */
		if((_get_con==1) && (_get_dsel_l == 1) && ( ((_get_dinsel==0)&&(_get_dest_dt==0))||((_get_dinsel==2)&&(_get_soura_dt==0))||
			((_get_dinsel==6)&&(_get_soura_dt==0))||((_get_dinsel==7)&&(_get_sourb_dt==0)) ))
		{
           	data_cal = (double)Bin_all + (double)Ain;
            if((data_cal >= 0x7fffffff) ||
               ((data_cal + 1) < -2147483647))
            {
            	_set_hm_u_ovf;
            	data = Bin;
            	break;
            }
			if(Bin_all<0)
			{
				work = Bin + 65536;
			}
			else
			{
				work = (unsigned short)Bin;
			}
			work2 = Ain;

			data = work + work2;

			a = ((int)data_cal >> 16) & 0xffff;
			b = (Bin_all & 0xffff0000) >> 16;
			*carry = a - b;
        }
        else if((_get_con==0) && (_get_dsel_l == 1) && ( ((_get_dinsel==0)&&(_get_dest_dt==0))||((_get_dinsel==2)&&(_get_soura_dt==0))||
            ((_get_dinsel==6)&&(_get_soura_dt==0))||((_get_dinsel==7)&&(_get_sourb_dt==0)) )){
            work = Bin;
            work2 = Ain;

            data = work + work2;
			if((data > 32767) || (data < -32768))
			{
				_set_hm_l_ovf;
				data = Bin;
			}
        }else{
            work = (unsigned short)Bin;
            work2 = (unsigned short)Ain;
            data = work + work2;
            if(!(_get_con)&&(data>=65536))
            {
            	_set_hm_l_ovf;
            	data = Bin;
            }
            if(_get_con)
        	{
                *carry = (short)((data & 0xffff0000) >> 16);
        	}
        }

		break;
	case 2:	/* Min( Bin(HM)�Ain ) */
		data = MIN(Bin,Ain);
		break;
	case 3: /* Max( Bin(HM)�Ain ) */
		data = MAX(Bin,Ain);
		break;
	default:
		return;
	}

	if(ENDIAN){ /* little */
		AU[1] = (unsigned char)((data>> 8)&0xff);
		AU[0] = (unsigned char)((data    )&0xff);
	}else{ /* big */
		AU[2] = (unsigned char)((data>> 8)&0xff);
		AU[3] = (unsigned char)((data    )&0xff);
	}
	
    return;
}

/******************************************************************************/
/* Read1LineSrc0HP                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/02/13  j.ishii                                             */
/* 01-00-01 : 2007/02/23  s.ishikawa                                          */
/* 01-02-00 : 2007/06/19  s.ishikawa                                          */
/*                        16bpp                                               */
/* 01-02-01 : 2007/06/27 S.Ishikawa                                           */
/*                       Labeling Max 0x03ff->0x0fff                          */
/* 01-03-00 : 2007/07/30 S.Ishikawa                                           */
/*                       Mcom APLNG->IPLEN                                    */
/* 01-03-01 : 2007/08/02 S.Ishikawa                                           */
/*                       warning                                              */
/* 01-05-00 : 2007/09/06 S.Ishikawa                                           */
/*                       Changed xlng, ylng                                   */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void Read1LineSrc0HP(int Height, short *data){
    unsigned long xlng, ylng, apsize;
    unsigned int i;
    int datatype;

    if(McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001)) ){
        xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
        ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
    }else{
        xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
        ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
    }

    datatype = 0; // Specify source A/0
    GetImgAccessTypeHP(&datatype);
    if (datatype == 9) {
        SIMLOG(SL_LS, SL_ERR, "ERROR, 2*8bpp/pixel is specified in HP source A/1.\n");
        Legacy_assert_error();
    }
        
/* 1Line Read */
    for(i=0;i<xlng;i++){
    	apsize = IMPREG_APSIZE_SA_READ();
    	if (6 == datatype)
    	{
    		*(data + i) = *(unsigned short *)(pSrc0 + (IMPREG_APSASP_READ() - SASP) + i * 2 + IMPREG_APSIZE_SA_READ() * Height);
    	}
    	else
    	{
    		*(data + i) = *(pSrc0 + (IMPREG_APSASP_READ() - SASP) + i + IMPREG_APSIZE_SA_READ() * Height);
    	}
        if(datatype==0){ /* signed8 */
            if(*(data + i)&0x80) *(data + i) = (short)(*(data + i) | 0xff00);
            else *(data + i) = (short)(*(data + i) & 0xff);
        }else if(datatype==1){ /* unsigned8/label */
            *(data + i) = (short)(*(data + i) & 0xff);
        }else if(datatype==2){ /* binary */
            if(*(data + i)&0x80) *(data + i) = 1;
            else *(data + i) = 0;
        }else if(datatype==3){ /* kari label */
            *(data + i) = (short)(*(data + i) & LABELINGMAX);
        }else if(datatype==6){ /* 16bpp */
            *(data + i) = (short)(*(data + i) & 0xffff);
        }
    }

    return;
}

/******************************************************************************/
/* Read1LineSrc1HP                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/02/13  j.ishii                                             */
/* 01-00-01 : 2007/02/23  s.ishikawa                                          */
/* 01-02-00 : 2007/06/19  s.ishikawa                                          */
/*                        16bpp                                               */
/* 01-02-01 : 2007/06/27 S.Ishikawa                                           */
/*                       Labeling Max 0x03ff->0x0fff                          */
/* 01-03-00 : 2007/07/30 S.Ishikawa                                           */
/*                       Mcom APLNG->IPLEN                                    */
/* 01-03-01 : 2007/08/02 S.Ishikawa                                           */
/*                       warning                                              */
/* 01-05-00 : 2007/09/06 S.Ishikawa                                           */
/*                       Changed xlng, ylng                                   */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void Read1LineSrc1HP(int Height, short *data){
    unsigned long xlng, ylng;
    unsigned int i;
    int datatype, acscnt_sb;

    acscnt_sb =  ((IMPREG_APCMD_READ() >> 18) & 0x0001);
    if(McomFlg || ((((IMPREG_IPLEN_READ())>>31) & 0x0001)) ){
        xlng = ((IMPREG_IPLEN_READ()) & 0x3fff);
        ylng = (((IMPREG_IPLEN_READ())>>16) & 0x3fff);
    }else{
        xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
        ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);
    }

    datatype = 1; // Specify source B/1
    GetImgAccessTypeHP(&datatype);
    if (datatype == 9) {
        SIMLOG(SL_LS, SL_ERR, "ERROR, 2*8bpp/pixel is specified in HP source B/1.\n");
    }

    for(i=0;i<xlng;i++){
    	if(acscnt_sb == 0)
    	{
    		*(data + i) = 0;
    	}
    	else
    	{
    		if (6 == datatype)
    		{
    			*(data + i) = *(pSrc1 + (IMPREG_APSBSP_READ() - SBSP) + i * 2 + IMPREG_APSIZE_SB_READ() * Height);
    		}
    		else
    		{
    			*(data + i) = *(pSrc1 + (IMPREG_APSBSP_READ() - SBSP) + i + IMPREG_APSIZE_SB_READ() * Height);
    		}
			if(datatype==0){ /* signed8 */
				if(*(data + i)&0x80) *(data + i) = (short)(*(data + i) | 0xff00);
				else *(data + i) = (short)(*(data + i) & 0xff);
			}else if(datatype==1){ /* unsigned8/label */
				*(data + i) = (short)(*(data + i) & 0xff);
			}else if(datatype==2){ /* binary */
				if(*(data + i)&0x80) *(data + i) = 1;
				else *(data + i) = 0;
			}else if(datatype==3){ /* kari label */
				*(data + i) = (short)(*(data + i) & LABELINGMAX);
			}else  if(datatype==6){ /* 16bpp */
				*(data + i) = (short)(*(data + i) & 0xffff);
			}
    	}
    }

    return;
}

/******************************************************************************/
/* TrunsXY                                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/8    j.ishii                                             */
/* 01-01-00 : 2007/05/24  S.Ishikawa                                          */
/*                        Add 'break' case 2                                  */
/* 01-03-00 : 2007/08/02 S.Ishikawa                                           */
/*                       warning                                              */
/* 01-03-01 : 2007/08/07 S.Ishikawa                                           */
/*                       long 0xffff6000 -> int64 0xffffffffffff6000          */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void TrunsXY(short x,short y,short *trns_x,short *trns_y)
{
//	long const_a,const_b,const_c,const_d;
	int64 const_a,const_b,const_c,const_d;

	switch(_get_xyctl)
	{
	case 0:
		*trns_x = x;
		*trns_y = y;
		break;
	case 1:
		*trns_x = (short)((x * x) & 0xffff);
		*trns_y = (short)(((x * x)>>16) & 0x1fff);
		break;
	case 2:
		*trns_x = (short)((y * y) & 0xffff);
		*trns_y = (short)(((y * y)>>16) & 0x1fff);
        break;
	case 3:
		*trns_x = (short)((x * y) & 0xffff);
		*trns_y = (short)(((x * y)>>16) & 0x1fff);
		break;
	case 4:
		*trns_x = x;
		*trns_y = y;
		break;
	case 5:
		const_a = ((IMPREG_HPWINSP_READ() >>16) & 0x9fff);
		const_b = ((IMPREG_HPWINSP_READ()     ) & 0x9fff);
		const_c = ((IMPREG_HPWINLNG_READ() >>16) & 0x9fff);
		const_d = ((IMPREG_HPWINLNG_READ()     ) & 0x9fff);

		if(const_a & 0x8000) const_a |= 0xffffffffffff6000;
		if(const_b & 0x8000) const_b |= 0xffffffffffff6000;
		if(const_c & 0x8000) const_c |= 0xffffffffffff6000;
		if(const_d & 0x8000) const_d |= 0xffffffffffff6000;

		*trns_x = (short)((x * const_b + y * const_a)>>10);
		*trns_y = (short)((x * const_d + y * const_c)>>10);

		break;
	case 6:
		const_a = ((IMPREG_HPWINSP_READ() >>16) & 0x9fff);
		const_b = ((IMPREG_HPWINSP_READ()     ) & 0x9fff);
		const_c = ((IMPREG_HPWINLNG_READ() >>16) & 0x9fff);
		const_d = ((IMPREG_HPWINLNG_READ()     ) & 0x9fff);

		if(const_a & 0x8000) const_a |= 0xffffffffffff6000;
		if(const_b & 0x8000) const_b |= 0xffffffffffff6000;
		if(const_c & 0x8000) const_c |= 0xffffffffffff6000;
		if(const_d & 0x8000) const_d |= 0xffffffffffff6000;

		*trns_x = (short)( ((x * const_b)>>10) + (((y * const_a)>>10)<<_get_xsft) );
		*trns_y = (short)( ((x * const_d)>>10) + (((y * const_c)>>10)<<_get_ysft) );
		break;
	case 7:
	default:
		return;
	}
}


/******************************************************************************/
/* Read1LineHP                                                                */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/8    j.ishii                                             */
/******************************************************************************/
void Read1LineHP(int Height,short (**upper_data)[LINE_SIZE],short (**lower_data)[LINE_SIZE],
                 short (**upper_adr)[LINE_SIZE],short (**lower_adr)[LINE_SIZE],
                 bool *twox8bpp)
{
    int datatype;
    
	static short data1[LINE_SIZE],data2[LINE_SIZE];
    
	switch(_get_dinsel)
	{
	case 0:
		Read1LineDest1(Height, data1);
		*upper_data = &data1;
		*lower_data = &data1;
		*upper_adr = &data1;
		*lower_adr = &data1;
        datatype = 2; GetImgAccessTypeHP(&datatype);
		break;
	case 1:
		Read1LineDest1(Height, data1);
		Read1LineDest2(Height, data2);
		*upper_data = &data2;
		*lower_data = &data1;
		*upper_adr = &data2;
		*lower_adr = &data1;
        datatype = 2; GetImgAccessTypeHP(&datatype);
		break;
	case 4:
		Read1LineDest1(Height, data1);
		Read1LineDest2(Height, data2);
		*upper_data = &data2;
		*lower_data = &data2;
		*upper_adr = &data1;
		*lower_adr = &data1;
		break;
	case 5:
		Read1LineDest1(Height, data1);
		Read1LineDest2(Height, data2);
		*upper_data = &data1;
		*lower_data = &data1;
		*upper_adr = &data2;
		*lower_adr = &data2;
        datatype = 2; GetImgAccessTypeHP(&datatype);
		break;
	case 2:
		Read1LineSrc0HP(Height, data1);
		*upper_data = &data1;
		*lower_data = &data1;
		*upper_adr = &data1;
		*lower_adr = &data1;
        datatype = 0; GetImgAccessTypeHP(&datatype);
		break;
	case 6:
		Read1LineSrc0HP(Height, data1);
		Read1LineSrc1HP(Height, data2);
		*upper_data = &data1;
		*lower_data = &data1;
		*upper_adr = &data2;
		*lower_adr = &data2;
        datatype = 0; GetImgAccessTypeHP(&datatype); // H.Shiota, need to check if datatype of source 0 and 1 are the same.
		break;
	case 7:
		Read1LineSrc0HP(Height, data1);
		Read1LineSrc1HP(Height, data2);
		*upper_data = &data2;
		*lower_data = &data2;
		*upper_adr = &data1;
		*lower_adr = &data1;
        datatype = 0; GetImgAccessTypeHP(&datatype); // H.Shiota, need to check if datatype of source 0 and 1 are the same.
		break;
	default:
		break;
	}

    *twox8bpp = (datatype == 9) ? TRUE : FALSE;        

	return;
}

/******************************************************************************/
/* InitHM                                                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/9    j.ishii                                             */
/* 01-01-00 : 2007/05/23 S.Ishikawa                                           */
/*                       memset comment                                       */
/* 01-02-00 : 2007/07/10 S.Ishikawa                                           */
/*                       changed HMCNT                                        */
/* 01-03-00 : 2007/08/07 S.Ishikawa                                           */
/*                       HPMNMX hpmin/hpmax 14bit->16bit                      */
/* 02-00-00 : 2008/03/04 S.Ishikawa                                           */
/*                       changed for SAD                                      */
/* 02-00-01 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void InitHM()
{
	IMPREG_HPSTS_WRITE( 0);
	IMPREG_HPACC_WRITE( 0);
	IMPREG_HPMAXEP_WRITE( 0);

    if((IMPREG_HPSADCTL_READ()>>17)&0x1){
        g_HPadr = g_Widthcnt;
        g_Widthcnt = 0;
    }

    if((((IMPREG_HPSADCTL_READ()>>16)&0x1)==0) || (((IMPREG_IPSADCTL_READ()>>31)&0x1)==1)){
	    IMPREG_HPMINSP_WRITE( 0);
	    IMPREG_HPSADMIN_WRITE( 0x007fffff);
        g_Widthcnt = 0;
        g_HPadr = 0;
    }

//	IMPREG_HPMNMX_READ() = 0x20001fff;
	IMPREG_HPMNMX_WRITE( 0x80007fff);

	IMPREG_HMCNT_WRITE( IMPREG_HMCNT_READ() & 0xfffff800 );

/*
	memset(pHM,0,HM_MEM_SIZE);
*/
}

/******************************************************************************/
/* AddHMCNT                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/9    j.ishii                                             */
/* 01-01-00 : 2007/05/30 S.Ishikawa                                           */
/*                       changed overflowcnt >=1023 -> >=1024                 */
/* 01-01-01 : 2007/06/06 S.Ishikawa                                           */
/*                       1024 -> HM_SIZE                                      */
/* 02-00-00 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void AddHMCNT()
{
	short cnt;
	cnt = (short)_get_cnt;

	switch(_get_cntmode)
	{
	case 0:
		if(!(_flg_cntovf))
		{
			cnt++;
//            if(cnt >= 1023)
            if(cnt >= HM_SIZE)
			{
				cnt = 0;
				_set_cntovf;
			}
		}
		break;
	case 1:
		cnt++;
//		if(cnt >= 1023)
		if(cnt >= HM_SIZE)
		{
			cnt = 0;
			_set_cntovf;
		}
		break;
	case 2:
		cnt = 0;
		break;
	default:
		break;
	}

	IMPREG_HMCNT_WRITE( ((IMPREG_HMCNT_READ() & 0xffffc000) | cnt) );

	return;
}

/******************************************************************************/
/* FeatureExtraction                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/9    j.ishii                                             */
/* 01-00-01 : 2007/04/06  s.ishikawa                                          */
/*                        HPMAXEP x_dt 00,01-> FirstPoint                     */
/*                                x_dt 10,11-> LastPoint�@�@�@�@              */
/* 01-01-00 : 2007/05/24  S.Ishikawa                                          */
/*                        HPMNMX  x_dt 10(bry) -> MAX MIN X Point             */
/* 01-01-01 : 2007/05/25  S.Ishikawa                                          */
/*                        hpmax 0x3fff->0xffff                                */
/* 01-01-02 : 2007/06/05  S.Ishikawa                                          */
/*                        (_flg_cntovf) ON -> return                          */
/* 01-03-00 : 2007/08/07 S.Ishikawa                                           */
/*                       HPMNMX hpmin/hpmax 14bit->16bit                      */
/* 01-04-00 : 2007/08/20 S.Ishikawa                                           */
/*                       HPMNMX hpmin/hpmax 14bit->16bit debug                */
/* 02-00-00 : 2008/03/04 S.Ishikawa                                           */
/*                       changed for SAD                                      */
/******************************************************************************/
void FeatureExtraction(short data,short data2,short trns_x,short trns_y)
{
	long Acc;
	short hpmax,hpmin;
    int sadmode;
	int64 hpsadmin, saddata;

	Acc = IMPREG_HPACC_READ();
	Acc += data;
	IMPREG_HPACC_WRITE( Acc);

    if(_flg_cntovf) return;

    sadmode = ( ((((IMPREG_IPFUN_READ())>>28) & 0x0f)==9) && ((((IMPREG_IPFUN2_READ())>>24) & 0x000f)==1) );

	hpmax = (short)(((IMPREG_HPMNMX_READ())>>16) & 0x0000ffff);
	hpmin = (short)(((IMPREG_HPMNMX_READ())    ) & 0x0000ffff);
    hpsadmin = (IMPREG_HPSADMIN_READ()) & 0x00ffffff;
    if(hpsadmin & 0x00800000) hpsadmin = hpsadmin | 0xFFFFFFFFFF800000l;
/*	
	if(hpmax <= data)
	{
        if((!( ((_get_dinsel==0)&&(_get_dest_dt==2)) || ((_get_dinsel==2)&&(_get_soura_dt==2)) || (_get_dinsel==1))) && (hpmax==data)){
        }else{
		    hpmax = data;
		    IMPREG_READ(_HPMAXEP] = (trns_y << 16) | (trns_x);
        }
	}
	if(hpmin > data)
	{
		hpmin = data;
		IMPREG_READ(_HPMINSP] = (trns_y << 16) | (trns_x);
	}
*/

    if( ((_get_dinsel==0)&&(_get_dest_dt==2)) || ((_get_dinsel==2)&&(_get_soura_dt==2)) || ((_get_dinsel==1)&&(_get_dest_dt==3))){
        if(data){
	        if(hpmax < trns_x)
	        {
	            hpmax = trns_x;
	        }
	        IMPREG_HPMAXEP_WRITE( ((trns_y << 16) | (trns_x)) );

	        if(hpmin==0x7fff)
            {
                IMPREG_HPMINSP_WRITE( ((trns_y << 16) | (trns_x)) );
            }

	        if(hpmin > trns_x)
	        {
		        hpmin = trns_x;
	        }
        }
    }else{
	    if(hpmax < data)
	    {
		    hpmax = data;
		    IMPREG_HPMAXEP_WRITE( ((trns_y << 16) | (trns_x)) );
	    }

        if(sadmode){
            saddata = ((data2<<16)&0xffff0000) | (data&0xffff);
            if(saddata & 0x80000000) saddata = saddata | 0xFFFFFFFF80000000l;

            if(hpsadmin > saddata){
                hpsadmin = saddata;
                trns_y = (short)(IMPREG_HPSADCTL_READ() & 0x00001fff);
                IMPREG_HPSADMIN_WRITE( (unsigned long)(hpsadmin&0x00ffffff) );
       	        IMPREG_HPMINSP_WRITE( ((trns_y << 16) | (trns_x)) );
            }
        }else{
	        if(hpmin > data)
	        {
		        hpmin = data;
   		        IMPREG_HPMINSP_WRITE( ((trns_y << 16) | (trns_x)) );
	        }
        }
    }

	IMPREG_HPMNMX_WRITE( (((hpmax&0xffff) << 16) | (hpmin&0xffff)) );
	
	return;
}

/******************************************************************************/
/* HPAccumulate                                                               */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/2/8    j.ishii                                             */
/* 01-00-01 : 2007/04/06  s.ishikawa                                          */
/*                        FeatureExtraction data changed                      */
/* 01-01-00 : 2007/05/23 S.Ishikawa                                           */
/*                       InitHM enable                                        */
/* 01-01-01 : 2007/05/28  s.ishikawa                                          */
/*                        FeatureExtraction data changed                      */
/* 01-01-02 : 2007/05/31  s.ishikawa                                          */
/*                        changed"select upper data"                          */
/* 01-01-03 : 2007/6/4    s.ishikawa                                          */
/*                        debug                                               */
/* 01-01-04 : 2007/6/5    s.ishikawa                                          */
/*                        HPSTS cntovf                                        */
/* 01-03-00 : 2007/07/30 S.Ishikawa                                           */
/*                       Mcom APLNG->IPLEN                                    */
/* 01-03-01 : 2007/08/02 S.Ishikawa                                           */
/*                       warning                                              */
/* 02-00-00 : 2008/03/04 S.Ishikawa                                           */
/*                       changed for SAD                                      */
/* 02-00-01 : 2008/03/07 S.Ishikawa                                           */
/*                       IP Regster 2Set                                      */
/******************************************************************************/
void HPAccumulate()
{
	short trns_x,trns_y;
	short (*upper_data)[LINE_SIZE],(*lower_data)[LINE_SIZE],(*upper_adr)[LINE_SIZE],(*lower_adr)[LINE_SIZE];
	int Heightcnt,Widthcnt,xlng,ylng,xs,ys;
	int dinsel = _get_dinsel;
	short adr,data,carry;
	int IsWindow;
    int sadmode;
	unsigned long fun;
//start, temperory for Issue #56144
    int datatype_s0, datatype_s1, datatype_d;
//end, temperory for Issue #56144

    bool twox8bpp;

	/* chack hpen */
	if(!_get_hpen) return;
/*
#ifdef _DEBUG
*/
	InitHM();
/*
#endif
*/
	if (_get_xyctl == 5)
	{
		if((_get_asel_u != 2) && (_get_asel_u != 3))
		{
			return;  //HP register setting error
		}
	}
	carry = 0;
    sadmode = ( ((((IMPREG_IPFUN_READ())>>28) & 0x0f)==9) && ((((IMPREG_IPFUN2_READ())>>24) & 0x000f)==1) );
    fun = (((IMPREG_IPFUN_READ())>>28) & 0x0f);

	/* init window */
	if(_get_xyctl == 4) IsWindow = 1;
	else IsWindow = 0;
	
	if(IsWindow)
	{
		xlng = _get_hp_xlng;
		ylng = _get_hp_ylng;
		xs = _get_hp_xs;
		ys = _get_hp_ys;
	}
	else
	{
        if(McomFlg){
            xlng = _get_xlngiplen;
            ylng = _get_ylngiplen;
        }else{
		    xlng = _get_xlng;
		    ylng = _get_ylng;
        }
		xs = 0;
		ys = 0;
	}

    /* for SAD */
    if(sadmode)
	{
    	xlng = 25;
        ylng = 1;
    	if(_get_hpx_clr)
    	{
    		g_Widthcnt = 0; /* Rest by IMPLIB when search from new line */
    	}
    }

//start, temperory for Issue #56144
#if 0
	{ // For log output
        int datatype_s0, datatype_s1, datatype_d;
        datatype_s0 = 0;
        GetImgAccessTypeHP(&datatype_s0);
        datatype_s1 = 1;
        GetImgAccessTypeHP(&datatype_s1);
        datatype_d = 2;
        GetImgAccessTypeHP(&datatype_d);    
        
        SIMLOG(SL_LS, SL_L5, "dinsel:%d, dtype_s0:%d, dtype_s1:%d, dtype_d:%d, xlng:%d, ylng:%d, _get_asel_u:%d, _get_dsel_u:%d, _get_asel_l:%d, _get_dsel_l:%d\n",
               dinsel, datatype_s0, datatype_s1, datatype_d, xlng, ylng, _get_asel_u, _get_dsel_u, _get_asel_l, _get_dsel_l);
    }
#endif
// For log output
    datatype_s0 = 0;
    GetImgAccessTypeHP(&datatype_s0);
    datatype_s1 = 1;
    GetImgAccessTypeHP(&datatype_s1);
    datatype_d = 2;
    GetImgAccessTypeHP(&datatype_d);    
    
    SIMLOG(SL_LS, SL_L5, "dinsel:%d, dtype_s0:%d, dtype_s1:%d, dtype_d:%d, xlng:%d, ylng:%d, _get_asel_u:%d, _get_dsel_u:%d, _get_asel_l:%d, _get_dsel_l:%d\n",
           dinsel, datatype_s0, datatype_s1, datatype_d, xlng, ylng, _get_asel_u, _get_dsel_u, _get_asel_l, _get_dsel_l);
//end, temperory for Issue #56144

	/* main loop */
	Heightcnt = 0;
	while(Heightcnt<ylng)
	{
		Read1LineHP(Heightcnt+ys,&upper_data,&lower_data,&upper_adr,&lower_adr, &twox8bpp);
		Widthcnt = 0;
		while(Widthcnt<xlng)
		{
			TrunsXY((short)(Widthcnt+g_Widthcnt),(short)Heightcnt,&trns_x,&trns_y);
			
			/* select lower address */
			switch(_get_asel_l)
			{
			case 0:
				adr = (short)_get_cnt; break;
			case 1:
				adr = (*lower_adr)[Widthcnt+xs];
//start, temperory for Issue #56144
				//if(adr < 0) adr = (short)(256 + adr);
				if (datatype_d == 6)
				{//singned 16bit case
					if (adr < 0)
					{
						adr = (short)(2048 + adr);//-1024 ~ -1 is mapped to 1024 ~ 2047
					}
				}
				else
				{//singed 8bit case
					if(adr < 0) adr = (short)(256 + adr);
				}
//end, temperory for Issue #56144
				break;
			case 2:
				adr = trns_x; break;
			case 3:
				adr = trns_y; break;
			default:
				return;
			}
			/* select lower data */
			switch(_get_dsel_l)
			{
			case 0:
				data = 1; break;
			case 1:
				data = (*lower_data)[Widthcnt+xs]; break;
			case 2:
				data = trns_x; break;
			case 3:
				data = trns_y; break;
			default:
				return;
			}

            SIMLOG(SL_LS, SL_L6, "Lower:  Heightcnt:%d, Widthcnt:%d, data(hex):%x\n", Heightcnt, Widthcnt, data);

            if ( ( ((dinsel==0)&&(_get_dest_dt==2)) || ((dinsel==2)&&(_get_soura_dt==2)) )
                 && ((*lower_data)[Widthcnt+xs]==0) ){
                /* Binary & data=0 Skip */
            }else if( (fun==0xa)&&(dinsel==1)&&((*lower_data)[Widthcnt+xs]==0) ){
                /* dinsel=1(labeling) & data=0 Skip */
            }else{
//			    FeatureExtraction(data,trns_x,trns_y);
//			    FeatureExtraction((*lower_data)[Widthcnt+xs],trns_x,trns_y);
			    if(sadmode)
			    {/* For SAD mode, use data from IMG_1001 directly */
			    	FeatureExtraction(g_sad_lowdata[Widthcnt],g_sad_updata[Widthcnt],
			    			(short)(Widthcnt+g_Widthcnt),(short)Heightcnt);
			    }
			    else
			    {
			    	FeatureExtraction((*lower_data)[Widthcnt+xs],(*upper_data)[Widthcnt+xs],
                                  (short)(Widthcnt+g_Widthcnt),(short)Heightcnt);
			    }

                /* accumlate lower */
                if ( !twox8bpp ||
                     (twox8bpp && Widthcnt%2 == 1)) { // See 30.10.2.5 of HP spec
                    WriteAU_L(data,ReadHM_L(adr + g_HPadr),ReadHM_AU(adr + g_HPadr),&carry);
                    WriteHM_L(adr + g_HPadr,ReadAU_L());
                    SIMLOG(SL_LS, SL_L6, "Count up AU_L of HP, adr:%d, data:%d, HM:%d\n", adr, data, ReadAU_L());
                }
            }

			/* select upper address */
			switch(_get_asel_u)
			{
			case 0:
				adr = (short)_get_cnt; break;
			case 1:
				adr = (*upper_adr)[Widthcnt+xs];
//start, temperory for Issue #56144
				//if(adr < 0) adr = (short)(256 + adr);
				if (datatype_d == 6)
				{//singned 16bit case
					if (adr < 0)
					{
						adr = (short)(2048 + adr);//-1024 ~ -1 is mapped to 1024 ~ 2047
					}
				}
				else
				{//singed 8bit case
					if(adr < 0) adr = (short)(256 + adr);
				}
//end, temperory for Issue #56144
				break;
			case 2:
				adr = trns_x; break;
			case 3:
				adr = trns_y; break;
			default:
				return;
			}
			/* select upper data */
            if((_get_con)&& !( (_get_xyctl==1)||(_get_xyctl==2)||(_get_xyctl==3) )) data = 0;
            else{

			switch(_get_dsel_u)
			{
			case 0:
				if(_get_con) data = 0;
				else data = 1;
				break;
			case 1:
				data = (*upper_data)[Widthcnt+xs]; break;
			case 2:
				data = trns_x; break;
			case 3:
				data = trns_y; break;
			default:
				return;
			}

            }
            SIMLOG(SL_LS, SL_L6, "Higher: Heightcnt:%d, Widthcnt:%d, data(hex):%x\n", Heightcnt, Widthcnt, data);
            
            if ( ( ((dinsel==0)&&(_get_dest_dt==2)) || ((dinsel==2)&&(_get_soura_dt==2)) ) && ((*upper_data)[Widthcnt+xs]==0) ){
                /* Binary & data=0 Skip */
            }else if( (fun==0xa)&&(dinsel==1)&&((*upper_data)[Widthcnt+xs]==0) ){
                /* dinsel=1(labeling) & data=0 Skip */
            }else{
			    /* accumlate upper */
                if ( !twox8bpp ||
                     (twox8bpp && Widthcnt%2 == 0)) { // See 30.10.2.5 of HP spec
                    WriteAU_U(data,ReadHM_U(adr + g_HPadr),carry);
                    WriteHM_U(adr + g_HPadr,ReadAU_U());
                    SIMLOG(SL_LS, SL_L6, "Count up AU_U of HP, adr:%d, data:%d, HM:%d\n", adr, data, ReadAU_U()); 
                }

			    AddHMCNT();
            }
			Widthcnt++;
		}
		Heightcnt++;
	}
	
    g_Widthcnt += xlng;
	IMPREG_HPCTL_WRITE((IMPREG_HPCTL_READ() & 0xFFFF7FFF));//clear hpen bit

	return;
}


//------------------------------------------------
/* Function specification, H.Shiota
  [Abstraction]
  Decide the image format to HP according to HPFORM.

  [input]
      datatype: Specify source/destination of image.
          0: source A/0
          1: source B/1
          2: destination

  [output]
      datatype: Image type.
          0: signed8
          1: unsigned8/label
          2: binary
          3: kari label for destination, reserved for source A/0 and B/1.
          4: reserved
          5: 8bpp/pixel
          6: 16bpp/pixel
          7: reserved
          8: reserved
          9: 2 * 8bpp/pixel
          others: reserved
*/

int GetImgAccessTypeHP(int *datatype){
    unsigned long cnf;
    int form1, form2, gamen, bit;

    gamen = *datatype;

    if (gamen == 0) { // Source 0/A from AP
        if((IMPREG_HPFORM_READ() >> 24) & 0x0001){
            *datatype = ((IMPREG_HPFORM_READ() >> 8) & 0x0007) + 4;
        } else {
            *datatype = ((IMPREG_HPCTL_READ() >> 6) & 0x0003);            
        }
    } else if (gamen == 1) { // Source 1/B from AP
        if((IMPREG_HPFORM_READ() >> 24) & 0x0001){
            *datatype = ((IMPREG_HPFORM_READ() >> 12) & 0x0007) + 4;
        } else {
            *datatype = ((IMPREG_HPCTL_READ() >> 4) & 0x0003);
        }
    } else if (gamen == 2) { // Destination from IP
        if((IMPREG_HPFORM_READ() >> 24) & 0x0001){
            *datatype = ((IMPREG_HPFORM_READ() >> 16) & 0x0007) + 4;
        } else {
            *datatype = ((IMPREG_HPCTL_READ() >> 0) & 0x0003);
        }
    } else {
        SIMLOG(SL_LS, SL_ERR, "ERROR: Wrong HP input: %d\n", gamen);
        *datatype = -1;
    }

    return(0);
}
