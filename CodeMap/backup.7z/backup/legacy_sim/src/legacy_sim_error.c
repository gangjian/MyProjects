/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_sim_error.c                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __GNUC__
#include <stdbool.h>
#endif
#include "impsim_int.h"
#include "legacy_sim.h"
#include "distributer_sim_prot.h"

#define FILENAME_ONLY  1
#define FILE_PATH(x, y) sprintf(filename, fmt, x, y);

#if PIPE_HO_DEBUG
unsigned char *pDebug, *localpDebug[20];
unsigned long x_pDebug, y_pDebug, num_pDebug, type_pDebug;
static out_count = 0;
#endif


/******************************************************************************/
/* Legacy_assert_error                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Legacy_assert_error(void) {
	
#ifdef	COVERAGE_MEASUREMENT
	return;
#else	
    SIMLOG(SL_LS, SL_ERR, "Legacy ERROR asserted.\n");
	Legacy_reg_dump();
	if (McomFlg) {
		Legacy_MCOMreg_dump();
	}
	assert_error();
	
#endif
}


/******************************************************************************/
/* Legacy_debug_print                                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Legacy_debug_print(void) {
	
    SIMLOG(SL_LS, SL_ERR, "Legacy_debug_print\n");
	Legacy_reg_dump();
	if (McomFlg) {
		Legacy_MCOMreg_dump();
	}
	
	return;
}


/******************************************************************************/
/* Legacy_reg_dump                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Legacy_reg_dump(void) {
	
    SIMLOG(SL_LS, SL_ERR, "##############   Legacy_reg_dump start   ##############\n");
	SIMLOG(SL_LS, SL_ERR, "   APSASP      -> %08x\n",IMPREG_APSASP_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSBSP      -> %08x\n",IMPREG_APSBSP_READ());
	SIMLOG(SL_LS, SL_ERR, "   APDSP       -> %08x\n",IMPREG_APDSP_READ());
	SIMLOG(SL_LS, SL_ERR, "   APLNG       -> %08x\n",IMPREG_APLNG_READ());
	SIMLOG(SL_LS, SL_ERR, "   APDLY       -> %08x\n",IMPREG_APDLY_READ());
	SIMLOG(SL_LS, SL_ERR, "   APMAG       -> %08x\n",IMPREG_APMAG_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSIZE_SA   -> %08x\n",IMPREG_APSIZE_SA_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSIZE_SB   -> %08x\n",IMPREG_APSIZE_SB_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSIZE_DST  -> %08x\n",IMPREG_APSIZE_DST_READ());
	SIMLOG(SL_LS, SL_ERR, "   APCLPX      -> %08x\n",IMPREG_APCLPX_READ());
	SIMLOG(SL_LS, SL_ERR, "   APCFG       -> %08x\n",IMPREG_APCFG_READ());
	SIMLOG(SL_LS, SL_ERR, "   APCMD       -> %08x\n",IMPREG_APCMD_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPFUN       -> %08x\n",IMPREG_IPFUN_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPFUN2      -> %08x\n",IMPREG_IPFUN2_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPFORM      -> %08x\n",IMPREG_IPFORM_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPLEN       -> %08x\n",IMPREG_IPLEN_READ());
	SIMLOG(SL_LS, SL_ERR, "   ESNGENCTL   -> %08x\n",IMPREG_ESNGENCTL_READ());
	SIMLOG(SL_LS, SL_ERR, "   CNST        -> %08x\n",IMPREG_CNST_READ());
	SIMLOG(SL_LS, SL_ERR, "   KNLMSK      -> %08x\n",IMPREG_KNLMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   KNLMSK2     -> %08x\n",IMPREG_KNLMSK2_READ());
	SIMLOG(SL_LS, SL_ERR, "   LMCTL       -> %08x\n",IMPREG_LMCTL_READ());
	SIMLOG(SL_LS, SL_ERR, "   BINTHR      -> %08x\n",IMPREG_BINTHR_READ());
	SIMLOG(SL_LS, SL_ERR, "   IFCFG       -> %08x\n",IMPREG_IFCFG_READ());
	SIMLOG(SL_LS, SL_ERR, "   PSA         -> %08x\n",IMPREG_PSA_READ());
	SIMLOG(SL_LS, SL_ERR, "   IFCTL       -> %08x\n",IMPREG_IFCTL_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF02H    -> %08x\n",IMPREG_COEFF02H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF35H    -> %08x\n",IMPREG_COEFF35H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF68H    -> %08x\n",IMPREG_COEFF68H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF911H   -> %08x\n",IMPREG_COEFF911H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF1214H  -> %08x\n",IMPREG_COEFF1214H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF1517H  -> %08x\n",IMPREG_COEFF1517H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF1820H  -> %08x\n",IMPREG_COEFF1820H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF2123H  -> %08x\n",IMPREG_COEFF2123H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF24H    -> %08x\n",IMPREG_COEFF24H_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF02     -> %08x\n",IMPREG_COEFF02_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF35     -> %08x\n",IMPREG_COEFF35_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF68     -> %08x\n",IMPREG_COEFF68_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF911    -> %08x\n",IMPREG_COEFF911_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF1214   -> %08x\n",IMPREG_COEFF1214_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF15     -> %08x\n",IMPREG_COEFF15_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF1820   -> %08x\n",IMPREG_COEFF1820_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF2123   -> %08x\n",IMPREG_COEFF2123_READ());
	SIMLOG(SL_LS, SL_ERR, "   COEFF24     -> %08x\n",IMPREG_COEFF24_READ());
	SIMLOG(SL_LS, SL_ERR, "   MCR1B0      -> %08x\n",IMPREG_MCR1B0_READ());
	SIMLOG(SL_LS, SL_ERR, "   MCR2B0      -> %08x\n",IMPREG_MCR2B0_READ());
	SIMLOG(SL_LS, SL_ERR, "   MCR3B0      -> %08x\n",IMPREG_MCR3B0_READ());
	SIMLOG(SL_LS, SL_ERR, "   MCR12B0     -> %08x\n",IMPREG_MCR12B0_READ());
	SIMLOG(SL_LS, SL_ERR, "   MCINIT      -> %08x\n",IMPREG_MCINIT_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTASEL1   -> %08x\n",IMPREG_PFFTASEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTASEL2   -> %08x\n",IMPREG_PFFTASEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTAMSK    -> %08x\n",IMPREG_PFFTAMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTBSEL1   -> %08x\n",IMPREG_PFFTBSEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTBSEL2   -> %08x\n",IMPREG_PFFTBSEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTBMSK    -> %08x\n",IMPREG_PFFTBMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTASEL1    -> %08x\n",IMPREG_FFTASEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTASEL2    -> %08x\n",IMPREG_FFTASEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTAMSK     -> %08x\n",IMPREG_PFFTAMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTBSEL1    -> %08x\n",IMPREG_FFTBSEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTBSEL2    -> %08x\n",IMPREG_FFTBSEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTBMSK     -> %08x\n",IMPREG_FFTBMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTDSEL1    -> %08x\n",IMPREG_FFTDSEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTDSEL2    -> %08x\n",IMPREG_FFTDSEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTDMSK     -> %08x\n",IMPREG_FFTDMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTCTL      -> %08x\n",IMPREG_FFTCTL_READ());
    SIMLOG(SL_LS, SL_ERR, "##############   Legacy_reg_dump end   ##############\n");
	
	return;
}

/******************************************************************************/
/* Legacy_FFT_reg_dump                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/09/12 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Legacy_FFT_reg_dump(void) {
	
    SIMLOG(SL_LS, SL_ERR, "##############   Legacy_FFT_reg_dump start   ##############\n");
	SIMLOG(SL_LS, SL_ERR, "   APSASP      -> %08x\n",IMPREG_APSASP_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSBSP      -> %08x\n",IMPREG_APSBSP_READ());
	SIMLOG(SL_LS, SL_ERR, "   APDSP       -> %08x\n",IMPREG_APDSP_READ());
	SIMLOG(SL_LS, SL_ERR, "   APLNG       -> %08x\n",IMPREG_APLNG_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSIZE_SA   -> %08x\n",IMPREG_APSIZE_SA_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSIZE_SB   -> %08x\n",IMPREG_APSIZE_SB_READ());
	SIMLOG(SL_LS, SL_ERR, "   APSIZE_DST  -> %08x\n",IMPREG_APSIZE_DST_READ());
	SIMLOG(SL_LS, SL_ERR, "   APCFG       -> %08x\n",IMPREG_APCFG_READ());
	SIMLOG(SL_LS, SL_ERR, "   APCMD       -> %08x\n",IMPREG_APCMD_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPFUN       -> %08x\n",IMPREG_IPFUN_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPFUN2      -> %08x\n",IMPREG_IPFUN2_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPFORM      -> %08x\n",IMPREG_IPFORM_READ());
	SIMLOG(SL_LS, SL_ERR, "   IPLEN       -> %08x\n",IMPREG_IPLEN_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTASEL1   -> %08x\n",IMPREG_PFFTASEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTASEL2   -> %08x\n",IMPREG_PFFTASEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTAMSK    -> %08x\n",IMPREG_PFFTAMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTBSEL1   -> %08x\n",IMPREG_PFFTBSEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTBSEL2   -> %08x\n",IMPREG_PFFTBSEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   PFFTBMSK    -> %08x\n",IMPREG_PFFTBMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTASEL1    -> %08x\n",IMPREG_FFTASEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTASEL2    -> %08x\n",IMPREG_FFTASEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTAMSK     -> %08x\n",IMPREG_PFFTAMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTBSEL1    -> %08x\n",IMPREG_FFTBSEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTBSEL2    -> %08x\n",IMPREG_FFTBSEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTBMSK     -> %08x\n",IMPREG_FFTBMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTDSEL1    -> %08x\n",IMPREG_FFTDSEL1_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTDSEL2    -> %08x\n",IMPREG_FFTDSEL2_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTDMSK     -> %08x\n",IMPREG_FFTDMSK_READ());
	SIMLOG(SL_LS, SL_ERR, "   FFTCTL      -> %08x\n",IMPREG_FFTCTL_READ());
    SIMLOG(SL_LS, SL_ERR, "##############   Legacy_FFT_reg_dump end   ##############\n");
	
	return;
}

/******************************************************************************/
/* Distributer_reg_dump                                                       */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/11/05 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Distributer_reg_dump(void) {
    SIMLOG(SL_LS, SL_ERR, "##############   Distributer_reg_dump start  ##############\n");
	SIMLOG(SL_LS, SL_ERR, "   VCR         -> %08x\n", DIST_REG_READ(DP_VCR));
	SIMLOG(SL_LS, SL_ERR, "   IMR         -> %08x\n", DIST_REG_READ(DP_IMR));
	SIMLOG(SL_LS, SL_ERR, "   G0INTSEL    -> %08x\n", DIST_REG_READ(DP_G0INTSEL));
	SIMLOG(SL_LS, SL_ERR, "   G1INTSEL    -> %08x\n", DIST_REG_READ(DP_G1INTSEL));
	SIMLOG(SL_LS, SL_ERR, "   G2INTSEL    -> %08x\n", DIST_REG_READ(DP_G2INTSEL));
	SIMLOG(SL_LS, SL_ERR, "   CSTPR       -> %08x\n", DIST_REG_READ(DP_CSTPR));
	SIMLOG(SL_LS, SL_ERR, "   CSTPSR      -> %08x\n", DIST_REG_READ(DP_CSTPSR));
	SIMLOG(SL_LS, SL_ERR, "   CRSTR       -> %08x\n", DIST_REG_READ(DP_CRSTR));
	SIMLOG(SL_LS, SL_ERR, "   CDXOFFR     -> %08x\n", DIST_REG_READ(DP_CDXOFFR));
	SIMLOG(SL_LS, SL_ERR, "   IMPCNUMOSR  -> %08x\n", DIST_REG_READ(DP_IMPCNUMOSR));
	SIMLOG(SL_LS, SL_ERR, "   MCR         -> %08x\n", DIST_REG_READ(DP_MCR));
	SIMLOG(SL_LS, SL_ERR, "   IMPCAREA    -> %08x\n", DIST_REG_READ(DP_IMPCAREA));
	SIMLOG(SL_LS, SL_ERR, "   IMPCAREA_EN -> %08x\n", DIST_REG_READ(DP_IMPCAREA_EN));
	SIMLOG(SL_LS, SL_ERR, "   IMPCSR      -> %08x\n", DIST_REG_READ(DP_IMPCSR));
	SIMLOG(SL_LS, SL_ERR, "   IMPS        -> %08x\n", DIST_REG_READ(DP_IMPS));
	SIMLOG(SL_LS, SL_ERR, "   DRPSEL      -> %08x\n", DIST_REG_READ(DP_DRPSEL));
	SIMLOG(SL_LS, SL_ERR, "   IMP0DRPCTL  -> %08x\n", DIST_REG_READ(DP_IMP0DRPCTL));
	SIMLOG(SL_LS, SL_ERR, "   IMP1DRPCTL  -> %08x\n", DIST_REG_READ(DP_IMP1DRPCTL));
	SIMLOG(SL_LS, SL_ERR, "   IMP2DRPCTL  -> %08x\n", DIST_REG_READ(DP_IMP2DRPCTL));
	SIMLOG(SL_LS, SL_ERR, "   IMP3DRPCTL  -> %08x\n", DIST_REG_READ(DP_IMP3DRPCTL));
    SIMLOG(SL_LS, SL_ERR, "##############   Distributer_reg_dump  end   ##############\n");
}

/******************************************************************************/
/* Output_src_dst                                                             */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Output_src_dst(void) {
	unsigned char *adr;
	int i, size;
	int acscnt_sa, acscnt_sb, acscnt_ds, pfsrca, pfsrcb, pfdst, soura_dt, sourb_dt, dest_dt;
	
	size = 1024;
	acscnt_sa = ((IMPREG_APCMD_READ() >> 19) & 0x0001);
	acscnt_sb = ((IMPREG_APCMD_READ() >> 18) & 0x0001);
	acscnt_ds = ((IMPREG_APCMD_READ() >> 16) & 0x0001);
	pfsrca = ((IMPREG_APCFG_READ()>>8) & 0x0007);  /* src0 */
	pfsrcb = ((IMPREG_APCFG_READ()>>12) & 0x0007);  /* src1 */
	pfdst = ((IMPREG_APCFG_READ()>>16) & 0x0007);
	soura_dt =  ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
	sourb_dt =  ((IMPREG_IPFUN_READ() >> 20) & 0x0003);
	dest_dt =  ((IMPREG_IPFUN_READ() >> 16) & 0x0003);

	
	if (acscnt_sa) {
		adr = pSrc0;
		SIMLOG(SL_LS, SL_ERR, "\n=== Src0 memory dump start ===");
		if (pfsrca == 1) {
			if (soura_dt == 0) {
				SIMLOG(SL_LS, SL_ERR, "   signed 8bpp\n");
			} else if (soura_dt == 1) {
				SIMLOG(SL_LS, SL_ERR, "   unsigned 8bpp\n");
			} else if (soura_dt == 2) {
				SIMLOG(SL_LS, SL_ERR, "   BIN 8bpp\n");
			} else if (soura_dt == 3) {
				SIMLOG(SL_LS, SL_ERR, "   cbcr 8bpp\n");
			}
		} else if (pfsrca == 2) {
			SIMLOG(SL_LS, SL_ERR, "  16bpp\n");
		} else if (pfsrca == 3) {
			SIMLOG(SL_LS, SL_ERR, "  32bpp\n");
		} else {
			SIMLOG(SL_LS, SL_ERR, "   ?bpp error?\n");
		}
		SIMLOG(SL_LS, SL_ERR, "               00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");
		SIMLOG(SL_LS, SL_ERR, "              ------------------------------------------------");
		for (i=0; i<size; i++) {
			if (i%16 == 0) {
				SIMLOG(SL_LS, SL_ERR, "\n  %08x -> ",i);
			}
			if (i%4 == 0) {
				SIMLOG(SL_LS, SL_ERR, " %02x", *adr);
			} else {
				SIMLOG(SL_LS, SL_ERR, " %02x", *adr);
			}
			adr ++;
		}
		SIMLOG(SL_LS, SL_ERR, "\n=== Src0 memory dump end ===\n");
	}
	
	if (acscnt_sb) {
		adr = pSrc1;
		SIMLOG(SL_LS, SL_ERR, "\n=== Src1 memory dump start ===");
		if (pfsrcb == 1) {
			if (sourb_dt == 0) {
				SIMLOG(SL_LS, SL_ERR, "   signed 8bpp\n");
			} else if (sourb_dt == 1) {
				SIMLOG(SL_LS, SL_ERR, "   unsigned 8bpp\n");
			} else if (sourb_dt == 2) {
				SIMLOG(SL_LS, SL_ERR, "   BIN 8bpp\n");
			} else if (sourb_dt == 3) {
				SIMLOG(SL_LS, SL_ERR, "   cbcr 8bpp\n");
			}
		} else if (pfsrcb == 2) {
			SIMLOG(SL_LS, SL_ERR, "  16bpp\n");
		} else if (pfsrcb == 3) {
			SIMLOG(SL_LS, SL_ERR, "  32bpp\n");
		} else {
			SIMLOG(SL_LS, SL_ERR, "   ?bpp error?\n");
		}
		SIMLOG(SL_LS, SL_ERR, "               00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");
		SIMLOG(SL_LS, SL_ERR, "              ------------------------------------------------");
		for (i=0; i<size; i++) {
			if (i%16 == 0) {
				SIMLOG(SL_LS, SL_ERR, "\n  %08x -> ",i);
			}
			if (i%4 == 0) {
				SIMLOG(SL_LS, SL_ERR, " %02x", *adr);
			} else {
				SIMLOG(SL_LS, SL_ERR, " %02x", *adr);
			}
			adr ++;
		}
		SIMLOG(SL_LS, SL_ERR, "\n=== Src1 memory dump end ===\n");
	}
	
	if (acscnt_ds) {
		adr = pDst;
		SIMLOG(SL_LS, SL_ERR, "\n=== Dst memory dump start ===");
		
		if (pfdst == 1) {
			if (dest_dt == 0) {
				SIMLOG(SL_LS, SL_ERR, "   signed 8bpp\n");
			} else if (dest_dt == 1) {
				SIMLOG(SL_LS, SL_ERR, "   unsigned 8bpp\n");
			} else if (dest_dt == 2) {
				SIMLOG(SL_LS, SL_ERR, "   error? 8bpp\n");
			} else if (dest_dt == 3) {
				SIMLOG(SL_LS, SL_ERR, "   signed 12bit -> 8bpp\n");
			}
		} else if (pfdst == 2) {
			SIMLOG(SL_LS, SL_ERR, "  16bpp\n");
		} else if (pfdst == 3) {
			SIMLOG(SL_LS, SL_ERR, "  32bpp\n");
		} else {
			SIMLOG(SL_LS, SL_ERR, "   ?bpp error?\n");
		}
		SIMLOG(SL_LS, SL_ERR, "               00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");
		SIMLOG(SL_LS, SL_ERR, "              ------------------------------------------------");
		for (i=0; i<size; i++) {
			if (i%16 == 0) {
				SIMLOG(SL_LS, SL_ERR, "\n  %08x -> ",i);
			}
			if (i%4 == 0) {
				SIMLOG(SL_LS, SL_ERR, " %02x", *adr);
			} else {
				SIMLOG(SL_LS, SL_ERR, " %02x", *adr);
			}
			adr ++;
		}
		SIMLOG(SL_LS, SL_ERR, "\n=== Dst memory dump end ===\n");
	}
	
	return;
}


#ifdef DEBUG_OUTPUT
/******************************************************************************/
/* ResetDebugGamen                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/1/26 j.ishii                                               */
/******************************************************************************/
void ResetDebugGamen()
{
    FILE *fp;

    if ((fp = fopen("DebugGamen.txt", "w+")) != NULL)
    {
		fclose(fp);
	}
}

/******************************************************************************/
/* DebugOutputGamen                                                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2006/1/26 j.ishii                                               */
/******************************************************************************/
void DebugOutputGamen(int64 result[],int mode,int width)
{
    FILE *fp;
	int x;

    if ((fp = fopen("DebugGamen.txt", "a+")) != NULL)
    {
		fseek(fp,0,SEEK_END);
		for(x=0;x<width;x++)
		{
			switch(mode)
			{
				case 0:	// sign
					fprintf(fp,"% 5ld",result[x]);
					break;
				case 1:	//�@unsign
					fprintf(fp,"% 4ld",(unsigned long)result[x]);
					break;
				case 2:	//�@bin
					fprintf(fp,"%ld ",result[x] & 0x01);
					break;
				case 3:	// hex
					fprintf(fp,"%lX ",result[x]);
					break;
				default:
					break;
			}
		}
		fprintf(fp,"\n");
    }

	fclose(fp);
}
#endif // DEBUG_OUTPUT

/******************************************************************************/
/* Legacy_MCOMreg_dump                                                        */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void Legacy_MCOMreg_dump(void) {
	
	int i;
    SIMLOG(SL_LS, SL_ERR, "Legacy_MCOMreg_dump\n");
	
	for(i = 0; i < MCOM_NUM_REGS; i++){
		SIMLOG(SL_LS, SL_ERR, "   dump_pipe_regs(): bank:0, R%2d=%08lx", i, (unsigned long)MCOM_reg[0][i]);
		SIMLOG(SL_LS, SL_ERR, "   bank:1, R%2d=%08lx\n", i, (unsigned long)MCOM_reg[1][i]);
	}

	return;
}


#if PIPE_HO_DEBUG
/******************************************************************************/
/* PIPE_HO_debug_init                                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void PIPE_HO_debug_init(void) {
	
	int i;
	
	x_pDebug = (IMPREG_APLNG_READ() & 0x0000FFFF) * 2;
	y_pDebug = ((IMPREG_APLNG_READ() >> 16) & 0x0000FFFF) + 8;
	num_pDebug = 18;
	
	for (i=0; i<num_pDebug; i++) {
		localpDebug[i] = pDebug + (x_pDebug * y_pDebug) * i;
	}
	
	return;
}
#endif


#if PIPE_HO_DEBUG
/******************************************************************************/
/* PIPE_HO_collect_linebuf                                                    */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void PIPE_HO_collect_linebuf(void) {
	
	int i, j, x, y;
	unsigned char *read_p, *write_p;
	
//	localpDebug[0]  = src
//	localpDebug[1]  = Ix
//	localpDebug[2]  = Iy
//	localpDebug[3]  = Ixx
//	localpDebug[4]  = Ixy
//	localpDebug[5]  = Iyy
//	localpDebug[6]  = IxxA
//	localpDebug[7]  = IxyC
//	localpDebug[8]  = IyyB
//	localpDebug[9]  = detM
//	localpDebug[10] = TrM^2
//	localpDebug[11] = A
//	localpDebug[12] = B
//	localpDebug[13] = TrM
//	localpDebug[14] = AB
//	localpDebug[15] = CC
//	localpDebug[16] = Det M
	
	if (((IMPREG_IPFUN_READ() & 0xFF000000) == 0xF3000000) && (MCOM_reg[0][14] == 0x60)) {
		// Dump Ix
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[1];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[1] = localpDebug[1] + x_pDebug;
		
	} else if (((IMPREG_IPFUN_READ() & 0xFF000000) == 0xF3000000) && (MCOM_reg[0][14] == 0x70)) {
		// Dump Iy
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[2];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[2] = localpDebug[2] + x_pDebug;
		
		// Dump src
		read_p  = pLM256[MCOM_reg[0][8]];
		write_p = localpDebug[0];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[0] = localpDebug[0] + x_pDebug;
		
	} else if ((IMPREG_IPFUN_READ() == 0x13000003) && (MCOM_reg[0][8] == 0x60) && (MCOM_reg[0][9] == 0x60)) {
		// Dump Ixx
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[3];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[3] = localpDebug[3] + x_pDebug;
		
	} else if ((IMPREG_IPFUN_READ() == 0x13000003) && (MCOM_reg[0][8] == 0x60) && (MCOM_reg[0][9] == 0x70)) {
		// Dump Ixy
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[4];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[4] = localpDebug[4] + x_pDebug;
		
	} else if ((IMPREG_IPFUN_READ() == 0x13000003) && (MCOM_reg[0][8] == 0x70) && (MCOM_reg[0][9] == 0x70)) {
		// Dump Iyy
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[5];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[5] = localpDebug[5] + x_pDebug;
		
	} else if ((IMPREG_IPFUN_READ() == 0xF1000007) && (MCOM_reg[0][14] == 0x60)) {
		// Dump IxxA
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[6];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[6] = localpDebug[6] + x_pDebug;
		
	} else if ((IMPREG_IPFUN_READ() == 0xF1000007) && (MCOM_reg[0][14] == 0x80)) {
		// Dump IxyC
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[7];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[7] = localpDebug[7] + x_pDebug;
		
	} else if ((IMPREG_IPFUN_READ() == 0xF1000007) && (MCOM_reg[0][14] == 0x70)) {
		// Dump IyyB
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[8];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[8] = localpDebug[8] + x_pDebug;
		
	} else if (IMPREG_IPFUN_READ() == 0x12000007) {
		// Dump detM
		if (MCOM_reg[0][8] != 0x80) {
			SIMLOG(SL_LS, SL_ERR, "Dump detM\n");
			Legacy_assert_error();
		}
		read_p  = pLM256[MCOM_reg[0][8]];
		write_p = localpDebug[9];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[9] = localpDebug[9] + x_pDebug;
		
		// Dump TrM^2
		if (MCOM_reg[0][9] != 0x70) {
			SIMLOG(SL_LS, SL_ERR, "Dump TrM^2\n");
			Legacy_assert_error();
		}
		read_p  = pLM256[MCOM_reg[0][9]];
		write_p = localpDebug[10];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[10] = localpDebug[10] + x_pDebug;
		
	} else if (IMPREG_IPFUN_READ() == 0x10000000) {
		// Dump A
		read_p  = pLM256[MCOM_reg[0][8]];
		write_p = localpDebug[11];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[11] = localpDebug[11] + x_pDebug;
		
		// Dump B
		read_p  = pLM256[MCOM_reg[0][9]];
		write_p = localpDebug[12];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[12] = localpDebug[12] + x_pDebug;
		
		// Dump TrM
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[13];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[13] = localpDebug[13] + x_pDebug;
		
	} else if (IMPREG_IPFUN_READ() == 0x11000000) {
		// Dump AB
		read_p  = pLM256[MCOM_reg[0][8]];
		write_p = localpDebug[14];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[14] = localpDebug[14] + x_pDebug;
		
		// Dump CC
		read_p  = pLM256[MCOM_reg[0][9]];
		write_p = localpDebug[15];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[15] = localpDebug[15] + x_pDebug;
		
		// Dump Det M
		read_p  = pLM256[MCOM_reg[0][14]];
		write_p = localpDebug[16];
		
		for (i=0; i<x_pDebug; i++) {
			*write_p++ = *read_p++;
		}
		localpDebug[16] = localpDebug[16] + x_pDebug;
		
	}
	
	for (i=0; i<(num_pDebug-1); i++) {
		if (localpDebug[i] > (pDebug + (x_pDebug * y_pDebug) * (i+1))) {
			SIMLOG(SL_LS, SL_ERR, "localpDebug[%d] is broken!\n", (i+1));
			Legacy_assert_error();
		}
	}
	
	return;
}
#endif


#if PIPE_HO_DEBUG
/******************************************************************************/
/* PIPE_HO_save_file                                                          */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20 T.Sato                                               */
/*                       new                                                  */
/******************************************************************************/
void PIPE_HO_save_file(void)
{
	unsigned long x_lng, y_lng, x_offset, y_offset;
	char fmt[128] = "image_out/PIPE_%s_%d.pgm";
	char filename[128] = {0};
	x_lng = (IMPREG_APLNG_READ() & 0x0000FFFF);
	y_lng = (IMPREG_APLNG_READ() >> 16) & 0x0000FFFF;
	x_offset = 4;
	y_offset = 4;

	// for Harris Operator Precise
	if ((mem[0] == 0x8304) && (mem[1] == 0x848e)) {
		// all
		FILE_PATH("Precise_ALL" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_ALL.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug,
							x_pDebug,
							0,
							0,
							x_pDebug,
							y_pDebug*num_pDebug,
							16,
							0,
							5);
		FILE_PATH("Precise_ALL_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_ALL_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug,
							x_pDebug,
							0,
							0,
							x_pDebug,
							y_pDebug*num_pDebug,
							16,
							1,
							5);
		
		// PIPE_Precise_SRC.pgm
		FILE_PATH("Precise_SRC" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_SRC.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 0,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_Ix.pgm
		FILE_PATH("Precise_Ix" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Ix.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 1,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_Ix_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Ix_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 1,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_Iy.pgm
		FILE_PATH("Precise_Iy" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Iy.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 2,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_Iy_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Iy_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 2,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_Ixx.pgm
		FILE_PATH("Precise_Ixx" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Ixx.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 3,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_Ixx_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Ixx_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 3,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_Ixy.pgm
		FILE_PATH("Precise_Ixy" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Ixy.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 4,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_Ixy_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Ixy_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 4,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_Iyy.pgm
		FILE_PATH("Precise_Iyy" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Iyy.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 5,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_Iyy_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_Iyy_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 5,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_IxxA.pgm
		FILE_PATH("Precise_IxxA" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_IxxA.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 6,
							x_pDebug,
							x_offset * 2,
							y_offset,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_IxxA_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_IxxA_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 6,
							x_pDebug,
							x_offset * 2,
							y_offset,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_IyyB.pgm
		FILE_PATH("Precise_IyyB" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_IyyB.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 8,
							x_pDebug,
							x_offset * 2,
							y_offset,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_IyyB_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_IyyB_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 8,
							x_pDebug,
							x_offset * 2,
							y_offset,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_IxyC.pgm
		FILE_PATH("Precise_IxyC" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_IxyC.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 7,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_IxyC_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_IxyC_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 7,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_AB.pgm
		FILE_PATH("Precise_AB" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_AB.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 14,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_AB_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_AB_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 14,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_CC.pgm
		FILE_PATH("Precise_CC" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_CC.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 15,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_CC_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_CC_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 15,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_TrM.pgm
		FILE_PATH("Precise_TrM" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_TrM.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 13,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_TrM_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_TrM_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 13,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_detM.pgm
		FILE_PATH("Precise_detM" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_detM.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 16,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_detM_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_detM_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 16,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_DST.pgm
		FILE_PATH("Precise_DST" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_DST.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDst,
							x_lng * 2,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_DST_FULL" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_DST_FULL.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDst,
							x_lng * 2,
							0,
							0,
							x_lng * 2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_DST_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_DST_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDst,
							x_lng * 2,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Precise_DEST1.pgm
		FILE_PATH("Precise_DEST1" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_DEST1.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDest1,
							x_lng * 4,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							0,
							5);
		FILE_PATH("Precise_DEST1_8bpp" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Precise_DEST1_8bpp.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDest1,
							x_lng * 4,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
	} else if ((mem[0] == 0x5001) && (mem[1] == 0x5801)) {
	// for Harris Operator Fast
		// all
		FILE_PATH("Fast_ALL" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_ALL.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug,
							x_pDebug,
							0,
							0,
							x_pDebug,
							y_pDebug*num_pDebug,
							16,
							1,
							5);
		
		// PIPE_Fast_SRC.pgm
		FILE_PATH("Fast_SRC" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_SRC.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 0,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_Ix.pgm
		FILE_PATH("Fast_Ix" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_Ix.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 1,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_Iy.pgm
		FILE_PATH("Fast_Iy" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_Iy.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 2,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_Ixx.pgm
		FILE_PATH("Fast_Ixx" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_Ixx.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 3,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_Ixy.pgm
		FILE_PATH("Fast_Ixy" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_Ixy.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 4,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_Iyy.pgm
		FILE_PATH("Fast_Iyy" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_Iyy.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 5,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_IxxA.pgm
		FILE_PATH("Fast_IxxA" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_IxxA.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 6,
							x_pDebug,
							x_offset * 2,
							y_offset,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_IyyB.pgm
		FILE_PATH("Fast_IyyB" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_IyyB.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 8,
							x_pDebug,
							x_offset * 2,
							y_offset,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_IxyC.pgm
		FILE_PATH("Fast_IxyC" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_IxyC.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 7,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_AB.pgm
		FILE_PATH("Fast_AB" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_AB.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 14,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_CC.pgm
		FILE_PATH("Fast_CC" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_CC.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 15,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_TrM.pgm
		FILE_PATH("Fast_TrM" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_TrM.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 13,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_detM.pgm
		FILE_PATH("Fast_detM" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_detM.pgm", // )
#else
		OutputImageFile(filename,
#endif
							pDebug + (x_pDebug * y_pDebug) * 16,
							x_pDebug,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
		
		// PIPE_Fast_DST.pgm
		FILE_PATH("Fast_DST" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_DST.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDst,
							x_lng,
							y_offset,
							0,
							x_lng-x_offset-x_offset,
							y_lng-y_offset-y_offset,
							8,
							0,
							5);
		
		// PIPE_Fast_DST_FULL.pgm
		FILE_PATH("Fast_DST_FULL" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_DST_FULL.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDst,
							x_lng,
							0,
							0,
							x_lng,
							y_lng-y_offset-y_offset,
							8,
							0,
							5);
		
		// PIPE_Fast_DEST1.pgm
		FILE_PATH("Fast_DEST1" , out_count);
#if FILENAME_ONLY
		OutputImageFile("image_out/PIPE_Fast_DEST1.pgm", // )
#else
		OutputImageFile(filename,
#endif
							(unsigned char *)pDest1,
							x_lng * 2,
							x_offset * 2,
							0,
							(x_lng-x_offset-x_offset)*2,
							y_lng-y_offset-y_offset,
							16,
							1,
							5);
	}
	
	out_count ++;
	
	return;
}
#endif


/******************************************************************************/
/* OutputImageFile                                                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/06/20                                                      */
/*                       new                                                  */
/******************************************************************************/
int OutputImageFile(char* filename,             // output file name
					unsigned char *addr,        // output image start pointer
					unsigned long src_xlng,     // memory width (byte)
					unsigned long xoffset,      // x offset (byte)
					unsigned long yoffset,      // y offset (line)
					unsigned long xlng,         // clip image  width  (byte)
					unsigned long ylng,         // clip image  height (line)
					unsigned char bpp,          // 8:8bpp 16:16bpp 32:32bpp
 					unsigned char cull,         // unsigned char cull,
												// 0:None OOOOOO
												// 1:OXOXOXOX
												// 2:XOXOXOXO
												// 3:OXXXOXXXOXXX
												// 4:XXXOXXXOXXXO
												// 5:OOXXOOXXOOXX
												// 6:XXOOXXOOXXOO
					int type)                   // file format  1:p1�` 6:p6
{
	char TempP[2], TempX[10], TempY[10];
	char WriteBuff[50];
	unsigned long i, j; 
	unsigned char *adr_ptr;
	FILE *outfile;
	int TotalLen,TempXLen,TempYLen;

	if ((outfile = fopen(filename, "wb")) == NULL)
	{
		SIMLOG(SL_LS, SL_ERR, "Cannot open file!!\n");
		return -1;
	}

	sprintf( TempP, "%d", type );
	
	switch(cull)
	{
	case 0:
		sprintf( TempX, "%ld", (xlng) );
		sprintf( TempY, "%ld", (ylng) );
		break;
		
	case 1:
	case 2:
	case 5:
	case 6:
		sprintf( TempX, "%ld", (xlng/2) );
		sprintf( TempY, "%ld", (ylng) );
		break;
		
	case 3:
	case 4:
		sprintf( TempX, "%ld", (xlng/4) );
		sprintf( TempY, "%ld", (ylng) );
		break;
		
	default:
		SIMLOG(SL_LS, SL_ERR, "cull=[%d] is parameter error!\n", cull);
		fclose(outfile);
		return -2;
	}
	
	strcpy( WriteBuff,"P" );
	strcat( WriteBuff, TempP );
	strcat( WriteBuff,"\n" );

	//insert comment to header
	strcat( WriteBuff, "#" );
	TempXLen =strlen(TempX);
	TempYLen =strlen(TempY);
	TotalLen =11 + TempXLen + TempYLen;
	//      "P" + TempP + "\n" + "#" + "\n" + " " + "\n" + "255\n"
	// 11 =  1  +   1   +  1   +  1  +  1   +  1  +  1   +   4
	
	if (TotalLen % 16) {
		for (i=0; i < (16 - (TotalLen % 16)); i++) {
			strcat( WriteBuff, "X" );
		}
	}
	strcat( WriteBuff, "\n" );

	strcat( WriteBuff, TempX );
	strcat( WriteBuff, " " );
	strcat( WriteBuff, TempY );
	strcat( WriteBuff,"\n" );
	strcat( WriteBuff, "255\n" );

	fwrite(WriteBuff,1, strlen(WriteBuff), outfile);
	
	adr_ptr = addr + yoffset*src_xlng + xoffset;
	
	for (i=0; i<ylng; i++) {
		for (j=0; j<xlng; j++) {
			switch(cull)
			{
			// None
			case 0:
				fwrite(adr_ptr, 1, 1, outfile);
				break;
				
			// high byte(short)
			case 1:
				// OXOXOXOX
				fwrite(adr_ptr, 1, 1, outfile);
				adr_ptr++;
				j++;
				break;
				
			// low byte(short)
			case 2:
				// XOXOXOXO
				adr_ptr++;
				fwrite(adr_ptr, 1, 1, outfile);
				j++;
				break;
				
			// high byte(long)
			case 3:
				// OXXXOXXXOXXX
				fwrite(adr_ptr, 1, 1, outfile);
				adr_ptr+=3;
				j+=3;
				break;
				
			// low byte(long)
			case 4:
				// XXXOXXXOXXXO
				adr_ptr+=3;
				fwrite(adr_ptr, 1, 1, outfile);
				j+=3;
				break;
				
			case 5:
				// OOXXOOXXOOXX
				fwrite(adr_ptr, 1, 1, outfile);
				adr_ptr++;
				fwrite(adr_ptr, 1, 1, outfile);
				adr_ptr+=2;
				j+=3;
				break;
				
			case 6:
				// XXOOXXOOXXOO
				adr_ptr+=2;
				fwrite(adr_ptr, 1, 1, outfile);
				adr_ptr++;
				fwrite(adr_ptr, 1, 1, outfile);
				j+=3;
				break;
			}
			
			adr_ptr++;
		}
		adr_ptr += (src_xlng - xlng);
	}
	fclose(outfile);
	return (0);
}

/******************************************************************************/
/* dump_lm256                                                           	  */
/******************************************************************************/
void dump_lm256(int line, int xlng) {
#ifdef LEGACY_SIM_DEBUG
    int x;
    uint16_t val;

    if (xlng == 0) xlng = LM256_SIZE;
    
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_lm256(): Dump LM256. line:%d, xlng:%d\n", line, xlng);
    for (x=0; x<xlng; x++) {
        if(ENDIAN){ /* little */
            val = *(pLM256[line]+x*2)    | *(pLM256[line]+x*2+1)<<8;
        }else{ /* big */
            val = *(pLM256[line]+x*2)<<8 | *(pLM256[line]+x*2+1);
        }
        SIMLOG(SL_LS_ADPT, SL_L5, "dump_lm256(): line:%d, x:%d, val:%04x\n", line, x, (unsigned short)val);
    }
#endif
    return;        
}

/******************************************************************************/
/* dump_pipe_regs                                                           	  */
/******************************************************************************/
void dump_pipe_regs(int bank) {
#ifdef LEGACY_SIM_DEBUG    
    int i;

    for(i = 0; i < MCOM_NUM_REGS; i++){
        SIMLOG(SL_LS_ADPT, SL_L5, "dump_pipe_regs(): bank:%d, R%d=%08lx\n", bank, i, (unsigned long)MCOM_reg[bank][i]);
    }
#endif    
    return;
}

/******************************************************************************/
/* dump_pipe_mem                                                           	  */
/******************************************************************************/
void dump_pipe_mem(void) {
#ifdef LEGACY_SIM_DEBUG
    int i;

    SIMLOG(SL_LS_ADPT, SL_L5, "dump_pipe_mem(): Dump PIPE memory.\n");
        
    for (i=0; i<MCOM_MAX_MEM_ADDR+1; i++) {
        SIMLOG(SL_LS_ADPT, SL_L5, "dump_pipe_mem(): index:%04d, val:%08lx\n", i, (unsigned long)mem[IMP_WORK_CH][i]);
    }
#endif
    return;    
}

/******************************************************************************/
/* dump_hp_mem                                                           	  */
/******************************************************************************/
void dump_hp_mem(void) {
#ifdef LEGACY_SIM_DEBUG
    int i;
    uint32_t pHM_ul = (uint32_t)pHM[IMP_WORK_CH];
    uint32_t val;

    SIMLOG(SL_LS_ADPT, SL_L5, "dump_hp_mem(): Dump HM.\n");
        
    for (i=0; i<((int)(HM_MEM_SIZE))/4; i++) {
        ReadHM(IMP_WORK_CH, i, (unsigned long *)&val);
        SIMLOG(SL_LS_ADPT, SL_L5, "dump_hp_mem(): offset:%04x, addr:%08lx, val:%08lx\n",
               i, (unsigned long)(pHM_ul+i*4), (unsigned long)val);
    }
#endif
    return;    
}

/******************************************************************************/
/* dump_imp_reg                                                           	  */
/******************************************************************************/
void dump_imp_reg(void) {
#ifdef LEGACY_SIM_DEBUG
    /* Following debug dump is used for IMP-X2 or later. */
    
    uint8_t fun, subfun, abs_en, cut_en, bcm_en, bmask_en, bnr_en;
    uint8_t scale, ec_en, ec_mode, ec_bin;
    
    uint8_t val8;
    uint16_t val16;
    int val;

    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): Dump IMP registers.\n");    
    
    fun = (IMPREG_IPFUN_READ() >> 28) & 0x000f;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: fun: %01x\n", fun);
    
	subfun = (IMPREG_IPFUN_READ() >>24) & 0x0000000f;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: subfun: %01x\n", subfun);

    val8 = (IMPREG_IPFUN_READ() >> 22) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: soura_dt: %01x\n", val8);

    val8 = (IMPREG_IPFUN_READ() >> 20) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: sourb_dt: %01x\n", val8);
 
    val8 = (IMPREG_IPFUN_READ() >> 18) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: destext_dt: %01x\n", val8);    
    
    val8 = (IMPREG_IPFUN_READ() >> 16) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: dest_dt (datatype?): %01x\n", val8);
    
    abs_en = (IMPREG_IPFUN_READ() >> 11) & 0x0001;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: abs_en: %01x\n", abs_en);
    
    cut_en = (IMPREG_IPFUN_READ() >> 10) & 0x0001;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: cut_en: %01x\n", cut_en);
    
    bcm_en = (IMPREG_IPFUN_READ() >> 9) & 0x0001;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: bcm_en: %01x\n", bcm_en);
    
    bmask_en = (IMPREG_IPFUN_READ() >> 8) & 0x0001;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: bmask_en: %01x\n", bmask_en);
    
    bnr_en = (IMPREG_IPFUN_READ() >> 4) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: bnr_en: %01x\n", bnr_en);
    
    scale = IMPREG_IPFUN_READ() & 0x000f;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN: scale: %01x\n", scale);

    val8 = (IMPREG_IPFUN2_READ() >> 28) & 0x000f;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN2: exfun: %01x\n", val8);

    val8 = (IMPREG_IPFUN2_READ() >> 24) & 0x000f;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN2: exsubfun: %01x\n", val8);
    
    val8 = (IMPREG_IPFUN2_READ() >> 22) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN2: ex_soura_dt (WARNING. definition of this bits is not described in the register table: %01x\n", val8);

    val8 = (IMPREG_IPFUN2_READ() >> 6) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFUN2: ex_dest_dt: %01x\n", val8);        

    val8 = IMPREG_IPFORM_READ() & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFORM: scra_pre_em: %01x\n", val8);

    val8 = (IMPREG_IPFORM_READ() >> 4) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFORM: scrb_pre_em: %01x\n", val8);

    val8 = (IMPREG_IPFORM_READ() >> 8) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFORM: scra_ind_em: %01x\n", val8);        

    val8 = (IMPREG_IPFORM_READ() >> 12) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFORM: scrb_ind_em: %01x\n", val8);        

    val8 = (IMPREG_IPFORM_READ() >> 16) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFORM: scra_ind_om: %01x\n", val8);        
    
    val8 = (IMPREG_IPFORM_READ() >> 20) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFORM: scrb_ind_om: %01x\n", val8);        

    val8 = (IMPREG_IPFORM_READ() >> 28) & 0x0003;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): IPFORM: post_om: %01x\n", val8);        
    
    val16 = (IMPREG_BINTHR_READ() & 0x01FF);
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): BINTHR: thr_min inc. sign bit: %03x\n", val16);
    
    val16 = ((IMPREG_BINTHR_READ() >> 16) & 0x01FF);
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): BINTHR: thr_max inc. sign bit: %03x\n", val16);
    
    ec_en = (IMPREG_BINTHR_READ() >> 31) & 0x0001;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): BINTHR: ec_en: %01x\n", ec_en);
    
    ec_mode = ((IMPREG_BINTHR_READ() >> 13) & 0x0007);
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): BINTHR: ec_mode: %01x\n", ec_mode);
    
    ec_bin = ((IMPREG_BINTHR_READ() >> 29) & 0x0003);
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): BINTHR: ec_bin: %01x\n", ec_bin);
    
    val16 = IMPREG_APCLPX_READ() & 0x1fff;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): APCLPX: dxclpmax: %04x\n", val16);
    
    val16 = (IMPREG_APCLPX_READ() >> 16) & 0x1fff;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): APCLPX: dxclpmin: %04x\n", val16);

    val16 = IMPREG_APLNG_READ() & 0x3fff;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): APLNG: xlng (decimal): %d\n", val16);

    val16 = (IMPREG_APLNG_READ() >>16) & 0x3fff;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): APLNG: ylng (decimal): %d\n", val16);

    val16 = (IMPREG_APSIZE_SA_READ()) & 0xffff;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): APSIZE_SA (decimal): %d\n", val16);
    
    val16 = (IMPREG_APSIZE_SB_READ()) & 0xffff;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): APSIZE_SB (decimal): %d\n", val16);
    
    val16 = (IMPREG_APSIZE_DST_READ()) & 0xffff;
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): APSIZE_DST (decimal): %d\n", val16);        

    val = 0;
    GetImgAccessType(&val);
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): GetImgAccessType(): SrcA type:%d\n", val);

    val = 1;
    GetImgAccessType(&val);
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): GetImgAccessType(): SrcB type:%d\n", val);

    val = 2;
    GetImgAccessType(&val);    
    SIMLOG(SL_LS_ADPT, SL_L5, "dump_imp_reg(): GetImgAccessType(): Dst  type:%d\n", val);
    
#endif
    return;
}

