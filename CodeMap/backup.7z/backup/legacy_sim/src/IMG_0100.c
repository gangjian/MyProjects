/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0100.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"

static int64 IMG_RankFLT(short m[]);
static int64 IMG_5x5MinMaxFLT(short m[]);


/******************************************************************************/
/* IMG_0100                                                                   */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
int IMG_0100(){
    long xlng, ylng, Widthcnt, Heightcnt;
    int kernel, edge, rank, max5x5, min5x5, i, datatype;
    short m[25];
	short *soura_id = psLM6;
	short *soura_id2 = psLM7;
	int64 result[LINE_SIZE];
	int64 scale;

	short (*pReadLM[4])(int adr) = {ReadLM0,ReadLM1,ReadLM2,NULL};
	void (*pWriteLM[4])(int adr, short *data, int size) = {WriteLM0,WriteLM1,WriteLM2,NULL};

	if ( !USE_PIPE_FUNC && McomFlg ) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (PIPE). turn on USE_PIPE_FUNC when use PIPE for IMG_0100.\n");
		Legacy_assert_error();
	}
	
    rank = (((IMPREG_KNLMSK_READ())>>12) & 0x000f); /* rank 0:max�`8:min */
    if(rank>8){
        SIMLOG(SL_LS, SL_L4, "Error rank=%d\n",rank);
        return(-1);
    }
    max5x5 = (((IMPREG_KNLMSK_READ())>>10) & 0x0001);
    min5x5 = (((IMPREG_KNLMSK_READ())>> 9) & 0x0001);
    if(max5x5&min5x5){
        SIMLOG(SL_LS, SL_L4, "Error max5x5=%d min5x5=%d\n",max5x5, min5x5);
        return(-1);
    }

    kernel = (((IMPREG_IPFUN_READ())>>27) & 0x0001); /* 0:3x3 1:1x9 */
    edge   = (((IMPREG_IPFUN_READ())>>24) & 0x0003); /* 1:chuou gaso 3:"0" */

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

    datatype = ((IMPREG_IPFUN_READ() >> 22) & 0x0003);
    if((IMPREG_IPFORM_READ() >> 16) & 0x0007){
        datatype = ((IMPREG_IPFORM_READ() >> 16) & 0x0007) + 4;
    }

    if(datatype==6){
        for(i=0, scale=1;i<(signed int)((IMPREG_IPFUN2_READ() & 0x000f)<<4 | (IMPREG_IPFUN_READ() & 0x000f));i++) scale *= 2;
    }else{
        for(i=0, scale=1;i<(signed int)(IMPREG_IPFUN_READ() & 0x000f);i++) scale *= 2;
    }

#ifdef DEBUG_OUTPUT
	ResetDebugGamen();
#endif

    if(max5x5==0 && min5x5==0){

        if(kernel==0){ /* 0:3x3 */
/********** 3x3 **********/
            Heightcnt = 0;
        	
#if USE_PIPE_FUNC
            if(McomFlg){
                Widthcnt = 0;

			    while(Widthcnt < xlng)
			    {
                    if(Widthcnt == 0)
					{
						/* left edge */
						m[1] = ReadLM256A(2, Widthcnt);
						m[4] = ReadLM256A(1, Widthcnt);
						m[7] = ReadLM256A(0, Widthcnt);
						m[2] = ReadLM256A(2, Widthcnt+1);
						m[5] = ReadLM256A(1, Widthcnt+1);
						m[8] = ReadLM256A(0, Widthcnt+1);
						if(edge==3) result[Widthcnt] = 0;
						else result[Widthcnt] = (int64)ReadLM256A(1, Widthcnt) * (int64)scale;
					}
					else if(Widthcnt == xlng-1)
					{
						/* right edge */
						if(edge==3) result[Widthcnt] = 0;
						else result[Widthcnt] = (int64)ReadLM256A(1, Widthcnt) * (int64)scale;
					}
					else
					{
						/* kernel */
						m[0] = m[1]; m[1] = m[2]; m[2] = ReadLM256A(2, Widthcnt+1);
						m[3] = m[4]; m[4] = m[5]; m[5] = ReadLM256A(1, Widthcnt+1);
						m[6] = m[7]; m[7] = m[8]; m[8] = ReadLM256A(0, Widthcnt+1);

						result[Widthcnt] = IMG_RankFLT(m);
					}
                    Widthcnt++;
                }
		        Write1LineDst(0, result);
            }else{
#endif 
                while(Heightcnt <= ylng)
		        {
			        if(Heightcnt < ylng)
			        {
				        Read1LineSrc0(Heightcnt, soura_id);
			        }

			        Widthcnt = 0;

			        while(Widthcnt < xlng)
			        {
				        if(Heightcnt == 1 || Heightcnt == ylng)
				        {
					        /* top and bottom edge */
					        if(edge==3) result[Widthcnt] = 0;
					        else result[Widthcnt] = (int64)pReadLM[1](Widthcnt) * (int64)scale;
				        }
				        else if(Heightcnt != 0)
				        {
					        if(Widthcnt == 0)
					        {
						        /* left edge */
						        m[1] = pReadLM[0](Widthcnt);
						        m[4] = pReadLM[1](Widthcnt);
						        m[7] = soura_id[0];
						        m[2] = pReadLM[0](Widthcnt+1);
						        m[5] = pReadLM[1](Widthcnt+1);
						        m[8] = soura_id[1];
						        if(edge==3) result[Widthcnt] = 0;
						        else result[Widthcnt] = (int64)pReadLM[1](Widthcnt) * (int64)scale;
					        }
					        else if(Widthcnt == xlng-1)
					        {
						        /* right edge */
						        if(edge==3) result[Widthcnt] = 0;
						        else result[Widthcnt] = (int64)pReadLM[1](Widthcnt) * (int64)scale;
					        }
					        else
					        {
						        /* kernel */
						        m[0] = m[1]; m[1] = m[2]; m[2] = pReadLM[0](Widthcnt+1);
						        m[3] = m[4]; m[4] = m[5]; m[5] = pReadLM[1](Widthcnt+1);
						        m[6] = m[7]; m[7] = m[8]; m[8] = soura_id[Widthcnt+1];

						        result[Widthcnt] = IMG_RankFLT(m);
					        }
				        }
				        Widthcnt++;
			        }

			        if(Heightcnt > 0)
			        {
#ifdef DEBUG_OUTPUT
				        DebugOutputGamen(result,3,xlng);
#endif
				        Write1LineDst(Heightcnt-1, result);
			        }
			        if(Heightcnt < ylng)
			        {
				        pWriteLM[0](0, soura_id,xlng);
			        }
			        pWriteLM[3] = pWriteLM[1];
			        pWriteLM[1] = pWriteLM[0];
			        pWriteLM[0] = pWriteLM[3];
			        pReadLM[3] = pReadLM[1];
			        pReadLM[1] = pReadLM[0];
			        pReadLM[0] = pReadLM[3];
			        Heightcnt++;
		        }
#if USE_PIPE_FUNC
            }
#endif 
	    }
    	else { /* kernel=1  1:1x9 */
/********** 1x9 **********/
            Heightcnt = 0;

#if USE_PIPE_FUNC
            if(McomFlg) ylng = 1;
#endif 

            while(Heightcnt < ylng)
		    {
#if USE_PIPE_FUNC
                if(McomFlg){
                    Read1LineLM256A(Heightcnt, soura_id);
                }else{
#endif 
			        Read1LineSrc0(Heightcnt, soura_id);
#if USE_PIPE_FUNC
                }
#endif 

			    Widthcnt = 0;

			    while(Widthcnt < xlng)
			    {
				    if(Widthcnt < 4)
				    {
					    /* left edge */
					    if(Widthcnt == 3)
					    {
						    m[1] = soura_id[0];
						    m[2] = soura_id[1];
						    m[3] = soura_id[2];
						    m[4] = soura_id[3];
						    m[5] = soura_id[4];
						    m[6] = soura_id[5];
						    m[7] = soura_id[6];
						    m[8] = soura_id[7];
					    }
					    if(edge==3) result[Widthcnt] = 0;
					    else result[Widthcnt] = (int64)soura_id[Widthcnt] * (int64)scale;
				    }
				    else if(Widthcnt > xlng-5)
				    {
					    /* right edge */
					    if(edge==3) result[Widthcnt] = 0;
					    else result[Widthcnt] = (int64)soura_id[Widthcnt] * (int64)scale;
				    }
				    else
				    {
					    /* kernel */
					    m[0] = m[1]; m[1] = m[2]; m[2] = m[3];
					    m[3] = m[4]; m[4] = m[5]; m[5] = m[6];
					    m[6] = m[7]; m[7] = m[8]; m[8] = soura_id[Widthcnt+4];

					    result[Widthcnt] = IMG_RankFLT(m);
				    }
				    Widthcnt++;
			    }
#ifdef DEBUG_OUTPUT
			    DebugOutputGamen(result,3,xlng);
#endif
			    Write1LineDst(Heightcnt, result);

			    Heightcnt++;
		    }
	    }

    }else{ /* max5x5, min5x5 */
        Heightcnt = 0;
#if USE_PIPE_FUNC
        if(McomFlg){

            Widthcnt = 0;
            for(i=0;i<xlng;i++){
                if((Widthcnt==0)||(Widthcnt==1)||(Widthcnt==xlng-2)||(Widthcnt==xlng-1)){

                    if(edge==3) result[Widthcnt] = 0;
				    else result[Widthcnt] = (int64)ReadLM256A(2, Widthcnt) * (int64)scale;
                }else{
                    m[ 0] = ReadLM256A(4, Widthcnt-2);
                    m[ 1] = ReadLM256A(4, Widthcnt-1);
                    m[ 2] = ReadLM256A(4, Widthcnt  );
                    m[ 3] = ReadLM256A(4, Widthcnt+1);
                    m[ 4] = ReadLM256A(4, Widthcnt+2);
                    m[ 5] = ReadLM256A(3, Widthcnt-2);
                    m[ 6] = ReadLM256A(3, Widthcnt-1);
                    m[ 7] = ReadLM256A(3, Widthcnt  );
                    m[ 8] = ReadLM256A(3, Widthcnt+1);
                    m[ 9] = ReadLM256A(3, Widthcnt+2);
                    m[10] = ReadLM256A(2, Widthcnt-2);
                    m[11] = ReadLM256A(2, Widthcnt-1);
                    m[12] = ReadLM256A(2, Widthcnt  );
                    m[13] = ReadLM256A(2, Widthcnt+1);
                    m[14] = ReadLM256A(2, Widthcnt+2);
                    m[15] = ReadLM256A(1, Widthcnt-2);
                    m[16] = ReadLM256A(1, Widthcnt-1);
                    m[17] = ReadLM256A(1, Widthcnt  );
                    m[18] = ReadLM256A(1, Widthcnt+1);
                    m[19] = ReadLM256A(1, Widthcnt+2);
                    m[20] = ReadLM256A(0, Widthcnt-2);
                    m[21] = ReadLM256A(0, Widthcnt-1);
                    m[22] = ReadLM256A(0, Widthcnt  );
                    m[23] = ReadLM256A(0, Widthcnt+1);
                    m[24] = ReadLM256A(0, Widthcnt+2);

                    result[Widthcnt] = IMG_5x5MinMaxFLT(m);
                }
                Widthcnt++;
            }

            Write1LineDst(Heightcnt, result);

        }else{
#endif 
      	
/* All Line loop */
            while(Heightcnt < ylng){
/* 1Line */
			    if(Heightcnt < 2 || Heightcnt > ylng-3)
			    {
				    Read1LineSrc0(Heightcnt, soura_id);

                    for(i=0;i<xlng;i++){
				        /* top and bottom edge */
				        if(edge==3) result[i] = 0;
				        else result[i] = (int64)soura_id[i] * (int64)scale;
                    }

                    Write1LineDst(Heightcnt, result);
                }else{
                    Read1LineSrc0(Heightcnt - 2, soura_id2);
                    WriteLM0(0, soura_id2, xlng);
                    Read1LineSrc0(Heightcnt - 1, soura_id2);
                    WriteLM1(0, soura_id2, xlng);
                    Read1LineSrc0(Heightcnt    , soura_id2);
                    WriteLM2(0, soura_id2, xlng);
                    Read1LineSrc0(Heightcnt + 1, soura_id);
                    Read1LineSrc0(Heightcnt + 2, soura_id2);

                    Widthcnt = 0;
                    for(i=0;i<xlng;i++){
                        if((Widthcnt==0)||(Widthcnt==1)||(Widthcnt==xlng-2)||(Widthcnt==xlng-1)){

                            if(edge==3) result[Widthcnt] = 0;
				            else result[Widthcnt] = (int64)ReadLM2(Widthcnt) * (int64)scale;
                        }else{
                            m[ 0] = ReadLM0(Widthcnt-2);
                            m[ 1] = ReadLM0(Widthcnt-1);
                            m[ 2] = ReadLM0(Widthcnt  );
                            m[ 3] = ReadLM0(Widthcnt+1);
                            m[ 4] = ReadLM0(Widthcnt+2);
                            m[ 5] = ReadLM1(Widthcnt-2);
                            m[ 6] = ReadLM1(Widthcnt-1);
                            m[ 7] = ReadLM1(Widthcnt  );
                            m[ 8] = ReadLM1(Widthcnt+1);
                            m[ 9] = ReadLM1(Widthcnt+2);
                            m[10] = ReadLM2(Widthcnt-2);
                            m[11] = ReadLM2(Widthcnt-1);
                            m[12] = ReadLM2(Widthcnt  );
                            m[13] = ReadLM2(Widthcnt+1);
                            m[14] = ReadLM2(Widthcnt+2);
                            m[15] = soura_id[Widthcnt-2];
                            m[16] = soura_id[Widthcnt-1];
                            m[17] = soura_id[Widthcnt  ];
                            m[18] = soura_id[Widthcnt+1];
                            m[19] = soura_id[Widthcnt+2];
                            m[20] = soura_id2[Widthcnt-2];
                            m[21] = soura_id2[Widthcnt-1];
                            m[22] = soura_id2[Widthcnt  ];
                            m[23] = soura_id2[Widthcnt+1];
                            m[24] = soura_id2[Widthcnt+2];

                            result[Widthcnt] = IMG_5x5MinMaxFLT(m);
                        }
                        Widthcnt++;
                    }

                    Write1LineDst(Heightcnt, result);

                }
/* Next Line */
                Heightcnt++;
            }
#if USE_PIPE_FUNC
        }
#endif 

    }

    return(0);
}


/******************************************************************************/
/* IMG_RankFLT                                                                */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
static int64 IMG_RankFLT(short m[])
{
    int i, j, rank, k[9], msk ; 
    int64 work[9], temp;

    rank = (((IMPREG_KNLMSK_READ())>>12) & 0x000f); /* rank 0:max�`8:min */

    for(i=0;i<9;i++)
        k[i] = (((IMPREG_KNLMSK_READ())>>i) & 0x0001); /* kernelmask 0:use 1:unuse */

    msk = (((IMPREG_IPFUN_READ())>>26) & 0x0001); /* 0:mask disable 1:mask enable */


    for(i=0;i<9;i++){
//        if(msk & k[i]) work[i] = -256;
        if(msk & k[i]) work[i] = -32768;
        else work[i] = m[i];
    }

/* Sort */
    for(i=0;i<9;i++){
        for(j=i+1;j<9;j++){
            if(work[i] < work[j]){
                temp = work[i];
                work[i] = work[j];
                work[j] = temp;
            }
        }
    }
//SIMLOG(SL_LS, SL_L4, "%d %d %d %d %d %d %d %d %d\n",work[0], work[1], work[2], work[3], work[4], work[5], work[6], work[7], work[8]);

    return(work[rank]);
}


/******************************************************************************/
/* IMG_5x5MinMaxFLT                                                           */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/******************************************************************************/
static int64 IMG_5x5MinMaxFLT(short m[])
{
    int max5x5;
    int i, j, rank, k[9], msk;
    int kk[25] = { 8,7,6,7,8,5,4,3,4,5,2,1,0,1,2,5,4,3,4,5,8,7,6,7,8 };
    int64 work[9], temp;

    max5x5 = (((IMPREG_KNLMSK_READ())>>10) & 0x0001);

    rank = (((IMPREG_KNLMSK_READ())>>12) & 0x000f); /* rank 0:max�`8:min */

    for(i=0;i<9;i++){
        k[i] = (((IMPREG_KNLMSK_READ())>>i) & 0x0001); /* kernelmask 0:use 1:unuse */
//        work[i] = (max5x5) ? -256 : 256;
        work[i] = (short)((max5x5) ? -32768 : 32767);
    }

    msk = (((IMPREG_IPFUN_READ())>>26) & 0x0001); /* 0:mask disable 1:mask enable */

    for(i=0;i<25;i++){
//        if(msk & k[kk[i]]) temp = -256;
        if(msk & k[kk[i]]) temp = -32768;
        else temp = m[i];

        if(max5x5) work[kk[i]] = (short)((work[kk[i]] > temp) ? work[kk[i]] : temp);
        else work[kk[i]] = (short)((work[kk[i]] > temp) ? temp : work[kk[i]]);
    }

/* Sort */
    for(i=0;i<9;i++){
        for(j=i+1;j<9;j++){
            if(work[i] < work[j]){
                temp = work[i];
                work[i] = work[j];
                work[j] = temp;
            }
        }
    }

    return(work[rank]);
}


