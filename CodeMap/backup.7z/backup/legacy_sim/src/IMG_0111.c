/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014, 2015    Renesas Electronics Corp.                     **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         IMG_0111.c                                         */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/16 T.Sato                                               */
/*                         New  (Todo Review)                                 */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>     // for int32_t uint32_t
#include <stdbool.h>
#include "simlog.h"
#include "legacy_sim.h"

static int64 IMG_MatchANDC(short f[], short g[]);   //AND 0
static int64 IMG_MatchXNORC(short f[], short g[]);   //XNOR 1

/******************************************************************************/
/* IMG_0111 (binary image matching filter process)                            */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2015/02/20 T.Sato                                               */
/******************************************************************************/
int IMG_0111()
{
    long xlng, ylng, Widthcnt, Heightcnt;
    int kernel, edge, knlmsk;
    unsigned short subfun;
    short m[16], weight[16], temp;
	
	short *soura_id = psLM6;
	int64 result[LINE_SIZE];

    kernel = (((IMPREG_IPFUN_READ())>>27) & 0x0001); // always"1"
    edge   = (((IMPREG_IPFUN_READ())>>24) & 0x0003); // 0 or 2:NOOP  3:output"0"
//  knlmsk = (IMPREG_KNLMSK_READ() & 0x0003)|(((IMPREG_KNLMSK_READ())>>16) & 0x000f);//0:9*9 other:9*16
    knlmsk = (((IMPREG_KNLMSK_READ() & 0x0003)|(((IMPREG_KNLMSK_READ())>>14) & 0x007c)) == 0x7f) ? 0:1  ; //0:9*9 1:9*16 /* 01-00-01 */

    subfun = (unsigned short)(((IMPREG_IPFUN_READ())>>26) & 0x0001);//0:AND 1:XNOR 

	if ( !USE_PIPE_FUNC && McomFlg ) {
		SIMLOG(SL_LS, SL_ERR, "ERROR, not support (PIPE). turn on USE_PIPE_FUNC when use PIPE for IMG_0111.\n");
		Legacy_assert_error();
	}
	
	if(0x0001<subfun)
    {
        SIMLOG(SL_LS, SL_L4, "Error subfun=%d\n",subfun);
        return (-1);
    }

    xlng = ((IMPREG_APLNG_READ()) & 0x3fff);
    ylng = (((IMPREG_APLNG_READ())>>16) & 0x3fff);

//init LM0
    temp=0;
    Widthcnt= 0;
    while(Widthcnt < xlng)
    {
        WriteLM0(Widthcnt++,&temp,1);
    }

#ifdef DEBUG_OUTPUT
    ResetDebugGamen();
#endif


//9*16 kernel**********************************************************************
    if(knlmsk != 0)
    {
        //Read COEFF(9�~16)
        weight[ 0]=(short)(((IMPREG_COEFF02_READ())>>18) & 0x000001ff  );//weight0
        weight[ 1]=(short)(((IMPREG_COEFF02_READ())>> 9) & 0x000001ff  );//weight1
        weight[ 2]=(short)(  IMPREG_COEFF02_READ() & 0x000001ff        );//weight2
        weight[ 3]=(short)(((IMPREG_COEFF35_READ())>>18) & 0x000001ff  );//weight3
        weight[ 4]=(short)(((IMPREG_COEFF35_READ())>> 9) & 0x000001ff  );//weight4
        weight[ 5]=(short)(  IMPREG_COEFF35_READ() & 0x000001ff        );//weight5
        weight[ 6]=(short)(((IMPREG_COEFF68_READ())>>18) & 0x000001ff  );//weight6
        weight[ 7]=(short)(((IMPREG_COEFF68_READ())>> 9) & 0x000001ff  );//weight7
        weight[ 8]=(short)(  IMPREG_COEFF68_READ() & 0x000001ff        );//weight8
        weight[ 9]=(short)(((IMPREG_COEFF911_READ())>>18) & 0x000001ff );//weight9
        weight[10]=(short)(((IMPREG_COEFF911_READ())>> 9) & 0x000001ff );//weight10
        weight[11]=(short)(  IMPREG_COEFF911_READ() & 0x000001ff       );//weight11
        weight[12]=(short)(((IMPREG_COEFF1214_READ())>>18) & 0x000001ff);//weight12
        weight[13]=(short)(((IMPREG_COEFF1214_READ())>> 9) & 0x000001ff);//weight13
        weight[14]=(short)(  IMPREG_COEFF1214_READ() & 0x000001ff      );//weight14
        weight[15]=(short)(((IMPREG_COEFF15_READ())>>18) & 0x000001ff);//weight15

        Heightcnt=0;

#if USE_PIPE_FUNC
        if(McomFlg){
            while(Heightcnt < 9)
            {
                Read1LineLM256A(8 - Heightcnt, soura_id);   

                Widthcnt = 0;
                while(Widthcnt < xlng)
                {
                    temp = (short)(((ReadLM0(Widthcnt)<< 1)&0x01FF) | (soura_id[Widthcnt]&0x01));
                    WriteLM0(Widthcnt,&temp,1); //Write LM0 for 1bit from Src0
                    Widthcnt++;
                }

                Widthcnt = 0;

                while(Widthcnt < xlng)
                {

                    if(Widthcnt == 7)
                    {
                        m[10] = ReadLM0(0);
                        m[11] = ReadLM0(1);
                        m[12] = ReadLM0(2);
                        m[13] = ReadLM0(3);
                        m[ 0] = ReadLM0(4);
                        m[ 1] = ReadLM0(5);
                        m[ 2] = ReadLM0(6);
                        m[14] = ReadLM0(7);
                        m[ 3] = ReadLM0(8);
                        m[ 4] = ReadLM0(9);
                        m[ 5] = ReadLM0(10);
                        m[15] = ReadLM0(11);
                        m[ 6] = ReadLM0(12);
                        m[ 7] = ReadLM0(13);
                        m[ 8] = ReadLM0(14);


                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP

                    }
                    else if(Widthcnt > xlng-8 || Widthcnt < 7)//edgeline process (right or left)
                    {
                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP
                    }
                    else //cutoff 9*16 kernel
                    {
                        m[9]=m[10];  m[10]=m[11];  m[11]=m[12];  m[12]=m[13];
                        m[13]=m[0];  m[0]=m[1];    m[1]=m[2];    m[2]=m[14];
                        m[14]=m[3];  m[3]=m[4];    m[4]=m[5];    m[5]=m[15];
                        m[15]=m[6];  m[6]=m[7];    m[7]=m[8];    m[8]=ReadLM0(Widthcnt+7);

                        if(subfun==0)//ANDcount
                        {
                            result[Widthcnt] = IMG_MatchANDC(m, weight);
                        }
                        else if(subfun==1)//XNORcount
                        {
                            result[Widthcnt] = IMG_MatchXNORC(m, weight);
                        }
                        else
                        {
                            return (-1);
                        }

                    }

                    Widthcnt++;
                }

                if(Heightcnt == 8) Write1LineDst(Heightcnt-4, result);//output 1 line

                Heightcnt++;
            }
        }else{
#endif 
            while(Heightcnt < ylng+4)
            {
                if(Heightcnt < ylng)
                {
                    Read1LineSrc0(Heightcnt, soura_id); 
            
                    Widthcnt = 0;
                    while(Widthcnt < xlng)
                    {
                        temp = (short)(((ReadLM0(Widthcnt)<< 1)&0x01FF) | (soura_id[Widthcnt]&0x01));
                        WriteLM0(Widthcnt,&temp,1); //Write LM0 for 1bit from Src0
                        Widthcnt++;
                    }
                    
                }
                Widthcnt = 0;
                
                while(Widthcnt < xlng)
                {
                    
                    
                    if(Heightcnt < 8) //edgerange process (highline)
                    {
                        
                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP
                    }
                    else if(Heightcnt >= ylng) //edgerange process (lowline)
                    {
                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>(3-(Heightcnt-ylng)))&0x01)?0xFFFF:0);//NOOP
                    }
    //              else if(Heightcnt > 3) /* 01-00-01 */
                    else
                    {
                    // middle line
                        if(Widthcnt == 7)
                        {
                            m[10] = ReadLM0(0);
                            m[11] = ReadLM0(1);
                            m[12] = ReadLM0(2);
                            m[13] = ReadLM0(3);
                            m[ 0] = ReadLM0(4);
                            m[ 1] = ReadLM0(5);
                            m[ 2] = ReadLM0(6);
                            m[14] = ReadLM0(7);
                            m[ 3] = ReadLM0(8);
                            m[ 4] = ReadLM0(9);
                            m[ 5] = ReadLM0(10);
                            m[15] = ReadLM0(11);
                            m[ 6] = ReadLM0(12);
                            m[ 7] = ReadLM0(13);
                            m[ 8] = ReadLM0(14);


                            if(edge==3) result[Widthcnt] = 0;//output"0"
                            else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP

                        }
                        else if(Widthcnt > xlng-8 || Widthcnt < 7)//edgeline process (right or left)
                        {
                            if(edge==3) result[Widthcnt] = 0;//output"0"
                            else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP
                        }
                        else //cutoff 9*16 kernel
                        {
                            m[9]=m[10];  m[10]=m[11];  m[11]=m[12];  m[12]=m[13];
                            m[13]=m[0];  m[0]=m[1];    m[1]=m[2];    m[2]=m[14];
                            m[14]=m[3];  m[3]=m[4];    m[4]=m[5];    m[5]=m[15];
                            m[15]=m[6];  m[6]=m[7];    m[7]=m[8];    m[8]=ReadLM0(Widthcnt+7);

                            if(subfun==0)//ANDcount
                            {
                                result[Widthcnt] = IMG_MatchANDC(m, weight);
                            }
                            else if(subfun==1)//XNORcount
                            {
                                result[Widthcnt] = IMG_MatchXNORC(m, weight);
                            }
                            else
                            {
                                return (-1);
                            }

                        }
                    }
                    Widthcnt++;
                }

                if(Heightcnt > 3)
                {
        #ifdef DEBUG_OUTPUT
                    DebugOutputGamen(result,1,xlng);
        #endif
                    Write1LineDst(Heightcnt-4, result);//output 1 line
                }
                Heightcnt++;
            }
#if USE_PIPE_FUNC
        }
#endif 
    }

//9*9 kernel********************************************************************
    else 
    {
        //Read COEFF(9�~9)
        weight[ 2]=(short)(  IMPREG_COEFF02_READ() & 0x000001ff        );//weight2
        weight[ 3]=(short)(((IMPREG_COEFF35_READ())>>18) & 0x000001ff  );//weight3
        weight[ 4]=(short)(((IMPREG_COEFF35_READ())>> 9) & 0x000001ff  );//weight4
        weight[ 5]=(short)(  IMPREG_COEFF35_READ() & 0x000001ff        );//weight5
        weight[ 6]=(short)(((IMPREG_COEFF68_READ())>>18) & 0x000001ff  );//weight6
        weight[ 7]=(short)(((IMPREG_COEFF68_READ())>> 9) & 0x000001ff  );//weight7
        weight[ 8]=(short)(  IMPREG_COEFF68_READ() & 0x000001ff        );//weight8
        weight[14]=(short)(  IMPREG_COEFF1214_READ() & 0x000001ff      );//weight14
        weight[15]=(short)(((IMPREG_COEFF15_READ())>>18) & 0x000001ff);//weight15
        //Not use weight[0,1][9-13]
        
        Heightcnt=0;
#if USE_PIPE_FUNC
        if(McomFlg){
            while(Heightcnt < 9)
            {
                Read1LineLM256A(8 - Heightcnt, soura_id);   

                Widthcnt = 0;
                while(Widthcnt < xlng)
                {
                    temp = (short)(((ReadLM0(Widthcnt)<< 1)&0x01FF) | (soura_id[Widthcnt]&0x01));
                    WriteLM0(Widthcnt,&temp,1); //Write LM0 for 1bit from Src0
                    Widthcnt++;
                }

                Widthcnt = 0;
                while(Widthcnt < xlng)
                {
                    if(Widthcnt == 3)
                    {
                        m[14] = ReadLM0(0);
                        m[ 3] = ReadLM0(1);
                        m[ 4] = ReadLM0(2);
                        m[ 5] = ReadLM0(3);
                        m[15] = ReadLM0(4);
                        m[ 6] = ReadLM0(5);
                        m[ 7] = ReadLM0(6);
                        m[ 8] = ReadLM0(7);

                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP

                    }
                    else if(Widthcnt > xlng-5 || Widthcnt < 3)//edgerange process(right or left)
                    {
                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP
                    }
                    else //cutoff 9*9 kernel
                    {
                        m[2]=m[14];   m[14]=m[3];   
                        m[3]=m[ 4];   m[ 4]=m[5];
                        m[5]=m[15];   m[15]=m[6];   
                        m[6]=m[ 7];   m[ 7]=m[8];    m[8]=ReadLM0(Widthcnt+4);
                        

                        if(subfun==0)//ANDcount
                        {
                            result[Widthcnt] = IMG_MatchANDC(m, weight);
                        }
                        else if(subfun==1)//XNORcount
                        {
                            result[Widthcnt] = IMG_MatchXNORC(m, weight);
                        }
                        else
                        {
                            return (-1);
                        }

                    }
                    Widthcnt++;
                }
                if(Heightcnt == 8) Write1LineDst(Heightcnt-4, result);//output 1 line

                Heightcnt++;
            }
        }else{
#endif 
            while(Heightcnt < ylng+4)
            {
                if(Heightcnt < ylng)
                {
                    Read1LineSrc0(Heightcnt, soura_id); 
            
                    Widthcnt = 0;
                    while(Widthcnt < xlng)
                    {
                        temp = (short)(((ReadLM0(Widthcnt)<< 1)&0x01FF) | (soura_id[Widthcnt]&0x01));
                        WriteLM0(Widthcnt,&temp,1); //Write LM0 for 1bit from Src0
                        Widthcnt++;
                    }
                    
                }
                Widthcnt = 0;
                
                while(Widthcnt < xlng)
                {               
                    if(Heightcnt < 8)//edgerange process (highline)
                    {

                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP
                    }
                    else if(Heightcnt >= ylng)//edgerange process (lowline)
                    {
                        if(edge==3) result[Widthcnt] = 0;//output"0"
                        else result[Widthcnt] = (((ReadLM0(Widthcnt)>>(3-(Heightcnt-ylng)))&0x01)?0xFFFF:0);//NOOP
                    }
    //              else if(Heightcnt > 3) /* 01-00-01 */
                    else
                    {

                    //middle line
                        if(Widthcnt == 3)
                        {
                            m[14] = ReadLM0(0);
                            m[ 3] = ReadLM0(1);
                            m[ 4] = ReadLM0(2);
                            m[ 5] = ReadLM0(3);
                            m[15] = ReadLM0(4);
                            m[ 6] = ReadLM0(5);
                            m[ 7] = ReadLM0(6);
                            m[ 8] = ReadLM0(7);

                            if(edge==3) result[Widthcnt] = 0;//output"0"
                            else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP

                        }
                        else if(Widthcnt > xlng-5 || Widthcnt < 3)//edgerange process(right or left)
                        {
                            if(edge==3) result[Widthcnt] = 0;//output"0"
                            else result[Widthcnt] = (((ReadLM0(Widthcnt)>>4 )&0x01)?0xFFFF:0);//NOOP
                        }
                        else //cutoff 9*9 kernel
                        {
                            m[2]=m[14];   m[14]=m[3];   
                            m[3]=m[ 4];   m[ 4]=m[5];
                            m[5]=m[15];   m[15]=m[6];   
                            m[6]=m[ 7];   m[ 7]=m[8];    m[8]=ReadLM0(Widthcnt+4);
                            

                            if(subfun==0)//ANDcount
                            {
                                result[Widthcnt] = IMG_MatchANDC(m, weight);
                            }
                            else if(subfun==1)//XNORcount
                            {
                                result[Widthcnt] = IMG_MatchXNORC(m, weight);
                            }
                            else
                            {
                                return (-1);
                            }

                        }
                    }
                    Widthcnt++;
                }

                if(Heightcnt > 3)
                {
        #ifdef DEBUG_OUTPUT
                    DebugOutputGamen(result,1,xlng);
        #endif
                    Write1LineDst(Heightcnt-4, result); //output 1 line
                }
                Heightcnt++;
            }
#if USE_PIPE_FUNC
        }
#endif 
    }

    return 0;

}

/******************************************************************************/
/* IMG_MatchANDC (AND count / subfun 0)                                       */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26  T.Kumabe                                            */
/* 01-00-01 : 2007/02/23   S.Ishikawa  check masked bit(!=0 -> ==0)           */
/* 01-02-00 : 2007/07/20   S.Ishikawa                                         */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_MatchANDC(short f[], short g[])
{
//  short temp;
//  long result;
    int64 temp, result;
    int i,j; //j:shift count

    result = 0;
    j=0;
        
    for(i=0; i<16; i++)
    {
        if(((IMPREG_KNLMSK_READ())>>j & 0x01)== 0) //check masked bit
        {
            temp = ((f[i] & g[i]) & 0x01ff);

            //count of bit"1"
            result += (temp & 0x01) + ((temp & 0x02)>>1) + ((temp & 0x04)>>2) + ((temp & 0x08)>>3)+
            ((temp & 0x10)>>4) + ((temp & 0x20)>>5) + ((temp & 0x40)>>6) + ((temp & 0x80)>>7)+ 
            ((temp & 0x100)>>8);
        }

        j++;
        if(j==9) j=16; //move shift position
    }
    return result;  
}



/******************************************************************************/
/* IMG_MatchXNORC (XNOR count / subfun 1)                                     */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2007/01/26   T.Kumabe                                           */
/* 01-00-01 : 2007/02/23   S.Ishikawa  check masked bit(!=0 -> ==0)           */
/* 01-02-00 : 2007/07/20   S.Ishikawa                                         */
/* 01-03-00 : 2007/07/31 S.Ishikawa                                           */
/*                       result long->int64                                   */
/******************************************************************************/
static int64 IMG_MatchXNORC(short f[], short g[])
{
//  short temp;
//  long result;
    int64 temp, result;
    int i,j; //j:shift count
    
    result=0;
    j=0;

    for(i=0; i<16; i++)
    {   
        if(((IMPREG_KNLMSK_READ())>>j & 0x01)== 0)//check masked bit
        {
            temp = ((~(f[i] ^ g[i])) & 0x01ff);
    
            //count of bit"1"
            result += (temp & 0x01) + ((temp & 0x02)>>1) + ((temp & 0x04)>>2) + ((temp & 0x08)>>3)+
            ((temp & 0x10)>>4) + ((temp & 0x20)>>5) + ((temp & 0x40)>>6) + ((temp & 0x80)>>7)+
            ((temp & 0x100)>>8);
        }
        
        j++;
        if(j==9) j=16; //move shift position
    }
    return result;  
}
