/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_micro_dec.h                                 */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/

#ifndef __LEGACY_MICRO_DEC_H__
#define __LEGACY_MICRO_DEC_H__

/* return OP code */
int op(int ins);

/* return 2nd OP code */
int op2(int ins);

/* return number of Destination Register */
int dest(int ins);

/* return number of Source Register */
int source(int ins);

/* return immediate value */
int imm(int ins);

/* return displacement value */
int disp(int ins);

int disp_pc(int ins);

/* return op of SYNC */
int sync(int ins);

/* return IP bit */
int ip(int ins);

/* return AP bit */
int ap(int ins);

/* return push/pop */
int pop(int ins);

/* return stack number */
int stack_num_pop(int ins);
int stack_num_push(int ins);

/* return FLIP bit */
int flip(int ins);
int flip_lm(int ins);
int flip_mc(int ins);
/* return MVB bit */
int mvb_lm(int ins);
int mvb_r(int ins);
int mvb_sp(int ins);
int mvb_dir(int ins);

int op(int ins) 
{
  return (ins >> 12);
}

int op2(int ins)
{
  return (ins & 0xf);
}

int dest(int ins)
{
  return ((ins & 0xf00) >> 8);
}

int source(int ins)
{
  return ((ins & 0xf0) >> 4);
}

int imm(int ins)
{
  return (ins & 0xff);
/*
  if((ins & 0x80) != 0)
    return -(ins & 0x7f);
  else
    return (ins & 0x7f);
*/
}

int disp(int ins)
{
  return ((ins & 0xff0) >> 4);
/*
  if((ins & 0x800) != 0)
    return -((ins & 0x7f0) >> 4);
  else
    return ((ins & 0xff0) >> 4);
*/
}

int disp_pc(int ins)
{
  if((ins & 0x800) != 0)
    return ((ins & 0xff0) >> 4) | 0xffffff00;
  else
    return ((ins & 0xff0) >> 4);
}

int disp_r(int ins)
{
  return ((ins & 0xf0) >> 4);
}

int sync(int ins)
{
  return ((ins & 0x800) >> 10);
}

int ip(int ins)
{
  return ((ins &0x2) >> 1);
}

int ap(int ins)
{
  return (ins & 0x1);
}

int pop(int ins)
{
  return (ins & 0x1);
}

int stack_num_pop(int ins)
{
  return ((ins & 0xf0) >> 4);
}

int stack_num_push(int ins)
{
  return ((ins & 0xf00) >> 8);
}

int stack_start_pop(int ins)
{
  return ((ins & 0xf00) >> 8);
}

int stack_end_pop(int ins)
{
  return ((ins & 0xf0) >> 4);
}

int stack_start_push(int ins)
{
  return ((ins & 0xf00) >> 8);
}

int stack_end_push(int ins)
{
  return ((ins & 0xf0) >> 4);
}
int flip(int ins)
{
  return (ins & 0x3);
}
int flip_lm(int ins)
{
  return ((ins & 0x200) >> 9);
}
int flip_mc(int ins)
{
  return ((ins & 0x100) >> 8);
}
int mvb_lm(int ins)
{
  return ((ins & 0x800) >> 11);
}
int mvb_r(int ins)
{
  return ((ins & 0x7f0) >> 4);
}
int mvb_sp(int ins)
{
  return ((ins & 0x8) >> 3);
}
int mvb_dir(int ins)
{
  return ((ins & 0x4) >> 2);
}

#endif /* !__LEGACY_MICRO_DEC_H__ */
