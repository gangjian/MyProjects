/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_micro_op.h                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/

#ifndef __LEGACY_MICRO_OP_H__
#define __LEGACY_MICRO_OP_H__

/* R type Instruction 1 */
#define OP_R 0x1

#define OP2_MV 0x0
#define OP2_ADD 0x1
#define OP2_ADDC 0x2
#define OP2_SUB 0x5
#define OP2_SUBC 0x6
#define OP2_NEG 0x7
#define OP2_MULT16 0x8

/* R type Instructions 2 */
#define OP_R2 0x2

#define OP2_SHL_L 0x0
#define OP2_SHR_L 0x1
#define OP2_SHR_A 0x2
#define OP2_CMP 0x8
#define OP2_CAT 0xC

/* R type instructions with immdediate value */
#define OP_MI 0x8
#define OP_ADDI 0x9
#define OP_CMPI 0xA
#define OP_SUBI 0xD

/* I type Instructions */
#define OP_I 0x3

#define OP2_ST 0x0
#define OP2_ST_PC 0x1
#define OP2_LD 0x4
#define OP2_LD_PC 0x5
#define OP2_CP 0x8
#define OP2_CP_PC 0x9

/* I type instructions with immediate value */
#define OP_STI 0xB

/* J type instructions */
#define OP_J 0x4

#define OP2_BT 0x0
#define OP2_BT_PC 0x4
#define OP2_BT_R 0x8
#define OP2_BF 0x1
#define OP2_BF_PC 0x5
#define OP2_BF_R 0x9
#define OP2_JMP 0x2
#define OP2_JMP_PC 0x6
#define OP2_JMP_R 0xA
#define OP2_GOSUB 0x3
#define OP2_GOSUB_PC 0x7
#define OP2_GOSUB_R 0xb
#define OP2_RTS 0xf

/* other instructions */

/* EXE/SNC */
#define OP_SYNC 0x5

/* PUSH/POP*/
#define OP_STACK 0x6

/* No Operation */
#define OP_NOP 0x7

#define OPNOP_NOP 0x0
#define OPNOP_INT 0x1
#define OPNOP_FLIP 0x2
#define OPNOP_MVB 0x3

/* micro code end */
#define OP_SLEEP 0x0

#define MCOM_R0 0
#define MCOM_R1 1
#define MCOM_R2 2
#define MCOM_R3 3
#define MCOM_R4 4
#define MCOM_R5 5
#define MCOM_R6 6
#define MCOM_R7 7
#define MCOM_LM_RD_START_A 8
#define MCOM_LM_RD_START_B 9
#define MCOM_LM_RD_TOP 10
#define MCOM_LM_RD_BOTTOM 11
#define MCOM_LM_INPUT_WT_PTR_A 12
#define MCOM_LM_INPUT_WT_PTR_B 13
#define MCOM_LM_RESULT_WT_PTR 14
#define MCOM_SP 15

#define MCOM_IPREG_S 0x00001000
#define MCOM_IPREG_E 0x00001FFF

#endif /* !__LEGACY_MICRO_OP_H__ */
