/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_sim.h                                       */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/

#ifndef __LEGACY_SIM_H__
#define __LEGACY_SIM_H__

#include "legacy_sim_regs.h"

// H.Shiota, Changed to little
// #define ENDIAN 0 /* 0:big, 1:little */
#define ENDIAN 1 /* 0:big, 1:little */

#define LITTLE 1 /* 0:big, 1:little */

#define OUTFILE 1 /* 0:ascii, 1:raw */

#define CONVOLUTION_DEBUG 0 /* 0:normal, 1:output debug file *///cho

#define DEB_MATRIX_MODE 0 /* 0:normal, 1:output debug file */
#define MTX_JMIN 0 /* output area(j loop min) */
#define MTX_JMAX 0 /* output area(j loop max) */

#define SAD_DEBUG 0 /* 0:normal, 1:output debug file */

#define PIPE_HO_DEBUG 0 /* Harris Operator debug 0:off, 1:on */
#define PIPE_LOGLEVEL SL_L6

#define USE_PIPE_FUNC 0 /* 0:not used pipe,  1:use pipe */
#define SKIP_FOR_COVERAGE  1 /* 1:skip,  0:no skip */

#ifndef IMPSIM_INTEGRATED
// For UT environment
#endif

#define IMP_X4_V2H  1

#define CM0_SIZE 4096 * 4
#define HM_SIZE 2048

#define CM1_SIZE 1024 * 4
#define THRM0_SIZE 4096
#define THRM1_SIZE 512
#define FIFO_SIZE 256
#define LM256_SIZE 512

#define LM_NUM 512

#define LINE_NUM 16

#define XSIZE 8192
#define YSIZE 4096

#define XPIX (8192+4)
#define YPIX (4096+4)

#define LINE_SIZE XPIX

#define SA_SIZE XPIX*YPIX
#define DT_SIZE XPIX*YPIX

/* Memory Size */
#define REG_MEM_SIZE    0x1d10  //Max address of register (MCSTALL:0x1d0c)
#define CM0_MEM_SIZE    CM0_SIZE
#define CM1_MEM_SIZE    CM1_SIZE
#define HM_MEM_SIZE     HM_SIZE*4 // HP has 2 set of 16bit * HM_SIZE
#define THRM0_MEM_SIZE  THRM0_SIZE*4 // H.Shiota, multiplied by 4
#define THRM1_MEM_SIZE  THRM1_SIZE*4 // H.Shiota, multiplied by 4
#define FIFO_MEM_SIZE   FIFO_SIZE*4
#define DEST_LINE_PIX   XPIX
#define DEST_LINE_PIX_L XPIX/2
#define DEST_MEM_SIZE   DT_SIZE*2
#define DT_MEM_SIZE     DT_SIZE*2
#define FFT_LM_SIZE     512  // a part of LM256_MEM_SIZE
#define LM256_MEM_SIZE  LM256_SIZE*2

#define LINE_MEM_SIZE   LINE_SIZE*2


#define DEST_MEM_POST_END1 0x05
#define DEST_MEM_POST_END2 0xA5
#define DEST_MEM_POST_END3 0xA0
#define DEST_MEM_POST_END4 0x34

#if 0
/* for fseek (setmem) */
#define IMGADRSIZE 54+r*3


#define CM0SIZE 12035+r*257
#define HMSIZE 18306+r*129

#define CM1SIZE 3011+r*65
#define THRM0SIZE 12037+r*257
#define THRM1SIZE 1509+r*33

//#define LMSIZE (1270+r*17)
//#define LMSIZE (15174+r*193)
#define LMSIZE (2534+r*33)
#define FIFOSIZE (2292+r*17)
#endif

/* imgrun Paramater check */
#define IMGRUNCHECKREG "APCMD"
#define IMGRUNCHECKSABIT 0x00080000
#define IMGRUNCHECKSBBIT 0x00040000
#define IMGRUNCHECKDSBIT 0x00010000


#define IMGACCESS 16 /* 16 data=128bit */

typedef struct {
 unsigned long stadr;
 short ImgData[IMGACCESS];
} IMG_DATA;

typedef struct {
 unsigned long stadr;
 long ImgData[IMGACCESS];
} IMG_DATA_L;

/* MemAccessImg */
#define ACCESSIMGCKREG "CNF"
#define ACCESSIMGFORM1 0x01000000
#define ACCESSIMGFORM2 0x02000000

#define APCMDEX 0x80000000


/* imgrun use */
#define	MAX_CHAR 8
#define	KIDO_MAX 255

/* for MCOM */
#define MCOM_MAX_FILE_NAME 100
#define MCOM_MAX_MEM_ADDR 0x0fff
#define MCOM_MAX_LINE_LENGTH 100
#define MCOM_NUM_REGS 16

#define MCOM_NUM_REGSETS 2

#define LABELINGMAX 0x0FFF

/* DL(MOV) */
#define DL_IPREG_HM_S 0x00002000
// H.Shiota #define DL_IPREG_HM_E 0x00003FFF
#define DL_IPREG_HM_E (DL_IPREG_HM_S + HM_MEM_SIZE)
#define DL_IPREG_CMA_S 0x00008000
#define DL_IPREG_CMA_E 0x0000BFFF
#define DL_IPREG_CMB_S 0x0000C000
#define DL_IPREG_CMB_E 0x0000FFFF
#define DL_IPREG_THTDATA0_S 0x00010000
#define DL_IPREG_THTDATA0_E 0x00013FFF
#define DL_IPREG_THTDATA1_S 0x00014000
#define DL_IPREG_THTDATA1_E 0x000147FF

// address map for IMP 4 ch
#define IMPX4_LEGACY_CH0_S 0xFF900000
#define IMPX4_LEGACY_CH0_E 0xFF91FFFF
#define IMPX4_LEGACY_CH1_S 0xFF920000
#define IMPX4_LEGACY_CH1_E 0xFF93FFFF
#define IMPX4_LEGACY_CH2_S 0xFF940000
#define IMPX4_LEGACY_CH2_E 0xFF95FFFF
#define IMPX4_LEGACY_CH3_S 0xFF960000
#define IMPX4_LEGACY_CH3_E 0xFF97FFFF

// data format
#define  PXL8BPP     1
#define  PXL16BPP    2
#define  PXL32BPP    3
#define  PXL8BPPx2   4
#define  PXL1BPP     5
#define  PXL11BPP    6
#define  PXL12BPP    7
#define  PXLS8BPP    8
#define  PXLU8BPP    9
#define  PXLCOLDIFF  10
#define  PXL2CHI     11
#define  PXLRESERVED 12

/*64bit int*/
#ifdef WIN32
/* for Windows */
// H.Shiota, TBD. Need to clean up the code.
// __int64 cannot be used under MINGW.
// typedef __int64 int64;
typedef long long int64;
typedef unsigned long long uint64;
#else
/* for 64bit Linux */
typedef long long int64;
typedef unsigned long long uint64;
#endif

// bool is typedefed in stdbool.h in C99
#ifndef __GNUC__
typedef int bool;
#endif
#define FALSE 0
#define TRUE 1

#define Get8b(x) (((x)>>7)&0x01)
#define CELL 16	/* 4x4 or 1x16 kernel */
#define MIN(a,b) (a<b?a:b)
#define MAX(a,b) (a>b?a:b)

#define GET_CNSTA(consta) {\
	consta = (short)((IMPREG_CNST_READ()>>16)&0x000000ff);\
	if(IMPREG_CNST_READ()&0x01000000)	consta |= 0xff00;\
	}
#define GET_CNSTB(constb) {\
	constb = (short)(IMPREG_CNST_READ()&0x000000ff);\
	if(IMPREG_CNST_READ()&0x00000100)	constb |= 0xff00;\
	}
#define GET_CNSTA16(consta) {\
	consta = (short)((IMPREG_CNST_READ()>>16)&0x0000ffff);\
	}
#define GET_CNSTB16(constb) {\
	constb = (short)(IMPREG_CNST_READ()&0x0000ffff);\
	}



/******************************************************************************/
/*                         Prototype declaration                              */
/******************************************************************************/

/* ------------------------legacy_memaccess.c ------------------------------- */
void ReadHM(int ch, int adr, unsigned long *data);
void WriteHM(int ch, int adr, unsigned long data);
void ReadCM0(int ch, int adr, unsigned long *data);
void WriteCM0(int ch, int adr, unsigned long data);
void ReadCM1(int ch, int adr, unsigned long *data);
void WriteCM1(int ch, int adr, unsigned long data);
void ReadTHTDATA0(int ch, int adr, unsigned long *data);
void WriteTHTDATA0(int ch, int adr, unsigned long data);
void ReadTHTDATA1(int ch, int adr, unsigned long *data);
void WriteTHTDATA1(int ch, int adr, unsigned long data);
int GetImgAccessType(int *type);
short ReadLM0(int adr);
void WriteLM0(int adr, short *data, int size);
short ReadLM1(int adr);
void WriteLM1(int adr, short *data, int size);
short ReadLM2(int adr);
void WriteLM2(int adr, short *data, int size);
short ReadLM3(int adr);
void WriteLM3(int adr, short *data, int size);
short ReadLM4(int adr);
void WriteLM4(int adr, short *data, int size);
short ReadLM5(int adr);
void WriteLM5(int adr, short *data, int size);
short ReadLM256A(int line, int adr);
short ReadLM256B(int adr);
void WriteLM256(int lmno, int adr, short *data, int size);
void Read1LineLM256A(int Height, short *data);
void Read1LineLM256B(short *data);
void Read1LineSrc0(int Height, short *data);
void Read1LineSrc1(int Height, short *data);
void Read1LineSrcL0(int Height, long *data);
void Read1LineSrcL1(int Height, long *data);
void Read1LineDest1(int Height, short *data);
void Read1LineDest2(int Height, short *data);
void IPtoAP(void);
void CheckEndOfIntermediateBuffer();
void ReadBaseAdr(unsigned char *adr, unsigned long *data);
void WriteBaseAdr(unsigned char *adr, unsigned long data);

void Write1LineDst(int Height, int64 *data);
void Write1LineDest2(int Height, int64 *data);

/* ------------------------legacy_hp.c -------------------------------------- */
void HPAccumulate();

/* ------------------------legacy_kick.c ------------------------------------ */
void kick_ap(void);
void kick_ifid_with_dl(void);
void kick_software_reset(void);

/* ------------------------IMG2_0100.c -------------------------------------- */
int pffta_wadr(/*int fftctl, */int pfftasel1, int pfftasel2, int pfftamsk, int in_adr);
int pfftb_wadr(/*int fftctl, */int pfftbsel1, int pfftbsel2, int pfftbmsk, int in_adr);

/* ------------------------legacy_sim_error.c ------------------------------- */
void Legacy_assert_error(void);
void Legacy_debug_print(void);
void Legacy_reg_dump(void);
void Legacy_FFT_reg_dump(void);
void Distributer_reg_dump(void);
void Output_src_dst(void);
void Legacy_MCOMreg_dump(void);

#if PIPE_HO_DEBUG
void PIPE_HO_debug_init(void);
void PIPE_HO_collect_linebuf(void);
void PIPE_HO_save_file(void);
#endif

#ifndef DEBUG_OUTPUT
void DebugOutputGamen(int64 *result,int mode,int width);
void ResetDebugGamen();
#endif // DEBUG_OUTPUT

int OutputImageFile(char* filename,             // output file name
					unsigned char *addr,        // output image start pointer
					unsigned long src_xlng,     // memory width (byte)
					unsigned long xoffset,      // x offset (byte)
					unsigned long yoffset,      // y offset (line)
					unsigned long xlng,         // clip image  width  (byte)
					unsigned long ylng,         // clip image  height (line)
					unsigned char bpp,          // 8:8bpp 16:16bpp 32:32bpp
 					unsigned char cull,         // unsigned char cull,
					int type);                  // file format  1:p1�` 6:p6

/* ------------------------legacy_exec.c ------------------------------------ */
void Convert8bppParallel();
void AllocateLineMemory();
void PIPECommonProc();

/* ------------------------IMG_****.c---------------------------------------- */
/* ------------------------IMG2_****.c--------------------------------------- */
int IMG_0000();
int IMG_0001();
int IMG_0010();
int IMG_0011();
int IMG_0100();
int IMG_0101();
int IMG_0110();
int IMG_0111();
int IMG_1000();
int IMG_1001();
int IMG_1010();
int IMG_1011();
int IMG_1100();
int IMG_1101();
int IMG_1110();
int IMG_test();
int IMG2_0001();
int IMG2_0010();
int IMG2_0011();
int IMG2_0100();
int IMG2_0101();
int IMG2_0110();
int IMG2_0111();


/******************************************************************************/
/*                         Global variable declaration                        */
/******************************************************************************/

/* ------------------------legacy_regtable.c -------------------------------- */
extern unsigned long SASP;
extern unsigned long SBSP;
extern unsigned long DSP;
extern unsigned long IPFORM_BACKUP;
extern unsigned long IMPREG[IMP_CH_MAX][REGSETS_MAX][REGMAX];
extern const struct REGTBL regtable[REGMAX];

/* ------------------------legacy_memaccess.c ------------------------------- */
extern unsigned char *pLM256[LM_NUM];

/* ------------------------legacy_hp.c -------------------------------------- */
extern int g_Widthcnt, g_HPadr;

/* ------------------------legacy_exec.c ------------------------------------ */
extern unsigned char *pSrc0, *pSrc1, *pDst;
extern unsigned int UseImg[3];
extern int MCOM_InputLine_SA, MCOM_InputLine_SB, MCOM_OutputLine_Dst;
extern int MCOM_regselectSET, MCOM_regselectEXC;
extern int McomFlg;
extern int MCOM_reg[MCOM_NUM_REGSETS][MCOM_NUM_REGS];
extern int mem[IMP_CH_MAX][MCOM_MAX_MEM_ADDR+1]; // "uint32_t" is prefered, but original declaration is "int".

/* ------------------------legacy_adpt.c ------------------------------------ */
extern unsigned char  	*pCM0[IMP_CH_MAX], *pCM1[IMP_CH_MAX], *pHM[IMP_CH_MAX], *pTHRM0[IMP_CH_MAX], *pTHRM1[IMP_CH_MAX], *pFIFO;
extern unsigned short 	*pDest1, *pDest2;
extern unsigned long 	*plDest1;
extern unsigned char  	*pDR;

extern unsigned short 	*pLINE0[LINE_NUM], *pLINE1[LINE_NUM], *pLINE2[LINE_NUM], *pLINE3[LINE_NUM], *pLINE4[LINE_NUM], *pLINE5[LINE_NUM], *pLINE6[LINE_NUM], *pLINE7[LINE_NUM], *pLINE8[LINE_NUM];
extern char 			*pcLM0, *pcLM1, *pcLM2, *pcLM3, *pcLM4, *pcLM5, *pcLM6, *pcLM7, *pcLM8;
extern short 			*psLM0, *psLM1, *psLM2, *psLM3, *psLM4, *psLM5, *psLM6, *psLM7, *psLM8;
extern int 				*plLM0, *plLM1, *plLM2, *plLM3, *plLM4, *plLM5, *plLM6, *plLM7, *plLM8;
extern unsigned char 	*pucLM0, *pucLM1, *pucLM2, *pucLM3, *pucLM4, *pucLM5, *pucLM6, *pucLM7, *pucLM8;
extern unsigned short 	*pusLM0, *pusLM1, *pusLM2, *pusLM3, *pusLM4, *pusLM5, *pusLM6, *pusLM7, *pusLM8;
extern unsigned int 	*pulLM0, *pulLM1, *pulLM2, *pulLM3, *pulLM4, *pulLM5, *pulLM6, *pulLM7, *pulLM8;

/* ------------------------legacy_sim_error.c ------------------------------- */
#if PIPE_HO_DEBUG
extern unsigned char *pDebug, *localpDebug[20];
extern unsigned long x_pDebug, y_pDebug, num_pDebug, type_pDebug;
#endif


#endif /* !__LEGACY_SIM_H__ */
