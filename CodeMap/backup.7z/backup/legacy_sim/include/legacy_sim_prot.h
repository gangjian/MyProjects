/* ****************************************************************************
**                               Renesas                                     **
**                                                                           **
*************************  COPYRIGHT INFORMATION  *****************************
**                                                                           **
** This program contains proprietary information that is a trade secret of   **
** Renesas and also is protected as an unpublished work under                **
** applicable Copyright laws. Recipient is to retain this program in         **
** confidence and is not permitted to use or make copies thereof other than  **
** as permitted in a written agreement with Renesas.                         **
**                                                                           **
** Copyright (C) 2014      Renesas Electronics Corp.                         **
** All rights reserved.                                                      **
**                                                                           **
***************************************************************************** */

/******************************************************************************/
/*                         legacy_sim_prot.h                                  */
/*----------------------------------------------------------------------------*/
/* 01-00-00 : 2014/08/01   T.Sato                                             */
/*                         New  (Todo Review)                                 */
/******************************************************************************/

#ifndef __LEGACY_SIM_PROT_H__
#define __LEGACY_SIM_PROT_H__

/* API's invoked by upper software like implib */
int legacy_sim_init(void);
int legacy_sim_close(void);
uint32_t legacy_sim_read_reg(uint32_t);
void legacy_sim_write_reg(uint32_t, uint32_t);
int legacy_sim_wait_imp(void);
uint32_t legacy_sim_get_ex_status(void);

/* Internal functions used in legacy_sim_adpt */
int write_reg(int, uint32_t, uint32_t);
int read_reg(int, uint32_t, uint32_t *);
bool is_imp_working(void);
const char *reg_offset_to_name(uint32_t);
void dump_imp_reg(void);
void dump_hp_mem(void);
void dump_pipe_mem(void);
void dump_pipe_regs(int);
void dump_lm256(int, int);

int APDMACExec(void);
int APExec(void);
int HPExec(int);
int PIPEExec(void);
    
/* Exported from original simulator */
int McomGetRegAdr(int, int **);
int IPExec(void);
void illegal_ins(int, int);
    
/* Bit assignment for each register. */
#define _IFCTL_IF_EXEC 0x00000001
#define _IFCTL_IF_STOP 0x80000000
#define _APCMD_EX 0x80000000
#define _APCMD_IM_HM 0x20000000
#define _APIHSP_IMHM_ADD 0x00007ffc
#define _HMPTR_MODE 0x00008000
#define _HMPTR_HMADR 0x000007ff
#define _HMDATA_HM_UD 0xffff0000
#define _HMDATA_HM_UL 0x0000ffff
#define _HPCTL_HPEN 0x00008000
#define _CNF_RST 0x80000000
#define _STS_IP  0x00000001
#define _STS_HP  0x00000002
#define _STS_MIS_MAT 0x00000008
#define _STS_FIFO 0x00000010
#define _STS_MATRIX_OVF 0x00000080
#define _MCINIT_MC_EN 0x80000000
#define _MCINIT_MC_ENDIAN 0x40000000
#define _MCINIT_PCINIT 0x000000ff

/* Misc */
#define DL_IPREG_PIPEM_S 0x00001000
#define DL_IPREG_PIPEM_E 0x00001bff

/* Commands for HPExec() */
#define HPEXEC_HM_RESET 0x01
#define HPEXEC_HPEN 0x02

#endif /* !__LEGACY_SIM_PROT_H__ */
